'use strict';
/** Composition root only. Game rules live in js/, content lives in js/data/. */
(() => {
 const loaded=Abyss.Save.load();
 Abyss.UI.bind(Abyss.Engine);Abyss.I18n.bind();
 Abyss.StoryPlayer.bind();Abyss.NarrativeUI.bind();Abyss.JackUI.bind();Abyss.WastelandUI.bind();Abyss.ExpansionUI.bind();Abyss.WallpaperUI.bind();Abyss.Wallpapers.bind();
 Abyss.ContainmentUI.bind();Abyss.SceneCompositionUI.bind();Abyss.HuntUI.bind();Abyss.DrawUI.bind();Abyss.ClimateAudio.bind();Abyss.ModeUI.bind();Abyss.ColorUI.bind();
 Abyss.Wardrobe.bind(Abyss.Engine);
 Abyss.ProgressionUI.bind();
 Abyss.Engine.subscribe(Abyss.UI.render);
 Abyss.RoadUI.bind();Abyss.HappyClubUI.bind();Abyss.HappyClubWheelUI.bind();Abyss.StoryUI.bind();Abyss.EconomyUI.bind();
 Abyss.Engine.init(loaded);
 if(!Abyss.Save.warning())Abyss.Save.write(Abyss.Engine.snapshot());
 Abyss.LabRoomUI.bind();Abyss.LabOperationsUI.bind();Abyss.GardenUI.bind();Abyss.HomesteadUI.bind();Abyss.WastelandNews.bind();Abyss.UndergroundUI.bind();Abyss.Navigation.bind();Abyss.ClimateUI.bind();
 Abyss.UI.render(Abyss.Engine.snapshot());
 if(Abyss.Save.warning())Abyss.UI.toast(Abyss.Save.warning());
 Abyss.UI.showPending();
 if(Abyss.Save.needsMenu())Abyss.ModeUI.open('menu');
})();

