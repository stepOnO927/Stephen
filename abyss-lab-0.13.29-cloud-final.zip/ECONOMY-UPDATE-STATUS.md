# 生存的代价：本地开发进度（2026-10-05）

本次为开发中的更新，尚未替换 GitHub Pages 公开版本。不能视为附件全部完成。

## 已接入
- 独立 underground 模块：数据、存档、市场、人物、事件、模型、界面。
- 325 条新增内容：50 变卖物、80 普通物品、60 家具、70 服饰（30 地图限定）、20 药剂、20 武器、25 异常物。
- 五种支付币种、区域供需价格、黑市来源记录、六种鉴定方法、假货隔离、典当与赎回、竞价状态、实体货物及仓储/车辆容量检查。
- 重要人物持续风险预警和救助窗口、死亡记录、七个独立继承者身份、一次性葬礼与市场冲击、十个成就。
- 200 条事件记录为20个主题的10种地点/来源变体，不是200条完全独立长剧情。
- 旧存档补充 underground 子结构；继承流程保留新增世界货物。真实 API 密钥未读取或上传。

## 已通过的检查
- underground.test：内容计数和引用、旧存档、买卖原子性、假货鉴定、一次性赎回、赃物拒售、车辆容量、死亡预警、继承者、救助、剧情模式隔离。
- hunt.test：15项，含200场战斗及新增药剂可观察效果。
- underground-browser：本地服务器真实浏览器；市场、货物、纪念册、重载；1920×1080、1366×768、390×844无页面横向溢出或脚本异常。
- 完整回归运行通过至 journey-encounters；末尾 containment-life 的旧数量基线因新增内容报错，修正为检查原有内容后，与 containment-risk、entitlement-carry、chat-server 均单独通过。新增基线分别检查，不删除旧行为断言。

## 尚未完成，不能宣称已实现
- 七名继承者的独立任务池和更完整的关系差异。
- 遗物的专属模型、保留/变卖交互及长线追忆剧情。
- 劫匪家属、复仇、更多战斗死亡原因及详细后续支线。
- 八类商人分别经营的完整界面与专属库存规则。
- 部分药剂的专属记忆/潜行剧情效果（基础属性效果已接入）。
- 拍卖、所有币种、跨地图仓储、继承货物的完整浏览器长流程验证。
- 新美术目前为独立可替换的程序化素材；部分采用同一造型家族的尺寸和部件变化，不能称作325个独立手工模型。
- 正式版本号、发布日志及公开网站更新待以上工作和完整回归完成。

## 本次主要文件
index.source.html、index.html、game.js、js/state.js、js/engine.js、js/legacy.js、js/caravans.js、js/street.js、js/navigationData.js、js/navigation.js、js/accessoryArt.js、js/attachmentRig.js、js/weaponArt.js、js/combat.js、js/economyArt.js、js/bedroomDepth.js、js/itemModel.js、js/road/core.js、js/road/cargo.js、js/underground/*、underground.css、tests/underground*.cjs及相关旧内容基线测试、tools/test.cjs、语言包。
