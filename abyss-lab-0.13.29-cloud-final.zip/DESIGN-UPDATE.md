# 服饰美术与取名更新

日期：2026-10-02。沿用用户指定的 merged-game 项目。

## 服饰

保留 50 件饰品及原解锁方式，没有改变装备槽位或玩法数值。所有饰品改用新的独立 2D 图形与材质组装：研究帽重新裁形，马甲增加翻领/口袋/胸章，毛衣增加编织线，披肩增加流苏，雨衣增加领口和包边，眼镜改为细铜框与透明反光镜片，背包增加翻盖/背带，装甲和头盔增加分件与铆钉，天体饰品采用月白/黄铜，异常物件采用墨紫和断裂轮廓。

七组配色：深海研究制服、雨夜邮差、苔庭手作、旧时光藏品、月潮仪式、退役工业标本、无名回声。配色独立于稀有度，不再所有同稀有度饰品使用相同底色。新增六套搭配设计预览，仅供展示，不直接解锁物品。

素材仍为代码原生 SVG，不是 3D 模型；支持后续用 visual.asset 替换 PNG/WebP。

## 怪物名字

点击生命监测顶部的名字旁小铅笔，或菜单中的「怪物取名 / 改名」。新游戏确认后也会打开取名窗口。

支持 1–12 个 Unicode 字符、八个灵感名字、免费改名、Enter 提交、错误提示和自动保存。同步显示于生命监测、培养舱铭牌、衣橱预览与无障碍文本；日志记录改名。禁止尖括号及控制字符，使用 textContent/转义避免把名称当 HTML。

旧存档版本 1/2/3 若无 name 字段，默认为「零号」，保留进度。当前 schema 仍为 3，存储 key 不变。

## 文件

新增：js/data/accessoryStyles.js、js/accessoryModels.js、js/identity.js、tests/identity.test.cjs、verification/outfit-design-preview.html/png、本报告。
修改：js/accessoryArt.js、js/state.js、js/engine.js、js/ui.js、js/wardrobe.js、style.css、index.source.html、index.html、tests/load-game.cjs、tests/engine.test.cjs、tests/browser.test.cjs、ARCHITECTURE.md。

## 测试

55 项非浏览器检查全部通过（包含 100 组长期模拟）。Chrome file:// 验证新游戏、取名/改名、非法输入、名称重载、全部 50 个饰品图层、装备/卸下、多槽位、预设、图鉴、滤镜、旧存档、探索返航和独立单 HTML。

1920×1080、1366×768 主界面/衣橱/探索检查通过；390×844 衣橱无横向溢出。控制台与资源错误为 0。设计预览文件使用隔离测试数据，不会改变玩家存档。
