# 横向研究等级显示修复 — 2026-10-06

修改 index.source.html、navigation.css、js/navigation.js，重建 index.html 和公开打包入口；更新 CHANGELOG.md。
研究等级与时间横向排列，等级徽标不换行；日期和行动点保持完整。研究面板的等级和研究点也采用横向标签/数字布局。窄屏栏独立占据正常布局行，不用浮动坐标覆盖内容；ResizeObserver按实际顶栏高度更新内容区避让。
隔离Chromium验证中文/英文各1920、1366、1024、768、390宽度：等级同基线、各状态单元无重叠、无页面横向溢出、研究面板低于顶栏。控制台无异常。未读取真实玩家存档。
GitHub提交 30a7a53add25203d28ac3cbb6cc4f6c03e154aab，Pages Run45。发布结果需要最终确认。公网AI仍关闭。
