'use strict';
// Server-only RPC adapter. Never import into browser bundles.
const crypto=require('node:crypto');
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
function createSupabaseAccess({url,key,code,fetchImpl=fetch,timeout=8000,pollInterval=5000}={}){
 if(!url||!key||!code)throw Error('Cloud access configuration incomplete');
 const endpoint=new URL('/rest/v1/rpc/abyss_ai_access',url);
 if(endpoint.protocol!=='https:')throw Error('Cloud database requires HTTPS');
 const listeners=new Set();
 let pollTimer=null,polling=false,lastSnapshot=null,unavailable=false;
 async function rpc(op,data={}){
  let response;
  try{response=await fetchImpl(endpoint,{method:'POST',headers:{apikey:key,Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify({p_op:op,p_data:data}),signal:AbortSignal.timeout(timeout)});}catch{throw Error('AI_ACCESS_UNAVAILABLE');}
  if(!response.ok)throw Error('AI_ACCESS_UNAVAILABLE');
  let result;try{result=await response.json();}catch{throw Error('AI_ACCESS_UNAVAILABLE');}
  if(!result||typeof result!=='object'||Array.isArray(result))throw Error('AI_ACCESS_UNAVAILABLE');
  return result;
 }
 const tokenHash=req=>{const raw=(req.headers.cookie||'').match(/(?:^|;\s*)abyss_ai=([a-f0-9]{64})(?:;|$)/)?.[1];return raw?hash(raw):null;};
 const emit=e=>{for(const f of listeners)f(e);};
 // A local event emitter misses requests handled by another server instance.
 // Poll only while a verified owner has an active SSE subscription. No public
 // client receives the privileged database key or the snapshot contents here.
 async function poll(){
  if(polling||!listeners.size)return;polling=true;
  try{
   const value=await rpc('snapshot');
   if(!listeners.size)return;
   const serialized=JSON.stringify(value);
   if(serialized!==lastSnapshot||unavailable){lastSnapshot=serialized;unavailable=false;emit({type:'refresh'});}
  }catch{
   if(listeners.size&&!unavailable){unavailable=true;emit({type:'unavailable'});}
  }finally{polling=false;}
 }
 return {
  async redeem(req,value,name){
   // Count attempts in the database, including incorrect codes, across server instances.
   const allowed=await rpc('attempt',{ipHash:hash(req.socket.remoteAddress||'unknown')});
   if(!allowed.ok)return {status:429,error:'申请过于频繁，请一分钟后重试。'};
   if(typeof value!=='string'||!crypto.timingSafeEqual(Buffer.from(hash(value)),Buffer.from(hash(code))))return {status:403,error:'兑换码不正确。'};
   const existingHash=tokenHash(req);
   if(existingHash){const u=await rpc('status',{tokenHash:existingHash});if(u.status!=='locked')return {status:200,user:u};}
   const token=crypto.randomBytes(32).toString('hex');
   const r=await rpc('request',{tokenHash:hash(token),name:String(name||'未命名玩家').slice(0,40)});
   if(!r.ok)return {status:503,error:'申请名额已满。'};
   emit({type:'request',userId:r.user.id});return {status:202,user:r.user,token};
  },
  status:req=>rpc('status',{tokenHash:tokenHash(req)}),
  authorize:req=>rpc('authorize',{tokenHash:tokenHash(req)}),
  async reserve(grant){const r=await rpc('reserve',{tokenHash:grant.tokenHash});if(!r.ok){const e=Error(r.error||'AI权限不可用');e.status=r.status;e.code=r.code;throw e;}return r;},
  async decide(id,status){const r=await rpc('decide',{id,status});if(r.ok)emit({type:status,userId:id});return !!r.ok;},
  snapshot:()=>rpc('snapshot'),
  subscribe:f=>{
   listeners.add(f);
   if(!pollTimer){pollTimer=setInterval(poll,Math.max(50,pollInterval));pollTimer.unref?.();void poll();}
   return()=>{listeners.delete(f);if(!listeners.size){clearInterval(pollTimer);pollTimer=null;lastSnapshot=null;unavailable=false;}};
  }
 };
}
module.exports={createSupabaseAccess};
