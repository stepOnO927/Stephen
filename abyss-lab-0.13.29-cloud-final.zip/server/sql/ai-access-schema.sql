-- Deployment draft: service-only RPC. No player saves, dialogue or API keys stored.
-- Apply to the selected Supabase project via apply_migration after project confirmation.
create schema if not exists abyss_private;
revoke all on schema abyss_private from public, anon, authenticated;
grant usage on schema abyss_private to service_role;
create table if not exists abyss_private.ai_settings (
 id boolean primary key default true check(id),
 per_user integer not null default 20 check(per_user between 1 and 100),
 global_limit integer not null default 100 check(global_limit between 1 and 1000),
 max_users integer not null default 1000 check(max_users between 1 and 10000)
);
insert into abyss_private.ai_settings(id) values(true) on conflict do nothing;
create table if not exists abyss_private.ai_users (
 id uuid primary key default gen_random_uuid(),
 token_hash text not null unique check(token_hash ~ '^[a-f0-9]{64}$'),
 name text not null check(length(name) between 1 and 40),
 status text not null default 'pending' check(status in ('pending','approved','banned')),
 created_at timestamptz not null default now()
);
create table if not exists abyss_private.ai_usage (
 day date not null, scope text not null, used integer not null default 0 check(used>=0),
 primary key(day,scope)
);
create table if not exists abyss_private.ai_events (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references abyss_private.ai_users(id),
 type text not null check(type in ('request','approved','banned','pending')), at timestamptz not null default now()
);
create index if not exists ai_events_at on abyss_private.ai_events(at desc);
create index if not exists ai_events_user on abyss_private.ai_events(user_id);
create table if not exists abyss_private.ai_attempts (
 ip_hash text primary key check(ip_hash ~ '^[a-f0-9]{64}$'),
 window_start timestamptz not null default now(), used integer not null default 0
);
alter table abyss_private.ai_settings enable row level security;
alter table abyss_private.ai_users enable row level security;
alter table abyss_private.ai_usage enable row level security;
alter table abyss_private.ai_events enable row level security;
alter table abyss_private.ai_attempts enable row level security;
revoke all on all tables in schema abyss_private from public, anon, authenticated;
grant select,insert,update,delete on all tables in schema abyss_private to service_role;

create or replace function public.abyss_ai_access(p_op text,p_data jsonb default '{}'::jsonb)
returns jsonb language plpgsql security invoker set search_path='' set statement_timeout='5s' as $$
declare
 u abyss_private.ai_users%rowtype;
 cfg abyss_private.ai_settings%rowtype;
 today date := (now() at time zone 'UTC')::date;
 global_used integer; user_used integer; attempts integer;
 payload jsonb; rows jsonb;
begin
 -- Privilege check is also explicit: accidental future grants must not expose the API.
 if current_user <> 'service_role' and current_user <> 'postgres' then
  raise insufficient_privilege using message='server only';
 end if;
 select * into strict cfg from abyss_private.ai_settings where id=true;
 if p_op='attempt' then
  insert into abyss_private.ai_attempts as a(ip_hash,used) values(p_data->>'ipHash',1)
  on conflict(ip_hash) do update set
   used=case when a.window_start < now()-interval '1 minute' then 1 else a.used+1 end,
   window_start=case when a.window_start < now()-interval '1 minute' then now() else a.window_start end
  returning used into attempts;
  delete from abyss_private.ai_attempts where window_start < now()-interval '1 day';
  return jsonb_build_object('ok',attempts<=5);
 elsif p_op='request' then
  -- Serialize admission count, not AI generation. Only hashes are persisted.
  perform 1 from abyss_private.ai_settings where id=true for update;
  if (select count(*) from abyss_private.ai_users)>=cfg.max_users then return jsonb_build_object('ok',false); end if;
  insert into abyss_private.ai_users(token_hash,name) values(p_data->>'tokenHash',left(coalesce(nullif(p_data->>'name',''),'未命名玩家'),40)) returning * into u;
  insert into abyss_private.ai_events(user_id,type) values(u.id,'request');
  return jsonb_build_object('ok',true,'user',jsonb_build_object('id',u.id,'name',u.name,'status',u.status,'createdAt',u.created_at,'todayUsed',0,'dailyLimit',cfg.per_user));
 elsif p_op='decide' then
  if p_data->>'status' not in ('approved','banned','pending') then return jsonb_build_object('ok',false); end if;
  update abyss_private.ai_users set status=p_data->>'status' where id=(p_data->>'id')::uuid returning * into u;
  if not found then return jsonb_build_object('ok',false); end if;
  insert into abyss_private.ai_events(user_id,type) values(u.id,u.status);
  return jsonb_build_object('ok',true);
 elsif p_op='snapshot' then
  select coalesce(jsonb_agg(jsonb_build_object('id',a.id,'name',a.name,'status',a.status,'createdAt',a.created_at,'todayUsed',coalesce(b.used,0),'dailyLimit',cfg.per_user) order by a.created_at desc),'[]'::jsonb)
   into rows from abyss_private.ai_users a left join abyss_private.ai_usage b on b.day=today and b.scope=a.id::text;
  select coalesce(jsonb_agg(jsonb_build_object('id',e.id,'type',e.type,'userId',e.user_id,'at',e.at) order by e.at),'[]'::jsonb)
   into payload from (select * from abyss_private.ai_events order by at desc limit 100) e;
  return jsonb_build_object('users',rows,'events',payload,'dailyGlobalLimit',cfg.global_limit,'todayUsed',coalesce((select used from abyss_private.ai_usage where day=today and scope='global'),0));
 end if;
 if p_op not in ('status','authorize','reserve') then raise invalid_parameter_value using message='invalid operation'; end if;
 if p_op='reserve' then
  -- Global -> user lock ordering: quota check + both increments in one transaction.
  insert into abyss_private.ai_usage(day,scope) values(today,'global') on conflict do nothing;
  select used into global_used from abyss_private.ai_usage where day=today and scope='global' for update;
  select * into u from abyss_private.ai_users where token_hash=p_data->>'tokenHash' for update;
 else
  select * into u from abyss_private.ai_users where token_hash=p_data->>'tokenHash';
  select used into global_used from abyss_private.ai_usage where day=today and scope='global';
 end if;
 if u.id is null then
  if p_op='status' then return jsonb_build_object('status','locked','dailyLimit',cfg.per_user); end if;
  return jsonb_build_object('ok',false,'status',403,'code','AI_APPROVAL_REQUIRED','error','AI权限尚未批准。');
 end if;
 select coalesce((select used from abyss_private.ai_usage where day=today and scope=u.id::text),0) into user_used;
 if p_op='status' then return jsonb_build_object('id',u.id,'name',u.name,'status',u.status,'createdAt',u.created_at,'todayUsed',user_used,'dailyLimit',cfg.per_user); end if;
 if u.status <> 'approved' then return jsonb_build_object('ok',false,'status',403,'code',case when u.status='banned' then 'AI_BANNED' else 'AI_APPROVAL_REQUIRED' end,'error',case when u.status='banned' then '主机已封禁此AI权限。' else 'AI权限尚未批准。' end); end if;
 if user_used>=cfg.per_user or coalesce(global_used,0)>=cfg.global_limit then return jsonb_build_object('ok',false,'status',429,'code','AI_DAILY_LIMIT','error','今日AI用量已达上限。'); end if;
 if p_op='reserve' then
  update abyss_private.ai_usage set used=used+1 where day=today and scope='global';
  insert into abyss_private.ai_usage as a(day,scope,used) values(today,u.id::text,1)
   on conflict(day,scope) do update set used=a.used+1;
 end if;
 return jsonb_build_object('ok',true,'tokenHash',u.token_hash);
end;
$$;
revoke all on function public.abyss_ai_access(text,jsonb) from public,anon,authenticated;
grant execute on function public.abyss_ai_access(text,jsonb) to service_role;
comment on function public.abyss_ai_access(text,jsonb) is 'Server-only AI approval and atomic daily quota; no OpenAI calls inside transactions.';
