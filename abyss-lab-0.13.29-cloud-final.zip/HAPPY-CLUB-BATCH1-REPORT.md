# Happy Club 第1批验收

完成文件：js/happyClub/round.js、HAPPY-CLUB-PREVIEW.html、tests/happy-club-round.test.cjs、tests/happy-club-preview-browser.cjs。复用既有TargetPlacementValidator。规则测试加入tools/test.cjs。分批清单BATCHED-UPDATES.md。

实现：25秒单轮；六级42/27/17/9/4/1权重；Static Night异常3%、Festival Rare/Epic提升；九移动模式；尺寸按既有校验器六级缩放；稀有度逐级缩短存在时间；奖励两击1Token；超时MISS；Bomb开场3秒保护、相隔至少4秒、每局最多2、模式5/7/9%出现率、1.1–1.8秒可见、单击结束且保留此前Token；最多3同时/16总量；高稀有刷新空窗；路径和变形 envelope 事前检查，逐段检查移动，安全退出/暂停；resize不让旧靶变成危险可点击区域。Reduced Motion降低路径和变形幅度，不改稀有度/Bomb权重。

规则专项：300固定种子、91,075姿态、2,988次奖励清除、153例Bomb奖励保留；九移动方式与六稀有度均出现，平均13.5933次生成/25秒。布局校验器原测试与runtime测试继续通过。

真实Chrome开发测试场：1366/768/390三宽度，原生两次点击、25秒计时结束、清理点击靶、高对比与减弱运动、Token输出、无横向溢出/脚本错误，退出0。测试不访问正式玩家档。

边界：这批是开发规则和可操作隔离测试场。未接入正式世界地图、付费门票、存档与六级奖池；尚未作为正式游戏更新公开发布。不能称Happy Club整份规格完成，也不能称历史扩展全部完成。下一批先地图/驾驶到达/门票及存档，再真实奖励、成就、人物、新闻联动。
