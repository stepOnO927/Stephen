# 怪物对话交付说明

## 新增
- server.js：Node HTTP 服务，POST /api/creature-chat，官方 OpenAI JavaScript SDK 的 client.responses.create；store:false，无工具，输出仅 {reply, source}，失败额外提供通用 error/code。
- server/dialogue.cjs：输入白名单、四档认知规则、人物语言指导、备用对白及长度限制。
- server/creature-lore.txt：后续设定接入点；重启服务器生效。
- js/chatContext.js：从本地游戏只读提取状态摘要，不发送钱、物品、科技列表或完整存档，不发送未知剧情。
- js/creatureChat.js：独立交流弹窗、Loading、超时、错误、标签页历史、清空和取消请求。AI 返回即使包含修改属性的字段也完全忽略，不调用 Engine.dispatch/replace 或 Save.write。
- package.json、pnpm-lock.yaml、.env.example、.gitignore、两个双击启动/配置文件、开始游戏.md、测试文件。

## 修改
- index.source.html / index.html：交流入口及新增脚本。
- style.css：交流终端样式，沿用当前配色。
- js/ui.js：菜单入口、新游戏/导入时清空聊天。原玩法与 v4 存档格式不变。
- tools/test.cjs：统一逻辑与后端测试；已有浏览器测试支持 localhost 回归。

## Key 与本机运行
真实 Key 从 OPENAI_API_KEY 环境变量或服务器 .env 读取。没有写入 HTML、客户端 JavaScript 或 localStorage。静态服务使用白名单，.env、服务器代码、设定、依赖包均不开放下载。
服务器只监听 127.0.0.1，验证 Host 与 Origin，要求 JSON，每分钟总计 8 次且只允许单请求在途。输入最多 1000 字、请求体最多 32 KiB；SDK 不自动重试，默认 20 秒超时，浏览器 28 秒超时。
安装版本：openai 6.49.0，dotenv 17.4.2，通过本机 pnpm 安装 npm 仓库包；该电脑没有 npm 命令，双击启动器可使用已存在的 Node 运行时。常规安装了 Node 的电脑可使用 npm install / npm start。
默认模型 gpt-4.1-mini，可仅在服务器 .env 修改 OPENAI_MODEL。AI 不知情限制由只读上下文和角色指令实施，模型文字可能仍有误述；文字永远无法改变实际游戏数据。低智力回应另有本地硬限制。

## 验证与限制
原有 75 项游戏逻辑检查及隐藏事件专项检查通过；后端 5 组测试通过，包含官方 SDK 向本地模拟 Responses 上游发送真实 HTTP 请求、密钥文件隔离、输入验证、限流、超时、错误和并发。
浏览器专项检查覆盖 localhost 备用对白、Loading、历史重载/清空、恶意回复字段不修改游戏状态、状态白名单、1920/1366/390 尺寸和页面错误检查。
真实 OpenAI 请求未调用：没有配置真实 API Key，不能确认用户账户余额、网络或模型权限。
从 file:// 改到 localhost 必须通过现有导出/导入搬运存档，开始游戏.md 提供图形界面步骤。

官方用法参考：https://developers.openai.com/api/docs/quickstart
