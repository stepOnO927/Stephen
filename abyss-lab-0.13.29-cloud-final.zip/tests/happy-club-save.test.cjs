'use strict';
const assert=require('node:assert/strict'),{A}=require('./load-game.cjs')(),plain=x=>JSON.parse(JSON.stringify(x)),scene={viewport:{x:0,y:0,width:1000,height:500},uiBounds:[],foregroundBounds:[]};let clock=100000;const previous=Date.now;Date.now=()=>clock;
try{
 let s=A.State.create(123);s.mode='raising';s.money=100000;s.road.ownedVehicles=['sedan'];s.road.vehicle='sedan';s.road.fuel=20;s.road.location='happy_club';s.road.mode='park';A.Engine.replace(s);assert.equal(A.Engine.dispatch({type:'road:enter'}).ok,true);assert.ok(A.RoadNetwork.route('lab','happy_club',1));assert.equal(A.RoadMap.create('happy_club').enemies.length,0);
 const run=(type,payload)=>A.Engine.dispatch({type:'happy:'+type,payload}),snap=()=>A.Engine.snapshot();
 assert.equal(run('start',{scene}).ok,true);assert.equal(snap().money,92000);assert.equal(snap().happyClub.plays,1);assert.equal(A.Engine.dispatch({type:'road:retreat'}).ok,false);const paid=plain(snap());assert.equal(run('start',{scene}).ok,false);assert.deepEqual(plain(snap()),paid);
 clock+=400;let v=A.HappyClub.frame(snap());assert.ok(v.targets.length);const target=v.targets[0];assert.equal(run('shoot',target.center).message,'HIT_1');const half=plain(snap());A.Engine.replace(half);assert.equal(A.HappyClub.frame(snap()).targets[0].hits,1);assert.equal(run('shoot',target.center).message,'TARGET_CLEARED');let h=snap().happyClub;assert.equal(Object.values(h.active.round.tokens).reduce((a,b)=>a+b,0),1);
 A.Save.write(snap());A.Engine.replace(A.Save.load());assert.equal(run('finish').ok,true);h=snap().happyClub;assert.equal(Object.values(h.tokens).reduce((a,b)=>a+b,0),1);assert.equal(h.history.length,1);assert.equal(h.active,null);assert.equal(run('finish').ok,false);A.Engine.replace(A.Save.load());assert.equal(Object.values(snap().happyClub.tokens).reduce((a,b)=>a+b,0),1);
 assert.equal(run('start',{scene}).ok,true);assert.equal(snap().money,80000);clock+=26000;assert.equal(run('checkpoint').ok,true);assert.equal(snap().happyClub.active,null);assert.equal(run('start',{scene}).ok,true);assert.equal(snap().money,62000);assert.equal(run('finish').ok,true);assert.equal(run('start',{scene}).ok,false);
 s=snap();s.day++;s.age++;A.Engine.replace(s);assert.equal(run('start',{scene}).ok,true);assert.equal(snap().money,54000);run('finish');s=snap();s.road.location='lab';s.road.mode='home';A.Engine.replace(s);assert.equal(run('start',{scene}).ok,false);
 const old=plain(snap());delete old.happyClub;const migrated=A.State.validate(old);assert.equal(migrated.money,old.money);assert.equal(migrated.happyClub.active,null);assert.equal(migrated.happyClub.plays,0);
 const corrupt=plain(half);corrupt.happyClub.active.round.tokens.COMMON=16;const recovered=A.State.validate(corrupt);assert.equal(recovered.happyClub.active,null);assert.equal(recovered.happyClub.recoveryError,true);
 for(let seed=1;seed<=100;seed++){let round=new A.HappyClubRound({seed,scene});for(let t=0;t<=25000;t+=500){const view=plain(round.advance(t));round=A.HappyClubRound.restore(plain(round.serialize()));assert.deepEqual(plain(round.view()),view);}}
 console.log('PASS connected safe venue, ticket fees and daily cap, live two-hit/save-load, exactly-once token settlement, timeout/reload, active-round road guard, migration/corrupt recovery, 5100 serialized round checkpoints');
}finally{Date.now=previous;}


