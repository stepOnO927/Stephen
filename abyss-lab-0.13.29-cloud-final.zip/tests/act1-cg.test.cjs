'use strict';
const {A}=require('./load-game.cjs')(),assert=require('node:assert/strict'),fs=require('fs'),crypto=require('crypto');
const s=A.State.create();s.mode='story';s.narrative.active={id:'project_survival',line:0};
for(let line=0;line<22;line++){s.narrative.active.line=line;assert.equal(A.StoryCG.frame(s).cg,line<6?null:'CG_ACT1_EMPTY_DISH');}
const a=A.StoryCG.assets.CG_ACT1_EMPTY_DISH;assert.equal(a.motion.scale,1.03);assert.equal(a.motion.x,0);assert.equal(a.motion.y,2);assert.equal(a.motion.duration,9000);
assert.equal(crypto.createHash('sha256').update(fs.readFileSync(a.src)).digest('hex'),'6e749a134d1e9f936fcc1e85100f24f8b63ad41ea0555a44f8462a1fc460eb5a');
A.Save.start('story');assert.ok(!A.StoryBook.gallery()[a.id]);const current=A.Engine.snapshot();current.narrative.chapter=1;current.story.chapterClock=1;current.narrative.active={id:'project_survival',line:6};A.Engine.replace(current);A.StoryBook.unlock(a.id);A.StorySaves.save('quick');A.StorySaves.load('quick');assert.equal(A.StoryCG.frame(A.Engine.snapshot()).cg,a.id);A.Save.importText(A.Save.serialize(A.Engine.snapshot()));assert.ok(A.StoryBook.gallery()[a.id]);
console.log('PASS ACT I trigger at food bowl line, exact source image, motion, quick load and collection export/import');
