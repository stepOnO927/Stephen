'use strict';
const assert=require('node:assert/strict'),{A}=require('./load-phase6.cjs')(),D=require('../server/dialogue.cjs');
const s=A.State.create();s.mode='story';A.Campaign.prepare(s);assert.equal(s.narrative.playerName,'Jack');
const legacy=JSON.parse(JSON.stringify(s));legacy.narrative.playerName='旧名字';assert.equal(A.State.validate(legacy).narrative.playerName,'Jack');
assert.equal(A.Narrative.command(s,'player','other').ok,false);assert.equal(A.ChatContext.from(s).playerName,null);
A.Narrative.activate(s,'bond_jack_background');while(s.narrative.active.line<4)assert.ok(A.Narrative.command(s,'advance').ok);assert.ok(A.Narrative.command(s,'choose','share').ok);assert.equal(A.ChatContext.from(s).playerName,'Jack');assert.equal(A.State.validate(s).narrative.flags.knows_jack,true);
assert.equal(A.Narrative.text(A.State.create(),{id:'test',speaker:'creature',text:'{player}，你来了。'}),'你，你来了。');s.narrative.b07LanguageStage=5;assert.equal(A.Narrative.text(s,{id:'test',speaker:'creature',text:'{player}，你来了。'}),'Jack，你来了。');
const c=D.sanitize({message:'Hello',context:{uiLanguage:'en',playerName:'Jack',languageStage:2,intelligence:10,learnedWords:['you']}}).context;assert.equal(c.uiLanguage,'en');assert.equal(c.playerName,'Jack');assert.equal(D.fallback(c),'…You.');assert.ok(D.instructions('','en').includes('使用英语'));assert.equal(D.sanitize({message:'Hi',context:{uiLanguage:'invalid',playerName:'invented'}}).context.playerName,null);
console.log('PASS fixed jack, legacy normalization, knowledge-gated name, saved background, English server/fallback');
