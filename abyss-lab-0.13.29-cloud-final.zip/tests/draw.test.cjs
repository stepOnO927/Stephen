'use strict';
const assert=require('node:assert/strict'),{A}=require('./load-game.cjs')();
const plain=x=>JSON.parse(JSON.stringify(x));
function fresh(seed=77){const s=A.State.create(seed);s.mode='raising';A.Campaign.prepare(s);s.money=1000;return s;}
let s=fresh(),before=plain(s);
assert.equal(A.HuntRewards.quote(s,1,'scrap').ok,false);
assert.equal(A.HuntRewards.quote(s,1,'credits').ok,true);
assert.equal(A.HuntRewards.quote(s,10,'credits').cost,800);
for(const [count,currency] of [[2,'scrap'],[1,'bogus'],[1,null],[NaN,'credits']]){assert.equal(A.HuntRewards.draw(s,count,currency).ok,false);assert.deepEqual(plain(s),before);}
s.money=79;before=plain(s);assert.equal(A.HuntRewards.draw(s,1,'credits').ok,false);assert.deepEqual(plain(s),before);
for(let seed=1;seed<=120;seed++){
 const credit=fresh(seed),scrap=fresh(seed);scrap.hunt.combatCurrency=100;
 const a=A.HuntRewards.draw(credit,10,'credits'),b=A.HuntRewards.draw(scrap,10);
 assert.ok(a.ok&&b.ok);assert.equal(credit.money,200);assert.equal(scrap.money,1000);assert.equal(a.payment.cost,800);assert.equal(b.payment.cost,80);
 assert.deepEqual(plain(a.results),plain(b.results));assert.equal(credit.rng,scrap.rng);assert.equal(credit.ap,5);assert.deepEqual(plain(credit.stats),plain(scrap.stats));assert.ok(a.results.some(r=>A.HuntRewards.rank(r.rarity)>=1));
}
s=fresh();s.hunt.combatCurrency=8;s.hunt.gachaPity.rare=19;
assert.ok(A.HuntRewards.draw(s,1,'credits').ok);assert.equal(s.hunt.gachaPity.rare,0);assert.ok(A.HuntRewards.draw(s,1,'scrap').ok);assert.equal(s.hunt.gachaPity.total,2);
A.Engine.replace(fresh());const initial=A.Engine.snapshot(),r=A.Engine.dispatch({type:'hunt:draw',payload:{count:10,currency:'credits'}});assert.ok(r.ok);assert.equal(A.Engine.snapshot().money,200);assert.equal(A.Engine.snapshot().ap,initial.ap);
assert.equal(A.Save.load().hunt.gachaPity.total,10);assert.deepEqual(plain(A.Save.load().hunt.gachaHistory),plain(A.Engine.snapshot().hunt.gachaHistory));
A.Save.start('story');s=A.Engine.snapshot();s.money=1000;A.Engine.replace(s);before=plain(A.Engine.snapshot());assert.equal(A.Engine.dispatch({type:'hunt:draw',payload:{count:1,currency:'credits'}}).ok,false);assert.deepEqual(plain(A.Engine.snapshot()),before);
console.log('PASS distinct currencies, exact credits payment, atomic invalid/insufficient requests, 120 matched seeded batches, shared pity, no AP/stat changes, saved outcomes and Story guard');
