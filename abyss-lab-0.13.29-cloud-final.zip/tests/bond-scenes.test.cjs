'use strict';
const assert=require('node:assert/strict'),{A}=require('./load-phase6.cjs')();
let s=A.State.create();s.mode='story';A.Campaign.prepare(s);s.pendingEvent=null;
A.Narrative.activate(s,'project_b07');const ap=s.ap;
for(let i=0;i<7;i++){assert.equal(s.narrative.active.line,i);assert.ok(A.Narrative.command(s,'advance').ok);s=A.State.validate(JSON.parse(JSON.stringify(s)));}
assert.equal(s.narrative.active.line,7);assert.equal(s.ap,ap);
A.Narrative.activate(s,'bond_first_i');assert.equal(A.Narrative.command(s,'choose','respect').ok,false);
for(let i=0;i<6;i++)assert.ok(A.Narrative.command(s,'advance').ok);
const loyalty=s.stats.loyalty;assert.ok(A.Narrative.command(s,'choose','respect').ok);s=A.State.validate(s);
assert.ok(s.narrative.milestones.first_i_event);assert.ok(s.memories.some(m=>m.id==='first_i_event'));assert.equal(s.stats.loyalty,loyalty);assert.equal(s.ap,ap);
console.log('PASS continuous beats, cursor reload, early choice rejection, FIRST I persistence, no AP or loyalty rewards');
