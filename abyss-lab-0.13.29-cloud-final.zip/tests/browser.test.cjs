const assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),{pathToFileURL}=require('url');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE || 'playwright');
(async()=>{
 const browser=await chromium.launch({...(process.env.BROWSER_EXECUTABLE?{executablePath:process.env.BROWSER_EXECUTABLE}:{}),headless:true});const page=await browser.newPage({viewport:{width:1366,height:768}});const errors=[],failed=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});page.on('requestfailed',r=>failed.push(r.url()));
 const root=path.resolve(__dirname,'..');const artifacts=fs.mkdtempSync(path.join(require('os').tmpdir(),'abyss-phase2-'));
 console.log('Browser screenshots: '+artifacts);
 const url=process.env.GAME_URL||pathToFileURL(path.join(root,'index.html')).href;
 async function resolveProgress(){for(let i=0;i<10;i++){const ch=page.locator('[data-progress="story"]:visible,[data-progress="evolution"]:visible');if(!await ch.count())break;await ch.first().click();}}
 async function clearNotices(){for(let i=0;i<60;i++){await resolveProgress();const reveal=page.locator('[data-wardrobe="ack"]:visible');if(await reveal.count()){await reveal.click();continue;}const choice=page.locator('[data-command="event"]:enabled:visible');if(await choice.count()){await choice.first().click();continue;}const ending=page.locator('[data-command="ackEnding"]:visible');if(await ending.count()){await ending.click();continue;}break;}}
 async function wardrobe(){await page.locator('[data-action="wardrobe"]').click();}
 await page.goto(url);await page.evaluate(()=>{Abyss.Save.start('raising');document.getElementById('modal').close();});assert.equal(await page.evaluate(()=>Abyss.Engine.snapshot().version),4);
 await page.locator('[data-action="name"]').click();
 await page.locator('#name-input').fill('<bad>');await page.locator('#name-form button[type="submit"]').click();assert.ok((await page.locator('#name-error').innerText()).length);
 await page.locator('[data-name-suggestion="月芽"]').click();await page.locator('#name-form button[type="submit"]').click();
 assert.equal(await page.locator('#creature-name').innerText(),'月芽');assert.ok((await page.locator('#specimen-name').innerText()).includes('月芽'));
 await page.reload();assert.equal(await page.evaluate(()=>Abyss.Engine.snapshot().name),'月芽');
 await wardrobe();assert.equal(await page.locator('.accessory-card').count(),3);
 await page.locator('[data-wardrobe="select"][data-item="research_cap"]').click();await page.locator('[data-wardrobe="equip"]').click();
 assert.equal(await page.evaluate(()=>Abyss.Engine.snapshot().collection.equipped.head),'research_cap');assert.equal(await page.locator('#monster [data-accessory-slot="head"]').getAttribute('data-item'),'research_cap');assert.ok(await page.locator('#wardrobe-creature [data-accessory-slot="head"] path').count());
 await page.locator('[data-wardrobe="mode"][data-mode="archive"]').click();assert.equal(await page.locator('.accessory-card').count(),await page.evaluate(()=>Abyss.Data.accessories.filter(a=>!a.secret).length));assert.ok((await page.locator('.collection-total').innerText()).includes((await page.evaluate(()=>Abyss.Data.accessories.filter(a=>!a.secret).length))+' + ?'));assert.equal(await page.locator('[data-item="absent_crown"]').count(),0);
 await page.locator('[data-filter="rarity"]').selectOption('legendary');assert.equal(await page.locator('.accessory-card').count(),await page.evaluate(()=>Abyss.Data.accessories.filter(a=>a.rarity==='legendary'&&!a.secret).length));
 await page.locator('[data-wardrobe="select"][data-item="broken_halo"]').click();assert.equal(await page.locator('.accessory-detail h3').innerText(),'???');assert.equal(await page.locator('[data-wardrobe="equip"]').count(),0);
 const savedBefore=await page.evaluate(()=>JSON.stringify(Abyss.Engine.snapshot().collection.equipped));await page.locator('[data-wardrobe="preview"]').click();assert.equal(await page.locator('#wardrobe-creature [data-accessory-slot="head"]').getAttribute('data-item'),'broken_halo');assert.ok((await page.locator('#wardrobe-creature [data-accessory-slot="head"]').getAttribute('class')).includes('silhouette'));assert.equal(await page.evaluate(()=>JSON.stringify(Abyss.Engine.snapshot().collection.equipped)),savedBefore);assert.equal(await page.locator('#monster [data-accessory-slot="head"]').getAttribute('data-item'),'research_cap');
 await page.locator('[data-filter="owned"]').selectOption('owned');assert.equal(await page.locator('.accessory-card').count(),0);await page.locator('[data-filter="rarity"]').selectOption('all');await page.locator('[data-wardrobe="slot"][data-slot="head"]').click();assert.equal(await page.locator('.accessory-card').count(),1);
 await page.locator('[data-wardrobe="mode"][data-mode="shop"]').click();await page.locator('[data-wardrobe="select"][data-item="round_glasses"]').click();await page.locator('[data-wardrobe="buy"]').click();assert.equal(await page.locator('.accessory-reveal h4').innerText(),'圆框眼镜');await clearNotices();
 await page.locator('[data-wardrobe="mode"][data-mode="wardrobe"]').click();await page.locator('[data-wardrobe="select"][data-item="round_glasses"]').click();await page.locator('[data-wardrobe="equip"]').click();assert.equal(await page.locator('#monster [data-accessory-slot="face"]').getAttribute('data-item'),'round_glasses');
 await page.locator('[data-wardrobe="mode"][data-mode="presets"]').click();await page.locator('[data-wardrobe="preset-save"][data-preset="1"]').click();await page.locator('[data-preset-name="1"]').fill('小小观察员');await page.locator('[data-wardrobe="preset-rename"][data-preset="1"]').click();assert.equal(await page.locator('[data-preset-name="1"]').inputValue(),'小小观察员');
 await page.locator('[data-wardrobe="unequip"][data-slot="head"]').click();await page.locator('[data-wardrobe="preset-load"][data-preset="1"]').click();assert.equal(await page.evaluate(()=>Abyss.Engine.snapshot().collection.equipped.head),'research_cap');
 await page.locator('#close-modal').click();await page.reload();await clearNotices();assert.equal(await page.evaluate(()=>Abyss.Engine.snapshot().collection.equipped.face),'round_glasses');assert.equal(await page.evaluate(()=>Abyss.Engine.snapshot().collection.presets[0].name),'小小观察员');
 await wardrobe();await page.locator('[data-wardrobe="mode"][data-mode="presets"]').click();await page.locator('[data-wardrobe="preset-delete"][data-preset="1"]').click();assert.equal(await page.evaluate(()=>Abyss.Engine.snapshot().collection.presets.length),0);await page.locator('#close-modal').click();
 // Acquisition through a real gameplay action; not only direct model grants.
 await page.evaluate(()=>Abyss.UI.open('legacy:food'));await page.locator('[data-command="feed"][data-id="ration"]').click();assert.equal(await page.locator('.accessory-reveal h4').innerText(),'晚餐纽扣');await clearNotices();
 await page.locator('[data-action="explore"]').first().click();await page.locator('[data-exp-cmd="start"][data-exp-id="sewers"]').click();
 assert.equal(await page.locator('[data-action="food"]').isDisabled(),true);
 await page.reload();assert.ok(await page.locator('#exp-terminal').isVisible());
 for(const [width,height] of [[1920,1080],[1366,768]]){
  await page.setViewportSize({width,height});await page.screenshot({path:path.join(artifacts,'expedition-'+width+'.png')});
  assert.ok(await page.evaluate(()=>{const r=document.getElementById('exp-terminal').getBoundingClientRect();return r.left>=0&&r.top>=0&&r.right<=innerWidth&&r.bottom<=innerHeight;}));
 }
 await page.locator('[data-exp-view="close"]').click();
 assert.equal(await page.locator('[data-action="food"]').isDisabled(),true);
 await page.locator('[data-action="explore"]').first().click();
 assert.ok(await page.locator('#exp-terminal').isVisible());
 for(let i=0;i<20&&await page.evaluate(()=>!!Abyss.Engine.snapshot().exploration.active);i++){
  const choice=page.locator('[data-exp-cmd="choose"]:visible');
  if(await choice.count())await choice.first().click();else await page.locator('[data-exp-cmd="advance"]').click();
 }
 assert.equal(await page.evaluate(()=>Abyss.Engine.snapshot().exploration.active),null);
 await page.locator('[data-exp-view="close"]').click();await page.locator('#modal').waitFor({state:'visible'});await resolveProgress();assert.equal(await page.locator('.accessory-reveal h4').innerText(),'帆布背包');await clearNotices();
 // Fixture grants cover artwork and hidden set rendering; gameplay remains untouched by the UI.
 await page.evaluate(()=>{const s=Abyss.Engine.snapshot();for(const id of ['lab_vest','tail_ribbon','canvas_pack'])Abyss.Accessories.grant(s,id,'视觉验证');s.collection.reveals=[];Abyss.Engine.replace(s);for(const id of ['research_cap','round_glasses','lab_vest','id_tag','canvas_pack','tail_ribbon'])Abyss.Engine.dispatch({type:'accessory:equip',payload:{id}});});
 assert.ok(await page.evaluate(()=>Abyss.Engine.snapshot().collection.discoveredSets.includes('lab')));
 for(const [width,height] of [[1920,1080],[1366,768]]){
  await page.setViewportSize({width,height});await page.screenshot({path:path.join(artifacts,`lab-${width}.png`)});assert.equal(await page.evaluate(()=>document.documentElement.scrollHeight),height);
  await wardrobe();await page.locator('[data-wardrobe="mode"][data-mode="wardrobe"]').click();await page.locator('[data-wardrobe="slot"][data-slot="all"]').click();await page.screenshot({path:path.join(artifacts,`wardrobe-${width}.png`)});
  const layout=await page.evaluate(()=>{const modal=document.getElementById('modal'),slots=document.querySelector('.outfit-slots');return {right:modal.getBoundingClientRect().right,bottom:modal.getBoundingClientRect().bottom,slotsBottom:slots.getBoundingClientRect().bottom,preview:document.getElementById('wardrobe-creature-mount').getBoundingClientRect().height};});assert.ok(layout.right<=width&&layout.bottom<=height);assert.ok(layout.slotsBottom<=layout.bottom);assert.ok(layout.preview>100);
  const duplicateIds=await page.evaluate(()=>{const ids=[...document.querySelectorAll('[id]')].map(e=>e.id);return ids.filter((v,i)=>ids.indexOf(v)!==i);});assert.equal(duplicateIds.length,0);
  await page.locator('#close-modal').click();
 }
 // Visit every procedural item at its actual attachment point, including mutations.
 await page.evaluate(()=>{const s=Abyss.Engine.snapshot();s.mutations=Abyss.Data.mutations.map(m=>m.id);for(const a of Abyss.Data.accessories)Abyss.Accessories.grant(s,a.id,'图层验证');s.collection.reveals=[];Abyss.Engine.replace(s);});
 const artIds=await page.evaluate(()=>Abyss.Data.accessories.map(a=>a.id));for(const id of artIds){await page.evaluate(id=>Abyss.Engine.dispatch({type:'accessory:equip',payload:{id}}),id);assert.ok(await page.locator(`#monster [data-item="${id}"]>*`).count());}
 await wardrobe();await page.locator('[data-wardrobe="mode"][data-mode="archive"]').click();assert.equal(await page.locator('.accessory-card').count(),artIds.length);await page.locator('[data-filter="sort"]').selectOption('date');assert.equal(await page.locator('.accessory-card').first().getAttribute('data-item'),await page.evaluate(()=>Object.entries(Abyss.Engine.snapshot().collection.owned).sort((a,b)=>b[1].order-a[1].order)[0][0]));
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(artifacts,'wardrobe-mobile.png'),fullPage:true});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth),390);
 await page.locator('#close-modal').click();
 // Real browser localStorage v1 migration.
 const old=await page.evaluate(()=>{const s=Abyss.State.create(91);s.version=1;s.day=9;s.age=8;s.money=71;s.ap=3;s.stats.loyalty=69;for(const key of ['collection','personality','memories','favoriteFood'])delete s[key];for(const key of Object.keys(localStorage))if(key.startsWith('abyss-lab-'))localStorage.removeItem(key);localStorage.setItem(Abyss.Save.KEY,JSON.stringify(s));return s;});
 await page.reload();const migrated=await page.evaluate(()=>Abyss.Engine.snapshot());assert.equal(migrated.version,4);for(const k of ['day','age','money','ap','stats'])assert.deepEqual(migrated[k],old[k]);
 // Portable HTML is still standalone.
 const isolated=path.join(artifacts,'isolated');fs.mkdirSync(isolated,{recursive:true});fs.copyFileSync(path.join(root,'index.html'),path.join(isolated,'index.html'));await page.goto(pathToFileURL(path.join(isolated,'index.html')).href);await page.evaluate(()=>{Abyss.Save.start('raising');document.getElementById('modal').close();});await wardrobe();assert.equal(await page.locator('.accessory-card').count(),3);
 await page.locator('#close-modal').click();await page.locator('[data-action="menu"]').click();await page.locator('[data-mode="slots"][data-id="raising"]').click();await page.locator('[data-mode="new"][data-id="raising"]').click();await page.locator('[data-action="name"]').click();
 assert.ok(await page.locator('#name-form').isVisible());await page.locator('#name-input').fill('小墨');await page.locator('#name-form button[type="submit"]').click();
 assert.equal(await page.evaluate(()=>Abyss.Engine.snapshot().name),'小墨');assert.equal(await page.evaluate(()=>Abyss.Engine.snapshot().day),1);
 await page.locator('[data-action="name"]').click();await page.screenshot({path:path.join(artifacts,'naming.png')});
 assert.deepEqual(errors,[]);assert.deepEqual(failed,[]);console.log('PASS phase2 browser: all requested flows, 50 artwork layers, v1 migration, file:// standalone, both desktop viewports, mobile; zero console/resource errors');await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});




