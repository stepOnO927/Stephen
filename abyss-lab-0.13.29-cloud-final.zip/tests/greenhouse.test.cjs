'use strict';
const assert=require('node:assert/strict'),{A}=require('./load-game.cjs')(),copy=x=>JSON.parse(JSON.stringify(x));
const s=A.State.create(88);s.mode='raising';s.money=5000;A.Climate.init(s);A.Engine.replace(s);
const run=(type,payload)=>A.Engine.dispatch({type,payload});
assert.equal(A.PlantData.length,200);assert.equal(new Set(A.PlantData.map(p=>p.id)).size,200);
assert.ok(run('garden:unlock').ok);assert.ok(run('garden:plant',{id:'plant_1'}).ok);
let g=A.Engine.snapshot();assert.equal(g.greenhouse.seeds.plant_1,2);assert.equal(g.ap,4);
assert.deepEqual(copy(A.State.validate(g).greenhouse),copy(g.greenhouse));
const before=copy(g);assert.equal(run('garden:plant',{id:'invalid'}).ok,false);assert.deepEqual(copy(A.Engine.snapshot()),before);
for(let i=0;i<4;i++){const prev=copy(g);g.day++;g.age++;g.climate.weatherByRegion.forest&&(g.climate.weatherByRegion.forest.temperature=20);A.Garden.observe(prev,g,{type:'rest'});}
assert.ok(g.greenhouse.plants[0].growth>0,'daily growth is real');g.greenhouse.plants[0].growth=100;A.Engine.replace(g);assert.ok(run('garden:harvest',{uid:1}).ok);assert.equal(A.Engine.snapshot().greenhouse.harvest.length,1);assert.equal(run('garden:harvest',{uid:1}).ok,false);
assert.ok(run('garden:sell',{batch:0}).ok);
g=A.Engine.snapshot();g.ap=5;g.stats.health=50;A.Engine.replace(g);assert.ok(run('medical:assess',{patient:'b07'}).ok);assert.ok(run('medical:treat',{patient:'b07'}).ok);assert.equal(A.Engine.snapshot().stats.health,50);assert.equal(run('medical:treat',{patient:'b07'}).ok,false);
g=A.Engine.snapshot();const prev=copy(g);g.day++;g.age++;A.Infirmary.observe(prev,g);assert.equal(g.stats.health,53);const checked=A.State.validate(g);assert.equal(checked.infirmary.patients[0].days,1);
const old=copy(g);delete old.greenhouse;delete old.infirmary;assert.equal(A.State.validate(old).greenhouse.unlocked,false);assert.equal(A.State.validate(old).greenhouse.lastDay,old.day);
g.mode='story';A.Engine.replace(g);assert.equal(run('garden:unlock').ok,false);
const expedition=A.State.create(12);expedition.mode='raising';expedition.greenhouse.unlocked=true;const initial=copy(expedition);initial.exploration.active={steps:0,forceReturn:false};A.Garden.observe(initial,expedition,{type:'exp:advance'});assert.equal(expedition.greenhouse.discovered.length,0);initial.exploration.active={steps:2,forceReturn:true};A.Garden.observe(initial,expedition,{type:'exp:advance'});assert.equal(expedition.greenhouse.discovered.length,0);initial.exploration.active.forceReturn=false;A.Garden.observe(initial,expedition,{type:'exp:advance'});assert.equal(expedition.greenhouse.discovered.length,1);
console.log('PASS 200 unique plants; planting/AP; atomic rejection; harvest anti-repeat; sale; additive migration; delayed treatment; reload; story isolation');
