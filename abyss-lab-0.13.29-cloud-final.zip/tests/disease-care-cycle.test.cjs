'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),{A}=require('./load-game.cjs')(),copy=x=>JSON.parse(JSON.stringify(x)),base=copy(A.Engine.snapshot()),results=[];let runs=0;
for(const d of A.DiseaseData)for(const host of d.hostTypes)for(let seed=1;seed<=8;seed++){
 const s=copy(base);s.rng=seed*944129+d.number;s.money=100000;s.ap=5;s.infirmary.level=8;s.stats.hunger=20;s.home.conditions.air=85;s.home.conditions.contamination=0;s.stats.pollution=0;s.road.mode='inside';s.road.location='lab';s.climate.labResources.water=100;s.climate.labResources.medicine=100;
 let id=host==='HUMAN'?'jack':host==='B07'?'b07':null;
 if(['PET','MONSTER'].includes(host)){s.pets.push(A.Pets.create(s,A.ContainmentData.species.find(d=>d.id===(host==='PET'?'cat':'hound'))));id=s.pets.at(-1).id;}
 if(host==='NPC'){id=A.StreetData.people[0].id;s.street.people[id].visits=1;s.operations.residents=[id];}
 A.Infirmary.sync(s.infirmary,s);const p=s.infirmary.patients.find(p=>p.id===id);assert.equal(p.hostType,host);p.stress=25;p.sleep=75;p.medicalTrust=75;p.conditions=[];assert.ok(A.Illness.expose(s,p,d.diseaseId,'care-cycle'));
 const c=p.conditions[0],recipe=d.category==='PSYCHOLOGICAL'?'calming':d.category==='CONTAMINATION'?'pollution':null;let days=0,courses=0,spent=0,resupplyCost=0;
 while(c.status!=='RECOVERED'&&days<180){s.ap=5;s.pendingEvent=null;
  for(const resource of ['water','medicine'])if(s.climate.labResources[resource]<15){const money=s.money;assert.ok(A.Climate.command(s,'resupply',{id:resource}).ok);resupplyCost+=money-s.money;}
  if(!p.plan){assert.ok(A.Infirmary.command(s,'assess',{patient:id}).ok);if(recipe)s.infirmary.products[recipe]=1;const stock=s.climate.labResources.medicine;assert.ok(A.Infirmary.command(s,'treat',{patient:id,...(recipe?{recipe}:{})}).ok);spent+=stock-s.climate.labResources.medicine;courses++;}
  const before=copy(s);s.day++;s.age++;days++;A.Infirmary.observe(before,s,{type:'rest'});assert.ok(Number.isFinite(A.Infirmary.health(s,p)));assert.ok(s.climate.labResources.water>=0);assert.ok(s.climate.labResources.medicine>=0);
 }
 assert.equal(c.status,'RECOVERED',d.diseaseId+'/'+host+'/'+seed+' care-cycle did not recover');assert.equal(spent,courses*3);assert.ok(days<=d.incubation+A.DiseaseBalance.get(d).days*3+12,d.diseaseId+' excessive real care duration');
 const migrated=A.State.validate(copy(s)).infirmary.patients.find(p=>p.id===id);assert.ok(migrated?.conditions.some(c=>c.id===d.diseaseId&&c.status==='RECOVERED'),'real host course survives save');
 results.push({disease:d.number,host,seed,days,courses,medicine:spent,resupplyCredits:resupplyCost,health:+A.Infirmary.health(s,p).toFixed(2)});runs++;
}
fs.writeFileSync('verification/disease-care-cycles.json',JSON.stringify({runs,results},null,2));console.log('PASS '+runs+' real four-day care cycles across every supported host, assessment/treatment AP, exact reserve costs, resupply, daily symptoms, bounded recovery and reload');
