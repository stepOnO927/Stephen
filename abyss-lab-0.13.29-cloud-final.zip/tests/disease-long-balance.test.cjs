'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),{A}=require('./load-game.cjs')();
const copy=x=>JSON.parse(JSON.stringify(x));
const base=A.State.create(1001);base.stats.pollution=0;base.home.conditions.air=85;base.home.conditions.contamination=0;
assert.equal(A.DiseaseBalance.rows.length,90);assert.equal(Object.keys(A.DiseaseBalance.profiles).length,90);
const results=[];let runs=0;
for(const d of A.DiseaseData){
 const b=A.DiseaseBalance.get(d);assert.equal(b.number,d.number);assert.ok(b.days>=2&&b.days<=28);assert.ok(b.contact===0||d.infectious);
 const groups={cared:[],neglected:[],hostile:[]};
 for(const mode of Object.keys(groups))for(let seed=1;seed<=40;seed++){
  const s=copy(base);s.rng=seed*123457+d.number*13;s.day=1;s.age=0;
  const p=s.infirmary.patients[0];p.hostType=d.hostTypes.includes('B07')?'B07':d.hostTypes[0];p.stress=mode==='neglected'?90:25;p.sleep=75;p.medicalTrust=70;
  if(mode!=='neglected'){p.plan=d.category==='PSYCHOLOGICAL'?'calm':d.category==='CONTAMINATION'?'pollution':'physical';p.supportPlants=d.plantSupports.slice(0,1);}
  if(mode==='hostile'){s.home.conditions.air=10;s.home.conditions.contamination=85;s.stats.pollution=85;s.climate.labResources.water=5;p.sleep=25;p.stress=85;}
  assert.ok(A.Illness.expose(s,p,d.diseaseId,'simulation'));const c=p.conditions[0];let elapsed=0,previous=0;
  while(c.status!=='RECOVERED'&&elapsed<600){s.day++;elapsed++;A.Illness.tick(s,p);assert.ok(c.progress>=previous&&Number.isFinite(c.progress));previous=c.progress;assert.ok(A.Infirmary.health(s,p)>=0);}
  assert.equal(c.status,'RECOVERED',d.diseaseId+' / '+mode+' / '+seed+' never recovered');
  if(mode==='cared')assert.ok(elapsed<=d.incubation+b.days*2+3,d.diseaseId+' excessive cared duration');
  if(d.category==='PSYCHOLOGICAL')assert.equal(s.stats.health,base.stats.health,'mental condition cannot remove health directly');
  assert.equal(A.Illness.expose(s,p,d.diseaseId,'again'),false,'recovery protection blocks immediate reinfection');
  const migrated=A.Illness.read(copy(p.conditions))[0];assert.equal(migrated.protection,b.protection);assert.equal(migrated.careDays,c.careDays);
  groups[mode].push(elapsed);runs++;
 }
 const mean=a=>+(a.reduce((a,b)=>a+b,0)/a.length).toFixed(2);
 const row={number:d.number,id:d.diseaseId,name:d.name,careDays:b.days,caredMean:mean(groups.cared),neglectedMean:mean(groups.neglected),hostileMean:mean(groups.hostile)};
 assert.ok(row.caredMean<=row.neglectedMean,d.diseaseId+' care should not be slower');results.push(row);
}
const old=A.Illness.read([{id:'disease_15',progress:48,days:3,severity:'MILD',status:'IMPROVING',afterDays:0}])[0];assert.equal(old.progress,48);assert.equal(old.protection,0);assert.equal(old.careDays,0);
const isolated=copy(base),source=isolated.infirmary.patients[0],target=isolated.infirmary.patients[1];A.Illness.expose(isolated,source,'disease_15','test');source.conditions[0].status='STABLE';source.quarantine=true;for(let i=0;i<1000;i++)A.Illness.contacts(isolated);assert.equal(target.conditions.length,0);
fs.mkdirSync('verification',{recursive:true});fs.writeFileSync('verification/disease-long-balance.json',JSON.stringify({runs,seedCount:40,maximumDays:600,results},null,2));
console.log('PASS '+runs+' disease courses: 90 diagnoses × 3 care/environment settings × 40 seeds; bounded recovery, faster care, mental separation, protection, quarantine and migration');
