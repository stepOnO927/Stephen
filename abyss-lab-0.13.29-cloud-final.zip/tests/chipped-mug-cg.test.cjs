'use strict';
const {A}=require('./load-game.cjs')(),assert=require('node:assert/strict'),fs=require('fs'),crypto=require('crypto');
const s=A.State.create();s.mode='story';s.narrative.active={id:'daily_cup',line:0};
for(let line=0;line<15;line++){s.narrative.active.line=line;assert.equal(A.StoryCG.frame(s).cg,line<6?'CG_ACT1_EMPTY_DISH':'CG_ACT1_CHIPPED_MUG');}
const a=A.StoryCG.assets.CG_ACT1_CHIPPED_MUG;assert.equal(a.motion.scale,1.035);assert.equal(a.motion.x,-2);assert.equal(a.motion.y,0);assert.equal(a.motion.duration,9000);assert.equal(a.duration,700);assert.equal(a.transition,'crossfade');
assert.equal(crypto.createHash('sha256').update(fs.readFileSync(a.src)).digest('hex'),'876a3041a58692725ab22f250226649e6b1d78969486ea4f72d842d214aa8df6');
A.Save.start('story');assert.ok(!A.StoryBook.gallery()[a.id]);const current=A.Engine.snapshot();current.narrative.chapter=2;current.story.chapterClock=2;current.narrative.active={id:'daily_cup',line:6};A.Engine.replace(current);A.StoryBook.unlock(a.id);A.StorySaves.save('quick');A.StorySaves.load('quick');assert.equal(A.StoryCG.frame(A.Engine.snapshot()).cg,a.id);A.Save.importText(A.Save.serialize(A.Engine.snapshot()));assert.ok(A.StoryBook.gallery()[a.id]);
console.log('PASS daily_cup CG cue, exact supplied image, motion/crossfade, quick-load and collection export/import');
