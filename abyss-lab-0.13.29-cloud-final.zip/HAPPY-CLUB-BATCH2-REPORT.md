# Happy Club 第2批：地图、门票、存档

持续总目标为active，尚未完成；后续仍按BATCHED-UPDATES.md推进。

已实装：永久道路地点happy_club，深林(-3,3)、安全区域、停车/票口/靶场/奖品/休息/宠物等待区。道路图构建前加入，现70条连通道路。以原驾车、停稳、下车进入为条件，无载具不会凭空提供车。公路现场按钮及探索菜单提供靶场入口。

门票使用主资金：8000/12000/18000，每日最多3轮，下一日重置收费次数。挑战期间阻止其他游戏命令绕过地点/时钟。只用本地射击，不调用AI，不花真钱。

存档新增可选happyClub version1：plays/day/spent/visits/visitStamp/nextId、六级tokens银行、active{id/day/startedAt/round}、最近20次history。旧档缺字段默认空。round保存RNG、已出现靶、路径/变形、命中、统计、时钟；恢复重建并重新检查布局。刷新不会退门票或重发Token；25秒使用真实时间，后台时间不免费暂停。命中/每秒/页面离开检查点保存；显式退出结算LEFT；Bomb/TIME保留已赚Token，结束只入账一次。损坏子记录安全舍弃并标恢复错误，不破坏整个旧档。导入到不匹配地点时封存该轮并保留验证过的Token，避免活动死锁。

测试：300种子核心及原布局校验通过；5100round保存/加载检查点，门票费用/次数/原生两击之间读档/结算唯一性/刷新/超时/旧档/坏记录/道路限制通过。真实浏览器1366/768/390三宽度正式界面原生点击、购票扣款、刷新保留active、第三轮后关闭与Token持久化通过。原公路旅行/连通/核心养成事务回归通过，以对应退出记录为证据。

尚未完成：六级物品转盘、wheelEligible排除和轻量保底、完整统计/成就/NPC/新闻及特殊活动。当前界面明确提示Token保留待奖池接入，不假发其他奖励。这批尚未公开发布；待下一批奖池连通后一起发布与公网验收。

修改：js/happyClub/location.js、round.js、core.js、ui.js、happy-club.css、js/state.js、engine.js、road/ui.js、navigationData.js、navigation.js、game.js、index.source.html与生成index.html；测试happy-club-save.test.cjs、happy-club-game-browser.cjs与总入口。

当前测试细分：happy-club-save、happy-club-round、公路旅行、道路连通以及三尺寸真实浏览器均退出0。核心引擎回归已通过前14个检查，最后100种子×35日长跑仍在执行中；未把整个核心回归预先标为退出0。
## 2026-10-08 补充验证
核心引擎15项（含100种子长期运行）已退出0。奖池/统计/人物后续变化见HAPPY-CLUB-BATCH3-REPORT，不再沿用此前“尚待接入奖池”作为当前结论。
