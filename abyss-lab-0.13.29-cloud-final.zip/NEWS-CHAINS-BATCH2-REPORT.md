# 独立新闻第二批 — 0.13.4-preview

本批新增5条已实现长链：16地铁重新开放、19通行证登记、22商队领队死亡、24官员更换、28悬赏登记。累计20/90，剩余70条。没有宣称完成整组16–30。

## 真实触发来源

- 16：地铁相邻原blocked路段由climate:repairRoad实际清除；普通维修和别处开放不触发。
- 19：真实事务使street.permits增加，新闻不重复签发许可证。
- 22：person_june在纪念册中有死亡记录且npcAlive=false；受伤、离队和临时接班不等于死亡。
- 24：person_elias死亡记录、npcSuccessor和存活接任者同时存在。
- 28：gang_case悬赏实际被接受；新闻不结算悬赏、不擅自击杀目标。

每条有初报、独立两选项、1–3游戏日等待、复查两选项、次日结案或超时。文本中英同步。除原纪念系统的一次性回馈外没有额外金钱奖励。

## 实际影响

入口标记消耗材料；维护站补燃料/登记站补食物/接任等候区补水使用实验室真实库存并转入当地储备。向接任者提供2食物可增加其独立信任3；原官员关系不复制。纪念调用原funeral入口，拒绝重复回馈。悬赏勘查耗2材料提高狩猎信心2，悬赏已处理时拒绝扣费。

## 文件

新增js/greenhouse/newsChainsBatch2.js、tests/news-chains-batch2.test.cjs、tests/news-batch2-browser.cjs。
修改js/greenhouse/newsChains.js、index.source.html、tests/news-chains.test.cjs、tools/test.cjs、package.json、CHANGELOG.md、TASK-AUDIT.md；重建index.html和公共发布包。

## 存档与验证

保持infirmary.newsChains.version=1，无删除或重置；记录容量从固定15改为已实现主题数量20，旧15条不丢失。缺失子状态旧档仍为空，不回溯扣旧日资源。

12组相关回归全部通过，包含原15链60组合、新5链20组合、旧档、重复、超时、资源不足、NPC死亡误报防护、过期对象、养成/剧情隔离、医疗、温室、武器存档和20章故事。

两套隔离浏览器测试通过：实际按钮/成本/纪念/接任信任、刷新、跨日跟进结案、英文、1366/768/390宽度、零pageerror。测试跨日使用隔离状态时钟；不宣称本轮完成整套主游戏端到端实日游玩。没有读取玩家真实存档。

## 未完成与下一步

17检查站、18配给政策、20宵禁、21失踪、23医生失踪、25劫匪首领死亡、26新帮派、27帮派分裂、29赏金猎人活动、30怪物迁移尚未具备足够的权威状态。需要先建立对应持久状态、行为影响和测试，再生成公告；不会将现有伤病、普通道路变更或任意日志当成这些事件。逐病平衡和历史大型扩展继续分批，配音由用户后续制作。公网AI未开放。

## 公开发布验收

GitHub Pages Run 51成功（29秒），commit cfb9b9c03b1cd7431395b0ae5adb30d159659fbe。公开网址 https://stepono927.github.io/Stephen/ 。部署后两套隔离浏览器流程再次全部通过，公开页面显示0.13.4-preview；截图 verification/news-batch2-public-desktop.png。发布文件仅index.html、CHANGELOG.md、TASK-AUDIT.md，无私密后台、API密钥或玩家存档。

