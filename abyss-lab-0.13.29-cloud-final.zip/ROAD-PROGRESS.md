## 0.10.0-preview — weather integration

Roads now read saved regional weather and persistent conditions, route around closures, show a departure brief and charge weather-adjusted fuel/wear. New closures can park an active trip safely. Collapsed bridges remain until repaired. Existing ownership, 39 destination entries, 67 links, bounds and minimap behavior are preserved. Details and remaining limitations: TASK-STATUS.md.

## Travel repair — 0.8.3-preview

Completed: distance-indexed route-specific scenery, visual interpolation, cached meshes, adaptive render resolution, suspended background lab painting; explicit garage ownership and no free starter in new saves; direct entry at all 39 destinations; 12 pixel room purposes and purpose-specific hospital/machine-room fixtures; small-screen/HUD fixes.

Save migration: Road v3 preserves old owned vehicles, route progress and other game state. Old automatic sedans are labeled legacy gifts instead of silently deleting them. New saves start with no vehicle, and purchase/recovery records its origin. A selected vehicle absent from the owned list is rejected on load and cannot drive.

Verification: full regression suite passes; real browser acquisition, trip arrival, safe-town entry, hospital entry, movement, exit and reload pass. 30/30 rendered cursor samples update. Under software WebGL, hiding the otherwise still-animated background laboratory lowered average test frame time from about 100ms to 18ms. Actual hardware frame rates may differ. Historical pending work is unchanged below.

## Controls repair — 0.8.2-preview

Completed: explicit cockpit departure controls; canvas keyboard focus restoration; immediate failure text; seat/resume without trip reset; clear standing controls and compact-car limits; upper-right minimap.

Verified in a browser: keyboard acceleration after destination selection, pointer-held throttle, parking/seating/resuming, standing and walking in a truck, map placement at desktop/mobile sizes, no overflow or page errors. These changes do not complete the earlier backlog below.

## Navigation update — 0.8.1-preview

Completed: 67 connected roads / 39 reachable destinations; protection-aware shortest routes; live position/heading minimap; hard shoulder limits; map ceiling boundary; roadside retarget and immediate arrival-save fixes; legacy route reconstruction without trip reset. Detours keep the map cursor in place.

Verified: graph connectivity at every location's tier, route bounds, moving pose, save/reload, legacy route migration, both shoulders, no arrival overshoot, immediate arrival persistence; browser driving and moving SVG arrow, cabin controls, pixel exploration, reload, 1366×768 / 1920×1080 / mobile widths, zero page errors. Original historical backlog below remains pending.

Limitation: route-based driving; no free off-road movement or manual junction turns.

# v0.8.0-preview · 2026-10-04 实际进度

这是可运行的开发预览，不代表所有历史需求已经完成。最后指令优先：后排恢复真正的 WebGL 3D，不再使用投影 SVG 后舱。

## 本轮完成

- 后舱使用透视相机、深度测试和三角形网格。支持可步行车型的 WASD 移动、Q/E 或拖动转头。小轿车与摩托保留座位视角，不能冒充可走动房车。
- 18 种载具定义：15 项性能、容积、单件尺寸上限、稀有度、内饰布局、维修记录与昵称。加速、刹车、极速、油耗已使用车型数据。
- 内饰分为露天货斗、货运舱、医疗舱、牢笼、金库运输、房车、广播指挥、行政、履带、研究等布局。厨房、床、电脑、柜体为独立立体结构。模型仍为程序化低多边形占位，不是18套完成美术。
- 运输尺寸 TINY / SMALL / MEDIUM / LARGE / OVERSIZED 接入新增遗物、家具装车和换车；摩托禁止大件，超跑额外检查最长边、重量和容积。所有旧库存的精确物理运输尚未统一。
- 载具回收接入设施记录、零件、商队护送和收藏物回收；部分仍为简化工程条件。超级隐藏车辆不提前显示名字。
- 39 个地图地点；七个重点地点使用不同的空间配置。其余关卡仍复用基础房间构造。可以真正横版移动、跳跃、攻击、防御、装填、开门、回收和撤退，支持探索中读档。
- 64 件探索专属装扮；不会由兑换码、普通商店或自动解锁发放。接入现有衣柜、穿戴与图层。
- 35 件遗物，每件独立中英文背景。艺术按表、笔、瓶、相机、唱片、母带、奖章、文件、硬币、眼珠等结构绘制，仍有同类共享基础结构。
- 遗物品质、商人偏好、异常拒收、出售/交换/保留/陈列/卸入实验室。8 项探索收藏成就，1 把 AK47，复用现有武器库与物品系统。
- 100 条公路观察、80 条地点观察、36 条 B-07 同行文字、20 条离家观察。它们主要是短观察事件，不是100个长篇独立支线。地点事件限定实际地点；七个重点地点的选项按事件内容编写。其他部分还需要继续提高叙事差异。
- 30 名主要人物的独立外形参数、30 个个人短事件及保存选择。120 名次要人物的当前活动重新区分；不称为120条完整任务线。

## 实际修复

没油仍能前移；原地救援刷日期；陈列切回保留刷物品；家具已在卧室摆放仍能重复装车；隐藏通道发现状态读档丢失；门锁不能阻挡移动；战斗路线选择不生效；破损武器仍能攻击；毒伤状态丢失；公路收入超过存档货币上限；人物短事件覆盖盗窃/替代者的重要回应；暂存帧错误声称已写盘。

## 存档

顶层仍为v4。新增 road.version=2；无公路字段的旧档建立默认状态，不清除已有养成、剧情、衣柜或库存。开发中的v1公路档可迁移；旧临时crawler房车映射为nomad。车辆、遗物、任务零件、地点、战斗、昵称和维修组件有读档校验。浏览器测试使用独立测试环境，没有清空玩家档。

## 验证

原有规则检查分批通过，包括100次长期养成、探索、衣柜、剧情、科技、颜色、居所、战斗、兑换/删档、跨代和API mock。新增公路专项通过18车型、旧存档、尺寸限制、移动/转头、关键漏洞和30名人物选择。实际浏览器覆盖1366×768、1920×1080、390宽度；车辆、横版移动、重载、商队、故事免费登记均通过。未调用付费AI。

## 仍未完成

- 927完整车主维修剧情、真实计时极速挑战、午夜赛道挑战，及完整的秘密车异常事件链。现有搜集旗标/守卫奖励不能冒充赛车任务。
- 18套完成外观和专属驾驶舱、正式纹理、全面家具碰撞、所有变异的3D形体、3D配饰精确合身、车内宠物寻路。
- 13部件均可记录和维修；目前磨损主要作用在发动机/轮胎，尚非13部件完整故障模拟。完整改装、拖车、音效、复杂追车与天气操控仍待做。
- 七大地点的长篇环境支线、分段Boss、全部旧物品物理装载、首次遗物专属长事件、全部NPC角色关系与法律/继任/家庭演变。
- 历史待办中的长梦境探索、完整连续性碰撞剧情、领导更替、继任照护者、云端AI等仍未全部完成。详见原 TASK-STATUS.md；不删除历史待办。

## 修改位置

新增 js/data/vehicleData.js、roadLayouts.js、roadData.js、roadRewards.js、roadEvents.js、npcDesigns.js、streetIdentity.js、streetCases.js；js/road/ 下 state、cargo、vehicles、core、map、combat、loot、webgl、pixel、art、ui、content 等模块；road.css。

集成修改 index.source.html、index.html、game.js、state.js、engine.js、redeem.js、bedroom.js、accessoryArt.js、accessoryModels.js、modeUI.js、legacy.js、npcModels.js、street.js、economyUI.js；语言包、构建文件和专项测试。完整结构说明见 ARCHITECTURE.md。
