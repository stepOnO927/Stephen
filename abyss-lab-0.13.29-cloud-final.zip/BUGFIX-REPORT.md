# 合并版检查与修复报告

检查日期：2026-10-02
修改对象：`merged-game/`，来自用户指定的 `abyss-lab-merged-game.zip`。保留原 ZIP，提供独立修复包。

## 本次确认及修复的问题

1. 远征进行中，喂食、训练、陪伴、实验、治疗、奖励、休息等实验室按钮仍显示为可操作，但引擎会拒绝命令。现在这些按钮同步禁用；其他入口尝试进入实验室玩法时会返回探索终端。
2. 探索获得饰品后，关闭探索终端没有继续处理待展示提示。现在终端关闭（包括 Escape）且远征已结束时，自动展示待处理事件、结局或饰品发现提示。
3. 打开探索终端没有关闭已有的主弹窗，可能形成两个模态窗口。现在打开前关闭主弹窗。
4. 浏览器测试仍断言存档版本为 2，并寻找已被新终端替代的旧探索按钮。更新为版本 3 和 `exp:start/choose/advance` 路径，补充远征期间按钮锁定、刷新续行、关闭重开和双桌面尺寸检查。

## 修改文件

- `js/ui.js`：远征期间按钮状态和入口保护。
- `js/expeditionUI.js`：模态窗口交接及终端关闭后提示恢复。
- `tests/browser.test.cjs`：修正合并后的测试预期，增加探索 UI 回归验证。
- `index.html`：通过现有构建脚本重新生成独立运行版本。
- `BUGFIX-REPORT.md`：本报告。
- `verification/`：实际浏览器截图。

没有重建架构或 UI，没有改变玩法数值；本次没有新增饰品系统，而是验证已有 Phase 2 实现及修复集成问题。

## Phase 2 实现核对

饰品共 50 件：常见 15、少见 12、稀有 10、史诗 7、传说 4、异常 2。七个槽位、衣橱、图鉴、商店、五个搭配预设、发现展示、隐藏套装、隐藏性格、结构化记忆均已存在并保留。

定义结构：`id, name, zh, description, rarity, slot, unlock, type, secret, lore, visual, alternatives`。
`visual` 包含 `layer, renderer, asset, color, accent, variant`。获得记录保存在 `collection.owned`，穿戴保存在 `collection.equipped`，不写回静态数据；因此 obtained/equipped 是从存档推导出的状态。

渲染顺序：glow → wings → accessory-back → body → shell → accessory-body → tail → accessory-tail → limbs → accessory-neck → horns → eyes → accessory-head → accessory-face → accessory-charm → tentacles → organs。饰品保持独立 SVG 图层，可通过 `visual.asset` 和绘制模块替换为 PNG/WebP。

存档沿用 `abyss-lab-save-v1` key 和版本 3；保留已有 v1/v2→v3 迁移，本次没有新增 schema 或修改迁移逻辑。测试验证旧养成存档和旧探索存档合并为统一库存后保留数据。

美术限制：50 件饰品仍为程序绘制的 SVG 占位图，没有正式 PNG/WebP 素材。音效保留 `abyss:accessory-reveal` 事件和 soundKey 接口，未加入真实音频。

## 验证结果

- 非浏览器测试：饰品 19 项、引擎 15 项、探索 15 项、完整合并流程 1 项，全部通过。引擎包括 100 组 seeded 长期模拟。
- Chrome 实际使用 file:// 打开生成的 index.html。
- 新游戏、装备/卸下、多槽位、存档重载、衣橱/图鉴、槽位/稀有度/拥有状态筛选、锁定剪影、发现饰品、预设保存/载入/重命名/删除、套装、所有 50 件图层、旧存档迁移通过。
- 实际按钮走完远征，刷新恢复远征、关闭重开终端、返航入库、返回后饰品提示通过。
- 主界面、衣橱、探索终端验证 1920×1080 与 1366×768；衣橱另验证 390×844 无横向页面溢出。查看桌面实际截图，未发现整体布局越界。
- 复制单独 index.html 到无资源文件目录后仍可运行。
- 浏览器 console error、pageerror、requestfailed 均为 0。

运行：直接打开 index.html。开发模块入口是 index.source.html；修改模块后执行 `node tools/build-local.cjs` 更新独立发布入口。
