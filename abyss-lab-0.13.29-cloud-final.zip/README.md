公开试玩：https://stepono927.github.io/Stephen/

最新交付与待办见 TASK-STATUS.md。公开静态版使用本地对白；localhost 保留服务器端 AI。两个网址的浏览器存档相互独立，可在设置导出/导入。

# ABYSS LAB · Unified game

An offline creature-care game that combines accessory collection and wardrobe features with multi-stage exploration, loot, world changes, and lore discoveries.

## Run

Open `index.html` in a current desktop browser. It is a self-contained portable build and needs no network connection or package install. Keep the file in a stable folder so the browser continues using the same local-storage origin. Use the in-game save export before moving the game or clearing browser data.

For source development, edit `index.source.html`, `style.css`, and `js/` modules, then run `node tools/build-local.cjs` to rebuild `index.html`.

## Play

The laboratory keeps the original feeding, training, experiments, care, loyalty, mutations, daily cycle, events, and save loop. Use the exploration terminal to visit five destinations, resolve up to three encounters, collect materials, and unlock world flags, hidden areas, documents, and expedition records. The wardrobe manages 50 accessories across seven equipment slots, an accessory archive, and five outfit presets. Accessory reactions, personality, and memories remain part of the creature state.

Exploration food loot and laboratory food stocks use a shared quantity inventory. Food recovered in the field can be transferred to its lab food key. Accessory records and lore documents remain distinct archive entries.

## Saves

The existing `abyss-lab-save-v1` local-storage key remains in use. New saves use schema version 4. Version 1 exploration, version 2 accessory, and version 3 combined saves migrate into the expanded state; creature values, food quantities, expedition progress, equipment, personality, and memories are retained. Each successful command auto-saves, including expedition progress.

## Verification

Run the checks from this directory:

```sh
node tests/engine.test.cjs
node tests/accessories.test.cjs
node tests/expedition.test.cjs
node tests/integration-flow.test.cjs
```

The browser test file uses Playwright, which is not bundled with this offline game.


## Phase 3 entry points

Open the footer Research button for the technology network, protocols, object identification, biological history and story archive. XP is earned through first discoveries, research-related actions and expeditions; repeated actions give less XP. Purchase nodes with Research Points and the existing inventory. Hidden branches appear only after discovery. Evolution observations and story choices persist when reloading.

The game remains 2D. Pseudo-3D items use SVG front/top/side faces, gradients and shadows; accessories retain independent layers with derived edge thickness. See PHASE3-REPORT.md for content counts, migration details and verification.
