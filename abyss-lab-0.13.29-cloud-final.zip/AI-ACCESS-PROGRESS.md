# AI权限与历史扩展进度 — 2026-10-06

已实施：server/access.cjs服务器端兑换/待审批/批准/暂停/封禁，独立权限记录，HttpOnly cookie，错误兑换频率限制，每人20请求/UTC日、全局100请求/UTC日，400输出token上限和现有输入限制。请求在API调用前授权和持久化用量，失败闭锁。失败请求仍占保守用量，不返还以免重复尝试扩大费用。这个请求上限不等于美元预算；实际费用还应使用平台预算监控。
server/admin.html主机后台 /ai-admin：仅localhost Host+loopback socket，SSE实时新申请通知，批准/封禁。打开后台才会即时看到通知；关闭后台时申请保留，重开可查看。不宣称手机/邮件通知。
前端交流界面增加独立AI兑换申请，不与物品兑换混用，不在HTML写入兑换码。不储存API Key；权限token是HttpOnly cookie，玩家存档不包含权限。管理员不靠游戏兑换码认证。
本机默认兑换码 Stephen114514（服务器端配置），可用CHAT_REDEEM_CODE覆盖。API Key仍仅服务器端既有OPENAI_API_KEY。server-private全部排除版本控制和公开静态服务。主机批准是安全边界，兑换码本身不是公开服务安全凭证。
测试7/7后端通过；真实Chromium隔离浏览器完成申请→SSE即时通知→批准→封禁；cookie不可由JS读到，无控制台错误，无付费API调用。修复测试accessFile:null原本错误退回实际文件路径，测试现已使用纯内存，初次合成记录已归档清空，仅处理确定为测试的记录，不碰玩家进度。

尚未完成公网部署：GitHub Pages只能承载静态游戏，目前仍本地备用对白。2026-10-06更新：Vercel和Supabase均已连接，账户均暂无项目；等待用户确认Supabase组织及费用后创建。异步数据库适配器与私有SQL定义已实现，本地Postgres测试通过，详见SUPABASE-AI-INTEGRATION.md。Vercel不能使用本机JSON持久文件；必须先实现数据库事务/全局预算原子计数、独立管理员身份与实时通知、跨域受控会话、秘密环境变量后再启用公开AI。当前server.js仍限制localhost，故不会把此原型直接暴露公网。

历史大型扩展剩余：见TASK-AUDIT.md。独立区域长剧情、阵营援助/背叛长线、聚落/法律/家庭/战争、继承照护者、完整梦境关卡、完整车辆模拟/挑战、精确运输及全部突变适配、永久NPC迁居、独立季节病谱仍未全部实现。本轮未擅改受保护剧情，也未把短文本/模板数量当成完成。
正式美术：9张用户提供CG已接入；其余人物/遗物/敌人/载具/家具正式插画与动作仍有缺口，需要按资源逐项制作或接入。用户先前要求不擅自作图的CG任务没有生成新图。

本轮文件：server.js、server/access.cjs、server/admin.html、js/creatureChat.js、style.css、.env.example、.gitignore、tests/ai-access.test.cjs、tests/ai-access-browser.cjs、tests/chat-server.test.cjs、tools/test.cjs、package.json、index.source.html、index.html、js/data/updateLog.js、CHANGELOG.md、TASK-AUDIT.md。公开Pages未改成可以收费调用AI。

封禁以服务器权限凭证为单位。换浏览器/清cookie可重新申请，但仍必须由主机再次批准，不能自行解封。既有物品兑换码不授予AI权限。主机本身在本机交流界面也需要申请后在后台批准，私有API不会被绕过。

完整tools/test.cjs回归已完成：62个测试模块全部通过；审批浏览器测试通过。没有付费AI调用。

