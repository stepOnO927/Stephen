# 独立靶子布局校验器

文件：`js/happyClub/TargetPlacementValidator.js`。
当前游戏已经在 `index.source.html` 中载入该模块；浏览器入口为 `Abyss.TargetPlacementValidator`。Node 可直接 `require()`，无需安装依赖。

统一校验出生位置、六档尺寸、safe gap、完整移动路径和 Bomb 额外 20% 间距。支持静止、折线、二阶/三阶 Bezier 和有限线性尺寸变化；不支持的轨迹或旋转返回失败。路径使用连续包络证明，不靠几个采样点假定安全。最多三个目标；批量出生全部通过才返回 SPAWN，失败无部分出生。

调用顺序：

1. `validate(candidate, scene)`，成功后保留返回的不可变 `plan`。
2. 每次移动及场地/遮挡改变时调用 `validateAdvance(plan, from, to, scene)`。
3. MOVE 按返回的 pose 绘制；PAUSE 保持当前 pose；HIDE 立即移除绘制和点击区域，返回 pose 为 null。
4. 多靶同帧出生使用 `validateBatch`，不能分别绕过预留路径。

坐标统一使用靶场局部 CSS 像素，不能混入设备 DPR 像素。场地的 `viewport` 与 UI/树干等 `uiBounds`、`foregroundBounds` 必须使用同一坐标系。已有目标使用同一校验器生成的 plan；序列化后须重新准备和验证。渲染不能自行添加未经验证的缩放或位移。

独立测试（安装 Node 后在解压目录运行）：

```text
node tests/target-placement-runtime.test.cjs
```

2026-10-08 本地验收：独立运行时测试、原几何测试的 229 条获准连续曲线、实际 Chrome 1366/768/390 宽各 183 个姿态全部通过。游戏源码 312 个本地资源可加载；已审定剧情和旧档兼容回归通过。测试使用隔离数据，没有读取玩家真实存档。

本次补丁统一非法移动请求的 HIDE/null-pose 返回值，并测试窗口缩小恢复、新增 UI/前景遮挡、未来/当前 Bomb 冲突、调用方修改输入、非零场地原点及小屏间距。

此包是独立代码与测试，不是完整游戏发布包。完整 Happy Club 的门票、25 秒挑战、击中计数、奖励转盘等尚未实现。现已随0.13.20-preview发布到 https://stepono927.github.io/Stephen/，独立Chrome公网校验通过。
