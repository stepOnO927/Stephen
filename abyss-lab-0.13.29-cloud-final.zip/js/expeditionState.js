'use strict';
Abyss.ExpeditionState=(()=>{
 const fresh=()=>({version:1,items:{},flags:{},documents:[],rooms:[],records:[],active:null,penalty:null});
 const ensure=s=>s.exploration||(s.exploration=fresh());
 const flags=['sewer_gate_open','factory_power_restored','forest_signal_detected','ruins_archive_unlocked','unknown_creature_seen','city_contact_met','mutation_resonance','pod_found','researcher_seen','radio_received','matching_footprints','elevator_found','object_awakened','anomaly_gate_open'];
 function validate(raw,s){
  if(raw==null)return fresh();
  if(raw.version!==1)throw Error('未知探索存档版本');
  const x=fresh(),D=Abyss.ExpeditionData;const num=(n,max=10000000)=>Number.isInteger(n)&&n>=0&&n<=max;
  for(const item of D.loot){const r=raw.items?.[item.id];if(!r)continue;if(!num(r.day,s.day)||typeof r.date!=='string')throw Error('探索物资数据无效');x.items[item.id]={day:r.day,date:r.date.slice(0,40),source:typeof r.source==='string'?r.source.slice(0,80):'未知',identified:r.identified===true,discovered:true};}
  for(const flag of flags)if(raw.flags?.[flag]===true)x.flags[flag]=true;
  x.documents=Array.isArray(raw.documents)?[...new Set(raw.documents.filter(id=>D.documents.some(d=>d.id===id)))]:[];
  x.rooms=Array.isArray(raw.rooms)?[...new Set(raw.rooms.filter(r=>D.locations.some(l=>l.rooms.some(n=>l.id+':'+n===r))))]:[];
  const sanitizeRecord=r=>({day:num(r.day,s.day)?r.day:s.day,location:D.locations.some(l=>l.id===r.location)?r.location:'sewers',steps:num(r.steps,3)?r.steps:0,condition:String(r.condition||'已返回').slice(0,40),loot:Object.fromEntries(D.loot.filter(i=>num(r.loot?.[i.id],100)).map(i=>[i.id,r.loot[i.id]])),notes:Array.isArray(r.notes)?r.notes.slice(0,20).filter(t=>typeof t==='string').map(t=>t.slice(0,300)):[],health:num(r.health,100)?r.health:0});
  x.records=Array.isArray(raw.records)?raw.records.slice(0,60).filter(r=>r&&typeof r==='object').map(sanitizeRecord):[];
  if(raw.penalty&&num(raw.penalty.until,s.day+2)&&num(raw.penalty.amount,15))x.penalty={until:raw.penalty.until,amount:raw.penalty.amount};
  if(raw.active){const a=raw.active,l=D.locations.find(l=>l.id===a.location),event=D.events.find(e=>e.id===a.event&&e.location===a.location);if(!l||!['departure','encounter','consequence','return'].includes(a.stage)||!num(a.steps,3)||!num(a.environment,20)||!num(a.day,s.day)||(a.stage!=='departure'&&!event))throw Error('远征进度无效');
   x.active={...sanitizeRecord(a),environment:a.environment,stage:a.stage,event:event?.id||null,seen:Array.isArray(a.seen)?[...new Set(a.seen.filter(id=>D.events.some(e=>e.id===id&&e.location===a.location)))]:[],result:typeof a.result==='string'?a.result.slice(0,500):'',forceReturn:a.forceReturn===true,day:a.day};delete x.active.condition;delete x.active.health;
  }return x;
 }
 return {fresh,ensure,validate,flags};
})();
Abyss.WorldState={getWorldFlag:(s,flag)=>Abyss.ExpeditionState.ensure(s).flags[flag]===true,setWorldFlag(s,flag,value=true){if(!Abyss.ExpeditionState.flags.includes(flag))throw Error('未注册世界标记');Abyss.ExpeditionState.ensure(s).flags[flag]=value===true;},unlockDocument(s,id){if(!Abyss.ExpeditionData.documents.some(d=>d.id===id))throw Error('未知档案');const x=Abyss.ExpeditionState.ensure(s);if(!x.documents.includes(id))x.documents.push(id);}};
