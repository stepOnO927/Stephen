'use strict';
// Lossless JSON key dictionary at the storage boundary; exports and live state stay unchanged.
((root,factory)=>{const codec=factory();if(typeof module==='object'&&module.exports)module.exports=codec;if(root.Abyss)root.Abyss.LocalStoreCodec=codec;})(typeof globalThis==='object'?globalThis:this,()=>{
 const FORMAT='abyss-local-keys-v2',LEGACY_FORMAT='abyss-local-keys-v1',MAX_KEYS=10000,MAX_NODES=2000000,MAX_DEPTH=160;
 const leaf=v=>v===null||typeof v==='string'||typeof v==='boolean'||typeof v==='number'&&Number.isFinite(v);
 function pack(value){const keys=[],indices=new Map(),counts=new Map(),strings=[],stringIndices=new Map();let nodes=0;
  const count=(v,depth)=>{if(++nodes>MAX_NODES||depth>MAX_DEPTH)throw new RangeError('Local save exceeds structural limits');if(typeof v==='string'){if(v.length>=12)counts.set(v,(counts.get(v)||0)+1);return;}if(leaf(v))return;if(!v||typeof v!=='object')throw new TypeError('Local save must contain JSON values');for(const item of Array.isArray(v)?v:Object.values(v))count(item,depth+1);};count(value,0);
  for(const [text,total]of counts){const index=strings.length;if(index>=MAX_KEYS)break;const referenceLength=6+String(index).length;if(total>=3&&total*(JSON.stringify(text).length-referenceLength)>JSON.stringify(text).length+2){strings.push(text);stringIndices.set(text,index);}}nodes=0;
  const walk=(v,depth)=>{if(++nodes>MAX_NODES||depth>MAX_DEPTH)throw new RangeError('Local save exceeds structural limits');if(typeof v==='string'&&stringIndices.has(v))return {s:stringIndices.get(v)};if(leaf(v))return v;if(!v||typeof v!=='object')throw new TypeError('Local save must contain JSON values');if(Array.isArray(v))return Array.from(v,x=>walk(x,depth+1));
   const pairs=Object.entries(v).map(([key,item])=>{if(!indices.has(key)){if(keys.length>=MAX_KEYS)throw new RangeError('Too many local save keys');indices.set(key,keys.length);keys.push(key);}return [indices.get(key),walk(item,depth+1)];});return pairs.length>=4?{o:pairs.flatMap(pair=>pair)}:Object.fromEntries(pairs);
  };return {format:FORMAT,keys,strings,data:walk(value,0)};
 }
 function unpack(raw){if(raw?.format!==FORMAT&&raw?.format!==LEGACY_FORMAT)return raw;
  const strings=raw.format===FORMAT?raw.strings:[];if(!Array.isArray(strings)||strings.length>MAX_KEYS||strings.some(s=>typeof s!=='string'||s.length>1000000)||new Set(strings).size!==strings.length)throw new TypeError('Invalid local save text dictionary');
  if(!Array.isArray(raw.keys)||raw.keys.length>MAX_KEYS||raw.keys.some(k=>typeof k!=='string'||k.length>10000)||new Set(raw.keys).size!==raw.keys.length||!Object.hasOwn(raw,'data'))throw new TypeError('Invalid local save dictionary');let nodes=0;
  const walk=(v,depth)=>{if(++nodes>MAX_NODES||depth>MAX_DEPTH)throw new RangeError('Local save exceeds structural limits');if(leaf(v))return v;if(!v||typeof v!=='object')throw new TypeError('Invalid local save value');if(Array.isArray(v))return Array.from(v,x=>walk(x,depth+1));if(raw.format===FORMAT&&Object.hasOwn(v,'s')){if(Object.keys(v).length!==1||!Number.isSafeInteger(v.s)||v.s<0||v.s>=strings.length)throw new TypeError('Invalid local save text reference');return strings[v.s];}
   if(raw.format===FORMAT&&Object.hasOwn(v,'o')){if(Object.keys(v).length!==1||!Array.isArray(v.o)||v.o.length%2!==0||v.o.length>MAX_KEYS*2)throw new TypeError('Invalid local save object');const pairs=[],used=new Set();for(let i=0;i<v.o.length;i+=2){const code=v.o[i];if(!Number.isSafeInteger(code)||code<0||code>=raw.keys.length||used.has(code))throw new TypeError('Invalid local save object key');used.add(code);pairs.push([raw.keys[code],walk(v.o[i+1],depth+1)]);}return Object.fromEntries(pairs);}
   return Object.fromEntries(Object.entries(v).map(([code,item])=>{if(!/^(0|[1-9]\d*)$/.test(code)||!Number.isSafeInteger(Number(code))||Number(code)>=raw.keys.length)throw new TypeError('Invalid local save key reference');return [raw.keys[Number(code)],walk(item,depth+1)];}));
  };return walk(raw.data,0);
 }
 function stringify(value){const plain=JSON.stringify(value),packed=JSON.stringify(pack(JSON.parse(plain)));return packed.length<plain.length?packed:plain;}
 return Object.freeze({FORMAT,LEGACY_FORMAT,pack,unpack,stringify});
});
