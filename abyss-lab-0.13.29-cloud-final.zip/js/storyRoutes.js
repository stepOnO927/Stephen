'use strict';
// Ordered gates within the player's chosen decision. Scores never select an ending alone.
Abyss.StoryRoutes=(()=>{
 const rules=[
  {decision:'continue',ending:'observer',priority:100,when:(s,v,f)=>f.HOST_TRIGGER&&v.HOST_ROUTE_INSTABILITY>=15},
  {decision:'destroy',ending:'grey_tide',priority:90,when:(s,v,f)=>f.SECOND_GREY_TIDE},
  {decision:'copy',ending:'no_record',priority:90,when:(s,v,f)=>f.IRREVERSIBLE_ERASURE},
  {decision:'leave',ending:'proof',priority:90,when:(s,v,f)=>f.IRREVERSIBLE_ERASURE&&f.READ_photo},
  {decision:'leave',ending:'no_name',priority:90,when:(s,v,f)=>f.IRREVERSIBLE_ERASURE&&!f.READ_photo},
  {decision:'leave',ending:'last_human',priority:95,when:s=>!s.campaign.creatureAlive},
  {decision:'autonomy',ending:'black_sun',priority:90,when:(s,v,f)=>f.IRREVERSIBLE_ERASURE&&v.JACK_NIHILISM>=12},
  {decision:'leave',ending:'we',priority:80,when:(s,v,f)=>f.ZERO_CHAMBER&&v.CONTINUITY_SCORE>=12&&v.WORLD_ABYSS_KNOWLEDGE>=24&&v.B07_TRUST>=12&&v.B07_AUTONOMY>=12&&!f.IRREVERSIBLE_ERASURE},
  {decision:'leave',ending:'sea',priority:70,when:(s,v,f)=>s.story.promises.promise_sea==='kept'&&f.COAST_UNLOCKED&&v.B07_TRUST>-15},
  {decision:'continue',ending:'betrayal',priority:70,when:(s,v)=>s.story.scores.betrayal>=50&&s.story.lies.length>=3},
  {decision:'autonomy',ending:'zero',priority:70,when:(s,v,f)=>f.READ_zero&&v.ZERO_AWARENESS>=24&&v.B07_IDENTITY>=8},
  {decision:'settle',ending:'ordinary_day',priority:70,when:(s,v,f)=>f.EVENING_radio&&f.EVENING_stay&&v.WORLD_HUMANITY>=15},
  {decision:'settle',ending:'first_memory',priority:60,when:(s,v,f)=>f.READ_photo&&v.B07_TRUST>=20&&v.B07_ATTACHMENT>=15},
  {decision:'settle',ending:'after_abyss',priority:60,when:(s,v,f)=>f.EDEN_CONSENT&&v.JACK_COMPASSION>=25&&v.WORLD_ABYSS_KNOWLEDGE>=24},
  {decision:'continue',ending:'long_life',priority:60,when:(s,v,f)=>f.READ_photo&&v.WORLD_STABILITY>=15&&v.B07_HOPE>=25},
  {decision:'continue',ending:'observer',priority:50,when:(s,v)=>v.B07_RESENTMENT>=60},
  {decision:'creature',ending:'symbiosis',priority:50,when:()=>true},
  {decision:'seal',ending:'ascension',priority:50,when:()=>true},
  {decision:'eden',ending:'new_eden',priority:50,when:(s,v,f)=>f.EDEN_CONSENT&&v.WORLD_STABILITY>=0},
  {decision:'sacrifice',ending:'together_end',priority:50,when:(s,v)=>v.B07_ATTACHMENT>=25&&v.JACK_SELF_SACRIFICE>=12},
  {decision:'settle',ending:'small_world',priority:40,when:s=>s.story.scores.small_world>=20},
  {decision:'leave',ending:'abandonment',priority:40,when:(s,v)=>v.B07_TRUST<-15},
  {decision:'autonomy',ending:'fledgling',priority:0,when:()=>true},
  {decision:'eden',ending:'green_hell',priority:0,when:()=>true},
  {decision:'sacrifice',ending:'last_creature',priority:0,when:()=>true},
  {decision:'settle',ending:'home',priority:0,when:()=>true},
  {decision:'leave',ending:'together',priority:0,when:()=>true},
  {decision:'continue',ending:'continuation',priority:0,when:()=>true}
 ];
 function ending(s,decision){return rules.filter(r=>r.decision===decision&&r.when(s,s.story.values,s.story.flags)).sort((a,b)=>b.priority-a.priority)[0]?.ending||'continuation';}
 return {rules,ending};
})();
