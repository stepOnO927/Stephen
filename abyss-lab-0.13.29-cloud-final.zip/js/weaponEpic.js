 'use strict';
// Fight-local Epic mechanics; each trigger is bounded and saveable.
Abyss.WeaponEpic=(()=>{
 const R=Abyss.WeaponRare,has=(f,id)=>f?.enemyStatus?.some(x=>x.id===id&&x.turns>0),rank=R.rank;
 const designs={
 weapon_fang:["恢复效率提高","实验体同行时恢复效率增加","攻击提高8%","同伴重伤后下一次命中恢复Jack健康","队友低生命时恢复效率增加","每场一次队友危险生命时短暂强化攻击恢复和防御"],
 ud_weapon_14:["链电概率提高","第二目标链电伤害提高","链电射程提高","链电有概率短暂打断第二目标","暴击链电伤害提高","首次链电清除第二目标护盾并产生风暴打断"],
 weapon_road_ak47:['后坐影响降低','首次交战稳定性提高','连续命中逐渐增伤，最多五层','弹匣剩余三发以内暴击提高','实验体低生命时短暂提高攻击','每场一次受重创后短暂坚守'],
 weapon_needle:['连续命中叠刺','第三次命中附加弱刺','动作时间−8%','三层后破甲','刺层上限提升至6','满层刺群爆发并回落'],
 weapon_staff:['状态抗性+10%','科技伤害后两回合防御提升','攻击+10%','抵抗状态后下一击放电','抗性再+10%','首次科技干扰免疫并获得放电窗口'],
 weapon_blade:['低生命阈值提高到45%','低生命暴击穿透+15%','动作时间−8%','单目标决斗攻击和闪避提升','低生命暴击伤害+12%','首次低于20%生命，三回合绝境强化'],
 weapon_flail:['破甲+10%','命中积累破甲惯性','动作时间−7%','破甲目标伤害+12%','格挡破坏+12%','满惯性机械目标额外削弱防御'],
 weapon_thorn:['毒伤+1','中毒目标命中叠加荆毒','动作时间−7%','减速目标毒伤增强','状态穿透+12%','满毒层下一箭爆发并刷新毒'],
 weapon_glassfang:['破甲+10%','暴击附加三回合防御裂纹','动作时间−8%','裂纹目标弱点伤害+15%','暴击穿透+12%','首次高额暴击碎盾或削甲'],
 weapon_scatter:['护盾伤害+12%','近距离破甲+15%','攻击+10%','命中护盾概率硬直','格挡破坏+15%','首次近距装甲命中，三类破坏强化'],
 ud_weapon_12:['格挡破坏+12%','命中格挡目标强化下一击','攻击+10%','破盾附加防御裂纹','护盾伤害+18%','首次破盾获得一次快速后续重击'],
 ud_weapon_13:['机械伤害+12%','机械命中标记弱点','射程+5%','机械暴击附加防御裂纹','破甲+12%','首次机械精英命中识别强弱点'],
 ud_weapon_15:['债务层增伤','每次命中积累两层债务','动作时间−8%','三层债务暴击穿透+12%','清账爆发增强','满债务下一击清账并短暂加速']};
 const translated={weapon_fang:['Improved recovery','Recovery improves while B-07 participates','Eight percent increased attack','A heavy ally wound lets the next hit heal Jack','Low-health allies improve recovery','Once per battle, an endangered ally briefly strengthens attack, recovery and defense'],ud_weapon_14:['Increased chain chance','Increased damage to the second target','Increased chain range','Chains may interrupt the second target','Critical chains deal more damage','The first chain clears the second shield and triggers a storm interruption']};const dictionary={};for(const [id,lines]of Object.entries(translated))designs[id].forEach((v,i)=>dictionary[v]=lines[i]);Abyss.I18n.register(dictionary);
 for(const w of Abyss.WeaponData.weapons)if(designs[w.id])w.epicResonance=designs[w.id];
 function stats(s,w,f={},e={}){f=f||{};e=e||{};if(w?.id==='weapon_fang')return Abyss.CombatParty.stats(s,w,f);if(w?.id==='weapon_road_ak47')return Abyss.WeaponFirearm.stats(s,w,f);const r=rank(s,w),o={};if(!designs[w?.id])return o;const low=f.hp<f.maxHp*.45,mech=R.mechanical(e),stacks=f.weaponStacks||0;
 switch(w.id){
 case 'ud_weapon_14':if(r>=3)o.range=1.1;break;
 case 'weapon_needle':if(r>=1)o.damage=1+stacks*.025;if(r>=3)o.time=.92;if(r>=4&&stacks>=3)o.armorPen=.15;break;
 case 'weapon_staff':if(r>=1)o.resist=.1+(r>=5?.1:0);if(r>=3)o.attack=.1;if(f.weaponGroundUntil>=f.turn)o.defense=.18;break;
 case 'weapon_blade':if(r>=1&&low)o.damage=1.25;if(r>=2&&low)o.critPen=.15;if(r>=3)o.time=.92;if(r>=4){o.damage=(o.damage||1)*1.08;o.dodge=.05;}if(r>=5&&low)o.critDamage=.12;if(r>=6&&f.weaponDesperateUntil>=f.turn){o.damage=(o.damage||1)*1.2;o.critPen=(o.critPen||0)+.15;o.guardBreak=.2;}break;
 case 'weapon_flail':if(r>=1)o.armorPen=.1+(r>=2?stacks*.04:0);if(r>=3)o.time=.93;if(r>=4&&has(f,'break'))o.damage=1.12;if(r>=5)o.guardBreak=.12;break;
 case 'weapon_thorn':if(r>=3)o.time=.93;if(r>=5)o.statusPen=.12;break;
 case 'weapon_glassfang':if(r>=1)o.armorPen=.1;if(r>=3)o.time=.92;if(r>=4&&f.weaponCrackUntil>=f.turn){o.weak=true;o.weakPointDamage=.15;}if(r>=5)o.critPen=.12;break;
 case 'weapon_scatter':if(r>=1)o.shieldDamageBonus=.12;if(r>=2&&(f.distance??2.5)<=2)o.armorPen=.15;if(r>=3)o.attack=.1;if(r>=5)o.guardBreak=.15;if(r>=6&&(f.distance??2.5)<=2&&R.defenses(e).armor>0&&!f.weaponFortressUsed){o.shieldDamageBonus+=.3;o.armorPen=(o.armorPen||0)+.3;o.guardBreak=(o.guardBreak||0)+.3;}break;
 case 'ud_weapon_12':if(r>=1)o.guardBreak=.12;if(r>=3)o.attack=.1;if(r>=5)o.shieldDamageBonus=.18;if(f.weaponNextHeavy)o.damage=1.15;if(f.weaponFastFollow)o.time=.55;break;
 case 'ud_weapon_13':if(r>=1&&mech)o.damage=1.12;if(r>=3)o.range=1.05;if(r>=5)o.armorPen=.12;if(f.weaponMagnetUntil>=f.turn){o.weak=true;o.weakPointDamage=.15;}if(f.weaponOverrideUntil>=f.turn){o.weak=true;o.weakPointDamage=(o.weakPointDamage||0)+.3;}break;
 case 'ud_weapon_15':if(r>=1)o.damage=1+(f.weaponDebt||0)*.025;if(r>=3)o.time=.92;if(r>=4&&f.weaponDebt>=3)o.critPen=.12;if(f.weaponAccountUntil>=f.turn)o.time=.72;break;
 }
 if(f.weaponCrackUntil>=f.turn)o.defensePen=(o.defensePen||0)+.18;return o;
 }
 function beforeHit(s,w,f,e){const r=rank(s,w);if(w?.id==='ud_weapon_13'&&r>=6&&R.mechanical(e)&&e.elite&&!f.weaponOverrideUsed){f.weaponOverrideUsed=true;f.weaponOverrideUntil=f.turn+3;}}
 function hit(s,w,f,e,n,crit,shieldBefore){const r=rank(s,w);if(!r||!designs[w?.id])return n;const add=id=>{const x=f.enemyStatus.find(v=>v.id===id);if(x)x.turns=3;else f.enemyStatus.push({id,turns:3});};
 switch(w.id){
 case 'weapon_road_ak47':Abyss.WeaponFirearm.hit(w,f);break;
 case 'weapon_needle':{const cap=r>=5?6:4,st=f.weaponStacks||0;if(r>=6&&st>=cap){n+=Math.round(n*.45);f.weaponStacks=2;f.logs.push('THORN BLOOM');}else{f.weaponStacks=Math.min(cap,st+1);if(r>=2&&f.weaponStacks%3===0)n+=Math.round(n*.15);}break;}
 case 'weapon_staff':if(f.weaponDischarge){n+=Math.round(n*.18);f.weaponDischarge=false;}break;
 case 'weapon_flail':if(r>=6&&f.weaponStacks>=4&&R.mechanical(e)){f.weaponCrackUntil=f.turn+2;f.weaponStacks=0;f.logs.push('MACHINE EATER');}else if(r>=2)f.weaponStacks=Math.min(4,(f.weaponStacks||0)+1);break;
 case 'weapon_thorn':if(has(f,'poison')&&r>=2){if(r>=6&&f.weaponPoisonStacks>=4){n+=Math.round(n*.4);f.weaponPoisonStacks=1;add('poison');f.logs.push('THORN GARDEN');}else f.weaponPoisonStacks=Math.min(4,(f.weaponPoisonStacks||0)+1);}break;
 case 'weapon_glassfang':if(crit&&r>=2)f.weaponCrackUntil=f.turn+3;if(crit&&r>=6&&n>=35&&!f.weaponShatterUsed){f.weaponShatterUsed=true;if(f.enemyShield>0)f.enemyShield=Math.max(0,f.enemyShield-20);else f.weaponArmor=Math.min(.3,(f.weaponArmor||0)+.2);f.logs.push('BREAK CLEAN');}break;
 case 'weapon_scatter':if(shieldBefore>0&&r>=4&&Abyss.Util.random(s)<.25)add('stun');if(r>=6&&(f.distance??2.5)<=2&&R.defenses(e).armor>0)f.weaponFortressUsed=true;break;
 case 'ud_weapon_12':f.weaponFastFollow=false;if(r>=2){const next=shieldBefore>0||e.behavior==='defensive';f.weaponNextHeavy=next;}if(shieldBefore>0&&f.enemyShield<=n){if(r>=4)f.weaponCrackUntil=f.turn+3;if(r>=6&&!f.weaponGateUsed){f.weaponGateUsed=true;f.weaponFastFollow=true;f.logs.push('NO GATE HOLDS FOREVER');}}break;
 case 'ud_weapon_13':if(R.mechanical(e)){if(r>=2)f.weaponMagnetUntil=f.turn+3;if(r>=4&&crit)f.weaponCrackUntil=f.turn+3;}break;
 case 'ud_weapon_15':if(f.weaponDebt>=5){n=Math.round(n*(r>=6?1.7:r>=5?1.5:1.35));f.weaponDebt=0;if(r>=6)f.weaponAccountUntil=f.turn+2;f.logs.push('SETTLE THE ACCOUNT');}else f.weaponDebt=Math.min(5,(f.weaponDebt||0)+(r>=2?2:1));break;
 }return n;}
 function received(s,w,f,e,damage){Abyss.WeaponFirearm.received(s,w,f,damage);const r=rank(s,w);if(w?.id==='weapon_staff'&&r>=2&&R.mechanical(e))f.weaponGroundUntil=f.turn+2;if(w?.id==='weapon_blade'&&r>=6&&f.hp<f.maxHp*.2&&!f.weaponDesperateUsed){f.weaponDesperateUsed=true;f.weaponDesperateUntil=f.turn+3;f.logs.push('BOW BEFORE DEATH');}}
 function resist(s,w,f,e,id,rolled){const r=rank(s,w);if(w?.id==='weapon_staff'&&r>=6&&['stun','weaken'].includes(id)&&R.mechanical(e)&&!f.weaponInsulated){f.weaponInsulated=true;f.weaponDischarge=true;f.logs.push('PERFECT INSULATION');return true;}if(rolled&&w?.id==='weapon_staff'&&r>=4)f.weaponDischarge=true;return rolled;}
 function poison(s,w,f){const r=rank(s,w);return w?.id==='weapon_thorn'&&r>=1?4+(r>=2?f.weaponPoisonStacks||0:0)+(r>=4&&has(f,'slow')?2:0):3;}
 function miss(w,f){Abyss.WeaponFirearm.miss(w,f);if(designs[w?.id]){f.weaponStacks=0;if(w.id==='ud_weapon_15')f.weaponDebt=0;}}
 return {designs,stats,beforeHit,hit,received,resist,poison,miss};
})();
