'use strict';
Abyss.StoryVoices=(()=>{
 const stages=[0,0,1,1,2,2,2,3,3,4,4,4,4,4,4,5,5,5,5,5];
 function stage(s){return s.mode==='story'?stages[Math.min(19,s.narrative.chapter)]||0:Math.min(5,s.narrative.languageStage||0);}
 function grow(s){const n=s.narrative;n.b07LanguageStage=Math.max(n.b07LanguageStage||0,stage(s));return n.b07LanguageStage;}
 const corrections={project_sky:{19:['带去看？','Go see it?']},project_red_thread:{17:['Jasmine也疼？','Jasmine hurts too?']},project_bseries:{20:['记下来。','Write it down.']},project_mia:{1:['她的名字在纸上。你还找吗？','Her name is on the paper. Are you still looking?'],5:['找不到她的时候，你也会检查门？','When you cannot find her, do you check the door too?']},project_open_door:{39:['那先别说。','Then do not speak yet.']}};
 function apply(){for(const [id,beats]of Object.entries(corrections)){const node=Abyss.NarrativeData.nodes.find(n=>n.id===id);for(const [i,pair]of Object.entries(beats))if(node?.lines?.[i])node.lines[i].text=Abyss.JackData.tr(...pair);}}
 function text(s,b,node,source){if(s.mode!=='story'||b?.speaker!=='creature')return source;const voice=node?.presentationLanguageStage??grow(s);if(voice===0&&source.length>8&&!source.includes('{firstWord}'))return Abyss.HomeData.t('……嗯。','...Mm.');if(voice===1&&source.length>24)return b.simple||Abyss.HomeData.t('这个，为什么？','This. Why?');if(voice===2&&source.length>45)return b.simple||Abyss.HomeData.t('你说的，是真的吗？','Is what you said true?');return source;}
 apply();return {stages,stage,grow,text};
})();
