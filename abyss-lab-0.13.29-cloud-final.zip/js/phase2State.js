'use strict';
// Version-2 extension schema. Legacy gameplay fields remain owned by State.
Abyss.Phase2State = (() => {
 const traits=['curious','timid','aggressive','affectionate','independent','mischievous','calm','vengeful'];
 const memoryIds=['saved_life','starved','first_accessory','first_exploration','severe_experiment','first_evolution','escaped','favorite_food'];
 function defaults(seed=1,day=1) {
  const owned={};let sequence=0;
  for(const a of Abyss.Data.accessories.filter(a=>a.unlock.type==='starter'))owned[a.id]={day,order:++sequence,source:'实验室迎新物资',date:null};
  return {
   collection:{owned,equipped:Object.fromEntries(Object.keys(Abyss.Data.slots).map(k=>[k,null])),presets:[],discoveredSets:[],reveals:[],visits:{sewer:0,factory:0,forest:0,city:0,ruins:0},sequence,rng:(seed^0x5f3759df)>>>0||1,changes:0,lastReactionDay:0,merchantUntil:0},
   personality:Object.fromEntries(traits.map(t=>[t,t==='curious'?12:5])),
   memories:[{id:'first_accessory',firstDay:day,lastDay:day,count:1,detail:'实验室为它准备了研究帽、软项圈与身份铭牌。'}],favoriteFood:'fruit'
  };
 }
 function read(raw,s) {
  const base=defaults(s.rng,s.day);
  if(raw.version===1){
   base.personality.affectionate=Math.min(80,5+s.history.care*2);
   base.personality.curious=Math.min(80,12+s.history.explore+s.history.train);
   base.personality.vengeful=Math.min(80,5+s.resentment);
   base.personality.timid=Math.min(80,5+s.history.experiment*2);
   for(const [yes,id,text] of [[s.history.explore>0,'first_exploration','旧记录确认：曾一起探索。'],[!!s.form,'first_evolution','旧记录确认：已见证成熟。'],[!!s.awaySince,'escaped','旧记录确认：它正离开培养舱。']])if(yes)base.memories.push({id,firstDay:s.day,lastDay:s.day,count:1,detail:text});
   base.collection.merchantUntil=(s.eventDays.merchant||-10)+2;
   base.collection.merchantUntil=Math.max(0,base.collection.merchantUntil);
   return base;
  }
  const c=raw.collection;
  if(!c||typeof c!=='object'||!c.owned||!c.equipped||!Array.isArray(c.presets))throw new Error('饰品存档结构无效');
  const integer=(n,min=0,max=10000000)=>Number.isInteger(n)&&n>=min&&n<=max;
  const safe=(n,fallback=0,max=10000000)=>integer(n,0,max)?n:fallback;
  const out=base.collection;out.owned={};
  for(const a of Abyss.Data.accessories){const record=c.owned[a.id];if(!record)continue;
   if(!integer(record.day,1,s.day)||!integer(record.order,1))throw new Error('饰品获取记录无效');
   out.owned[a.id]={day:record.day,order:record.order,source:typeof record.source==='string'?record.source.slice(0,150):'旧档案',date:typeof record.date==='string'?record.date.slice(0,40):null};
  }
  const outfit=input=>Object.fromEntries(Object.keys(Abyss.Data.slots).map(slot=>{const id=input?.[slot];return [slot,out.owned[id]&&Abyss.Data.accessories.some(a=>a.id===id&&a.slot===slot)?id:null];}));
  out.equipped=outfit(c.equipped);
  out.presets=c.presets.slice(0,5).filter(p=>p&&integer(p.id,1,5)).map(p=>({id:p.id,name:typeof p.name==='string'?p.name.trim().slice(0,24)||`OUTFIT 0${p.id}`:`OUTFIT 0${p.id}`,outfit:outfit(p.outfit)})).filter((p,i,list)=>list.findIndex(x=>x.id===p.id)===i);
  out.reveals=Array.isArray(c.reveals)?[...new Set(c.reveals.filter(id=>out.owned[id]))].slice(0,200):[];
  out.discoveredSets=Array.isArray(c.discoveredSets)?[...new Set(c.discoveredSets.filter(id=>Abyss.Data.outfitSets.some(set=>set.id===id)))]:[];
  for(const place of Object.keys(out.visits))out.visits[place]=safe(c.visits?.[place]);
  out.sequence=Math.max(safe(c.sequence),...Object.values(out.owned).map(r=>r.order),0);
  out.rng=integer(c.rng,1,4294967295)?c.rng:out.rng;
  out.changes=safe(c.changes);out.lastReactionDay=safe(c.lastReactionDay,0,s.day);out.merchantUntil=safe(c.merchantUntil);
  for(const trait of traits)base.personality[trait]=safe(raw.personality?.[trait],base.personality[trait],100);
  base.memories=Array.isArray(raw.memories)?raw.memories.slice(0,32).filter(m=>m&&memoryIds.includes(m.id)&&integer(m.firstDay,1,s.day)&&integer(m.lastDay,m.firstDay,s.day)).map(m=>({id:m.id,firstDay:m.firstDay,lastDay:m.lastDay,count:safe(m.count,1),detail:typeof m.detail==='string'?m.detail.slice(0,200):''})).filter((m,i,list)=>list.findIndex(x=>x.id===m.id)===i):base.memories;
  base.favoriteFood=Abyss.Data.foods.some(f=>f.id===raw.favoriteFood)?raw.favoriteFood:'fruit';
  return base;
 }
 return {defaults,read,traits,memoryIds};
})();
