
'use strict';
// UI routes refer to existing controllers. No gameplay state belongs here.
Abyss.NavigationData = [
 ['home','⌂','主页','HOME',[]],
 ['life','♡','生活','LIFE',[
  ['care','照料','Care','care'],['talk','交流','Talk','chat'],['training','训练','Training','train'],['pets','住户','Pets','pets'],['habits','习惯与记忆','Habits & Memories','interactions'],['relationships','关系','Relationships','people'],['bedroom','卧室','Bedroom','bedroom'],['legacy','生命档案','Legacy','legacy'],['dreams','梦境','Dreams','dreams']]],
 ['explore','⌁','探索','EXPLORE',[
  ['map','区域地图','Regional Map','regionmap'],['roads','公路与车库','Roads & Garage','roads'],['happyClub','快乐俱乐部','Happy Club','happyClub'],['expedition','远征','Expeditions','explore'],['inventory','探索库存','Inventory','inventory'],['caravans','商队','Caravans','caravans'],['sites','资源地点','Resource Sites','regionmap']]],
 ['combat','⚔','战斗','COMBAT',[
  ['weapons','武器与配装','Weapons & Loadout','weapons'],['training','招式训练','Combat Training','combatTraining'],['bounties','悬赏','Bounties','bounties'],['bestiary','遭遇档案','Bestiary','bestiary'],['records','战斗记录','Combat Records','combatRecords'],['hunt','狩猎','Hunt','hunt']]],
 ['lab','◇','实验室','LAB',[
  ['operations','运营日报','Lab Operations','operations'],
  ['greenhouse','温室','Greenhouse','greenhouse'],['homestead','养殖区','Homestead','homestead'],['infirmary','医务室','Infirmary','infirmary'],
  ['research','研究协议','Research','protocols'],['tech','科技网络','Technology','research'],['experiments','实验','Experiments','experiment'],['mutations','突变','Mutations','mutations'],['evolution','进化','Evolution','evolution'],['containment','设施','Facilities','home'],['anomalies','异常物件','Anomalies','objects'],['serums','药剂','Serums','serums']]],
 ['collection','▧','收藏','COLLECTION',[
  ['storyCG','剧情插画','Story CG','storyCG'],['wardrobe','衣橱','Wardrobe','wardrobe'],['draw','回收抽奖','Salvage Draw','draw'],['colors','体色','Colors','colors'],['cosmetics','外观','Cosmetics','collection'],['wallpapers','壁纸','Wallpapers','wallpapers'],['valuables','变卖物','Valuables','valuables'],['furniture','家具','Furniture','bedroom'],['relics','世界遗物','World Relics','relics'],['goods','随身旧物','Goods','goods'],['achievements','成就','Achievements','achievements'],['archive','档案','Archive','archive'],['continuity','连续性','Continuity','continuity']]],
 ['world','◎','世界','WORLD',[
  ['news','废土新闻','Wasteland News','news'],['underground','地下经济','Underground Economy','underground'],['memorial','纪念与救助','Memorial & Relief','memorial'],['climate','季节与天气','Seasons & Weather','climate'],['people','街道上的人','People','street'],['settlements','聚落与声望','Settlements & Reputation','wasteland'],['factions','阵营与商路','Factions & Trade','caravans'],['personnel','人物档案','Personnel','personnel'],['journal','Jack 的日记','Jack’s Journal','journal'],['story','调查与主线','Story & Investigation','storyFiles']]],
 ['system','⚙','系统','SYSTEM',[
  ['records','记录与模式','Saves & Modes','savesMenu'],['settings','设置与语言','Settings & Language','settings'],['redeem','兑换码','Codes','redeem'],['guide','帮助','Help','guide'],['updates','更新日志','Updates','updates'],['credits','制作组','Credits','credits']]]
].map(([id,icon,zh,en,tabs])=>({id,icon,zh,en,tabs:tabs.map(([id,zh,en,action])=>({id,zh,en,action}))}));
