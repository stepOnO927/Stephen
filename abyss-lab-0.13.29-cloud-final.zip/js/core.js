/** Shared namespace and small pure utilities. Classic scripts also work over file://. */
'use strict';
window.Abyss = { Data: {}, Util: {} };
Abyss.Util = {
  clamp: (n, min = 0, max = 100) => Math.min(max, Math.max(min, n)),
  clone: value => JSON.parse(JSON.stringify(value)),
  escape: value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),
  // Persisted seeded PRNG: reloads do not reroll outcomes.
  random(state) {
    let n = state.rng | 0;
    n ^= n << 13; n ^= n >>> 17; n ^= n << 5;
    state.rng = n >>> 0;
    return state.rng / 4294967296;
  },
  pick(state, entries) { return entries[Math.floor(this.random(state) * entries.length)]; },
  matches(state, rules = {}) {
    return Object.entries(rules).every(([path, bounds]) => {
      const value = path.split('.').reduce((obj, key) => obj?.[key], state);
      if (bounds.min !== undefined && !(value >= bounds.min)) return false;
      if (bounds.max !== undefined && !(value <= bounds.max)) return false;
      return true;
    });
  }
};
