'use strict';
Abyss.DreamData=(()=>{
 const t=Abyss.HomeData.t;
 const seeds=[
 ['door','jack','旧门','The Old Door','门后有人说：“打开。”声音熟悉得令 Jack 不敢立刻相信。','Behind the door someone says “Open it.” The voice is too familiar to trust immediately.','red_key'],
 ['thread','jack','红线','Red Thread','Jasmine 在走廊另一头，把红线绕过一把没有锁孔的钥匙。她的脸没有看向他。','Jasmine winds red thread around a key without a lockhole at the far end of the corridor. She does not face him.','red_key'],
 ['sea','jack','没有海的岸','A Shore Without Sea','Jack 走到岸边。水声从身后传来，前方只有干净得不真实的地板。','Jack reaches the shore. Water sounds behind him. Ahead is an impossibly clean floor.','glass_shell'],
 ['alarm','jack','醒着的警报','A Waking Alarm','警报没有响。所有人却都捂着耳朵，等 Jack 决定最后一扇门。','No alarm sounds. Everyone covers their ears, waiting for Jack to decide the last door.','empty_photo'],
 ['behind','jack','玻璃里面','Inside the Glass','Jack 站在玻璃里面。外面的一只手停在按钮上，久久没有按下。','Jack stands inside the glass. A hand outside rests over a button without pressing.','white_flower'],
 ['intellect','creature','被拆开的句子','A Sentence Taken Apart','每个词都在不同的抽屉里。“我”那只抽屉没有标签。','Every word lies in a separate drawer. The drawer for “I” has no label.','empty_photo'],
 ['abyss','creature','水下的灯','Lights Under Water','暗水里有一排灯。它们亮起的顺序不像坐标，更像一句话。','A row of lights shines in dark water. Their order resembles a sentence rather than coordinates.','glass_shell'],
 ['companion','creature','空着的椅子','The Empty Chair','饭桌边有许多椅子。有人挪开最近的一把，说这只是为了方便。','There are many chairs at the table. Someone removes the nearest, saying it is only for convenience.','white_flower'],
 ['synthetic','creature','信号里的房子','A House in a Signal','信号重复一个地址。它没有去过那里，却知道窗帘的颜色。','A signal repeats an address. It has never been there, yet knows the curtains’ color.','empty_photo'],
 ['anomaly','creature','错误的楼梯','The Wrong Staircase','楼梯把每次向上都带回同一扇门。门牌上的名字慢了一拍才出现。','Every upward step returns to the same door. Its nameplate appears one beat late.','red_key'],
 ['host','creature','另一双手','Another Pair of Hands','镜子里的人类手掌贴着它。没有谁先退开，也没有谁证明这是记忆。','Human palms meet its own in the mirror. Neither withdraws. Neither proves this is a memory.','empty_photo'],
 ['shared1','shared','同一盏灯','The Same Lamp','醒来后，他们分别画了一盏坏灯。裂缝方向相同，但谁也没有说自己画得对。','After waking, they each draw a broken lamp. The cracks match. Neither claims to be right.','white_flower'],
 ['shared2','shared','两把钥匙','Two Keys','梦里他们各有一把钥匙。醒来后，Jack 先问它是否愿意讲，而不是先说自己的答案。','Each holds a key in the dream. On waking, Jack asks whether it wants to talk before offering his answer.','red_key'],
 ['unknown1','unknown','无编号房间','The Unnumbered Room','一张床有两道压痕。墙上的日历写着尚未到来的昨天。','A bed bears two impressions. The calendar names a yesterday that has not arrived.','empty_photo'],
 ['unknown2','unknown','白花','White Flower','白花从天花板向下长。有人记得它开过，却记不起自己的手。','A white flower grows downward from the ceiling. Someone remembers it blooming, but not their own hands.','white_flower']];
 const dreams=seeds.map(([id,type,zh,en,line,enLine,item])=>({id:'dream_'+id,type,name:t(zh,en),text:t(line,enLine),item,major:['door','thread','sea','host','unknown1'].includes(id)}));
 const items={red_key:t('红钥匙','Red Key'),glass_shell:t('玻璃贝壳','Glass Shell'),white_flower:t('白花','White Flower'),empty_photo:t('空照片','Empty Photograph')};
 Abyss.I18n.register(Abyss.HomeData.english);return {dreams,items};
})();
