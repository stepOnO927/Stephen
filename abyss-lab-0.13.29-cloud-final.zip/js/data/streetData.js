'use strict';
Abyss.StreetData=(()=>{
 const english={},t=(a,b)=>(english[a]=b,a),places=['ironhaven','glassfield','switchyard','lantern','deadchannel','hollowwing'];
 const rows=[
 ['elias','Elias Ward','government','他把紧急管理章垫在漏水的桌腿下。','He props a leaking desk with the emergency seal.','给难民补一张居住证','Renew a refugee’s residency'],
 ['mara','Mara Quinn','medic','她在袖口写病人的名字，怕夜班把人忘掉。','She writes patient names on her cuff against night-shift exhaustion.','药包封口是否完好','Whether medicine seals are intact'],
 ['finch','Old Finch','drifter','他知道哪段隧道下雨也不积水，不知道自己的生日。','He knows which tunnels stay dry, not his birthday.','留一块不漏雨的地方','Keep a dry place'],
 ['rusk','Rusk','worker','清醒时他能听出轴承型号，喝酒后忘记关灯。','Sober, he hears bearing types. Drinking, he forgets the light.','有人陪他去诊所','Someone to walk to the clinic'],
 ['lenny','Lenny Three Cards','criminal','他只玩三张牌，第四张藏在债主那里。','He plays three cards; his creditor holds the fourth.','一场不会加债的牌局','A game that adds no debt'],
 ['vale','Captain Vale','security','她每天检查门闩，却给晚归的洗衣工留门。','She checks every latch but leaves one for late laundry workers.','不要把恐惧写成罪名','Do not write fear as a charge'],
 ['june','June Harrow','merchant','她算运费时总留出伤员座位。','Her freight accounts always allow a wounded passenger’s seat.','一条不再丢人的商路','A road that stops losing people'],
 ['reeve','Deacon Reeve','believer','祷告后他修屋顶，没问住户信不信。','After prayer he repairs roofs without asking belief.','雨前换掉破帆布','Replace torn canvas before rain'],
 ['milo','Milo','child','他把瓶盖排列成星座，名字全是自己起的。','He makes bottle-cap constellations and names them himself.','问 B-07 想叫什么','Ask what B-07 wants to be called'],
 ['graves','Graves','security','调查员先看日期，再看伤口，从不先看怪物。','The investigator checks dates and wounds before looking at the creature.','核对一份失踪记录','Verify a missing-person record'],
 ['ada','Ada Moss','government','她下班后继续盖章，因为明早队伍会更长。','She stamps after closing because tomorrow’s queue will be longer.','一张没有贿款的通行证','A permit without a bribe'],
 ['ivo','Ivo Pell','government','他拿贿款买孩子的药，知道这不是免责理由。','His bribes buy his child’s medicine; he knows that is no excuse.','账目不要被孩子看见','Keep the ledger from his child'],
 ['nara','Nara Holt','government','检疫员拒绝变质食物，自己的饭却只有半碗。','The inspector rejects spoiled food while eating half a bowl herself.','一份能信任的检测单','A trustworthy test sheet'],
 ['toll','Bridge Tom','raider','他收桥费，也会替过桥孩子系鞋带。','He collects bridge tolls and ties children’s shoes.','换一批不会抢水的同伴','Find companions who do not steal water'],
 ['ash','Ash Ren','raider','他用大两号的护甲掩盖发抖的肩膀。','Oversized armor hides his shaking shoulders.','把今天的枪声留在昨天','Leave today’s gunfire in yesterday'],
 ['dog','Sera Scrapdog','raider','她抢机器，却在每台拆掉的泵上留维修说明。','She steals machines and leaves repair notes on stripped pumps.','给旧农场找电机','Find a motor for the old farm'],
 ['oona','Oona Reed','drifter','她不住聚落，因为屋顶让她想起被赶走那天。','She avoids settlements; roofs recall the day she was expelled.','别人先问再坐下','Have people ask before sitting'],
 ['ben','Ben Station','drifter','他的毯子边缘干净，鞋子一直放在出口方向。','His blanket edges are clean; his shoes face the exit.','一块肥皂','A bar of soap'],
 ['luz','Luz Arlen','musician','她的手风琴缺两个音，整条街知道怎么补唱。','Her accordion lacks two notes; the street sings them in.','安静听完一首歌','Someone to hear a whole song'],
 ['orin','Orin Tin','musician','他用铁桶打鼓，抱怨发电机抢节拍。','He drums on tins and complains that the generator steals the beat.','一面不漏音的墙','A wall that holds a tune'],
 ['bea','Bea Kettle','bar','她给醉客端水，不把倒下的人赶到雪里。','She serves water to drunk patrons, never throwing them into snow.','帮 Rusk 联系护士','Contact a nurse for Rusk'],
 ['sol','Sol Mercer','bar','他记得酒的价钱，常忘记儿子的年龄。','He remembers drink prices, often forgetting his son’s age.','有人听他讲完名字','Someone to hear the whole name'],
 ['paz','Paz Linen','worker','她说洗衣房最讨厌的不是污渍，是晚发的薪水。','She says the laundry’s worst stain is late pay.','把烘干机修好','Repair the dryer'],
 ['teo','Teo Pump','worker','水压低了，他先道歉再钻进冷水里。','When pressure falls he apologizes before entering the cold water.','一双干袜子','Dry socks'],
 ['hana','Hana Loam','worker','她嫌土里石头多，嫌大人物讲话更多。','She complains of stones in soil and too many speeches above it.','留住下一季种子','Keep next season’s seed'],
 ['emi','Emi Vale','refugee','她把家门钥匙缝在衣服里，新地址不需要那把钥匙。','She sews the old key into clothes; the new address has no lock for it.','不再解释为什么搬家','Stop explaining why she moved'],
 ['sal','Sal Doran','refugee','他每天数一家人的杯子，借来的杯子也算。','He counts the family’s cups, including borrowed ones.','给最小的人留早餐','Keep breakfast for the smallest'],
 ['tess','Tess Wave','media','她播报坏消息前总先校准录音日期。','She checks recording dates before broadcasting bad news.','传闻有可核实的来源','Give rumors verifiable sources'],
 ['vera','Vera Silk','merchant','她喝真正的咖啡，却把职工工资说成可调整项。','She drinks real coffee and calls wages adjustable.','买下隔壁空仓库','Buy the empty warehouse'],
 ['nell','Nell Suture','medic','她的手很稳，卖情报时也一样。','Her hands are steady in surgery and in selling information.','把旧债从诊所移出去','Keep an old debt outside the clinic']
 ];
 const roles=['government','worker','merchant','raider','drifter','medic','security','bar','musician','believer'];
 const archetypes=roles.flatMap((role,r)=>Array.from({length:6},(_,v)=>({id:'look_'+role+'_'+v,role,coat:['#69766e','#8b7560','#637787','#887b80','#858165','#556e69'][(v+r*2)%6],hair:(v+r)%6,hat:(v+r)%3,bag:(v+r)%2,wear:v,age:20+v*10})));
 const named=rows.map(([id,name,role,detail,enDetail,want,enWant],i)=>({id:'person_'+id,name,role,place:places[i%6],look:archetypes[(roles.indexOf(role)<0?4:roles.indexOf(role))*6+i%6].id,detail:t(detail,enDetail),want:t(want,enWant),child:role==='child',addiction:['rusk','sol'].includes(id)?'alcohol':'none',wealth:id==='vera'?85:['drifter','refugee'].includes(role)?10:40,secret:['ivo','nell','lenny'].includes(id),faction:role==='raider'?'jackals':role==='government'?'civic':'independent'}));
 const minor=Array.from({length:120},(_,i)=>({id:'minor_'+i,name:['洛','艾','维','乔','南','伊','罗','米','凯','赛'][i%10]+['恩','拉','尔','亚','斯','德','贝','安','克','奥','宁','特'][Math.floor(i/10)],en:['Lo','Ae','Vi','Jo','Nan','Ei','Ro','Mi','Kai','Se'][i%10]+['en','ra','el','ya','s','de','be','an','k','o','ning','t'][Math.floor(i/10)],role:roles[i%10],place:places[Math.floor(i/10)%6],look:archetypes[i%60].id,detail:t('此人总会在换班前检查随身的小包。','Always checks a small bag before the shift changes.'),want:t('想把今天的事做完再回家。','Wants to finish today’s work and go home.'),child:false,addiction:i%17===0?'alcohol':'none',wealth:10+i%65,secret:false,faction:'independent'}));for(const n of minor)english[n.name]=n.en;
 const ambient=[['地板昨晚又漏水，我挪了三次椅子。','The floor leaked again. I moved my chair three times.'],['工资没来，发电机倒是准时吵醒我。','Pay never arrived. The generator woke me on time.'],['今天的汤有盐，我差点没认出来。','Today’s soup has salt. I almost did not recognize it.'],['别碰那枚胸章，它只是补住一个洞。','Leave the badge alone. It patches a hole.'],['有人把你的名字念错了。我替你改了。','Someone pronounced your name wrong. I corrected them.'],['这不是谣言，车站上有日期。','Not a rumor. The yard has a date on it.'],['先问它，不要问我它是什么。','Ask it first. Do not ask me what it is.'],['我不想谈以前。你要坐下就坐下。','I do not want to discuss the past. Sit if you want.'],['今晚风停了。还不敢把灯关掉。','The wind stopped. I still cannot switch off the light.'],['有人修好了一扇窗，没有留下名字。','Somebody fixed a window and left no name.'],['我们不一定认识，但这儿还有半杯热水。','We may not know each other. There is half a cup of hot water.'],['你听见歌了吗？不是收音机里那首。','Hear the song? Not the one on the radio.']].map(([a,b],i)=>({id:'street_line_'+i,text:t(a,b)}));
 const venues=['work','canteen','street','bar','home'];
 Abyss.I18n.register(english);return {named,minor,people:[...named,...minor],archetypes,ambient,venues,english};
})();
