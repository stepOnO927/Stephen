'use strict';
// Phase 8 authored content. CN and EN are written together; no live translation/API.
Abyss.JackData=(()=>{
 const D=Abyss.NarrativeData,english={},oldOrder=D.chapters.map(c=>c.id),original=new Map(D.chapters.map(c=>[c.id,{...c}]));
 const tr=(zh,en)=>(english[zh]=en,zh);
 function lines(raw){return raw.trim().split('\n').filter(Boolean).map(row=>{const [kind,zh,en]=row.split('|');return {speaker:kind==='N'?'narrator':kind==='B'?'creature':kind==='D'?'doctor':kind==='R'?'radio':'player',voice:kind==='T'?'thought':kind==='N'?'narration':'dialogue',text:tr(zh,en)};});}
 function replace(id,raw,extra={}){let node=D.nodes.find(x=>x.id===id);if(!node){node={id,group:'major',priority:100,once:true,requirements:{},choices:[]};D.nodes.push(node);}node.lines=lines(raw);node.text=node.lines[0].text;node.speaker=node.lines[0].speaker;node.jackScene=true;Object.assign(node,extra);return node;}
 const C=(id,zh,en,extra={})=>({id,label:tr(zh,en),...extra});
 const chapterSpecs=[
 ['b07','序章 · 仍然活着的东西','PROLOGUE · SOMETHING ALIVE',1,0],['survival','ACT I · 日常','ACT I · THE ROUTINE',3,0],['jack_name','ACT II · 名字','ACT II · THE NAME',8,1],['first_word','ACT III · 第一词','ACT III · THE FIRST WORD',12,2],['sky','ACT IV · 天空','ACT IV · THE SKY',18,3],['wasteland','ACT V · 废土','ACT V · THE WASTELAND',25,3],['red_thread','ACT VI · 红线','ACT VI · THE RED THREAD',30,3],['abandoned','ACT VII · 旧翼','ACT VII · THE OLD WING',35,3],['bseries','ACT VIII · B 系列','ACT VIII · THE B-SERIES',42,4],['open_door','ACT IX · 开门','ACT IX · THE OPEN DOOR',48,4],['mia','ACT X · Jasmine','ACT X · JASMINE',55,4],['zero','ACT XI · 零号','ACT XI · SPECIMEN ZERO',62,4],['incident','ACT XII · 连续性事故','ACT XII · THE CONTINUITY INCIDENT',70,4],['eden','ACT XIII · 伊甸','ACT XIII · EDEN',78,4],['black','ACT XIV · BLACK 权限','ACT XIV · BLACK CLEARANCE',86,4],['second_abyss','ACT XV · 第二灰潮','ACT XV · THE SECOND GREY TIDE',94,4],['chamber','ACT XVI · 零号舱','ACT XVI · ZERO CHAMBER',102,4],['between','ACT XVII · 之间','ACT XVII · THE BETWEEN',110,4],['last_door','ACT XVIII · 最后一扇门','ACT XVIII · THE LAST DOOR',118,4],['final','终幕 · 连续','FINAL ACT · CONTINUITY',125,4]
 ];
 D.chapters.splice(0,D.chapters.length,...chapterSpecs.map(([id,zh,en,day,language],index)=>({...(original.get(id)||{}),id,title:tr(zh,en),index,legacy:original.get(id)?.legacy||false,requirements:{day:{min:day},'narrative.languageStage':{min:language}}})));
 for(const c of D.chapters){let response=D.nodes.find(n=>n.id==='project_'+c.id+'_response');if(!response){response={id:'project_'+c.id+'_response',group:'project_response',priority:100,once:true,text:'',choices:[C('honest','把能够确认的事告诉它，也承认不知道','Tell it what can be confirmed, and admit what remains unknown',{jack:{honesty:2,curiosity:1},campaignFlag:'honest'}),C('hide','先处理眼前的危险，暂时不回答','Deal with the immediate danger and postpone the answer',{jack:{pragmatism:2,fear:1},lie:true}),C('ask','听听它希望怎么做','Listen to what it wants to do',{jack:{compassion:2},philosophy:{autonomy:2}})]};D.nodes.push(response);}response.title=c.title;response.chapter=c.id;}
 replace('project_b07',`
N|Jack 的旧工作证只打开了维修入口。主控室的门仍亮着红灯。|Jack's old badge opened only the maintenance entrance. The control-room door still showed red.
T|二十七岁。一个包，一把不配套的扳手，半瓶不干净的水。先找能睡的地方。|Twenty-seven. One bag, a mismatched wrench, half a bottle of dirty water. First, somewhere to sleep.
N|他沿泵房的检修梯往下走。自动系统叫他“基础设施操作员”，没有叫他研究员。|He climbed down the pump-room ladder. The system called him an infrastructure operator, not a researcher.
J|行。好歹还有机器认得我。|Fine. At least a machine still recognizes me.
N|下面有电。培养舱内，一团小小的身体随着应急灯起伏。|There was power below. Inside a chamber, a small body rose and fell beneath an emergency lamp.
T|这里还有东西活着。不是库存，不是待处理的废物。活着。|Something in here was still alive. Not inventory. Not waste awaiting disposal. Alive.
N|Jack 没碰控制台。他先检查空气管和排水口，再用手背试玻璃的温度。|Jack left the console alone. He checked the air line and drain, then tested the glass with the back of his hand.
T|机器比人好懂。漏水会留痕迹，电线会发热。人不一定告诉你哪里坏了。|Machines were easier than people. Leaks left stains. Wires grew hot. People didn't always tell you what was broken.
N|舱里的东西退到角落。他退开半步。|The thing retreated into a corner. He took half a step back.
J|我不是来拆你的。暂时不是。|I'm not here to take you apart. Not planning to, anyway.
T|这笑话连我自己都不想听。|Even I didn't want to hear that joke.
N|应急发电机咳了两下。它的身体缩紧。Jack 也攥紧了扳手。|The emergency generator coughed twice. Its body tightened. Jack gripped his wrench too.
J|我先修那个。很吵，我知道。|I'll fix that first. It's loud. I know.
N|他用一片垫圈补住管道。手腕上的红线被螺栓勾了一下。|He patched the pipe with a washer. A bolt caught the red thread around his wrist.
T|别碰那根线。别问为什么。|Don't catch that thread. Don't ask why.
N|供氧指示恢复绿色。小身体仍没靠近，却不再把头藏起来。|The oxygen indicator turned green. The small body stayed back, but stopped hiding its head.
T|我只是在检修收容密封。这样说，比承认我在看它有没有睡着好听。|I was only inspecting the containment seals. That sounded better than admitting I was checking whether it had fallen asleep.
N|门锁卡在“关闭”。他有维护权限，也有一把手动钥匙。|The lock was stuck on CLOSED. He had maintenance access, and a manual key.
T|我能把它打开。这个念头，比门外的警报更响。|I could open it. That thought was louder than the alarm outside.
J|先把空气接稳。之后……之后再说。|First, reliable air. After that... we'll talk about after that.
N|他把一份营养胶放进喂食口，坐在玻璃外，没有给自己宣布一份新工作。|He put nutrient gel in the feeding hatch and sat outside the glass. He did not announce a new profession for himself.
T|今天只要不再让一扇门后面的东西死掉。今天先做到这个。|Today, just don't let something behind another door die. Today, start there.
`,{group:'project',title:D.chapters[0].title,nextNode:'project_b07_response'});
 replace('project_survival',`
N|三天后，泵能连续工作四十分钟。Jack 在接线图上画了一个不太像笑脸的圆。|Three days later, the pump could run forty minutes at a time. Jack drew something that wasn't quite a smile on the wiring diagram.
J|恭喜。供水部门唯一员工又少睡了两小时。|Congratulations. The water department's only employee has lost another two hours of sleep.
N|它盯着他打哈欠。他把工具袋从椅子上拿开，给自己腾地方。|It watched him yawn. He moved the tool bag off the chair to make room for himself.
T|父亲修电器，总说别用指头找电。母亲下夜班回来，总能看出谁在硬撑。|My father repaired electrical equipment: never use your fingers to find a live circuit. My mother came home from hospital night shifts and always knew who was pretending to be fine.
N|他把最后一句话咽回去，开始解释水滤芯。|He swallowed the last part and started explaining the water filter instead.
J|这个能换。那边的备用件，不能全部拆了。|This can be replaced. Those spares over there—we can't strip all of them.
N|食盆到位，灯调暗，空气阀打开。它在第三个动作之后放松下来。|Bowl placed. Light dimmed. Air valve open. After the third action, its body relaxed.
T|它记住了顺序。我竟有点高兴。顺序比我可靠。|It had remembered the sequence. I was pleased, absurdly. A sequence was more reliable than me.
N|Jack 坐下吃冷罐头。它把一小块胶推到喂食口边。|Jack sat down with a cold tin. It pushed a little piece of gel toward the feeding hatch.
J|你留着。这个型号不兼容我。|Keep it. That model isn't compatible with me.
N|它没有明白笑话，只把胶留在那里。|It didn't understand the joke. It left the gel there anyway.
T|我把它收进空碟。没吃，也没丢。总有些事修理说明上没有写。|I put it in an empty dish. Didn't eat it. Didn't throw it away. Repair manuals left out a few things.
`,{group:'project',nextNode:'project_survival_response'});
 replace('project_jack_name',`
N|工作证从记录本里滑出。它看了照片，又看 Jack。|The badge slipped out of the notebook. It looked at the photograph, then at Jack.
J|那是以前的我。维修部门。没有白大褂，也没什么像样的头衔。|That was me before. Maintenance. No lab coat. No impressive title.
T|照片拍得糟透了。我当时以为，会换一份更好的工作，再换一张照片。|The photo was terrible. I thought I'd get a better job first, then a better photograph.
N|他把证件平放，没有压住姓名栏。|He laid the badge flat without covering the name.
J|Jack。男的。二十七。会修泵，不太会讲话。这几项基本可靠。|Jack. Male. Twenty-seven. Good with pumps. Not much good at talking. Those details are fairly reliable.
N|它碰了碰字母，没有把那个声音复述出来。|It touched the letters. It did not repeat the sound.
T|知道一个人的名字，和愿意叫他，是两回事。|Knowing someone's name and wanting to call it were different things.
J|你也可以继续用刚才那个眼神叫我。我听得懂一点。|You can keep using that look to get my attention. I understand some of it.
N|它把工作证推回给他。照片上干净的袖口与现在的袖口重叠。|It pushed the badge back. The clean sleeve in the photograph overlapped the sleeve he wore now.
T|它看着我。不是穿过我看某个喂食按钮。看着我。这个区别让我不安。|It was looking at me. Not through me at some feeding button. At me. That distinction made me uneasy.
`,{group:'project',nextNode:'project_jack_name_response'});
 D.nodes.find(n=>n.id==='project_jack_name_response').choices=[C('honest','回答它关于证件和过去工作的问题','Answer its questions about the badge and your old job',{flag:'knows_jack',jack:{honesty:2},jackJournal:'name'}),C('partial','告诉它名字，把还不愿谈的部分说清楚','Give your name and clearly state what you are not ready to discuss',{flag:'knows_jack',jack:{honesty:1,fear:1},jackJournal:'name'})];
 replace('project_first_word',`
N|它停了很久。Jack 以为这一次也只会有喉间的气音。|It paused for a long time. Jack expected another sound from its throat.
T|我知道语言测试的按钮在哪。并不知道一个声音变成意思的那一刻，该把手放在哪。|I knew where the language-test button was. I didn't know where to put my hands when a sound became meaning.
B|{firstWord}。|{firstWord}.
N|Jack 没有按记录键。几秒后才想起还有那回事。|Jack did not press RECORD. It took him several seconds to remember there was such a button.
J|我听见了。|I heard you.
N|它再发出那个声音，更轻一点。|It made the sound again, a little more softly.
T|不是成绩。不是我把一件机器接通了。有人在试着让另一个人懂。|Not a score. Not a machine I had wired up. Someone was trying to be understood by someone else.
J|你不用再来一遍。想来一遍也行。|You don't have to do it again. You can if you want to.
N|他把两只手放在膝上。第一次没有立即开始下一项练习。|He put both hands on his knees. For once, he did not immediately begin the next exercise.
T|明天还得找药和电池。可今天有一个声音，不需要我把它修好。|Tomorrow still needed medicine and batteries. But today there was a voice that didn't need me to repair it.
`,{group:'project',nextNode:'project_first_word_response'});
 replace('project_sky',`
B|天……天空？|Sky... sky?
J|空气上面的——不对。是大气层，云是水汽凝结——|Above the air—no. The atmosphere. Clouds are condensed water vapour—
B|不。长什么样？|No. What does it look like?
N|Jack 停了。他能背出压力限值，却找不到一句合适的描述。|Jack stopped. He could recite pressure limits, but couldn't find a description.
T|我半辈子都在修那些把外面空气挡住的机器。现在连蓝色都解释不好。|I'd spent half my life fixing machines designed to keep outside air out. Now I couldn't explain blue.
J|很大。|It's big.
B|多大？|How big?
J|没有舱顶。你往上看，眼睛不用停在玻璃那儿。|No chamber roof. You look up, and your eyes don't have to stop at the glass.
N|它也抬头。舱顶的灯照得它眯了一下眼。|It looked up. The chamber light made it squint.
T|说“我会带你看”太容易。容易得像一张不用现在兑现的欠条。|I'll show you. Easy to say. Easy as an IOU that wouldn't be collected today.
B|你，见过？|You... seen it?
J|见过。海没见过。这个先记清，别让我的嘴把两件事混了。|Yes. Not the sea. Let's get that straight before my mouth mixes them up.
N|它把天空的词卡放在门边。Jack 没把它移回学习架。|It placed the sky card beside the door. Jack did not move it back to the teaching shelf.
`,{group:'project',nextNode:'project_sky_response'});
 D.nodes.find(n=>n.id==='project_sky_response').choices=[C('promise',"“我会带你去看。我要先准备一条安全的路。”","“I will show you. First I need to prepare a route.”",{jackFlag:'promise_sky',jack:{attachment:2,honesty:1},jackJournal:'sky'}),C('honest',"“我想带你看，但现在还不能保证。”","“I want to show you. I cannot promise it yet.”",{jack:{honesty:2,fear:1},jackJournal:'sky'}),C('ask','让它决定是否把天空词卡留在门边','Let it decide whether to leave the sky card beside the door',{jack:{compassion:1},philosophy:{autonomy:1}})];
 replace('project_wasteland',`
N|广播里有人哼歌。调音之后，那人开始报今日的饮水点。|Someone hummed on the radio. After tuning the receiver, they listed today's drinking-water stations.
J|还有人唱歌。倒挺奢侈。|People still singing. That's a luxury.
T|我说得刻薄，是怕自己太想听。|I sounded bitter because I wanted to hear it too badly.
B|去那里？|Go there?
J|先看看线路。我们不是来抢他们发电机的。|Check the route first. We're not here to steal their generator.
N|聚落入口的医生没有问他是哪位科学家，只问能不能接好消毒柜的电源。|The doctor at the settlement gate didn't ask which scientist he was. She asked if he could wire up the sterilizer.
D|先修插座。再谈你的袖口为什么全是血。|Fix the socket first. Then we'll discuss why your cuff is covered in blood.
J|不是全是。有一点是油。|Not all of it. Some of that's oil.
N|她没笑。他接好地线，才肯坐下让她清理伤口。|She didn't laugh. He finished the earth connection before sitting down to let her clean the wound.
B|你，也怕。|You... afraid too.
J|这不妨碍我修插座。|Doesn't stop me fixing a socket.
T|它没说妨碍。它只是把我躲开的那件事说了出来。|It hadn't said it stopped me. It had only said the thing I was avoiding.
`,{group:'project',nextNode:'project_wasteland_response'});
 replace('project_red_thread',`
N|红线起了毛边。Jack 用热针压住断口，却没把它换成更结实的扎带。|The red thread was fraying. Jack sealed the loose end with a hot needle, but didn't replace it with a stronger cable tie.
B|坏了。换？|Broken. Replace?
J|还能用。识别用的。|Still useful. Identification.
T|这句话用了三年。像把漏水的地方贴上标签，就能不用看下面那条裂缝。|I'd used that sentence for three years. As if labelling a leak meant I didn't have to look at the crack beneath it.
N|收音机里响起一个年轻女孩的声音。Jack 的针停在半空。|A young girl's voice came from the radio. Jack stopped with the needle in the air.
R|南侧的人听得见吗？请重复最后一个地名。|Can anyone on the south side hear us? Please repeat the last place name.
N|不是证据。甚至没有报名字。Jack 仍调高了音量。|Not evidence. Not even a name. Jack still turned up the volume.
B|Jasmine？|Jasmine?
J|你听见我梦里喊过？|You heard me say it in my sleep?
N|它点头，把那根线放回他的手心，没有替他回答。|It nodded and laid the thread back in his palm. It did not answer for him.
T|我可以把它写成一次无线电故障。这样又有东西能修，不需要承认我在等一个人。|I could call it a radio fault. Then there would be something to fix, instead of someone I was waiting for.
J|她是我妹妹。失踪。不是确认死了。|My sister. Missing. Not confirmed dead.
N|他把最后几个字说了两遍。|He said the last words twice.
`,{group:'project',nextNode:'project_red_thread_response'});
 D.nodes.find(n=>n.id==='project_red_thread_response').choices=[C('truth','讲述撤离时走散、之后几个月寻找的事','Tell it about the evacuation and the months spent searching',{jackFlag:'mia_shared',jack:{honesty:3,attachment:2},jackJournal:'mia'}),C('lie','说红线只是旧设备识别标记','Say the thread is only an old equipment marker',{jackFlag:'mia_lied',lie:true,jack:{control:2,fear:2},jackJournal:'mia'}),C('refuse',"“我现在说不下去。不是你的错。”","“I cannot talk about it right now. That is not your fault.”",{jack:{honesty:1,fear:2},jackJournal:'mia'}),C('partial','告诉它 Jasmine 是妹妹，但暂不谈撤离','Tell it Jasmine is your sister without discussing the evacuation yet',{jackFlag:'mia_shared',jack:{honesty:1,fear:1},jackJournal:'mia'}),C('change','转去修收音机，避开这次谈话','Work on the radio to avoid the conversation',{jack:{pragmatism:1,fear:2},jackJournal:'mia'})];
 replace('project_abandoned',`
N|旧翼配电柜的编号，和 Jack 以前修过的一模一样。他先找到接地端子。|The old wing's distribution cabinet had the same model number as one Jack used to service. He found the earth terminal first.
T|我的证件没有高级权限。我只是认得螺丝在哪。别把这个叫天赋。|My badge had no high clearance. I just knew where the screws were. Don't call that a gift.
B|你在这里工作过？|Did you work here?
J|没有。这型号到处都卖。旧型号，爱积灰。|No. They sold this model everywhere. Old model. Loves collecting dust.
N|通电后，档案机显示收容流程。一个手动越权按钮，与他记忆中的形状一样。|Once powered, the archive terminal displayed containment procedures. A manual override had the same shape as the one he remembered.
T|那扇走廊门后有人敲。我有权限。警报说污染。我等复核。门没开。|People had been pounding behind that corridor door. I had access. The alarm said contamination. I waited for verification. The door stayed shut.
J|别碰这个按钮。我先看接线。|Don't touch that button. Let me check the wiring first.
B|你在抖。|You're shaking.
J|柜子漏电。|The cabinet has a leak.
N|他说完就知道那不是完整的回答。旧柜子没有漏电。|As soon as he said it, he knew it wasn't the whole answer. The old cabinet wasn't leaking current.
T|他们死了。我不知道开门会救人，还是把污染带进另一条走廊。这件事没有给我一个能拧紧的结论。|They died. I don't know whether opening it would have saved them or spread contamination down another corridor. Nothing about it gave me a conclusion I could tighten with a wrench.
N|它没碰按钮，也没走开。Jack 把手从柜门上拿下来。|It left the button alone, and stayed. Jack took his hand off the cabinet door.
`,{group:'project',nextNode:'project_abandoned_response'});
 replace('project_bseries',`
N|B 系列记录逐份恢复。七种照料方式，七种称作“必要”的决定。|The B-series records recovered one at a time. Seven kinds of care. Seven kinds of decision called necessary.
J|不是七个物种。也不是谁的成绩表。|Not seven species. Not anybody's scorecard.
B|他们也有吃饭的时间？|Did they have dinner times too?
N|Jack 找到一张热食排班表。有人在表角画了一个杯子。|Jack found a hot-meal roster. Someone had drawn a cup in the corner.
T|我想把过去的人写成坏人。这样我只要不是他们，就能自动站在对的一边。|I wanted the people before me to be villains. Then simply not being them would put me on the right side.
N|另一页写着：抵抗增加。程序仍属必要。|Another page read: Resistance increased. Procedure remains necessary.
J|那次检查是必要的。|That examination was necessary.
N|字已经出了口。他停下来。|The words were already out. He stopped.
T|三小时前，死人的报告。现在，同一句话，同一间屋子，不同的怪物。我不知道玻璃哪一边才是我说的怪物。|Three hours ago, a dead person's report. Now, the same sentence, the same room, a different monster. I wasn't sure which side of the glass I meant.
B|必要给谁？|Necessary for whom?
J|我需要再想一遍。不是让你先同意。|I need to think again. That doesn't mean you have to agree first.
N|他把记录转向它。它可以自己翻页。|He turned the records toward it. It could turn the pages itself.
`,{group:'project',nextNode:'project_bseries_response'});
 replace('project_mia',`
N|他们把关于 Jasmine 的材料摆在桌上。红线留在 Jack 的手腕，没有被当作鉴定结论。|They laid out the material about Jasmine. The thread stayed on Jack's wrist; it was not treated as an identification result.
B|你在找她。还是在找一种让你不再害怕的答案？|Are you looking for her, or for an answer that lets you stop being afraid?
J|两种都有。说只有第一种，听起来比较好。|Both. Saying only the first sounds better.
T|三年前她十七，我二十四。第一次撤离的队伍被切成两截。我找了几个月，从没找到确认的遗体。|Three years ago she was seventeen and I was twenty-four. The first evacuation split into two groups. I searched for months. Never found a confirmed body.
N|照片里的女孩给红线打了一个歪结。Jack 没有把照片放大成遗像。|The girl in the photograph had tied a crooked knot in the thread. Jack did not enlarge it into a memorial portrait.
B|你把我留在这里，是怕又找不到一个人？|Do you keep me here because you're afraid of losing someone again?
J|有时候。不是全部。也不是一个够用的理由。|Sometimes. Not all of it. And not a sufficient reason.
N|它摸了摸自己的手，没有碰红线。|It touched its own hand, not the red thread.
B|我不是她。|I am not her.
J|我知道。|I know.
B|你得在开门的时候也知道。|You need to know it when you open the door, too.
T|它没有替我治好这件事。它只是不肯替另一个人留在笼子里。|It wasn't healing this for me. It was refusing to stay in a cage in somebody else's place.
`,{group:'project',nextNode:'project_mia_response'});
 replace('project_zero',`
N|零号文件的照片少了一角。Jack 没把空白补成一张完整的脸。|A corner was missing from the Zero photograph. Jack did not fill the blank into a complete face.
J|设备能告诉我们模板相似。不能告诉我们谁还是谁。|The equipment can tell us patterns are similar. It can't tell us who is still whom.
B|你会叫我零号吗？|Will you call me Zero?
J|你想让我那么叫吗？|Do you want me to?
N|它看着自己的名字，又看那个旧编号。|It looked at its own name, then at the old number.
T|我的工牌也沿用了旧编号。那没有让我变成上一位维修员。材料和人不是一回事。|My badge reused an old number too. It didn't turn me into the previous technician. Materials and people were different questions.
B|先不要。|Not yet.
J|好。先不要。|All right. Not yet.
N|这一次，Jack 没有在“先”后面偷偷加上“由我决定”。|This time Jack did not secretly add until I decide after the word yet.
T|我会看文件。但文件不能替它答完所有问题。|I'll read the file. The file cannot answer every question for it.
`,{group:'project',nextNode:'project_zero_response'});
 replace('project_incident',`
N|连续性事故的记录同时出现了报警、封门、撤电和不完整的确认。没有一行能包住所有责任。|The continuity incident recorded alarms, sealed doors, power cuts and incomplete confirmations at once. No single line contained all the responsibility.
J|我干过这套系统的维护。没做过这个项目的负责人。|I've maintained systems like this. I was never in charge of this project.
B|所以你没有责任？|So you aren't responsible?
J|不是。我知道自己做过哪些事。只是不能装作知道他们做过的全部。|No. I know what I did. I just can't pretend to know everything they did.
T|跟着协议走，有时是在保护别人。有时是在把自己的名字藏到一张表下面。|Following protocol sometimes protected people. Sometimes it hid my name under a form.
N|Jack 把当年未打开的走廊写在空白页上，没有写“别无选择”。|Jack wrote down the corridor he hadn't opened. He did not write no choice.
B|有人会知道吗？|Will somebody know?
J|你已经知道了。以后还有谁，需要我自己去面对。|You know now. Whoever else needs to know—I'll have to face that myself.
N|他没有要求它判断当年的门应该开还是关。|He did not ask it to decide whether that old door should have opened.
T|把审判交给它，也可能只是在找另一个肯说“不是你的错”的声音。|Asking it to judge might only mean looking for another voice willing to say it wasn't your fault.
`,{group:'project',nextNode:'project_incident_response'});
 replace('project_eden',`
N|伊甸图纸把一片住区标成“可恢复地块”。围栏里面晾着两件孩子的衣服。|The Eden map called a residential block recoverable land. Two children's shirts hung inside the fence.
J|图纸没画水管。我去看一眼。|The plan doesn't show a water pipe. I'll take a look.
B|你又去修东西。|You're going to fix something again.
J|这次有真的水管。|This time there is an actual pipe.
B|也有真的人。|And actual people.
N|Jack 放下工具，先问屋里的人想留还是想走。|Jack put down his tools and first asked the people inside whether they wanted to stay or leave.
T|我可以做一套完美的供水系统，然后把所有不适合图纸的人都搬开。那算修好吗？|I could make a perfect water system and move everyone who didn't fit its plan. Would that count as fixing anything?
D|药不能分成无限份。你不必答得漂亮，但得告诉他们剩多少。|Medicine isn't infinitely divisible. You don't need a beautiful answer. You do need to tell them how much remains.
J|好。先数清，再说清。|All right. Count it first. Then say it plainly.
N|它留在谈话里，没有被遣去等一个“为它好”的结果。|It stayed in the conversation. It wasn't sent away to wait for a result for its own good.
`,{group:'project',nextNode:'project_eden_response'});
 replace('project_black',`
N|BLACK 权限开放了新的门，也要求关闭别的门。Jack 读到“自动清理”时停了一下。|BLACK clearance opened new doors and demanded that others close. Jack paused at automatic clearance.
J|清理的是记录，还是里面的人？|Are we clearing records, or the people inside?
B|你以前也问过吗？|Did you ask that before?
J|问得不够早。|Not early enough.
T|我想把这一句话说得像忏悔，好让它显得已经做完。可接下来还是有一只手要按按钮。|I wanted that sentence to sound like a confession, something finished. But a hand still had to press the next button.
N|他把撤离路线和电源图并排放，不再只给它看已经替它选好的那一张。|He laid the evacuation route beside the power diagram. He no longer showed it only the one he had selected for it.
B|我们可以不同意吗？|Can we disagree?
J|可以。即使没有第三条路。|Yes. Even if there isn't a third route.
N|警报没有因此变轻。|The alarm did not become quieter because he said it.
T|不确定还在。我不能把它关进屋里，再叫屋里的人替我消掉它。|The uncertainty remained. I couldn't lock it in a room and ask the person inside to make it disappear for me.
`,{group:'project',nextNode:'project_black_response'});
 replace('project_second_abyss',`
N|第二灰潮的前沿逼近供电站。收音机里的歌停在第三个音上。|The second Grey Tide approached the power station. The song on the radio stopped on its third note.
J|备用机还有燃料。不是很多。|The backup generator has fuel. Not much.
B|你先坐下。|Sit down first.
J|我站着能看清接头。|I can see the connector better standing up.
N|他的左手抖了一下。它没有让他用设备故障把话绕开。|His left hand shook. It did not let him steer the conversation into equipment faults.
B|你的手。|Your hand.
J|累了。|Tired.
B|你在撒谎。|You're lying.
J|对。|Yes.
T|我教过它痛了要告诉我。我给自己留了一条没写在规则上的例外。|I'd taught it to tell me when something hurt. I'd kept an unwritten exception for myself.
N|Jack 把症状写下来，还没有给病程起一个确定的结局。|Jack wrote down the symptoms. He did not yet give the illness a certain ending.
J|请医生看。然后我们一起听，不只让我一个人听。|Let the doctor look. Then we listen together. Not just me.
`,{group:'project',nextNode:'project_second_abyss_response'});
 replace('project_chamber',`
N|零号舱的门没有卡住。卡住的是等待确认的流程。|The Zero Chamber door wasn't jammed. The stalled part was the procedure awaiting confirmation.
J|以前有人会为这个叫我来。让我拆开，清灰，换弹簧。|They used to call me for things like this. Open the casing. Clean the dust. Replace the spring.
B|现在呢？|And now?
J|现在我不能假装只是弹簧。|Now I can't pretend it's only a spring.
N|Jack 的工牌无法替他作出选择。|Jack's badge could not choose for him.
T|我仍不是科学家。我可以学，犯错，问别人。不能用“普通人”把手上的权限注销掉。|I'm still not a scientist. I can learn, be wrong, ask other people. Being ordinary doesn't cancel the access in my hand.
B|那我们慢一点。|Then let's go slowly.
J|好。|All right.
N|他们先走了一遍撤离通道。最后一扇门从内侧也能打开。|They walked the escape route first. The last door could also be opened from inside.
T|这一次，不把逃生口留在我一个人的口袋里。|This time, the escape route doesn't stay in my pocket alone.
`,{group:'project',nextNode:'project_chamber_response'});
 replace('project_between',`
B|我对你来说，是什么？|What am I to you?
N|Jack 没有立即回答。食盆已经洗净，门也已经可以打开。这不是一项测试。|Jack did not answer immediately. The bowl was washed. The door could open. This was not a test.
T|我想说家人，朋友，别走。最后一句最诚实，也最像一条命令。|I wanted to say family, friend, don't leave. The last was the most honest, and sounded most like an order.
J|我不知道哪个词不会把你挤小。|I don't know which word won't make you smaller.
B|那先别挤。|Then don't make me smaller yet.
N|它把空椅子挪近一点，没有把门关上。|It moved the empty chair closer. It did not close the door.
J|你也可以觉得我不只是一种人。|You can think I'm more than one kind of person too.
B|你照顾我。也关过我。|You cared for me. You also kept me locked in.
J|对。|Yes.
N|两个事实在房间里待着，没有互相抵消。|Both facts stayed in the room. Neither cancelled the other.
T|我以前以为，只要把东西维持着，它就算过得好。现在我至少知道，这两件事不同。|I used to think keeping something running meant it was living well. At least I know now those aren't the same thing.
`,{group:'project',nextNode:'project_between_response'});
 D.nodes.find(n=>n.id==='project_between_response').choices=[C('family',"“我把你当家人。但那不要求你留下。”","“I think of you as family. That does not require you to stay.”",{jack:{attachment:2,honesty:1},jackJournal:'between',philosophy:{autonomy:2}}),C('friend',"“我希望我们是朋友，包括可以不同意的那种。”","“I hope we are friends. The kind who can disagree.”",{jack:{compassion:2},jackJournal:'between'}),C('unknown',"“我还不知道。我不想拿一个词替你回答。”","“I don't know yet. I don't want a word to answer for you.”",{jack:{honesty:2,curiosity:1},jackJournal:'between'}),C('need',"“我需要你。我也知道这不是你的义务。”","“I need you. I know that is not your obligation.”",{jack:{attachment:3,fear:1},jackJournal:'between'}),C('raised',"“我是养大你的人。”","“I am the person who raised you.”",{jack:{control:2},jackJournal:'between'}),C('silence','留出位置，让它也能选择沉默','Leave room for it to choose silence too',{jackJournal:'between'})];
 replace('project_last_door',`
N|最后一扇设施门的两侧都有把手。Jack 试了里面的一侧，随后退开。|The last facility door had handles on both sides. Jack tested the inside handle, then stepped back.
B|今晚你还检查锁吗？|Will you check the lock tonight?
J|检查能不能开。不是只检查关没关。|I'll check that it opens. Not only that it closes.
T|这句话听起来进步很大。到害怕的时候，我还能不能做到，才是另一回事。|That sentence sounded like progress. Whether I could do it when frightened was another question.
N|走廊外有风，远处也有不知道从哪里来的响声。|There was wind outside the corridor, and a sound whose source they didn't know.
B|会有危险。|There will be danger.
J|会。|Yes.
B|你也会怕。|You'll be afraid too.
J|也会。|That too.
N|Jack 没把这个答案改成保证。|Jack did not turn the answer into a guarantee.
T|不能替一个人挡住所有危险，又要求自己永远不会成为其中一个。至少，我得承认这点。|I can't protect someone from every danger and insist I'll never become one of them. At least I have to admit that.
`,{group:'project',nextNode:'project_last_door_response'});
 replace('project_final',`
N|终端等待最后一份指令。Jack 手上的红线还在，供电图上也还有没弄懂的支路。|The terminal waited for the final instruction. The thread was still on Jack's wrist. The power map still had branches he didn't understand.
J|我没把世界修回来。|I haven't repaired the world.
B|我没让你修回来。|I didn't ask you to.
T|它救过我吗？我救过它吗？这屋里装不下一句干净的总结。|Had it saved me? Had I saved it? There wasn't room for a clean summary in this room.
N|他们看着几条能走的路。每一条都要留下别的东西。|They looked at the routes they could take. Each would leave something else behind.
J|决定之后，我仍得听你的回答。|After I decide, I still have to hear your answer.
B|包括不？|Including no?
J|包括。|Including that.
N|Jack 把终端拉到两个人都能看见的位置。|Jack moved the terminal where both could see it.
T|我最擅长让坏系统继续活着。可我不能再只用这个回答，解释我们要怎么活。|What I do best is keep broken systems alive. I can't use only that answer to explain how we should live.
`,{group:'project',nextNode:'project_final_response'});
 // Keep old response choices/resources and IDs. New intros replace old five-choice beat chains.
 for(const c of D.chapters){const intro=D.nodes.find(n=>n.id==='project_'+c.id);if(!intro)continue;intro.title=c.title;if(!intro.nextNode)intro.nextNode='project_'+c.id+'_response';}
 const speakers={narrator:tr('旁白','Narration'),doctor:tr('许岚 · 医生','Xu Lan · Doctor'),radio:tr('电台声','Radio voice')};
 const journals={},evidence=[],dreams=[],expandedEndings=['sea','we','betrayal','last_creature','collapse','together_end'];
 return {tr,lines,replace,C,english,oldOrder,chapters:chapterSpecs,speakers,journals,evidence,dreams,expandedEndings,flagIds:[],beatIds:[]};
})();
