'use strict';
Abyss.Phase6Data=(()=>{
const endingRows=[
['small_world','小小世界','你们留下修补一间温室。世界仍然很大，今天的饭桌却已经足够。','withered_flower','greenhouse'],
['new_eden','新伊甸','你们让新生的根避开仍有人居住的土地。修复是一项需要耐心的工作。',null,'moss'],
['green_hell','绿色地狱','植物恢复得比人类的适应更快。废墟变成森林，旧居民失去了回家的道路。',null,'bio_luminous'],
['symbiosis','共生','没有一份检查报告能再把你们分开。它仍问你，今天想坐哪一边。',null,'deep_sea'],
['together','同生','你们没有解决所有问题，却一起撑过了那一夜。',null,'sunset'],
['together_end','共死','终末的呼吸逐渐同步。玻璃两侧终于没有了距离。','red_thread','red_dusk'],
['observer','观察者','门从外面锁上。它坐在你曾坐过的椅子里，认真记录你的回应。','observation_key','midnight'],
['no_name','无名','记录中空出一个名字。你伸手时，那里已经没有可被机器辨认的轮廓。','empty_tag','ghost_record'],
['proof','存在证明','它消失了。你手里那只杯子的刻痕，不同意一切从未发生。',null,'paper_memory'],
['grey_tide','第二次灰潮','你让反应越过了设施边界。灰色海面没有留下胜利者。','black_ash','black_ash'],
['fledgling','离巢','它自己背好行囊。告别不是失去，门外也有属于它的生活。','feather','wind'],
['long_life','寿终','很多年后，它为你调整枕头。你曾教它的晚安，终于由它说给你听。','old_watch','old_world'],
['sea','看海','咸味的风吹过名字牌。你们没有讨论项目，只认真看了一天海。','salt_shell','sea_glass'],
['continuation','延续','新的报告承认个体有拒绝的权利。项目仍需被一次次质疑。',null,'lab_white'],
['abandonment','弃置','它等待的脚步没有回来。喂食器继续运行，直到最后一格电耗尽。',null,'rust'],
['ascension','升格','它不再属于单一形体。你仍留着一个能让它听见的呼唤。',null,'zero'],
['last_human','最后的人','广播每晚照常播放。你回答它，像回答一座仍有人居住的城市。',null,'wasteland_dust'],
['last_creature','最后的实验体','它走出空实验室，带着你缝过的衣服。它不知道下一顿晚饭在哪里。',null,'mourning'],
['home','家','没有哪块玻璃能定义它的归属。它将自己的小物件放在你身边。',null,'warm_linen'],
['we','我们','你发现自己的身份早于出生日期。零号也许是一组跨越形体的连续模式。你们没有得到完整答案，却一起离开。CONTINUITY TEST COMPLETE / SUBJECT COUNT: 2','zero_fragment','continuity'],
['no_record','无记录','你们主动放下可复写的身份，只将彼此认得的声音带到地面。','blank_page','ink'],
['first_memory','第一段记忆','它说起那只第一次收到的帽子。没有旧编号能替代这个视角。','first_button','honey'],
['zero','零','空舱发出两次回应。你们没有给第三次回应起名。','zero_echo','violet'],
['ordinary_day','普通的一天','修完收音机，煮好汤，收起晾干的衣服。今天没有改变世界。','radio_dial','garden'],
['black_sun','黑日','异常反应在空旷天空里开了一扇门。谁从另一侧看见了你们？','sun_shard','black_sun'],
['after_abyss','深渊之后','温室里的孩子把编号牌当成玩具。你们终于不必解释每一次成长。','garden_seed','rain'],
['betrayal','你教会了我','它使用你曾示范的谎言，将你留在了隔离区。记录里有很多次这样的示范。',null,'copper'],
['collapse','最后一盏灯','设施坍塌时，你把它推出出口。它在地面仍等着你的脚步。',null,'frost']
];
const hidden=new Set(['sea','fledgling','no_record','first_memory','zero','ordinary_day','black_sun','after_abyss','we']);
const endings=endingRows.map(([id,name,text,item,skin])=>({id,name,text,item,skin,hidden:hidden.has(id),playerDeath:['together_end','long_life','last_creature','collapse','betrayal'].includes(id),creatureDeath:['together_end','last_human','no_name','proof'].includes(id)}));
const skinRows=[['ashen','灰烬','#819493'],['wasteland_dust','废土尘','#bcaa85'],['lab_white','实验白','#dce3d8'],['midnight','午夜','#4c5877'],['bio_luminous','生物荧光','#8bbcaa'],['rust','锈色','#b37b64'],['moss','苔原','#809a62'],['deep_sea','深海','#597fa6'],['black_clearance','黑级权限','#646778'],['zero','零号','#b9bdd0'],['sunset','夕照','#dd9a83'],['old_world','旧世界','#b9a67a'],['continuity','连续性','#a6bfce'],['sea_glass','海玻璃','#80c6bd'],['ghost_record','幽灵记录','#c0c1cb'],['greenhouse','温室','#a1bd7f'],['black_ash','黑灰','#666279'],['red_dusk','红暮','#ad747f'],['wind','风羽','#b4c8bd'],['paper_memory','纸上记忆','#cdc2a6'],['mourning','守夜','#737f95'],['warm_linen','暖布','#d6bb97'],['ink','墨迹','#687984'],['honey','蜂蜜','#d5b777'],['violet','紫雾','#ae9abf'],['garden','庭院','#9fba8a'],['black_sun','黑日','#796482'],['rain','雨痕','#8eb3bf'],['copper','旧铜','#af8870'],['frost','霜色','#aecbd2']];
const skins=skinRows.map(([id,name,color],i)=>({id,name,color,category:i<3?'BASIC':i<9?'ACHIEVEMENT':endings.some(e=>e.skin===id)?'ENDING':'STORY',unlock:i<3?{basic:true}:endings.some(e=>e.skin===id)?{ending:endings.find(e=>e.skin===id).id}:{achievements:5+i*2}}));
const items=endings.filter(e=>e.item).map(e=>({id:e.item,name:({withered_flower:'枯花',red_thread:'红线',observation_key:'断裂观察钥匙',empty_tag:'空白名牌',black_ash:'黑灰',feather:'告别之羽',old_watch:'旧手表',salt_shell:'海盐贝壳',zero_fragment:'零号碎片',blank_page:'空白页',first_button:'第一颗纽扣',zero_echo:'零号回声',sun_shard:'黑日碎片',garden_seed:'园圃种子',radio_dial:'旧收音机旋钮'})[e.item],ending:e.id,description:'从「'+e.name+'」留下的异常物件。打开专属交流，不提供数值加成。'}));
const regions=[['ruined_city','旧城废墟','倒塌商场的地下室还开着一家汤铺。'],['polluted_district','污染区','居民用布条标记安全的风向。'],['settlement','幸存者聚落','小孩在电池的微光下修理纸风车。'],['highway','废弃公路','搬家的车队为你们留下一份晚饭。'],['dead_forest','死寂森林','枯树中有人挂起新的鸟巢。'],['industrial','工业残骸','焊工用废金属补好居民的水桶。'],['underground','地下设施','墙上的撤离路线覆盖着新的手写留言。'],['radio_tower','广播塔','修好的收音机先播放了一首歌。'],['lake','污染湖','湖边仍有人试种耐盐蔬菜。'],['refugee_camp','临时营地','一场关于汤太咸的争论盖过了远处警报。'],['military','军事遗迹','旧急救箱里放着一张家人的合照。'],['community','孤立社区','老人想知道它更喜欢果子还是热汤。'],['bio_zone','生物异常带','根系按照你们的脚步亮起，村民谨慎地种下第一株幼苗。']].map(([id,name,text])=>({id,name,text}));
// Actual progress conditions; data entries can be extended without editing achievement logic.
const achievements=[],add=(id,name,category,rules={},extra={})=>achievements.push({id:'p6_'+id,name,category,desc:extra.desc||'记录你们实际经历的一个片段。',rules,...extra});
for(const [field,label,category,levels]of [['history.feed','餐桌','RAISING',[1,10,30,60,100]],['history.care','陪伴','RELATIONSHIP',[1,10,30,60,100]],['history.train','练习','RAISING',[1,10,30,60]],['history.experiment','实验记录','RESEARCH',[1,10,30]],['history.explore','远征','EXPLORATION',[1,10,30,60]],['day','共同度过','LONGEVITY',[10,30,60,100,200,365,500,1000]],['stats.loyalty','信任','RELATIONSHIP',[70,85,100]],['resentment','留下的距离','FAILURE',[30,60,90]],['stats.intelligence','理解','LANGUAGE',[25,50,80,100]],['progress.research.level','知识','RESEARCH',[5,10,15,20]],['narrative.languageStage','语言阶段','LANGUAGE',[1,2,3,4,5]],['progress.evolution.stage','成长','EVOLUTION',[1,2,3,4]]])for(const n of levels)add(field.replaceAll('.','_')+'_'+n,label+' · '+n,category,{[field]:{min:n}},{desc:label+'达到 '+n+'。'});
for(const n of [1,3,5,10,15,20])add('mut_'+n,'不同的身体 · '+n,'MUTATION',{}, {test:'mutations',count:n});
for(const n of [1,5,10,20,35,50])add('collect_'+n,'珍藏 · '+n,'COLLECTION',{}, {test:'accessories',count:n});
for(const n of [1,3,5,7])add('outfit_'+n,'穿戴 · '+n,'WARDROBE',{}, {test:'equipped',count:n});
for(const n of [1,5,10,15,20])add('words_'+n,'词语 · '+n,'LANGUAGE',{}, {test:'words',count:n});
for(const n of [1,5,10,20])add('memory_'+n,'仍然记得 · '+n,'MEMORY',{}, {test:'memories',count:n});
for(const e of endings)add('ending_'+e.id,e.name,'ENDINGS',{}, {test:'ending',ending:e.id,secret:e.hidden});
for(const r of regions)add('region_'+r.id,'走过'+r.name,'EXPLORATION',{}, {test:'region',region:r.id});
for(const [id,name,test]of [['door','门曾打开','door'],['betrayal','你教会了我','betrayal'],['refusal','不再继续','refusal'],['broken','失约','broken'],['secret','零之前','secret'],['apology','对不起','apology']])add(id,name,id==='secret'?'SECRET':'STORY',{}, {test,secret:id==='secret'});
for(const [id,name,test,extra]of [['privacy','先问过它','story_flag',{flag:'PROFILE_PERMISSION'}],['truth_later','迟来的实话','story_lie',{}],['sea_promise','不是一句随口的话','story_promise',{}],['show_record','把记录放在两人之间','story_flag',{flag:'SHARED_b03'}],['unlocked_story','钥匙仍在口袋里','story_choices',{count:20}],['evening_radio','静电里的人','story_flag',{flag:'EVENING_radio'}],['host_observed','终端后的目光','story_flag',{flag:'HOST_TRIGGER',secret:true}],['new_echo','这次不是第一次','story_flag',{flag:'READ_familiar',secret:true}]])add('narrative_'+id,name,'STORY',{}, {test,...extra});
Abyss.Data.achievements.push(...achievements.map(a=>({...a,rules:{'campaign.achievedNever':{min:1}}}))); // dedicated Meta evaluator, never accidental empty-rule unlocks
for(const [id,name]of [['promise','约定'],['sea','海'],['rain','雨'],['music','音乐'],['garden','花园'],['tomorrow','明天'],['thanks','谢谢'],['sorry','对不起'],['free','自由'],['together','一起']])Abyss.NarrativeData.words.push({id,name});
return {endings,skins,items,regions,achievements};
})();
