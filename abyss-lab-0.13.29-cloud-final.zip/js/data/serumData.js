'use strict';
// Each row is a specimen, not a procedural name. Art remains independently replaceable.
Abyss.SerumData=(()=>{
 const t=Abyss.HomeData.t;
 const rows=[
 ['muscle','肌束催化剂','Muscle Catalyst','common','strength',3,'矿工把最后一箱留在升降机里，箱盖写着：先让他们回来。','The miners left the last case in the lift. Its lid reads: bring them home first.'],
 ['nerve','神经加速液','Neural Accelerator','common','intelligence',3,'停用的课堂只剩一台答题机。这瓶液体旁边，有一张从未交出的满分试卷。','An abandoned classroom kept one quiz machine and a perfect paper never handed in.'],
 ['reflex','反射复合液','Reflex Compound','common','dodge',2,'邮差留下的包裹没有收件人。他只说，躲开第一次袭击，才有机会送到第二封信。','A courier left a parcel with no recipient: survive the first ambush to deliver the second letter.'],
 ['warm','余温缓冲液','Residual Warmth','common','health',5,'一位夜班医师把瓶子捂在手里等停电结束。手写标签仍有指纹。','A night physician warmed the bottle in her hands through a blackout. The label retains her prints.'],
 ['salt','盐岸代谢液','Saltshore Metabolism','common','metabolism',1,'海岸救援站用它帮助流浪实验体适应新的食物。瓶底嵌着一粒不肯溶解的盐。','The coast shelter used it to help strays accept new food. One grain of salt never dissolves.'],
 ['gel','凝胶修复液','Gel Repair','common','recovery',2,'维修工把生物封胶送进医疗室，第一次在送货单上写了病人的名字。','A repair worker delivered biological sealant to the clinic, writing a patient’s name for the first time.'],
 ['moss','苔眠乳剂','Moss Rest Emulsion','common','calm',3,'温室值班表里只有一句话：它睡着时，不要为了数据叫醒它。','The greenhouse rota says: do not wake it for data.'],
 ['ration','长路酶','Long Road Enzyme','common','recipe',0,'车队厨师找到了不用精密设备也能消化的配方。旧标签有汤渍。','A convoy cook found a formula digestible without precision equipment. Soup stains mark its label.'],
 ['guard','护膜前体','Guard Membrane Precursor','common','guard',2,'被废弃的防护项目没能保护研究员，却保住了舱里那个小生命。','A cancelled protection project failed its staff, yet saved the small life in its chamber.'],
 ['breath','无尘呼吸液','Dustless Breath','common','resist',2,'一名通风工在灰尘最厚的走廊里，把自己的通行证绑在瓶颈。','A ventilation worker tied her pass to the neck in the dustiest corridor.'],
 ['glucose','黄灯糖化液','Amber Lamp Glycol','common','mood',4,'食堂最后亮着的黄灯下，有人把这瓶试制品留给下一位访客。','Under the canteen’s last amber lamp, someone left this prototype for the next visitor.'],
 ['step','轻步配方','Lightstep Formula','common','agility',3,'旧地铁的巡线员靠它让受伤的小兽跟上队伍，而不是拿它去跑比赛。','A metro inspector used it to help an injured creature keep up, never to win a race.'],
 ['hunter','伏猎血清','Hunter Serum','uncommon','attack:ambush',0,'林地观察员学会了安静等待。记录末页写着：不追逐，也是决定。','A forest observer learned to wait. The last page says: not pursuing is also a decision.'],
 ['gourmet','食客酶','Gourmet Enzyme','uncommon','recipe',1,'玻璃田的厨师坚持每个实验体都该有一道喜欢的菜。','A Glassfield cook insisted every specimen deserved a favourite dish.'],
 ['combo','复击催化剂','Multi-Strike Catalyst','uncommon','combo',2,'拳馆的旧沙袋旁，一瓶药剂被当作失去搭档后的纪念品。','Beside a gym’s old punching bag, a bottle commemorated a lost sparring partner.'],
 ['echo','回声辨识液','Echo Recognition','uncommon','attack:sonic',0,'死频道接线员发现，有些沉默只是频率不对。','A Dead Channel operator found some silences were merely the wrong frequency.'],
 ['iron','铁肤悬液','Iron Skin Suspension','uncommon','defense',3,'铁炉城的冷却池里捞起这瓶悬液，外壳比里面的液体先学会了生锈。','Salvaged from Ironhaven’s cooling pool, its casing learned rust before its contents.'],
 ['silk','丝路偏好液','Silkway Preference','uncommon','favorite',0,'有人想把食物偏好变成命令。下一任保管员划掉了命令二字。','Someone meant to make food preference an order. The next custodian crossed out “order.”'],
 ['spark','火花导液','Spark Conductor','uncommon','attack:electric',0,'停电时，它让诊室的小灯亮了十秒。足够医师找到门。','During a blackout it lit the clinic for ten seconds, enough to find the door.'],
 ['dew','冷露恢复剂','Cold Dew Recovery','uncommon','recovery',4,'林间救援队把露水色瓶子挂在担架上，说它像一小块尚未毁掉的早晨。','Forest rescuers hung it on a stretcher: a small piece of an unbroken morning.'],
 ['focus','瞄准凝露','Focus Condensate','uncommon','crit',2,'射手不再参加赏金任务后，把它留在修理店。标签写着：看清再动手。','A retired bounty marksman left it at a repair shop: see clearly before acting.'],
 ['burden','负重交换液','Burden Exchange','uncommon','strength',5,'搬运队记录了更强的肩膀，也记录了变慢的脚步。没有人删掉第二行。','The haulers logged stronger shoulders and slower steps. Nobody erased the second line.'],
 ['spore','孢雾引子','Spore Mist Primer','rare','attack:spore',0,'菌床里发现的密封瓶没有制造者。标签的字迹与菌丝走向一样。','A sealed bottle in a fungal bed has no maker. Its writing follows the mycelium.'],
 ['counter','迟一拍','One Beat Later','rare','counter',4,'一名护卫等到对方收手才出拳。瓶里的两层液体永远错开半拍。','A guard waited for the opening. Its two layers remain half a beat apart.'],
 ['shell','层甲记忆','Layered Shell Memory','rare','mutation:shell',0,'从坍塌育成舱找回。舱壳挡住了落梁，里面的名字被刮花了。','Recovered from a nursery chamber that held a fallen beam. The name inside was scratched away.'],
 ['map','折页认知剂','Folded Cognition','rare','intelligence',5,'地图师为不会看文字的同行者做了气味地图。这瓶液体是第一版失败稿。','A cartographer made scent maps for a companion unable to read. This was the first failed draft.'],
 ['chitin','甲质代偿液','Chitin Compensation','rare','defense',5,'废弃安保翼把每一次加固都记成成功，却不记录慢下来的转身。','The security wing logged every reinforcement as success, never the slower turns.'],
 ['moon','月相皮膜','Moonphase Membrane','rare','appearance',0,'夜间观察员没有再提交照片，只在瓶套里留下一幅手绘月亮。','A night observer stopped submitting photographs, leaving a hand-drawn moon in the sleeve.'],
 ['wing','浮力胚芽','Buoyancy Bud','rare','mutation:wings',0,'航站遗址的培养架上，所有瓶子都朝着窗户倾斜。只有这一瓶仍完整。','At an airfield nursery every bottle leaned toward the window. Only this one survived.'],
 ['trail','追迹薄荷','Trail Mint','rare','attack:pursuit',0,'一个孩子把追踪项目的编号贴纸换成了自己的寻猫启事。','A child replaced the tracking project’s number with a missing-cat notice.'],
 ['trust','同行缓释液','Companion Release','rare','affectionate',4,'救援队拒绝叫它服从配方。档案的新标题是：一起回来。','The rescue crew refused “obedience formula.” Its new file title: return together.'],
 ['acid','蚀甲玻璃','Armor Etch Glass','rare','pierce',4,'破窗逃生时救回的试制瓶，标签上仍压着一片安全玻璃。','Saved during a window evacuation, with a safety-glass fragment pressed into its label.'],
 ['storm','风暴阈值','Storm Threshold','epic','attack:beam',0,'雷暴烧毁了研究楼。幸存者发现仪表早在雷击前就记录到了光。','A storm burned the research wing. The instruments logged light before the strike.'],
 ['psyche','静室心音','Quiet Room Pulse','epic','attack:psychic',0,'隔音室的监控没有声音，却记录了两个人同时回头的瞬间。','A soundproof room recorded two people turning together, without a sound.'],
 ['regrow','再生余页','Regrowth Postscript','epic','mutation:regeneration',0,'报告最后一页被撕走了。瓶套夹着一段后来才长出的手写补充。','The report’s last page is missing. A handwritten postscript grew inside its sleeve.'],
 ['ember','灰烬肺叶','Ash Lung','epic','attack:burn',0,'消防员在熄灭的炉膛里找到这瓶药剂。它保存的不是火，是火后的空气。','A firefighter found it in a dead furnace. It kept the air after fire, not the flame.'],
 ['ribbon','红线保护剂','Red Thread Protector','epic','counter',6,'红线来自一张救援担架。它保护过谁，持有人没有写。','Its red thread came from a rescue stretcher. The custodian never named whom it protected.'],
 ['prism','棱镜饮片','Prism Suspension','epic','appearance',1,'观察大厅停用后，清洁员收集了最后一束穿过破玻璃的光。','After the hall closed, a cleaner collected its last ray through broken glass.'],
 ['feral','野性归档液','Feral Archive','epic','aggressive',6,'旧档案称它失控。旁边的逃生记录说，它只是先找到了出口。','The file says “out of control.” The evacuation record says it found the exit first.'],
 ['clock','秒针培养液','Secondhand Culture','epic','combo',5,'钟表匠发现液面总比秒针迟一格。那块表后来被送给一个不会计时的朋友。','A clockmaker saw the liquid lag one tick. He later gave the watch to a friend who could not tell time.'],
 ['void','空白器官前体','Blank Organ Precursor','legendary','mutation:extra_eyes',0,'无编号房间的冰柜里没有病历。这瓶的标签只写了一个问号。','An unnumbered freezer held no patient records. Its label has only a question mark.'],
 ['dawn','黎明承诺','Dawn Promise','legendary','recovery',8,'最后一次撤离时，医师留下自己的徽章，让后来的人知道这里曾有人等过。','At the final evacuation a physician left her badge: someone once waited here.'],
 ['oracle','未来侧影','Future Silhouette','legendary','attack:disrupt',0,'录像里这瓶药剂先被打碎，三分钟后才被放到桌上。保管员停止了播放。','A recording shows it shattered three minutes before being placed on the table. The custodian stopped playback.'],
 ['sea','无岸潮汐','Shoreless Tide','legendary','route:radiant',5,'海岸线尚未被画上地图时，这瓶液体已经留下了潮痕。','Its tide mark predates the coast’s first map.'],
 ['witness','最后见证液','Last Witness','legendary','intelligence',8,'记录员把自己的名字从研究成果里删掉，只保留了实验体的名字。','An archivist removed her own name from the results, keeping the specimen’s name alone.'],
 ['zero','零号回流','Zero Reflux','anomalous','attack:null',0,'空舱里的样本每天增加一滴。没有泵，没有管道，也没有被记录的供体。','A sample in an empty chamber gains a drop each day. No pump, tube or recorded donor exists.'],
 ['absence','缺席样本','Absent Sample','anomalous','route:void',6,'库存显示负一瓶。拿起它以后，旧清单上多了一张你的签名。','Inventory reads minus one bottle. After you pick it up, your signature appears on the old list.'],
 ['orbit','轨道偏移','Orbit Drift','anomalous','appearance',2,'液滴绕着瓶塞转。放在平地上时，阴影坚持认为瓶子已经倒下。','Drops orbit the stopper. On a level table its shadow insists the bottle has fallen.'],
 ['choice','未选之门','Unchosen Door','anomalous','route:gentle',6,'瓶中有两种互不相容的倒影。Jack 认得其中一扇门，却不记得打开过。','Two incompatible reflections occupy it. Jack knows one door but cannot remember opening it.'],
 ['wind','逆风定向液','Headwind Orientation','uncommon','agility',4,'公路引航员失去了所有路标。他留下一瓶试制品和一张纸：风会骗人，同行者不会总是。','A highway guide lost every signpost. He left a prototype and a note: the wind lies; companions do not always do so.']
 ];
 const shapes=['ampoule','flask','pear','hex','tube','orb','wedge','double','square','spiral'];
 const colors=['#b68963','#7eafaf','#a5b876','#b17880','#699b87','#88a9c4','#b5a69a','#a38ab0','#c3ae6c','#8196a0'];
 const serums=rows.map(([id,zh,en,rarity,effect,amount,lore,loreEn],i)=>({id:'serum_'+id,name:t(zh,en),en,rarity,effect,amount,lore:t(lore,loreEn),description:t('未完全验证的旧世界生物配方。使用前查看收益与代价。','An incompletely verified old-world biological formula. Check benefits and costs before use.'),source:['expedition','research_ruins','crafting','black_market'][i%4],draw:true,gambler:false,downside:i===19||i===24?{agility:-3}:i>=30?{stability:-3,pollution:2}:{},visual:{shape:shapes[i%10],width:39+i%7*3,height:70+i%9*4,neck:10+i%5*3,cap:['cork','crimp','screw','seal','antenna'][i%5],color:colors[i%10],mark:i,ornament:['thread','badge','crack','cage','leaf','wire','dial','seal','none'][i%9],liquid:['still','bubbles','split','swirl','orbit'][Math.floor(i/10)],asset:null}}));
 const bets=[['uncommon','铁币试剂','Iron Coin Wager','一个赌徒把欠条折成瓶套，留下一句：别把希望当工资。','A gambler folded an IOU into a sleeve: do not treat hope as wages.',.62,2],['rare','双面契约','Two-Faced Contract','瓶塞有两枚印章。签署者坚称自己只盖过其中一枚。','Its stopper has two seals. The signer insists she used just one.',.51,5],['epic','盲钟赌液','Blind Clock Wager','地下拳馆的钟没有表盘。每次开瓶，下注者都先听见铃声。','The underground gym clock has no face. Every opening precedes a bell.',.42,9],['legendary','末班车筹码','Last Train Chip','最后一班车离开后，有人把唯一的车票塞进了这瓶的底座。','After the last train left, someone tucked the sole ticket into its base.',.32,14],['anomalous','不存在的胜局','The Win That Never Was','瓶底记着一场没有人参加的胜利。失败名单上却有你的名字。','Its base records a victory nobody attended. Your name appears on the list of losses.',.23,20]];
 bets.forEach(([rarity,zh,en,lore,loreEn,chance,penalty],i)=>serums.push({id:'serum_bet_'+rarity,name:t(zh,en),en,rarity,effect:'gamble',amount:0,gambler:true,chance,penalty,lore:t(lore,loreEn),description:t('一次不可撤回的虚构试验；可能收益与惩罚随稀有度提高。','An irreversible fictional trial; rewards and penalties rise with rarity.'),source:'gacha',draw:true,downside:{},visual:{shape:['double','hex','spiral','orb','wedge'][i],width:54+i*3,height:101+i*5,neck:13+i*2,cap:'coin',color:['#769782','#83aaba','#9b80a9','#c0ab71','#b96c71'][i],mark:50+i,ornament:'dice',liquid:'split',asset:null}}));
 return {serums};
})();
