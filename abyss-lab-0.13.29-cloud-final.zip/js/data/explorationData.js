'use strict';
Abyss.ExpeditionData={
  "locations": [
    {
      "id": "sewers",
      "name": "下水道",
      "en": "SEWERS",
      "danger": 18,
      "unlock": 1,
      "discoveries": "食物 / 废料 / 异生物",
      "recommend": "建议健康 40、敏捷 15",
      "rooms": [
        "淹水隧道",
        "维修室",
        "巢穴"
      ],
      "cost": 2,
      "duration": 3
    },
    {
      "id": "factory",
      "name": "废弃工厂",
      "en": "ABANDONED FACTORY",
      "danger": 38,
      "unlock": 3,
      "discoveries": "机械零件 / 工业材料 / 实验设备",
      "recommend": "建议健康 55、力量 25",
      "rooms": [
        "装配线",
        "熔炉室",
        "经理办公室"
      ],
      "cost": 2,
      "duration": 3
    },
    {
      "id": "forest",
      "name": "森林",
      "en": "FOREST",
      "danger": 35,
      "unlock": 3,
      "discoveries": "有机材料 / 奇异植物 / 生物样本",
      "recommend": "建议健康 55、稳定 60",
      "rooms": [
        "枯树林",
        "湖泊",
        "废弃木屋"
      ],
      "cost": 2,
      "duration": 3
    },
    {
      "id": "city",
      "name": "夜间城市",
      "en": "CITY AT NIGHT",
      "danger": 52,
      "unlock": 5,
      "discoveries": "资金 / 人类物件 / 食物",
      "recommend": "建议健康 65、智力 30",
      "rooms": [
        "便利店后巷",
        "屋顶",
        "地铁入口"
      ],
      "cost": 2,
      "duration": 3
    },
    {
      "id": "ruins",
      "name": "实验废墟",
      "en": "RESEARCH RUINS",
      "danger": 72,
      "unlock": 7,
      "discoveries": "稀有突变 / 机密文档 / 实验材料",
      "recommend": "建议健康 75、稳定 75、智力 40",
      "rooms": [
        "观察翼",
        "低温舱",
        "档案室",
        "密室 ███"
      ],
      "cost": 2,
      "duration": 3
    }
  ],
  "events": [
    {
      "id": "sewers_0",
      "location": "sewers",
      "name": "管后异响",
      "text": "排水管后有什么在移动。",
      "weight": 20,
      "room": "淹水隧道",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "agility",
          "threshold": 31,
          "risky": true,
          "success": {
            "item": "fish",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "exhaustion"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "fish"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "sewers_1",
      "location": "sewers",
      "name": "封闭闸门",
      "text": "门后传来规律的敲击。",
      "weight": 20,
      "room": "维修室",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "strength",
          "threshold": 31,
          "risky": true,
          "success": {
            "item": "scrap",
            "flag": "sewer_gate_open",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "contamination"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "fish"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "sewers_2",
      "location": "sewers",
      "name": "检修终端",
      "text": "屏幕闪烁着旧维护指令。",
      "weight": 20,
      "room": "维修室",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "intelligence",
          "threshold": 31,
          "risky": true,
          "success": {
            "item": "gear",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "lost"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "fish"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "sewers_3",
      "location": "sewers",
      "name": "温水孢群",
      "text": "孢子在温水上拼成圆环。",
      "weight": 20,
      "room": "淹水隧道",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "stability",
          "threshold": 31,
          "risky": true,
          "success": {
            "item": "spore",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "loot"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "fish"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "sewers_4",
      "location": "sewers",
      "name": "巢穴残页",
      "text": "巢穴铺着防水的事故记录。",
      "weight": 5,
      "room": "巢穴",
      "requires": [
        "sewer_gate_open"
      ],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "intelligence",
          "threshold": 31,
          "risky": true,
          "success": {
            "item": "map",
            "flag": null,
            "doc": "001",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "penalty"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "fish"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "factory_0",
      "location": "factory",
      "name": "主配电箱",
      "text": "一根电缆通向地下深处。",
      "weight": 20,
      "room": "装配线",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "intelligence",
          "threshold": 37.666666666666664,
          "risky": true,
          "success": {
            "item": "wire",
            "flag": "factory_power_restored",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "exhaustion"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "scrap"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "factory_1",
      "location": "factory",
      "name": "倾覆机械臂",
      "text": "机械臂压住了补给箱。",
      "weight": 20,
      "room": "装配线",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "strength",
          "threshold": 37.666666666666664,
          "risky": true,
          "success": {
            "item": "gear",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "contamination"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "scrap"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "factory_2",
      "location": "factory",
      "name": "熔炉余温",
      "text": "关闭多年的熔炉仍然温热。",
      "weight": 20,
      "room": "熔炉室",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "stability",
          "threshold": 37.666666666666664,
          "risky": true,
          "success": {
            "item": "glass",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "lost"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "scrap"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "factory_3",
      "location": "factory",
      "name": "装配线回声",
      "text": "传送带忽然启动。",
      "weight": 20,
      "room": "装配线",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "agility",
          "threshold": 37.666666666666664,
          "risky": true,
          "success": {
            "item": "servo",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "loot"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "scrap"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "factory_4",
      "location": "factory",
      "name": "经理的抽屉",
      "text": "一份转移令盖着熟悉的章。",
      "weight": 5,
      "room": "经理办公室",
      "requires": [
        "factory_power_restored"
      ],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "intelligence",
          "threshold": 37.666666666666664,
          "risky": true,
          "success": {
            "item": "badge",
            "flag": null,
            "doc": "004",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "penalty"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "scrap"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "forest_0",
      "location": "forest",
      "name": "树间信号",
      "text": "树干内部传来无线电噪声。",
      "weight": 20,
      "room": "枯树林",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "intelligence",
          "threshold": 36.666666666666664,
          "risky": true,
          "success": {
            "item": "seed",
            "flag": "forest_signal_detected",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "exhaustion"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "berry"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "forest_1",
      "location": "forest",
      "name": "湖下微光",
      "text": "水面倒影比它慢了一拍。",
      "weight": 20,
      "room": "湖泊",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "stability",
          "threshold": 36.666666666666664,
          "risky": true,
          "success": {
            "item": "spore",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "contamination"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "berry"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "forest_2",
      "location": "forest",
      "name": "缠绕树根",
      "text": "枝根保护着一团发热组织。",
      "weight": 20,
      "room": "枯树林",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "strength",
          "threshold": 36.666666666666664,
          "risky": true,
          "success": {
            "item": "tissue",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "lost"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "berry"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "forest_3",
      "location": "forest",
      "name": "木屋脚步",
      "text": "屋顶传来第二组脚步声。",
      "weight": 20,
      "room": "废弃木屋",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "agility",
          "threshold": 36.666666666666664,
          "risky": true,
          "success": {
            "item": "berry",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "loot"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "berry"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "forest_4",
      "location": "forest",
      "name": "枯树林",
      "text": "没有风，树叶却朝同一方向倾斜。",
      "weight": 5,
      "room": "枯树林",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "stability",
          "threshold": 36.666666666666664,
          "risky": true,
          "success": {
            "item": "moss",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "penalty"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "berry"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "city_0",
      "location": "city",
      "name": "夜班联系人",
      "text": "陌生人认出了它的编号。",
      "weight": 20,
      "room": "便利店后巷",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "intelligence",
          "threshold": 42.33333333333333,
          "risky": true,
          "success": {
            "item": "coin",
            "flag": "city_contact_met",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "exhaustion"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "coin"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "city_1",
      "location": "city",
      "name": "后巷补给",
      "text": "便利店后门留着未拆封纸箱。",
      "weight": 20,
      "room": "便利店后巷",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "agility",
          "threshold": 42.33333333333333,
          "risky": true,
          "success": {
            "item": "gel",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "contamination"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "coin"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "city_2",
      "location": "city",
      "name": "屋顶追光",
      "text": "探照灯扫过唯一的通路。",
      "weight": 20,
      "room": "屋顶",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "agility",
          "threshold": 42.33333333333333,
          "risky": true,
          "success": {
            "item": "watch",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "lost"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "coin"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "city_3",
      "location": "city",
      "name": "地铁封条",
      "text": "封条内是一排空担架。",
      "weight": 20,
      "room": "地铁入口",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "strength",
          "threshold": 42.33333333333333,
          "risky": true,
          "success": {
            "item": "map",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "loot"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "coin"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "city_4",
      "location": "city",
      "name": "末班广播",
      "text": "广播要求所有研究员立即撤离。",
      "weight": 5,
      "room": "地铁入口",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "stability",
          "threshold": 42.33333333333333,
          "risky": true,
          "success": {
            "item": "tape",
            "flag": null,
            "doc": "011",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "penalty"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "coin"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "ruins_0",
      "location": "ruins",
      "name": "档案权限",
      "text": "终端要求输入一个已经遗忘的编号。",
      "weight": 20,
      "room": "档案室",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "intelligence",
          "threshold": 49,
          "risky": true,
          "success": {
            "item": "map",
            "flag": "ruins_archive_unlocked",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "exhaustion"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "glass"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "ruins_1",
      "location": "ruins",
      "name": "观察翼",
      "text": "每扇窗后都摆着同样的椅子。",
      "weight": 20,
      "room": "观察翼",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "stability",
          "threshold": 49,
          "risky": true,
          "success": {
            "item": "glass",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "contamination"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "glass"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "ruins_2",
      "location": "ruins",
      "name": "低温记录",
      "text": "霜层下是一组仍在跳动的数据。",
      "weight": 20,
      "room": "低温舱",
      "requires": [],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "intelligence",
          "threshold": 49,
          "risky": true,
          "success": {
            "item": "reagent",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "lost"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "glass"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "ruins_3",
      "location": "ruins",
      "name": "容器裂隙",
      "text": "某种组织正在向它伸展。",
      "weight": 20,
      "room": "低温舱",
      "requires": [
        "ruins_archive_unlocked"
      ],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "stability",
          "threshold": 49,
          "risky": true,
          "success": {
            "item": "tissue",
            "flag": "mutation_resonance",
            "mutation": true,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "loot"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "glass"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "ruins_4",
      "location": "ruins",
      "name": "密室 ███",
      "text": "门上刻着你的培养舱编号。",
      "weight": 5,
      "room": "密室 ███",
      "requires": [
        "ruins_archive_unlocked"
      ],
      "choices": [
        {
          "id": "investigate",
          "label": "深入调查",
          "stat": "strength",
          "threshold": 49,
          "risky": true,
          "success": {
            "item": "crystal",
            "flag": null,
            "doc": "redacted",
            "mutation": false,
            "effects": {
              "loyalty": 2
            }
          },
          "failure": {
            "effects": {
              "health": -7,
              "stability": -3
            },
            "hazard": "penalty"
          }
        },
        {
          "id": "observe",
          "label": "保持距离，扫描环境",
          "stat": "intelligence",
          "threshold": 18,
          "success": {
            "item": "glass"
          },
          "failure": {
            "effects": {
              "mood": -2
            }
          }
        },
        {
          "id": "ignore",
          "label": "忽略并继续",
          "success": {
            "effects": {
              "stability": 1
            }
          }
        },
        {
          "id": "retreat",
          "label": "下令撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "unknown_creature",
      "location": "sewers",
      "name": "另一只未知生物",
      "text": "它认出了你发出的呼唤。",
      "weight": 0.18,
      "rare": true,
      "requires": [],
      "choices": [
        {
          "id": "contact",
          "label": "尝试接触 · 高风险",
          "stat": "stability",
          "threshold": 70,
          "risky": true,
          "success": {
            "item": "key",
            "flag": "unknown_creature_seen"
          },
          "failure": {
            "effects": {
              "health": -8,
              "pollution": 8
            },
            "hazard": "lost"
          }
        },
        {
          "id": "ignore",
          "label": "记录后离开",
          "success": {
            "flag": "unknown_creature_seen"
          }
        },
        {
          "id": "retreat",
          "label": "撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "containment_pod",
      "location": "factory",
      "name": "遗弃收容舱",
      "text": "舱门从内部被打开。",
      "weight": 0.18,
      "rare": true,
      "requires": [],
      "choices": [
        {
          "id": "contact",
          "label": "尝试接触 · 高风险",
          "stat": "stability",
          "threshold": 70,
          "risky": true,
          "success": {
            "item": "servo",
            "flag": "pod_found"
          },
          "failure": {
            "effects": {
              "health": -8,
              "pollution": 8
            },
            "hazard": "lost"
          }
        },
        {
          "id": "ignore",
          "label": "记录后离开",
          "success": {
            "flag": "pod_found"
          }
        },
        {
          "id": "retreat",
          "label": "撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "researcher",
      "location": "city",
      "name": "雨中的研究员",
      "text": "他只留下了一句：不要相信楼层编号。",
      "weight": 0.18,
      "rare": true,
      "requires": [],
      "choices": [
        {
          "id": "contact",
          "label": "尝试接触 · 高风险",
          "stat": "stability",
          "threshold": 70,
          "risky": true,
          "success": {
            "item": "badge",
            "flag": "researcher_seen"
          },
          "failure": {
            "effects": {
              "health": -8,
              "pollution": 8
            },
            "hazard": "lost"
          }
        },
        {
          "id": "ignore",
          "label": "记录后离开",
          "success": {
            "flag": "researcher_seen"
          }
        },
        {
          "id": "retreat",
          "label": "撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "radio",
      "location": "forest",
      "name": "不存在的频道",
      "text": "电台播放着你明天的观察日志。",
      "weight": 0.18,
      "rare": true,
      "requires": [],
      "choices": [
        {
          "id": "contact",
          "label": "尝试接触 · 高风险",
          "stat": "stability",
          "threshold": 70,
          "risky": true,
          "success": {
            "item": "seed",
            "flag": "radio_received"
          },
          "failure": {
            "effects": {
              "health": -8,
              "pollution": 8
            },
            "hazard": "lost"
          }
        },
        {
          "id": "ignore",
          "label": "记录后离开",
          "success": {
            "flag": "radio_received"
          }
        },
        {
          "id": "retreat",
          "label": "撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "footprints",
      "location": "forest",
      "name": "相同的足迹",
      "text": "脚印与它完全一致，却大了一圈。",
      "weight": 0.18,
      "rare": true,
      "requires": [],
      "choices": [
        {
          "id": "contact",
          "label": "尝试接触 · 高风险",
          "stat": "stability",
          "threshold": 70,
          "risky": true,
          "success": {
            "item": "tissue",
            "flag": "matching_footprints"
          },
          "failure": {
            "effects": {
              "health": -8,
              "pollution": 8
            },
            "hazard": "lost"
          }
        },
        {
          "id": "ignore",
          "label": "记录后离开",
          "success": {
            "flag": "matching_footprints"
          }
        },
        {
          "id": "retreat",
          "label": "撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "elevator",
      "location": "ruins",
      "name": "密封地下电梯",
      "text": "按钮上没有上行箭头。",
      "weight": 0.18,
      "rare": true,
      "requires": [],
      "choices": [
        {
          "id": "contact",
          "label": "尝试接触 · 高风险",
          "stat": "stability",
          "threshold": 70,
          "risky": true,
          "success": {
            "item": "tape",
            "flag": "elevator_found"
          },
          "failure": {
            "effects": {
              "health": -8,
              "pollution": 8
            },
            "hazard": "lost"
          }
        },
        {
          "id": "ignore",
          "label": "记录后离开",
          "success": {
            "flag": "elevator_found"
          }
        },
        {
          "id": "retreat",
          "label": "撤回",
          "retreat": true
        }
      ]
    },
    {
      "id": "reactive",
      "location": "ruins",
      "name": "响应的物体",
      "text": "温热的金属随着它呼吸。",
      "weight": 0.18,
      "rare": true,
      "requires": [],
      "choices": [
        {
          "id": "contact",
          "label": "尝试接触 · 高风险",
          "stat": "stability",
          "threshold": 70,
          "risky": true,
          "success": {
            "item": "object17",
            "flag": "object_awakened"
          },
          "failure": {
            "effects": {
              "health": -8,
              "pollution": 8
            },
            "hazard": "lost"
          }
        },
        {
          "id": "ignore",
          "label": "记录后离开",
          "success": {
            "flag": "object_awakened"
          }
        },
        {
          "id": "retreat",
          "label": "撤回",
          "retreat": true
        }
      ]
    }
  ],
  "documents": [
    {
      "id": "001",
      "name": "事故报告",
      "text": "03:17，所有观察窗同时从内部起雾。值班员报告：舱里没有东西。"
    },
    {
      "id": "004",
      "name": "样本转移令",
      "text": "将零号系列转入下层设施。收件实验室编号与你的门牌一致。"
    },
    {
      "id": "011",
      "name": "设施疏散通知",
      "text": "撤离时不得呼叫样本名字。电梯只允许向下。"
    },
    {
      "id": "redacted",
      "name": "DOCUMENT ███",
      "text": "[已删节] 不是第一座。也不是最后一座。请勿恢复主信号。"
    }
  ],
  "tables": {
    "sewers": [
      "fish",
      "gel",
      "junk",
      "scrap",
      "spore",
      "key"
    ],
    "factory": [
      "scrap",
      "wire",
      "gear",
      "glass",
      "servo",
      "tape"
    ],
    "forest": [
      "berry",
      "moss",
      "spore",
      "seed",
      "tissue",
      "crystal"
    ],
    "city": [
      "coin",
      "gel",
      "watch",
      "junk",
      "badge",
      "map"
    ],
    "ruins": [
      "glass",
      "reagent",
      "map",
      "badge",
      "crystal",
      "core",
      "pod",
      "object17"
    ]
  },
  "loot": [
    {
      "id": "fish",
      "name": "盲眼鱼",
      "category": "FOOD",
      "rarity": "COMMON",
      "description": "温水管道中的食物。",
      "food": "meat"
    },
    {
      "id": "gel",
      "name": "密封营养包",
      "category": "FOOD",
      "rarity": "COMMON",
      "description": "未过期的补给。",
      "food": "ration"
    },
    {
      "id": "berry",
      "name": "夜光浆果",
      "category": "FOOD",
      "rarity": "UNCOMMON",
      "description": "浅蓝色果汁。",
      "food": "fruit"
    },
    {
      "id": "scrap",
      "name": "废金属",
      "category": "MECHANICAL PART",
      "rarity": "COMMON",
      "description": "仍可回收的金属。"
    },
    {
      "id": "gear",
      "name": "精密齿轮",
      "category": "MECHANICAL PART",
      "rarity": "UNCOMMON",
      "description": "齿距异常一致。"
    },
    {
      "id": "servo",
      "name": "实验伺服器",
      "category": "MECHANICAL PART",
      "rarity": "RARE",
      "description": "仍在响应旧协议。"
    },
    {
      "id": "spore",
      "name": "荧光孢子",
      "category": "BIOLOGICAL SAMPLE",
      "rarity": "COMMON",
      "description": "避光保存。"
    },
    {
      "id": "tissue",
      "name": "再生组织",
      "category": "BIOLOGICAL SAMPLE",
      "rarity": "RARE",
      "description": "断面正在闭合。"
    },
    {
      "id": "seed",
      "name": "黑色种子",
      "category": "BIOLOGICAL SAMPLE",
      "rarity": "UNCOMMON",
      "description": "会追随声音转动。"
    },
    {
      "id": "reagent",
      "name": "稳定试剂",
      "category": "RESEARCH MATERIAL",
      "rarity": "UNCOMMON",
      "description": "标签来自另一座实验室。"
    },
    {
      "id": "crystal",
      "name": "异常晶体",
      "category": "RESEARCH MATERIAL",
      "rarity": "EPIC",
      "description": "不规则的脉冲。"
    },
    {
      "id": "core",
      "name": "冷冻核心",
      "category": "RESEARCH MATERIAL",
      "rarity": "LEGENDARY",
      "description": "容器内的时间似乎更慢。"
    },
    {
      "id": "coin",
      "name": "旧币",
      "category": "VALUABLE",
      "rarity": "COMMON",
      "description": "旧城区仍有收购者。"
    },
    {
      "id": "watch",
      "name": "停摆手表",
      "category": "VALUABLE",
      "rarity": "UNCOMMON",
      "description": "每一只都停在 03:17。"
    },
    {
      "id": "key",
      "name": "无齿钥匙",
      "category": "UNKNOWN OBJECT",
      "rarity": "RARE",
      "description": "用途：???"
    },
    {
      "id": "object17",
      "name": "OBJECT ███-17",
      "category": "UNKNOWN OBJECT",
      "rarity": "ANOMALOUS",
      "description": "温热的金属物体。用途：???"
    },
    {
      "id": "badge",
      "name": "研究员证件",
      "category": "CLASSIFIED OBJECT",
      "rarity": "RARE",
      "description": "照片被刮去。"
    },
    {
      "id": "tape",
      "name": "加密磁带",
      "category": "CLASSIFIED OBJECT",
      "rarity": "EPIC",
      "description": "录音里只有呼吸。"
    },
    {
      "id": "wire",
      "name": "绝缘线圈",
      "category": "MECHANICAL PART",
      "rarity": "COMMON",
      "description": "尚可使用。"
    },
    {
      "id": "moss",
      "name": "滤毒苔藓",
      "category": "BIOLOGICAL SAMPLE",
      "rarity": "COMMON",
      "description": "吸附了大量尘埃。"
    },
    {
      "id": "glass",
      "name": "耐压玻璃",
      "category": "RESEARCH MATERIAL",
      "rarity": "COMMON",
      "description": "带有培养舱编号。"
    },
    {
      "id": "map",
      "name": "设施残图",
      "category": "CLASSIFIED OBJECT",
      "rarity": "UNCOMMON",
      "description": "地图边缘延伸至你的实验室。"
    },
    {
      "id": "pod",
      "name": "封存胚盒",
      "category": "CLASSIFIED OBJECT",
      "rarity": "LEGENDARY",
      "description": "封条上的日期尚未到来。"
    },
    {
      "id": "junk",
      "name": "潮湿杂物",
      "category": "UNKNOWN OBJECT",
      "rarity": "COMMON",
      "description": "用途：???"
    }
  ],
  "rarityWeights": {
    "COMMON": 70,
    "UNCOMMON": 23,
    "RARE": 5,
    "EPIC": 1.5,
    "LEGENDARY": 0.12,
    "ANOMALOUS": 0.01
  }
};
