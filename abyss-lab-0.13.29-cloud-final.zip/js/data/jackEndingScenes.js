'use strict';
(()=>{
 const {tr,replace,C}=Abyss.JackData;
 replace('p6_ending_we',`N|终端显示：最终实验体数量，2。|The terminal displayed: FINAL SUBJECT COUNT: 2.
B|不喜欢这个词。|I don't like that word.
J|我也不喜欢。|Neither do I.
N|Jack 关掉分类页，没有关掉照明。|Jack closed the classification page. He left the light on.
T|它记过我的体温。我记过它的。系统终于把两个人都算进去，却还是只会这么叫我们。|It has recorded my temperature. I have recorded its. The system finally counted both of us. Still, this was its only word.
B|你还是会想把门关上。|You'll still want to close the door.
J|可能会。|I might.
B|我还是会记得。|I'll still remember.
J|我知道。|I know.
N|没有人要求用今晚覆盖过去。|Neither asked tonight to overwrite the past.
J|我曾经是你最安全的人。也是把门锁着的人。|I was your safest person. I was also the person who kept the door locked.
B|现在也是你。|You're still you now.
T|不是赦免。也不是判决。我得继续在这里听。|Not absolution. Not a verdict. I had to remain here and listen.
N|钥匙平放在桌面，两个人都够得到。|The key lay flat on the table, within reach of both.
B|如果我改主意呢？|What if I change my mind?
J|我们再说。你不是签过同意就不能反悔的设备。|We talk again. You're not equipment that can't withdraw consent once signed.
N|它碰了一下钥匙，没有把它交回 Jack。|It touched the key. It did not hand it back to Jack.
B|你也可以说不。|You can say no too.
J|我会试着别把“不”藏在规则里面。|I'll try not to hide no inside a rule.
N|出口风扇的声音很远，门内的空气仍暖。|The exit fan sounded far away. The air inside was still warm.
T|我还怕。怕外面，怕没有计划，怕它发现不需要我。|I was still afraid. Of outside. Of no plan. Of it finding it didn't need me.
J|我想离开这里。|I want to leave this place.
B|去哪？|Where?
N|Jack 看了一眼没有填写目的地的地图。|Jack looked at the map with no destination marked.
T|这一次，不能只说“之后再说”，然后把钥匙收起来。|This time I couldn't say “later” and pocket the key.`,{group:'ending',title:tr('TRUE WE · 两个人','TRUE WE · Two of us'),nextNode:null,choices:[
 C('home','“找个能从里面开门的家。”','“A home where the door opens from inside.”',{jackFlag:'destination_home',nextNode:'p8_we_leave'}),
 C('sea','“我想看海。你愿意一起吗？”','“I want to see the sea. Would you come?”',{jackFlag:'destination_sea',nextNode:'p8_we_leave'}),
 C('you','“先去你想去的地方。”','“Where you want to go first.”',{jackFlag:'destination_you',nextNode:'p8_we_leave'}),
 C('figure','“我们边走边想。”','“We figure it out as we walk.”',{jackFlag:'destination_figure',nextNode:'p8_we_leave'}),
 C('silence','把门打开，留给它回答的时间','Open the door and leave time for its answer',{jackFlag:'destination_silence',nextNode:'p8_we_leave'})]});
 const we=replace('p8_we_leave',`J|这扇门，今天打开。|This door opens today.
N|Jack 将手动锁转到尽头，退开，没有把钥匙揣回口袋。|Jack turned the manual lock all the way. He stepped back without pocketing the key.
B|不是只开一会儿？|Not just for a little while?
J|不是。我会跟你商量，不会偷偷锁回去。|No. I'll talk to you. I won't secretly lock it again.
N|它看了眼曾经睡觉的地方。|It looked at the place where it had slept.
N|Jack 没催它。|Jack did not hurry it.
B|我想带走那个碗。|I want to take that bowl.
J|好。|All right.
N|他把碗装进包，包上空着的一侧留给它选择。|He packed the bowl, leaving the other side of the bag empty for its choices.
T|离开不是把留下过的东西全部扔掉。|Leaving didn't mean throwing away everything that had stayed.
N|它先走到门槛，再回头看他。|It reached the threshold first, then looked back.
B|你走不走？|Are you coming?
J|走。|Yes.
N|Jack 第一次没有站在门外看它，而是走到旁边。|For the first time Jack did not stand outside the door watching it. He walked alongside.
N|风里有尘土，水管里仍有没修好的响声。|There was dust in the wind. Unrepaired pipes still rattled.
B|坏了。|Broken.
J|是。今天先不修。|Yes. Not fixing that today.
N|它没有笑。他也没有把沉默解释成后悔。|It did not laugh. He did not interpret silence as regret.
T|它的脚步可以比我快，也可以停下。|Its steps could be faster than mine. It could stop.
N|设施在背后继续亮着。|The facility remained lit behind them.
N|他们跨过了最后一段门轨。|They stepped over the final door rail.
N|门没有在他们之间落下。|The door did not fall between them.
T|今天没有一个完整答案。今天有两个人走出来。|There wasn't a complete answer today. There were two of us walking out.
N|Jack 听见旁边的脚步，没有再把它们记成样本行为。|Jack heard footsteps beside him. He did not record them as specimen behavior.`,{group:'ending',title:tr('门外','Outside'),choices:[C('continue','把这段经历留在记录里','Keep this experience in the record',{jackEndComplete:true,jackJournal:'exit',openContainment:true})]});
 we.lines[6].variants=[{requirements:{'narrative.jack.flags.destination_sea':{min:1}},text:tr('碗也能带去海边吗？','Can the bowl come to the sea too?')},{requirements:{'narrative.jack.flags.destination_you':{min:1}},text:tr('先去有风的地方。碗也带着。','Somewhere with wind first. Bring the bowl too.')},{requirements:{'narrative.jack.flags.destination_home':{min:1}},text:tr('家里的门，我也要有钥匙。','I want a key to the door at home too.')}];
 replace('p6_ending_sea',`N|海没有照片里那么蓝。|The sea was not as blue as the photograph.
N|灰色的水一层层走向岸边，带着盐和旧木头的气味。|Grey water came ashore in layers, smelling of salt and old wood.
J|到了。|We're here.
B|你在发抖。|You're shaking.
J|风很大。也有一点……别的。|The wind. And a little... something else.
N|它站在他旁边，没有被放到他前面当作证明。|It stood beside him. He did not place it ahead of him as proof.
B|你以前真没见过？|Really never seen it before?
J|真没。|Really.
T|我以为到了会说点像样的话。二十七年没见过的东西，原来不等我准备好句子。|I thought I'd have something decent to say. Something unseen for twenty-seven years didn't wait for me to prepare a sentence.
N|一小股水浸过鞋底。Jack 后退一步。|A little water soaked through his soles. Jack stepped back.
J|好吧，鞋也第一次见海。|Well. First sea for the shoes too.
B|很湿。|Very wet.
J|观察准确。|Accurate observation.
N|它蹲下，等下一道浪自己过来。|It crouched and waited for the next wave to arrive by itself.
N|Jack 没有把它拉到安全线后。岸上没有画那条线。|Jack did not pull it behind a safety line. No line had been drawn on this shore.
J|浪大了我们一起退。|If the waves grow, we both step back.
B|可以。|All right.
N|他们没有解决明天吃什么。也没有得到 Jasmine 的最终答案。|They hadn't solved tomorrow's food. Nor received a final answer about Jasmine.
T|不能让海替所有不知道的事收尾。|I couldn't make the sea conclude everything unknown.
N|红线湿了，贴在手腕上。|The wet thread clung to his wrist.
B|你可以想她。|You can think of her.
J|嗯。也可以站在这里。|Yes. And stand here too.
N|风把他说话的尾音吹散。他没有再说一次。|The wind scattered the end of his sentence. He did not repeat it.
N|它看着水。他看着它，又看向水。|It watched the water. He looked at it, then at the water.
T|我终于没有拿一张照片，假装自己知道它会看到什么。|At last I wasn't holding a photograph and pretending to know what it would see.
N|他们在岸边待了很久。|They stayed on the shore a long time.`,{group:'ending',nextNode:null,choices:[C('stay','在这里停一会儿，再共同决定下一步','Stay a while, then decide the next step together',{jackEndComplete:true,jackJournal:'sea',openContainment:true})]});
 const endings=[
 ['collapse','最后的呼吸','The final breath','Jack 的手又抖了一次。这回扳手没有被捡起来。','Jack’s hand shook again. This time the wrench was not picked up.','他想说只是累了。话没有说完。','He wanted to say he was only tired. He could not finish.'],
 ['last_creature','留下来的名字','The remaining name','Jack 把隔离负载转到自己的线路，培养舱的供氧恢复了。','Jack transferred the isolation load to his own line. Air returned to the chamber.','他的呼吸声停了。它仍在呼吸，空椅子却不再等来脚步。','His breathing stopped. It was still breathing. The empty chair no longer received footsteps.'],
 ['betrayal','没有偿还','No debt repaid','它退到门外，隔离锁在 Jack 这一侧落下。','It stepped outside. The isolation lock dropped on Jack’s side.','它用过他教的授权谎言。他喊了一次它的名字；旧供氧线路没有响应维护卡。','It had used the authorization lie he taught it. He called its name once. The old oxygen line did not respond to his maintenance badge.'],
 ['together_end','灯灭以前','Before the light goes out','最后一组电池没有接通。','The last battery bank did not connect.','Jack 把工具放下。继续修理已经不是这一次的答案。','Jack set down his tools. More repairs were not the answer this time.']
 ];
 for(const [id,title,en,a,ae,b,be]of endings){const n=replace('p6_ending_'+id,`N|${a}|${ae}
N|${b}|${be}
T|我总想找到还能做的一件事。|I always want to find one more thing I can do.
N|这一次没有跳到一张结算表。|This time did not skip to a results table.
N|屋里的声音一点点减下来。|The sounds in the room diminished one by one.
J|我在这里。|I'm here.
N|这句话不是指令。|The words were not an instruction.
N|桌上还有旧照片和未写完的维护单。|An old photograph and an unfinished maintenance form remained on the desk.
N|红线没有告诉任何人应该原谅谁。|The red thread told nobody whom to forgive.
T|不能把“我尽力了”放在别人该回答的位置。|I can't put “I did my best” in the place where someone else should answer.
N|灯光在玻璃上留下一道细线。|The light left a thin line on the glass.
N|有人停在门槛，久久没有移动。|Someone remained at the threshold a long time.
N|没有新的警报要求他们赶快选择。|No new alarm demanded that they choose quickly.
N|那一晚慢慢过去。|That night passed slowly.
N|之后，有些声音再没有回来。|Afterward, some sounds never returned.
N|碗留在原来的架子上。|The bowl remained on its shelf.
N|备用钥匙没有被系统回收。|The system did not reclaim the spare key.
N|这段关系没有被改写成一次成功或失败的培养。|The relationship was not rewritten as a successful or failed raising experiment.
N|过去的照顾仍发生过。过去的锁也仍存在过。|The care had happened. So had the locked door.
N|后来再有人读到这份记录，日期之间留着空白。|When someone later read the record, there were blank spaces between dates.
N|空白没有替任何人说出原谅。|The blank spaces spoke forgiveness for nobody.
N|最后一行没有实验评级。|The last line contained no experimental grade.
N|只有一个曾经被叫过的名字。|Only a name that had once been spoken.
N|记录停在这里。|The record paused here.`,{group:'ending',title:tr(title,en),nextNode:null,choices:[C('remember','保留这段经历，包括没能修好的部分','Keep this experience, including what could not be repaired',{jackEndComplete:true,jackJournal:'exit'})]});
 if(id==='collapse'||id==='together_end'){n.lines.splice(6,0,{speaker:'creature',voice:'dialogue',minLanguage:4,requiresSwear:true,text:tr('别他妈现在不说话。','Don’t fucking stop talking now.'),noSwear:tr('别现在不说话。求你。','Don’t stop talking now. Please.'),language:{clean:tr('别现在不说话。求你。','Don’t stop talking now. Please.'),mild:tr('该死，别现在不说话。','Damn it, don’t stop talking now.'),full:tr('别他妈现在不说话。','Don’t fucking stop talking now.')}});}
 if(id==='collapse')n.lines.splice(13,0,...Abyss.JackData.lines(`N|天花板裂开以前，他把它推过出口。|Before the ceiling split, he pushed it through the exit.
J|走。门从你那边也能开。|Go. It opens from your side too.
N|塌下的梁隔开了脚步。它在地面等到灯光消失。|A fallen beam separated the footsteps. It waited above until the lights vanished.
N|天亮之后，它自己捡起那只旧包。|After dawn it picked up the old bag itself.`));
 if(id==='betrayal')n.lines.splice(13,0,...Abyss.JackData.lines(`N|数日之后，隔离日志停止更新。Jack 没有走出那道门。|Days later the isolation log stopped updating. Jack had not walked out of that door.
N|它没有留下胜利的宣言，只有一次删除授权的记录。|It left no declaration of victory. Only an authorization deletion.
N|读档的人能确认死亡，不能替它确认那时的每一个想法。|A reader could confirm the death, not every thought it had then.`));
 if(id==='last_creature')n.lines.splice(15,0,...Abyss.JackData.lines(`N|很久之后，它穿着 Jack 缝过的衣服走出实验室。|Much later it left the laboratory wearing clothes Jack had mended.
N|它带着碗，却还不知道下一顿饭在哪里。|It carried the bowl without knowing where the next meal would be.
N|门两侧的解锁柄仍然能用。|The releases on both sides of the door still worked.`));
 }
})();
