'use strict';
// Two hand-authored collections; no shared silhouette or rarity recolor variants.
Abyss.AtelierCollection=(()=>{
 const t=Abyss.HomeData.t,slots=['head','face','neck','body','back','tail','charm','utility','effect','weapon'];
 const rows=[
 ['tidal_cap','潮汐航灯帽','Tidal Lantern Cap','uncommon','灯罩缝在防水软帽上，留下盐粒和一道仔细补过的裂口。','A lantern cage sewn onto a waterproof cap bears salt and a carefully mended crack.'],
 ['tidal_lens','海盐潜水镜','Saltwater Diving Lenses','rare','旧铜镜框里装着两片不同年代的玻璃，仍然能看见海。','Two panes from different decades fit the old copper frame. Both still see the sea.'],
 ['tidal_rope','海结领巾','Sailor Knot Scarf','common','帆布的结打得很松，它随时可以自己解开。','The canvas knot is loose enough for the creature to untie itself.'],
 ['tidal_coat','深港水手衣','Deep Harbor Sailor Coat','rare','内衬刻着一道旧航线，目的地被改成了“回家”。','An old route is stitched inside. Its destination now reads “home”.'],
 ['tidal_bell','沉船航钟','Shipwreck Bell Rig','legendary','曾经为遇难者敲响的钟，被改成了同行者的行李。','A bell once rung for the lost has become a companion’s luggage.'],
 ['tidal_shell','潮间贝扣','Intertidal Shell Cuff','uncommon','一枚铰接贝壳，扣上时像在替尾巴盖一条小毯子。','A hinged shell closes like a small blanket over the tail.'],
 ['tidal_pearl','潮汐珍珠瓶','Tidal Pearl Reliquary','epic','瓶里的珍珠在涨潮时转动，即使这里距离海岸很远。','The pearl turns at high tide, even this far from the coast.'],
 ['tidal_sextant','折翼六分仪','Folded Sextant','rare','它测量的从来不是星星，是两个人之间愿意留下的距离。','It measures the distance two people choose to leave between them.'],
 ['tidal_echo','深海回旋','Deep Sea Wake','anomalous','没有水，气泡却仍然向一个看不见的海面浮去。','Without water, bubbles still rise toward an unseen sea.'],
 ['tidal_oar','归岸短桨','Homeward Oar','epic','磨光的桨面没有刀刃，只刻着一扇打开的门。','The polished oar has no edge, only the carving of an open door.'],
 ['archive_beret','夜班档案贝雷帽','Night Archive Beret','common','值夜班的人把笔插在帽边，怕忘记刚刚想到的一句话。','A night archivist kept a pen in the brim to save a thought.'],
 ['archive_loupe','档案放大镜','Archivist Loupe','uncommon','多层镜片可以折起，不用隔着玻璃看别人。','The layered lenses fold away when you want to see someone directly.'],
 ['archive_key','书页钥链','Page Key Necklace','rare','小钥匙开不了舱门，却能打开一本被钉死的日记。','The small key cannot open a chamber, but can open a sealed diary.'],
 ['archive_waistcoat','星页马甲','Star Page Waistcoat','epic','暗蓝布料上绣着书页和星图。它不需要成为谁的制服。','Pages and star charts are embroidered on dark blue cloth. It need not be anyone’s uniform.'],
 ['archive_library','随行书柜','Traveling Library','rare','不同厚度的旧书被绑在一起，最中间留着一本空白。','Old books of different sizes are bound together, with a blank one at the center.'],
 ['archive_seal','蜡封尾绶','Wax Seal Tail Sash','uncommon','蜡封上刻着 Jack 的字母，绶带的结却由它自己选择。','The seal bears Jack’s initial. The creature chose the knot.'],
 ['archive_rose','纸页玫瑰','Page Rose','legendary','从一份作废的实验命令折出的花。那些字终于不再命令人。','A rose folded from a cancelled experiment order. The words no longer command anyone.'],
 ['archive_lamp','口袋油灯','Pocket Oil Lamp','rare','它把小灯提到你面前，好像轮到它照亮你的路。','It holds the lamp toward you, as if it is its turn to light your path.'],
 ['archive_stars','未写的星页','Unwritten Star Pages','epic','书页在空中翻开，留下没有写过的星点。','Pages turn in the air, leaving stars that were never written.'],
 ['archive_quill','零墨羽笔','Zero Ink Quill','anomalous','笔没有墨水，却偶尔在玻璃上留下第二个人的笔迹。','The pen holds no ink, yet sometimes leaves a second hand’s writing on the glass.']
 ];
 const items=rows.map(([id,zh,en,rarity,desc,lore],i)=>({id:'atelier_'+id,name:en,zh:t(zh,en),description:t(desc,lore),rarity,slot:slots[i%10],type:'fashion',secret:rarity==='anomalous',unlock:{type:'hunt',hint:t('探索发现或废料抽取','Expedition discovery or scrap draws')},alternatives:rarity==='common'?[{type:'milestone',rules:{'history.care':{min:i<10?6:10}},hint:t('共同生活的纪念','A memento of life together')}]:[],visual:{renderer:'hunt',anchor:['HEAD_TOP','FACE_CENTER','NECK','CHEST','BACK','TAIL_TIP','CHARM_POINT','LEFT_SIDE','FOREGROUND','RIGHT_SIDE'][i%10],theme:i<10?'lab':'formal',variant:i%10,sculpture:id,asset:null},lore:t(desc,lore)}));
 Abyss.Data.accessories.push(...items);Abyss.HuntCosmetics.items.push(...items);
 Abyss.Data.outfitSets.push({id:'atelier_tidal',effect:'tidal',name:t('潮汐同行','Tidal Companions'),items:['atelier_tidal_cap','atelier_tidal_coat','atelier_tidal_rope'],text:t('它摇了摇衣领，像在试着记住海风的方向。','It shakes its collar as if remembering the direction of sea wind.')},{id:'atelier_archive',effect:'reader',name:t('夜班读者','Night Readers'),items:['atelier_archive_beret','atelier_archive_waistcoat','atelier_archive_lamp'],text:t('它把小灯挪向你，给你留出读下一页的位置。','It moves the lamp toward you and leaves room for you to read the next page.')});
 return {items};
})();
