'use strict';
// Two authored interludes per act; later paths inspect concrete biology and shared history.
(()=>{const D=Abyss.NarrativeData;const rows=[
['survival','最后一格电','备用电池亮起红灯。自动喂食器和旧档案终端不能同时工作。','先保障喂食器','分时使用电路，保留调查机会','藏好的食物','它把一小块食物压在身下。昨天你说了明天还会有晚饭。','补足储备，再告诉它位置','给它自己保管的食物盒'],
['irregularity','同一笔迹','两个相隔十七年的签名，在末尾留下相同的停顿。日期仍不足以证明身份。','把两页放在一起比对','先记录纸张与墨水差异','不一致的动作','记录说标本害怕水。它却在今日的水盆前玩了很久。','认真记录今天的差异','问它喜不喜欢水'],
['abandoned','未寄出的信','研究员在信里抱怨食堂的汤，最后一段才提到停止实验的申请。','读出信中普通生活的部分','把申请与撤离记录并排放好','矮小的门','旧育床后的维修门塌了一半。门边还摆着一只空杯子。','清理碎片，等待安全通路','先确认是否还有人回应'],
['bseries','第七份登记','七份表格没有记录物种，却详细记录研究员怎样道歉。','逐份比较照料方式','记录不同形态下相同的拒绝','没有签字的同意','同意栏只有研究员签名，标本一栏是空的。它看了很久。','承认这不是它的同意','把拒绝也加入新表格'],
['zero','三种来源','回收、培养、未知。三张标签贴在同一个旧箱子上。','保留三种解释','追查谁替换了标签','热过的杯沿','它把旧杯子放在自己常用杯子旁边，最后仍选择了新的。','尊重它现在的习惯','把两只杯子都留在架子上'],
['incident','撤离名单','同一名维护员同时出现在撤离名单和留守名单。通行门的时钟停了。','对照独立的电路日志','保留相互冲突的证词','没有镜头的走廊','这里没有监控。地面留下推车和爪印，谁先离开无法判断。','只写下能证实的痕迹','停止替旧痕迹认领一个名字'],
['wasteland','有歌的街区','一位老人修好扬声器，先播放了女儿喜欢的歌曲。今晚这里也有人做晚饭。','留下帮忙接通厨房电路','带走广播频率，准备明天的联络','聚落的门','守门人问它会不会咬人。这个问题让它缩回了手。','承认它会害怕，也会作出选择','请求一个不需要编号的暂住位置'],
['eden','未编号的菜园','扩散地图上写着无人区，眼前却晾着孩子的衣服。','重新测绘有人居住的边界','让村民参加修复计划','不一样的春天','菌群能吸收污染，也可能夺走普通植物的养分。没有万能的修复配方。','把试验限制在无人区','先保住现有的种子'],
['black','黑色授权','授权要求删除异常个体的所有关联记录。你手里的照片不属于数据库。','将照片放进密封袋','拒绝自动删除，保留审计轨迹','最后一次报警','旧系统把同情标记为观察偏差。它却在警报声里主动找你的手。','接住它的回应','把这次行为写成一条完整记录'],
['chamber','空位','旧舱比它大得多。抓痕也不对应今天的爪子，系统仍报出匹配。','记录尺寸上的矛盾','比较系统究竟匹配了什么','第二个人影','扫描屏出现两个轮廓，其中一个来自你站立的位置。','承认你也是被观察的人','保留两道独立的轮廓'],
['second_abyss','出生之前','一张工位登记包含你的名字，日期早于你所知道的出生。签字并不是证明。','寻找其他独立证据','让它知道你也在困惑','网络边缘','不同生物回应相同的节律，有的很友善，有的拒绝继续。你不能替所有个体决定。','保留每个个体的拒绝','关闭强制同步，只留自愿通道'],
['continuity','名字之间','它今天的身体已与第一天不同。第一句话却仍属于它，不属于某一个器官。','用它现在的名字呼唤','问它想保留怎样的记录','两份报告','一份报告记录身体变化，另一份记录你们如何度过饭点。两份都没有完整定义身份。','把日常和实验记录并排保存','承认它不必成为一个结论'],
['final','可以不伟大','聚落问你们愿不愿意帮忙修屋顶。终端仍在等待，屋顶却正在漏雨。','先把今天的屋顶修好','把计划讲给会受影响的人','它的答案','所有协议都已整理。你给它留出回答的空间，而不是替它把沉默记为同意。','听完它的想法','承认你们也可以选择普通生活']
];
for(const [id,t1,x1,l1,l2,t2,x2,l3,l4]of rows){const intro=D.nodes.find(n=>n.id==='project_'+id);if(!intro)continue;const originalNext=intro.nextNode;intro.nextNode='p6_beat_'+id+'_0';for(const [i,title,text,labels]of [[0,t1,x1,[l1,l2]],[1,t2,x2,[l3,l4]]]){const type=i===0?'compassion':'autonomy';D.nodes.push({id:'p6_beat_'+id+'_'+i,group:'project',speaker:'narrator',title,text,requirements:{},priority:100,once:true,nextNode:i===0?'p6_beat_'+id+'_1':originalNext,choices:[{id:'honest',label:labels[0],campaignFlag:id==='eden'?'eden_safe':id==='black'?'physical_proof':id==='second_abyss'?'before_birth':'honest',philosophy:{[type]:2}},{id:'independent',label:labels[1],philosophy:{freedom:2}},{id:'analyze',label:i===0?'请它指出记录里最不合理的一行':'问它希望怎样被记录',hidden:true,requirements:{'stats.intelligence':{min:60},'narrative.languageStage':{min:3}},philosophy:{research:2,continuity:1}},{id:'lie',label:'告诉它没有风险，催促继续',lie:true,philosophy:{ambition:1,utilitarianism:2},resentment:2},{id:'silence',label:i===0?'先留下记号，安静观察':'暂时不作结论',philosophy:{survival:1}}]});}}
})();

(()=>{const D=Abyss.NarrativeData;D.nodes.find(n=>n.id==='door').choices.push({id:'reverse_observation',label:'把断钥匙交给它，一起交换观察的位置',hidden:true,requirements:{metaItem:['observation_key']},philosophy:{autonomy:2}});D.nodes.find(n=>n.id==='p6_beat_second_abyss_0').choices.push({id:'fragment',label:'让零号碎片与两道独立轮廓互相校验',hidden:true,requirements:{metaItem:['zero_fragment']},campaignFlag:'zero_patterns',philosophy:{continuity:2}});D.nodes.find(n=>n.id==='p6_beat_black_0').choices.push({id:'blank_name',label:'用空白名牌保留一个不属于数据库的身份',hidden:true,requirements:{metaItem:['empty_tag']},campaignFlag:'physical_proof',philosophy:{freedom:2}});})();
