'use strict';
Abyss.ContainmentEvents=(()=>{
 const t=(a,b)=>Abyss.HomeData.t(a,b),cases=[
 ['食物藏在床脚','Food Beneath the Bed','它把半份食物留在床脚，像在准备下一次等待。','It saves half a meal beneath the bed, preparing for another wait.','换成密封食盒','Provide a sealed food box','一起检查藏点','Inspect the hiding place together'],
 ['灯下的退路','A Retreat Beneath the Lamp','它不愿从强光下走过。','It refuses to cross the bright light.','调暗那盏灯','Dim that lamp','留出阴影通道','Leave a shaded route'],
 ['门缝旁的等待','Waiting by the Door','它记住了气闸开启的声音。','It remembers the airlock’s opening sound.','安装软隔栏','Install a soft barrier','带它检查门口','Inspect the doorway together'],
 ['水碗被推远','The Displaced Bowl','水碗挡住了它习惯的路线。','The water bowl blocks its usual route.','把水碗移开','Move the bowl','重新安排小窝','Rearrange the nest'],
 ['另一位住户','Another Inhabitant','两个小生命隔着桌腿观察彼此。','Two small lives watch each other around a desk leg.','暂时分开房间','Separate their rooms for now','分别提供食物','Feed them separately'],
 ['新家具的气味','The New Furniture’s Scent','它反复检查新家具的边角。','It repeatedly inspects the new furniture’s edges.','先擦净边角','Clean the edges first','让它慢慢探索','Let it explore slowly'],
 ['玻璃后的声音','A Sound Behind Glass','B-07 停下动作，等它发出下一声。','B-07 pauses and waits for its next sound.','安静陪在旁边','Sit quietly nearby','让它们保留距离','Let them keep their distance'],
 ['旧布的归属','Whose Old Cloth','它不愿交出那块旧布。','It refuses to surrender the old cloth.','修补而不替换','Mend rather than replace it','再放一块新布','Offer another cloth'],
 ['短暂的失踪','Briefly Missing','它藏进一个没有标记的阴影里。','It hides in an unmarked shadow.','用熟悉的食物引导','Guide it with familiar food','静静等待它出来','Wait quietly for it'],
 ['不想继续练习','No More Practice','它把脸转开，练习该结束了。','It turns away. Practice should end.','结束今天的练习','End today’s practice','改为安静陪伴','Sit quietly instead'],
 ['小窝里的礼物','A Gift in the Nest','一块磨圆的废料躺在小窝入口。','Rounded scrap lies at the nest entrance.','保留它选的礼物','Keep its chosen gift','挂在窝旁','Hang it beside the nest'],
 ['过滤器低鸣','The Filter’s Hum','机械低鸣使它有些紧张。','The machine’s hum makes it uneasy.','增加软布隔音','Add soft sound insulation','移到安静空间','Move it somewhere quiet'],
 ['雨夜的清醒','Awake on a Rainy Night','外面的雨声让它迟迟不肯睡。','Rain outside keeps it awake.','放低夜灯','Lower the night light','陪到雨声变小','Stay until the rain softens']];
 const pets=Abyss.ContainmentData.species.flatMap(species=>cases.map((c,i)=>({id:'pet_event_'+species.id+'_'+i,species:species.id,name:t(species.name+' · '+c[0],species.en+' · '+c[1]),text:t(c[2],c[3]),choices:[{id:'first',label:t(c[4],c[5]),stress:-12,bond:3,separate:i===4||i===11},{id:'second',label:t(c[6],c[7]),stress:-7,bond:5}]})));
 const moments=[
 ['它把枕头推到靠墙的一边。','It pushes the pillow toward the wall.','把枕头留在那里','Leave the pillow there','询问是否需要另一只枕头','Ask about another pillow'],
 ['床单的一角一直被卷起来，像一道它能确认的边界。','A sheet corner stays rolled up, a boundary it can recognize.','不展开那一角','Leave that corner rolled','换一条更轻的床单','Offer a lighter sheet'],
 ['睡前它想让夜灯再低一点。','Before sleeping it wants the night light lower.','放低夜灯','Lower the night light','留下可关闭的开关','Leave a switch it can reach'],
 ['床脚的螺丝松了，它先把小住户引开。','A foot bolt loosened. It first guides the small inhabitants away.','一起固定床脚','Secure the bed foot together','先把床挪到墙边','Move the bed toward the wall first'],
 ['一条布被塞进床架的空隙。','A cloth is tucked into a gap in the frame.','询问它想藏住什么','Ask what it wants to keep hidden','保留这个小藏点','Keep the little hiding place'],
 ['雕花的阴影让它想起舱门的纹路。','Carved shadows remind it of the chamber door.','把床移开灯下','Move the bed out of direct light','用软布遮住阴影','Cover the carving with soft cloth'],
 ['它在沙发上留下了一块没人坐的位置。','It leaves one place on the sofa unoccupied.','把空位留给它选择','Let it choose who uses the space','坐在旁边的地上','Sit on the floor nearby'],
 ['一枚纽扣掉进坐垫之间。','A button slips between the cushions.','掀起坐垫找纽扣','Lift the cushion to find it','等它自己试着取出','Let it try retrieving it'],
 ['它想把沙发转向门口。','It wants the sofa facing the doorway.','一起转动沙发','Turn the sofa together','先测量门口通道','Measure the doorway clearance first'],
 ['靠背后有一声很轻的抓挠。','A light scratch sounds behind the backrest.','让宠物慢慢走出来','Let the pet emerge slowly','把靠背移离墙面','Move the backrest away from the wall'],
 ['布面的破口露出一层旧补丁。','A tear reveals an old patch beneath the cloth.','保留旧补丁继续缝补','Mend around the old patch','询问它是否想换面料','Ask whether it wants new fabric'],
 ['它试着邀请 Jack 坐进自己选的位置。','It invites Jack to sit in a place it chose.','接受它的邀请','Accept its invitation','先把工具放下再坐','Put the tools down before sitting'],
 ['它将椅子拖得离玻璃更远一点。','It pulls the chair farther from the glass.','保留这个距离','Keep that distance','问它是否想坐在门外','Ask if it wants to sit outside the door'],
 ['椅背上搭着一件尺寸太小的旧衣服。','An old, too-small garment hangs on the chair.','把旧衣留作纪念','Keep the old garment as a memory','征求同意后改成小毯','Ask permission to make it a small blanket']];
 const room=Abyss.ContainmentData.furniture.slice(0,14).map((f,i)=>({id:'room_event_'+f.id,name:t(f.name+'的痕迹',f.en+' Leaves a Trace'),text:t(moments[i][0],moments[i][1]),choices:[{id:'first',label:t(moments[i][2],moments[i][3]),stress:-4,bond:2},{id:'second',label:t(moments[i][4],moments[i][5]),stress:-3,bond:3}]}));
 const objects=Abyss.ContainmentData.objects.map(o=>({id:'room_event_'+o.id,name:o.name,text:o.lore,choices:[{id:'first',label:t('暂时封存并观察','Store it and observe'),stress:-5,bond:1,store:o.id},{id:'second',label:t('留下记录，保持距离','Record it and keep a distance'),stress:o.evil?4:0,bond:1}]}));
 const events=[...pets,...room,...objects];
 function observe(before,s,c){if(c.type!=='rest'||s.containmentEvent||Abyss.Util.random(s)>.35)return;const active=s.pets.filter(p=>p.active&&p.alive&&!p.escaped),placed=s.bedroom.placed.map(p=>p.id);const pool=events.filter(e=>e.species?active.some(p=>p.species===e.species):placed.includes(e.id.slice(11)));if(!pool.length)return;const e=Abyss.Util.pick(s,pool),p=e.species?Abyss.Util.pick(s,active.filter(p=>p.species===e.species)):null;s.containmentEvent={id:e.id,pet:p?.id||null,day:s.day};}
 function command(s,p){const e=events.find(x=>x.id===s.containmentEvent?.id),choice=e?.choices.find(c=>c.id===p?.choice);if(!choice)return {ok:false,message:t('当前没有这个生活事件。','This life event is not pending.')};const pet=s.pets.find(x=>x.id===s.containmentEvent.pet);if(pet){pet.stress=Abyss.Util.clamp(pet.stress+choice.stress);pet.bondJack=Abyss.Util.clamp(pet.bondJack+choice.bond);if(choice.separate)pet.room='separate';pet.memories.push({day:s.day,text:e.text+' / '+choice.label});pet.memories=pet.memories.slice(-30);}if(choice.store)s.bedroom.placed=s.bedroom.placed.filter(p=>p.id!==choice.store);Abyss.State.log(s,e.name+' / '+choice.label,'story');s.containmentEvent=null;return {ok:true,message:''};}
 Abyss.I18n.register(Abyss.HomeData.english);return {events,pets,observe,command};
})();
