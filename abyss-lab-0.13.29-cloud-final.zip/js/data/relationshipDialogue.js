'use strict';
// Each character has five authored responses, selected from their actual history.
Abyss.RelationshipDialogue=(()=>{
 const t=Abyss.WastelandData.t;
 const rows=[
 ['militia',[
 ['枪放在门边。上次的损失还没清点完，你先别进来。','Leave the gun at the gate. We have not finished counting the losses.'],
 ['修好一台泵，不会自动让你的通行证变绿。今晚我们先核对名单。','Repairing a pump does not clear your pass. Tonight we check the list.'],
 ['你上次教的办法救了门轴。守门的人想亲口谢谢你。','Your method saved the hinge. The guards want to thank you themselves.'],
 ['轮班表上空出了一行。我没填你的名字——愿不愿意来，自己说。','There is a blank on the rota. I did not add your name. Decide for yourself.'],
 ['你可以说那是必要的。我必须听见被你留下的人怎么说。','You may call it necessary. I need to hear the people you left behind.']]],
 ['mechanic',[
 ['工具柜换了锁。不是因为铁锈，你知道为什么。','The tools have a new lock. Not because of rust. You know why.'],
 ['先听泵的声音。等它说完，再把手册拿出来。','Listen to the pump. Take out the manual after it has finished speaking.'],
 ['新学徒装反了垫圈。我以前也装反过，别急着笑他。','The apprentice fitted a washer backward. So did I once. Do not laugh yet.'],
 ['给你留了那副小扳手。它自己挑的，别拿成你觉得更好的那副。','I kept the little spanners it chose. Do not substitute the ones you prefer.'],
 ['你拿走的是备用件。坏掉的那天，备用件就是全部。','You took the spares. On the day something breaks, spares are everything.']]],
 ['farmer',[
 ['种子库今天不接待客人。外面的空筐会告诉你理由。','No visitors to the seed store today. The empty baskets explain why.'],
 ['别踩那块湿土。这里还没决定谁可以走近幼苗。','Do not step on the wet soil. We have not decided who may approach the seedlings.'],
 ['上一季种子发芽了。我记了收成，也记了谁挨过饿。','Last season’s seed sprouted. I recorded the harvest and who went hungry.'],
 ['它给自己的花盆留了名字。我把那张纸压在玻璃下面。','It named its own pot. I kept the paper beneath the glass.'],
 ['粮仓少的那一袋不是数字。那是三个人过冬的饭。','The missing sack was not a number. It was three people’s winter food.']]],
 ['child',[
 ['你今天会把它带走吗？我想先问它。','Will you take it away today? I want to ask it first.'],
 ['这个玩具只有一只眼睛。不是你们实验室弄的，我摔的。','This toy has one eye. Your lab did not do that. I dropped it.'],
 ['我们给种子画了地图。它画的路没有经过门。','We drew a map for the seeds. Its road did not pass through a door.'],
 ['它说下次想玩别的。我把那局棋留着，不等于要它继续。','It wants a different game next time. Keeping the board does not make it stay.'],
 ['你说大人有理由。那为什么每次都让别人疼？','You say grown-ups have reasons. Why does someone else always hurt?']]],
 ['merchant',[
 ['今天只现款。欠账簿里已经有太多解释了。','Cash only today. The ledger already has too many explanations.'],
 ['水壶漏水，价格没藏着。你也别把代价藏着。','The kettle leaks. The price is plain. Keep your costs plain too.'],
 ['那条路通了。车队的孩子终于收到一双合脚的鞋。','The road reopened. A caravan child finally received shoes that fit.'],
 ['这里有两个座位。一个给你，一个让它自己决定坐不坐。','There are two seats. One for you; it decides whether to use the other.'],
 ['把一份资料卖两次容易。把一个名字卖掉以后，买不回来。','Selling a report twice is easy. A sold name cannot simply be bought back.']]],
 ['musician',[
 ['琴盒不开。有人把这里当成下一场葬礼的预告。','The case stays closed. Someone treats this place like a funeral announcement.'],
 ['你可以听。不必告诉我哪段更有用。','You may listen. You do not have to tell me which part is useful.'],
 ['上次那首歌还缺一节。今天缺的只是歌词，不是人。','The song still lacks a verse. Today only words are missing, not people.'],
 ['它把停顿记得很准。看来它听见的不只是我弹出来的东西。','It remembers the pauses exactly. It hears more than the notes I play.'],
 ['掌声不能替那些没回来的声音作证。今晚我不唱那首。','Applause cannot testify for missing voices. I will not sing that one tonight.']]],
 ['believer',[
 ['灯照着所有人。座位还要由坐在这里的人决定。','The lamp lights everyone. Those here decide who sits beside them.'],
 ['先吃饭。我们不在饿着的时候谈神迹。','Eat first. We do not discuss miracles on empty stomachs.'],
 ['有人问它是不是征兆。我说先问它愿不愿意被这么叫。','Someone called it an omen. I told them to ask whether it wanted that name.'],
 ['它昨天替我点了灯，随后离开。照顾不必换来留下。','It lit a lamp for me and left. Care need not buy someone’s presence.'],
 ['以救人的名义上锁，锁也不会因此变得轻一点。','A lock imposed in the name of rescue weighs just as much.']]],
 ['doctor',[
 ['药箱在这里。争执可以等，疼痛不能。','The medicine is here. Arguments may wait; pain cannot.'],
 ['先告诉我哪里疼。它愿不愿意回答，也是答案的一部分。','Tell me where it hurts. Whether it wants to answer is part of the answer.'],
 ['你留下的药用完了。最后一瓶给了一个从没见过你的人。','Your medicine is gone. The last bottle helped someone who never met you.'],
 ['它把爪子收回去了，我就停下。你今天也停得很及时。','It withdrew its paw, so I stopped. You stopped in time today too.'],
 ['治疗不附带原谅。把袖子卷起来，我们仍要处理伤口。','Treatment does not include forgiveness. Roll up the sleeve. We still treat the wound.']]],
 ['operator',[
 ['你的呼号还在，坐标先不公开。我们要保护听见它的人。','Your call sign remains. Your coordinates stay private to protect listeners.'],
 ['这段噪声没有说话。别把想听的名字补进去。','That noise contains no speech. Do not fill it with the name you want.'],
 ['北线回过一次话。我没有剪掉对方问“你是谁”的那句。','The northern line answered. I kept the question: Who are you?'],
 ['给它留了发言键。它可以什么也不说，频道照样等着。','I left it the microphone button. It may say nothing. The channel will wait.'],
 ['卖出去的坐标收不回来。我现在每晚都听那条线。','Sold coordinates cannot be recalled. I listen to that frequency every night now.']]],
 ['scavenger',[
 ['我不带你走近弟弟。先把你知道的路放在桌上。','I will not lead you to my brother. Put your routes on the table first.'],
 ['瓶盖不是垃圾。每一个都能告诉我谁在这里喝过水。','Bottle caps are not rubbish. Each tells me who drank here.'],
 ['弟弟今天能站起来了。他想知道那只提灯的手是谁的。','My brother stood today. He asks whose hand held the light.'],
 ['它不再跟着我的脚印走。很好，它也该有自己的路。','It no longer follows my footprints. Good. It needs its own path.'],
 ['你说包很轻。被你拿走的药，重的是没拿到它的人。','You say the bag was light. The missing medicine weighs on those who needed it.']]],
 ['technician',[
 ['我的旧工牌在抽屉里。它不能替我取得你的信任。','My old badge is in a drawer. It cannot obtain your trust for me.'],
 ['这份日志没有删掉确认键的操作者。我就在那一行。','The log keeps the operator who pressed confirm. I am on that line.'],
 ['我把操作顺序教给学徒，也教她什么时候必须停下。','I taught the apprentice the sequence and when she must stop.'],
 ['它问我当时为什么没停。我没有拿主管的名字回答。','It asked why I did not stop then. I did not answer with my supervisor’s name.'],
 ['我们都知道那按钮多容易按。容易不能算理由。','We both know how easy that button is to press. Ease is not a reason.']]],
 ['researcher',[
 ['样本袋没有打开。你不信我，至少这个决定是对的。','The sample bag is unopened. Distrusting me is at least a sound decision.'],
 ['纸上的过滤率很漂亮。纸不会告诉你疼多久。','The filtration rate looks beautiful on paper. Paper cannot tell you how long pain lasts.'],
 ['替代滤材终于通过了测试。这次没有谁躺在台上。','The substitute filter passed. This time nobody lay on a table.'],
 ['它改了我报告的称谓。不是样本，是来过这里的人。','It corrected the report. Not specimen: a person who was here.'],
 ['那句“只要一点”已经用过太多次。我不再让它替我免责。','Just a little has been used too often. I will not let it excuse me again.']]],
 ['courier',[
 ['邮包不给你看。信不是证明我清白的材料。','You cannot inspect the bag. Letters are not evidence of my innocence.'],
 ['这封不是给你的。我知道你很想知道里面是谁。','This letter is not yours. I know you want to know whose name is inside.'],
 ['北线投递恢复了。今天有一封邀请，不是通知。','Northern deliveries resumed. Today a letter is an invitation, not a notice.'],
 ['它给自己写了一封信。我问送去哪里，它说先留着。','It wrote itself a letter. Asked where to deliver it, it said: keep it for now.'],
 ['泄露地址以后，收信的人搬走了。你没有听见那次道别。','After the address leaked, the recipient moved. You did not hear that farewell.']]],
 ['cook',[
 ['饭仍给你。厨房的信任不是买饭的找零。','You still get a meal. Kitchen trust is not change from buying dinner.'],
 ['坐下以后再说。锅里还没煮开的东西不听你的安排。','Sit before talking. The unboiled pot does not follow your schedule.'],
 ['今天多煮了一点。有人第一次肯说自己还饿。','I cooked extra. Someone finally admitted they were still hungry.'],
 ['它自己挑了那只缺口碗。好用不是唯一的理由。','It chose the chipped bowl. Practicality is not the only reason.'],
 ['你拿走了储备，却叫我别担心。今晚的空锅替我担心。','You took the reserves and told me not to worry. Tonight’s empty pot worries for me.']]],
 ['teacher',[
 ['先在后排坐着。孩子的问题不会因为你来而取消。','Sit at the back first. Your arrival does not cancel the children’s questions.'],
 ['这里允许不知道。也允许说老师说错了。','Not knowing is allowed here. So is saying the teacher was wrong.'],
 ['旧课本补齐了一页。上面写了你们修好的水泵。','We restored a textbook page. It describes the pump you repaired.'],
 ['它今天拒绝朗读。没关系，课堂不是换一种形式的观察窗。','It declined to read aloud today. A classroom is not another observation window.'],
 ['孩子学会了你说的那句借口。我正在教他们怎样追问。','The children learned your excuse. I am teaching them how to question it.']]],
 ['ranger',[
 ['枪口朝下，但你还不能从我身后走过去。','The muzzle stays down. You still cannot walk behind me.'],
 ['先走到那棵树。信任不用一次走完整条路。','Walk to that tree first. Trust need not cover the whole road at once.'],
 ['水源今天没有新的脚印。你的路线标记起了作用。','No new tracks at the spring. Your route markers worked.'],
 ['它选了另一边的路。我跟着它走，不跟着你的指令。','It chose the other path. I follow it, not your instruction.'],
 ['你留下的路标把人带进了封锁区。先别叫那次失误结束。','Your marker led people into the blockade. Do not call that mistake over yet.']]],
 ['nurse',[
 ['先留在帘子外。里面的人有权拒绝你。','Wait outside the curtain. The person inside may refuse you.'],
 ['我会先碰一下箱盖，让病人知道接下来有声音。','I touch the lid first so patients know a sound is coming.'],
 ['新医护学会先问一声了。这比学会扎针还难一点。','The new carer learned to ask first. That was harder than the needle.'],
 ['它记得我会停下。今天它自己走到了帘子里面。','It remembers that I stop. Today it walked behind the curtain itself.'],
 ['伤口可以缝。被忽略的拒绝不能用同一根线处理。','A wound can be stitched. An ignored refusal cannot be handled with the same thread.']]],
 ['archivist',[
 ['耳机可以借，原带不行。有些声音不愿再被带走。','Borrow the headphones, not the tapes. Some voices do not want to be taken again.'],
 ['坏掉的那一边也要保留。它提醒我不是所有声音都能回来。','I keep the broken side. It reminds me not every voice returns.'],
 ['录音里有人笑了。我们确认过，他不是被要求笑的。','Someone laughed in the recording. We checked: he was not told to laugh.'],
 ['它删掉了一句自己的话。我照做了，没有留私下的副本。','It withdrew a sentence. I deleted it without keeping a private copy.'],
 ['你把原声卖掉以后，别人替它加了字幕。现在先听未经剪辑的。','After you sold the voice, others subtitled it. Listen to the unedited version first.']]],
 ['defector',[
 ['我离开了那间楼，不等于那间楼已经离开我。','I left the building. That does not mean the building left me.'],
 ['名单在这里。公开之前，先找仍会被这些名字伤到的人。','Here is the list. Before publishing, find those its names could still hurt.'],
 ['有个名字找到本人了。他不想见我，我把信留给了邮差。','We found someone from the list. He will not see me. I left the letter with the courier.'],
 ['它问我有没有叫过它的名字。我说没有。那是真的。','It asked whether I ever used its name. I said no. That is true.'],
 ['以前我们总说都是命令。你今天说的是同一句。','We used to say it was only orders. You said the same thing today.']]],
 ['mechanic2',[
 ['副驾驶锁着。钥匙在我这里，不在你的通行证里。','The passenger door is locked. I hold the key, not your clearance card.'],
 ['引擎在冷却。下一步棋可以等，决定去哪里也是。','The engine is cooling. The next move can wait. So can the destination.'],
 ['车能离开了。我今天没发动，想先问谁愿意同行。','The truck can leave. I did not start it. First I ask who wants to come.'],
 ['它把座椅向后调了一格。我留着，不把它调回默认位置。','It moved the seat back one notch. I leave it there instead of restoring the default.'],
 ['车修好了，同行的人没回来。你别只问车现在能跑多快。','The truck is repaired. The passenger did not return. Do not ask only how fast it goes.']]]
 ];
 const responses=Object.fromEntries(rows.map(([id,list])=>[id,list.map(([zh,en])=>t(zh,en))]));
 function index(s,id){const p=s.wasteland.people[id];if(s.social.outcomes[id]==='betrayed'||p.memories.some(m=>['stole','forced','lied'].includes(m.type)))return 4;if(s.campaign.creatureAlive!==false&&s.social.creature[id]>=35)return 3;if(p.trust<25)return 0;if(p.trust<50)return 1;if(p.trust>=75)return 3;return 2;}
 function greeting(s,id){const p=s.wasteland.people[id],npc=Abyss.WastelandData.npcs.find(n=>n.id===id);return p.visits<2?npc.hello:responses[id]?.[index(s,id)]||npc.hello;}
 Abyss.I18n.register(Abyss.WastelandData.english);return {responses,index,greeting};
})();
