'use strict';
// SOURCE OF TRUTH: user-supplied Claude revision, CN/EN copied without prose edits.
Abyss.StoryRevisionData=(()=>{
 const scenes={
 p8_lock_after:`N|Jack 把钥匙从锁里抽出来。他没有收进口袋，也没有放下。|Jack drew the key out of the lock. He didn't pocket it, and he didn't put it down.
B|你说怕我离开，不等于我欠你留下。|Being afraid I'll leave doesn't mean I owe you staying.
J|我知道。至少……我现在听见这句话了。|I know. At least... I hear that sentence now.
B|我也可能想回来。|I might want to come back.
N|Jack 抬头。“可能”两个字，他在嘴里又念了一遍。|Jack looked up. He said "might" again under his breath.
J|那是之后的选择。不是现在这把钥匙的价钱。|That's a later choice. Not the price of this key.
N|它看了看内侧没有把手的门板。|It looked at the door panel on its side, the one with no handle.
N|钥匙环还扣在他食指上，没有人替他掰开。|The key ring was still hooked around his forefinger. Nobody was prising it loose for him.
J|让我把内侧的释放装置接好。你可以看着我。|Let me wire the inside release. You can watch.
N|他从工具盘里拿出一截线和一把钳子。钳子先递给它看，然后才开始剥线。|He took a length of wire and a pair of pliers from the tray. He showed it the pliers first, then began to strip the wire.`,
 project_mia:`N|桌上摆着关于 Jasmine 的东西：一张照片，一页撤离名单的复印，一罐桃子。红线还在 Jack 手腕上，没有被摆上桌。|The table held what he had of Jasmine: one photograph, one photocopied page of the evacuation list, a tin of peaches. The red thread stayed on Jack's wrist.
B|她多大？|How old is she?
J|十七。……那年十七。现在二十。|Seventeen. ...She was seventeen then. Twenty now.
N|他数了一下，才说出第二个数。|He counted before he said the second number.
T|三年前撤离的队伍被切成两截。我找了几个月，没找到确认的遗体。|Three years ago the evacuation split in two. I searched for months. Never found a confirmed body.
B|她长什么样？|What does she look like?
J|比我矮一头。头发总是乱的。吃饭先挑我盘子里的。|A head shorter than me. Hair always a mess. Picks from my plate first.
B|这个。|This one.
N|照片里的女孩坐在台阶上，用牙咬着线头，给自己打结。结是歪的。|In the photograph a girl sat on a step, biting a thread end between her teeth, tying a knot in it. The knot was crooked.
J|夜市买的。三块钱。我说重系，她说歪的不容易松。|Night market. Three bucks. I told her to redo it. She said crooked ones don't come loose.
J|那天晚上她摘下来，忘在洗手台上。我说，明天给你。|That night she took it off and left it by the sink. I said, I'll give it to you tomorrow.
B|识别用的？|For identification?
J|编的。是她的。|Made that up. It's hers.
N|B-07 拿起叉子，叉走了他盘里最大的一块桃子。|B-07 picked up a fork and speared the biggest piece of peach on his plate.
J|喂，Jas——|Hey, Jas—
N|叉子停在半空。|The fork stopped in the air.
J|……没事。吃吧。|...It's nothing. Eat it.
B|我不是她。|I am not her.
J|我知道。|I know.
B|你得在开门的时候也知道。|You need to know it when you open the door, too.
J|嗯。|Yeah.
N|它把那块桃子放回他的盘里。|It put the peach back on his plate.
B|电台里那个女孩呢？|The girl on the radio?
J|之后没再收到过。|Haven't picked her up since.
B|你还听？|Do you still listen?
J|晚上开一会儿。|Evenings. For a bit.
N|他把照片翻过去，又翻回来，正面朝上。|He turned the photograph face down, then face up again.`,
 project_zero:`N|零号文件有两份正本，一份只剩目录。|The Zero file had two full copies and one that was only an index.
N|第一份写：Specimen Zero 于灰潮前两年终止。第二份写：Specimen Zero 在灰潮后第一年仍有生命体征。章是同一枚，签名栏都是空的。|The first read: Specimen Zero terminated two years before the Grey Tide. The second: Specimen Zero still showed vital signs a year after it. The same stamp. Both signature lines were blank.
J|先看哪份？|Which one first?
B|哪份是真的？|Which one is true?
J|不知道。章是一样的。|Don't know. The stamp's identical.
N|第二份的照片少了一角。缺口边缘很整齐，是裁掉的，不是烂掉的。|A corner was missing from the photograph in the second. The edge of the gap was straight. Cut, not rotted.
J|裁的。|Cut.
N|目录那份的页码从 4 直接跳到 11。|In the index copy, the page numbers jumped from 4 to 11.
J|5 到 10 去哪了？|Where did 5 through 10 go?
N|属性栏里有最后保存时间，比设施断电那天晚。修改人一栏是一串工号。Jack 低头看了一眼自己的工牌，又抬起头。|The properties panel gave a last-saved time. It was later than the night the facility lost power. The editor field was a string of ID digits. Jack glanced down at his own badge, then up again.
J|我接线之前，这台机器没电。|Before I wired it up, this machine had no power.
B|谁改的？|Who changed it?
J|……不知道。|...Don't know.
N|目录最后一行被涂黑了，只露出开头几个字：关联个体 B-。后面是一条黑杠。|The last line of the index had been blacked out. Only the start showed: ASSOCIATED SUBJECT B-. Then a black bar.
B|那个黑的。|That black one.
J|涂的。不是机器坏的。|Painted over. Not a fault in the machine.
J|能念的我念给你。你说停就停。|I'll read you what's legible. You say stop and I stop.
B|先不要。|Not yet.
J|好。先不要。|All right. Not yet.
N|他把文件夹合上，翻面扣在桌上。打印键的灯还亮着，他用指节把它按灭。|He closed the folder and laid it face down on the desk. The print button was still lit. He pressed it dark with his knuckle.
J|我看的时候你在旁边。想走开就走开。|When I read it, you're beside me. Walk away whenever you want.
N|它没有走开。它把椅子拖近了一点。|It didn't walk away. It dragged its chair a little closer.`,
 project_incident:`N|事故记录室的门轴发涩。Jack 沿着右手边的墙找开关，摸了一圈，什么也没摸到。|The records-room door stuck on its hinge. Jack ran his hand along the right-hand wall for a switch and found none.
B|左边。|Left.
N|他按了左边。灯亮了。|He tried the left. The lights came on.
J|你怎么知道？|How did you know?
B|……不知道。|...Don't know.
N|它站在门口，过了一会儿才进来。|It stood in the doorway. After a moment it came in.
N|终端里是事故编号 CI-0012。两条记录，编号相同，正文逐字相同，连“封们”这个错别字都一样。|The terminal held incident number CI-0012. Two entries, same number, same text word for word, down to the same misspelling: "sealled doors."
N|一条的日期是两年前。另一条的日期，比终端上的今天晚一天。状态：已确认。确认人：空白。|One was dated two years ago. The other was dated one day later than the terminal's today. Status: CONFIRMED. Confirmed by: blank.
J|这钟是我按电台对的。可能差几分钟。差不了一天。|I set this clock by the radio. Maybe a few minutes off. Not a day.
B|明天的日期。|Tomorrow's date.
J|输错了。复制的时候输错了。|Typo. Got it wrong when they copied it.
B|连错字一起输错了？|Typed the same typo wrong too?
J|……|...
N|他们进来时关好的门，现在敞着。门挡落在另一侧的地上。|The door they'd closed behind them stood open. The doorstop lay on the far side of the floor.
J|风。|Draft.
B|没有风。|There's no draft.
N|Jack 去看合页。弹簧是紧的。|Jack checked the hinge. The spring was tight.
N|他从腰包里掏出记号笔，在手背上写下那两个日期，写得很慢，像抄接线号。|He took a marker from his belt pouch and wrote the two dates on the back of his hand, slowly, the way he'd copy a wire number.
J|走。门别关。|Let's go. Leave the door.
N|B-07 退出去之前，又看了一眼左边的开关。|Before stepping out, B-07 looked once more at the switch on the left.`,
 project_black:`N|BLACK 权限开出一个新目录。最上面是一条待执行指令：BLACK-17-C。|BLACK clearance opened a new directory. At the top was a pending order: BLACK-17-C.
N|签发：民事恢复署副署长。复核：连续性办公室。对象：伊甸 E-3 住区。内容：停止供水与配电，地块状态更新为“已恢复”。执行窗口：七十二小时。|Issued by: Deputy Director, Civil Recovery Authority. Reviewed by: Continuity Office. Target: Eden Block E-3. Action: cut water and power; update land status to RECOVERED. Execution window: seventy-two hours.
J|E-3。晾着衣服的那片。|E-3. The block with the washing on the line.
N|指令末尾有一行小字：居民不予登记。|The last line of the order, in small print: Residents will not be registered.
N|终端自己弹出一个通话窗口。一个男声，平稳，像在念表格。|A call window opened on its own. A level male voice, reading as if from a form.
H|民事恢复署第七联络处，值班官 Hale。您正在使用遗留的 BLACK 权限。请确认身份。|Civil Recovery Authority, Liaison Office Seven. Duty Officer Hale. You are using a legacy BLACK clearance. Please confirm your identity.
J|维修员。基础设施操作员。|Maintenance. Infrastructure operator.
H|您的工牌早已失效。不过权限有效，这对我们更方便。|Your badge lapsed long ago. The clearance remains valid, which is more convenient for us.
J|方便什么？|Convenient how?
H|E-3 的泵站 P-12 和配电柜 D-4 需要现场手动断开。目前能进入的人只有您。|Pump station P-12 and distribution cabinet D-4 in E-3 must be disconnected by hand, on site. You are the only person with access.
B|他知道你修过。|He knows you fixed it.
J|那根管子图纸上没有。是我修的。|That pipe wasn't on the plan. I fixed it.
H|维修记录里有您的登记。|Your repair is in the maintenance log.
J|清理的是记录，还是里面的人？|Are we clearing records, or the people inside?
H|地块状态将更新为“已恢复”。我无权就居民去向发表意见。登记居民三十八人，实际居住人数无法核实。|The land status will be updated to RECOVERED. I am not authorized to comment on residents' whereabouts. Thirty-eight registered residents. Actual occupancy cannot be verified.
J|你们不核实。|You don't verify.
H|核实不在本指令范围内。|Verification is outside the scope of this order.
H|署里另有一份方案给您：您登记为在册监护人，B-07 登记为受管理个体。您保留配给、住所和通行权。|The Authority has a separate arrangement for you. You register as custodian of record. B-07 registers as a managed subject. You keep your rations, housing and right of passage.
B|受管理。|Managed.
H|这是标准称谓。窗口七十二小时。通话结束。|That is the standard term. The window is seventy-two hours. End of call.
B|你以前也问过吗？|Did you ask that before?
J|问得不够早。|Not early enough.
N|Jack 把撤离路线和 D-4 的配电图铺在桌上，用扳手压住两个角。|Jack spread the evacuation route and the D-4 wiring diagram on the desk and pinned two corners with a wrench.
B|我们可以不同意吗？|Can we disagree?
J|可以。即使没有第三条路。|Yes. Even if there isn't a third route.
N|终端角落的倒计时开始走：71:59:41。|In the corner of the terminal a countdown began: 71:59:41.`,
 project_open_door:`N|Jack 又把门锁试了一遍。没卡住。没人叫他试这一遍。|Jack tested the lock again. It wasn't jammed. Nobody had asked him to test it again.
B|你每晚都检查门。|You check the door every night.
J|这是我的工作。|It's my job.
B|不。|No.
N|它等着。Jack 没去找下一件工具。|It waited. Jack didn't reach for another tool.
B|已经很久没人付你工资了。|You stopped being paid a long time ago.
J|是。|Yes.
B|你喂我。害怕的时候，你留下。|You feed me. You stay when I'm afraid.
B|你让我知道你的名字。|You let me know your name.
B|为什么还要锁门？|Why do you still lock the door?`
 };
 const doorTail=`N|Jack 的手已经在钥匙上。|Jack's hand was already on the key.
J|我开过——没开过另一扇门。|I opened—I didn't open another door.
B|旧走廊。|The old corridor.
J|对。有人敲。报警说对面有污染。我等了。我照着协议。|Yes. People were pounding. The alarm said contamination on the other side. I waited. I followed protocol.
N|他停了一口气，才把下一句说出来。|He held a breath before he said the next part.
J|他们死了。|They died.
J|开了会多死几个，还是少死几个，我不知道。到现在也不知道。|If I'd opened it, more might have died, or fewer. I don't know. I still don't.
B|我不是那条走廊。|I am not that corridor.
J|我知道。|I know.
B|你把我留活了。|You kept me alive.
J|是。|Yes.
B|你把我留在这里。|You kept me here.
J|……是。|...Yes.
B|别再说它们是同一件事。|Stop saying those are the same thing.
J|你以为有一个完美答案等着我？我不知道还怎么办，所以我先让你活着。|You think there was a perfect answer waiting for me? I didn't know what else to do, so I kept you alive first.
B|我也不知道。|Neither did I.
N|它停了两次才说完。|It paused twice before finishing.
B|可我在里面。|But I was the one inside.
N|发电机的振动一直没停。|The generator's vibration kept going.
T|我想说我累。我想说没人教过我。那都是真的。可累的人仍拿着钥匙。|I wanted to say I was tired. That nobody had taught me. Both true. The tired person still held the key.
J|对不起。|I'm sorry.
B|我知道。|I know.
J|就这样？|That's it?
B|你想让我说什么？|What do you want me to say?
J|我不知道。|I don't know.
N|它没再说话。它看着钥匙。Jack 没把手收回去。|It said nothing more. It looked at the key. Jack didn't take his hand back.`;
 const replies={world:'B|你说过。还有呢？|You said that. What else?',hurt:"B|谁？|Who?\nJ|不知道。|Don't know.",leave:'B|还有呢？|What else?',silence:'B|你的手在钥匙上。|Your hand is on the key.'};
 const lore={authority:{zh:'民事恢复署',en:'Civil Recovery Authority'},office:{zh:'连续性办公室',en:'Continuity Office'},hale:{zh:'值班官 Hale',en:'Duty Officer Hale'},block:'Eden Block E-3',order:'BLACK-17-C',approval:'REQUIRES_NARRATIVE_APPROVAL',haleCard:{age:'40s',education:'administrative/legal',rank:'replaceable middle officer',speech:'passive clauses',humor:'none',fear:'accountability',goal:'close the procedure',secret:'knows E-3 is occupied',JackAttitude:'convenient compliance resource',B07Attitude:'managed subject'}};
 return {scenes,doorTail,replies,lore};
})();
