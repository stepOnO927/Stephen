'use strict';
// Declarative eligibility and affinity; no public fixed evolution tree.
Abyss.Data.mutations = [
 {id:'horns',name:'晶质双角',layer:'horns',desc:'矿化组织沿头部延伸，力量 +5。',rules:{'stats.strength':{min:14}},affinity:'feral',effects:{strength:5}},
 {id:'wings',name:'薄膜双翼',layer:'wings',desc:'轻薄翼膜能辅助滑行，敏捷 +5。',rules:{'stats.agility':{min:14}},affinity:'gentle',effects:{agility:5}},
 {id:'eye',name:'额外眼睛',layer:'eyes',desc:'新的感知器官，智力 +5。',rules:{'stats.intelligence':{min:14}},affinity:'radiant',effects:{intelligence:5}},
 {id:'shell',name:'矿质甲壳',layer:'shell',desc:'柔软身体生出保护层，稳定性 +6。',rules:{'stats.stability':{min:60}},affinity:'armored',effects:{stability:6}},
 {id:'tail',name:'平衡长尾',layer:'tail',desc:'一条灵活的尾巴，敏捷 +4。',rules:{'history.explore':{min:2}},affinity:'feral',effects:{agility:4}},
 {id:'tentacles',name:'感知触须',layer:'tentacles',desc:'触须能读取空气中的震动，智力 +4。',rules:{'stats.pollution':{min:15}},affinity:'void',effects:{intelligence:4}},
 {id:'glow',name:'发光器官',layer:'glow',desc:'生物荧光缓缓呼吸，心情 +6。',rules:{'bias.radiant':{min:2}},affinity:'radiant',effects:{mood:6}},
 {id:'regen',name:'再生组织',layer:'organs',desc:'休息时额外回复 5 点健康。',rules:{'history.care':{min:4}},affinity:'gentle',effects:{health:5}}
];

