'use strict';
Abyss.Data.forms = [
 {id:'guardian',name:'翡翠守护者',color:'#96e9b2',desc:'它学会了保护。你留下的耐心，成了它坚韧的甲胄。',weights:{'stats.loyalty':1.1,'stats.stability':.6,'history.care':3,'bias.armored':4},mutations:{shell:25,regen:20}},
 {id:'oracle',name:'星瞳先知',color:'#b9a8f4',desc:'它开始理解那些从未被教过的语言。深渊在它的眼中亮起。',weights:{'stats.intelligence':2,'bias.radiant':7,'history.experiment':3},mutations:{eye:25,glow:20}},
 {id:'wanderer',name:'夜幕游灵',color:'#9adcf1',desc:'熟悉的脚步总会回来。世界很大，而你是它认得的归途。',weights:{'stats.agility':2,'history.explore':9,'bias.feral':3},mutations:{wings:25,tail:20}},
 {id:'abyss',name:'深渊共鸣体',color:'#d09cda',desc:'它与未知融为一体。那道遥远的回声，仍然呼唤着你的名字。',weights:{'stats.pollution':1.7,'bias.void':9,'history.experiment':5},mutations:{tentacles:30,horns:15}}
];

