'use strict';
// All amounts are deltas; hunger 0 means full, 100 means starving.
Abyss.Data.foods = [
 {id:'ration',name:'营养凝胶',symbol:'◒',price:5,desc:'实验室的基础配方，安全而温和。',effects:{hunger:-29,health:3,stability:2},bias:'gentle'},
 {id:'meat',name:'合成肉排',symbol:'▰',price:10,desc:'高蛋白培养肉，适合力量生长。',effects:{hunger:-40,strength:3,mood:3},bias:'feral'},
 {id:'mushroom',name:'幽光菌菇',symbol:'♧',price:12,desc:'采自地下菌床，带有微弱荧光。',effects:{hunger:-22,intelligence:3,pollution:4},bias:'radiant'},
 {id:'fruit',name:'月露果',symbol:'◇',price:12,desc:'清甜的果肉有助于建立信任。',effects:{hunger:-25,mood:9,loyalty:4,agility:1},bias:'gentle'},
 {id:'gene',name:'异变腺体',symbol:'⬡',price:23,desc:'有活性的未知组织。收益与风险共存。',effects:{hunger:-25,strength:5,pollution:10,stability:-8},bias:'void'},
 {id:'mineral',name:'铁鳞虾',symbol:'⋈',price:15,desc:'富含矿物质，帮助形成保护组织。',effects:{hunger:-30,health:5,stability:4},bias:'armored'}
];
Abyss.Data.training = [
 {id:'strength',name:'力量训练',desc:'推拉配重，锻炼身体。',effects:{strength:5,hunger:9,mood:-2},history:'train'},
 {id:'intelligence',name:'认知训练',desc:'辨认符号，建立沟通。',effects:{intelligence:5,hunger:6,mood:2},history:'train'},
 {id:'agility',name:'敏捷训练',desc:'穿越小型障碍，练习平衡。',effects:{agility:5,hunger:8,mood:1},history:'train'}
];
Abyss.Data.experiments = [
 {id:'gentle',name:'温和基因观察',desc:'记录基因波动。突变检定 +16%，损伤较低。',price:10,effects:{intelligence:3,stability:-4,pollution:4,loyalty:-2,health:-2},resentment:1,bias:'radiant',mutationBonus:.16},
 {id:'unstable',name:'高强度诱变',desc:'突变检定 +48%；健康、忠诚下降，留下持久怨恨。',price:18,effects:{strength:4,stability:-15,pollution:14,loyalty:-12,health:-10},resentment:12,bias:'void',mutationBonus:.48}
];
