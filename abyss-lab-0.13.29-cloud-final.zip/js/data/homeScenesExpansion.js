'use strict';
// Authored room observations, attached to real room actions rather than an archive-only list.
Abyss.HomeScenesExpansion=(()=>{
 const t=Abyss.HomeData.t,D=Abyss.HomeData;
 D.scenes.forEach(s=>s.category='room');
 const rows={room:[
 ['medical','它先指了指床，再指自己的手。Jack 把检查步骤写在它看得见的位置。','It points to the bed, then its hand. Jack writes the examination steps where it can see them.'],
 ['genetics','样本柜有一格空着。Jack 写下“拒绝采样”，没有写“样本缺失”。','A sample drawer is empty. Jack writes “sampling declined,” not “sample missing.”'],
 ['engineering','它用耳朵辨出了松动的轴承，却退开让 Jack 来拧紧。发现问题不等于必须承担工作。','It hears a loose bearing, then steps aside for Jack. Finding a fault does not make fixing it its duty.'],
 ['storage','一箱旧毯子写着报废。它选了最粗糙的一条，把标签压在下面。','A box of blankets is marked discarded. It chooses the roughest and tucks the label underneath.'],
 ['power','电流声突然变低。它先望向通道门，确认门在停电时不会重新锁死。','The electrical hum drops. It checks the passage first, making sure a power failure will not lock it again.'],
 ['water','过滤器滴出第一杯干净的水。Jack 没喝，把杯子放在他们之间等它决定。','The filter produces its first clean cup. Jack places it between them and waits.'],
 ['hall','墙上的员工照片没有它的位置。Jack 拿下空相框，问它是否愿意留一张。','The staff wall has no place for it. Jack takes down an empty frame and asks whether it wants a photograph.'],
 ['lower','楼梯尽头有另一把锁。Jack 没把钥匙藏进口袋，先解释下面有什么，和他不知道什么。','Another lock waits below the stairs. Jack explains what is below, and what he does not know.'],
 ['zero','空舱显示着呼吸。它站在门外，第一次要求 Jack 也别进去。','The empty chamber registers breathing. It asks Jack to stay outside too.'],
 ['black','权限灯由白转黑。它问：“灯相信你，那些人呢？”Jack 没有立刻回答。','The clearance light turns black. It asks, “The light trusts you. What about those people?” Jack pauses.'],
 ['crawl','狭窄通道只够一人通过。Jack 先把出口的门推开，让它能看到另一端的光。','The passage fits one traveler. Jack opens the exit first so it can see the light at the other end.'],
 ['nursery','旧墙标着不同的身高。它把自己的手掌贴上去，又慢慢移开，没有留下新标记。','Old heights mark the wall. It lays a palm against them, then withdraws without adding its own.'],
 ['series','储存柜的号码不连续。Jack 没有用“损耗”解释缺掉的那些号码。','The storage numbers have gaps. Jack does not describe the missing ones as losses in stock.'],
 ['surgery','手术灯亮起时，它的肩膀缩了一下。Jack 关灯，让它选择从门口观察。','Its shoulders tighten under the surgical light. Jack switches it off and lets it watch from the doorway.'],
 ['sublevel','第三层的灰尘上有新脚印。脚印回来了一半，剩下一半消失在墙边。','Fresh footprints cross the dust on the third level. Half return; the others stop at a wall.'],
 ['stairs','没有编号的楼梯上，回声总比脚步多响一次。它停下，等那一次也过去。','On the unlisted stairwell each step makes one extra echo. It waits for the extra sound to pass.'],
 ['core','黑色核心没有温度。它却把爪子缩回，像碰到了某个被叫错的名字。','The black core has no warmth. It withdraws as if it touched a name spoken incorrectly.'],
 ['unnumbered','房间的窗外是另一个同样的房间。Jack 在门框系了线，决定今天不往更深处走。','The window overlooks an identical room. Jack ties a thread to the frame and goes no farther today.'],
 ['containment','旧门锁拆下后留下四个孔。Jack 想补平，它却摇头。痕迹不需要被美化才能留下。','Removing the lock leaves four holes. It refuses when Jack offers to fill them. A mark need not be beautiful to remain.'],
 ['living','它把椅子转了半圈，背对监控。Jack 把摄像头的电源放在它够得到的位置。','It turns the chair away from surveillance. Jack puts the camera switch within its reach.']
 ],repair:[
 ['power','Jack 更换了烧焦的接头，保留旧件放在桌上。它闻过后才相信危险已经过去。','Jack replaces the charred connector and leaves it on the table. It smells the old part before trusting the repair.'],
 ['water','水管接好后仍响了一声。Jack 跟它一起等了三分钟，没有用“正常”把疑问压回去。','The repaired pipe knocks once. Jack waits three minutes beside it, without dismissing the question as normal.'],
 ['medical','新门轴不会突然合上。它连续推了三次，第四次终于走进来。','The new hinge cannot snap shut. It tests the door three times, then enters on the fourth.'],
 ['engineering','两把不同型号的扳手都留下了划痕。这次修理的记录里有两个参与者。','Two sizes of wrench leave marks. The repair report names two participants.'],
 ['kitchen','修好的灶台第一次烧开水。它退开一小步，Jack 把小心写成判断力。','The repaired stove boils water. It steps back; Jack records judgment rather than fear.'],
 ['storage','架子重新固定。它把曾经砸下来的螺钉摆在最底层，没人再偷偷收走。','The shelves are secured. It keeps the fallen screw on the bottom shelf, where nobody hides it.'],
 ['greenhouse','温室补上一片有颜色的玻璃。阳光落下时，原来的裂口还能被看见。','A colored pane repairs the greenhouse. Sunlight still reveals where it once cracked.'],
 ['workshop','工作台终于不摇晃了。它试着坐上去，Jack 先问重量，再问是否舒服。','The bench no longer shakes. When it sits on top, Jack checks the load, then asks if it is comfortable.'],
 ['observation','观察窗换了透明胶层。它在玻璃上画了一条线：这边不是等待被评判的位置。','A clear seal repairs the window. It draws a line on the glass: this side is not a place for judgment.'],
 ['archive','档案灯不再闪。Jack 发现它保存着一张写错的旧纸，没有替它扔掉。','The archive light stops flickering. Jack finds it keeping a mistaken old note and leaves it alone.'],
 ['radio','收音机重新有了声音。Jack 先把音量降低，再告诉它那个名字是 Jasmine。','The radio speaks again. Jack lowers the volume before explaining that the name is Jasmine.'],
 ['hall','扶手补好了，旧磨痕仍在。它用自己的步幅试走，不需要沿着 Jack 的脚印。','The railing is repaired, its worn patches intact. It tests its own stride without following Jack’s steps.'],
 ['quarters','屋顶不漏水了。Jack 没把接水的破杯扔掉，它曾在难眠的夜里替他们数过时间。','The roof stops leaking. Jack keeps the broken cup that counted time on sleepless nights.'],
 ['living','修好的灯可以从低处关闭。它先关灯，又开回来，确认选择真的属于它。','The repaired light has a reachable switch. It turns it off and on, checking that the choice is real.'],
 ['genetics','培养架换了新护罩。Jack 在门口加了“先敲门”，没有加新的警告编号。','A new shield covers the culture rack. Jack adds “knock first” by the door instead of a warning number.']
 ],autonomy:[
 ['greenhouse','它挪开了盆栽，给自己的尾巴留出位置。Jack 顺着新的空隙走，没有摆回原处。','It moves a pot to make room for its tail. Jack walks around the new gap instead of restoring it.'],
 ['living','它把毯子搬到了另一面墙。那里没有摄像头，Jack 没有把摄像头也搬过去。','It carries its blanket to a wall without a camera. Jack does not move the camera with it.'],
 ['quarters','Jack 睡醒时，门口有一颗螺母。它说不出用途，也不愿让他收进工具箱。','Jack wakes to a nut by his door. It cannot explain the purpose and will not let him put it in the toolbox.'],
 ['kitchen','一块食物少了。它没有藏起剩下的包装。Jack 重新讨论取食规则，而不是惩罚它先有了想法。','Food is missing; the wrapper is not hidden. Jack discusses access rather than punishing it for making a decision.'],
 ['radio','它关掉了重复播放的广播。Jack 想提醒时刻表，又把话停在嘴边。','It switches off the repeating broadcast. Jack starts to mention the schedule, then stops.'],
 ['observation','它避开观察窗，自己选了没有标线的椅子。今天的测量留下一格空白。','It avoids the observation window and chooses an unmarked chair. Today’s measurements have one blank field.'],
 ['workshop','它借走一条软布，给自己的装饰包上了角。Jack 确认工具安全后把选择留给它。','It wraps the corners of its decoration in soft cloth. Jack checks safety, then leaves the choice with it.'],
 ['storage','它把不喜欢的帽子放回架子，旁边留出一个空位，等下一件真正想要的东西。','It returns an unwanted hat and leaves space beside it for something it might actually want.'],
 ['medical','它停在医务室门外，先观察 Jack 洗手。等仪器放下，才自己迈过门槛。','It watches Jack wash his hands from the doorway and enters only after he puts the instruments down.'],
 ['hall','它选择一个人走完走廊。Jack 等在拐角，直到它主动叫他。','It chooses to walk the corridor alone. Jack waits at the turn until it calls him.']
 ],home:[
 ['quarters','Jack 留着两只杯子，虽然它还不会用。那不是预言，只是明天仍有一张桌子。','Jack keeps two cups although it cannot use one yet. It is no prophecy, just a table for tomorrow.'],
 ['living','它问门外是不是家。Jack 说这要由住在里面的人慢慢决定。','It asks whether this is home outside the door. Jack says the people living here get to decide, slowly.'],
 ['kitchen','晚餐的记录只有食材，没有服从次数。它把一小块推给 Jack，等他自己的回答。','The dinner record lists ingredients, not obedience. It pushes a piece toward Jack and waits for his answer.'],
 ['greenhouse','他们没说话，听水滴落进土里。沉默没有变成一项需要修好的故障。','They listen to water entering the soil. Their silence does not become a fault to repair.'],
 ['radio','一段歌没有唱完。它让 Jack 再放一遍，这次不是为了识别声音。','A song cuts off. It asks Jack to play it again, this time for more than recognition.'],
 ['observation','它问 Jack 是否也讨厌被一直看着。Jack 承认讨厌，并关掉了记录灯。','It asks if Jack hates constant observation too. He admits he does and switches off the recording light.'],
 ['medical','恢复之后，它仍来这里坐着。Jack 把治疗床的编号盖住，留出一把普通椅子。','After recovering it still visits. Jack covers the bed number and leaves an ordinary chair.'],
 ['archive','它在旧报告上画了一扇开着的门。Jack 没用正确的工程图把画替换掉。','It draws an open door on an old report. Jack does not replace it with an accurate engineering plan.'],
 ['water','他们一起等下一滴水。以前是检查，现在只是一个不用急着离开的傍晚。','They wait for the next drop. Once it was an inspection; now it is an evening without haste.'],
 ['containment','Jack 从外面摸着锁孔，它从里面碰着同一个位置。安全与囚禁的记忆仍然隔着玻璃相遇。','Jack touches the lock holes outside; it touches the same place within. Safety and confinement still meet across glass.']
 ],crisis:[
 ['power','应急灯只够照亮出口。Jack 先确认通道能手动打开，再去救那台机器。','Emergency light reaches only the exit. Jack checks the manual door before saving the machine.'],
 ['power','备用电池只剩一组。Jack 把它接给空气循环，研究终端暂时黑下来。','One backup battery remains. Jack powers ventilation and leaves the research terminal dark.'],
 ['water','洪水越过门槛。它叼起旧玩具，Jack 没命令它扔掉来搬更贵的工具。','Water crosses the threshold. It takes the old toy; Jack does not order it to save costlier tools instead.'],
 ['water','水源污染了，隔离线画在地上。Jack 给它展示样本，而不是只说不许过去。','The water is contaminated. Jack shows the sample instead of merely forbidding passage.'],
 ['engineering','灰潮敲着外墙。Jack 叫出每一个仍在设施里的名字，等着每一个回应。','Grey Tide strikes the outer wall. Jack calls every name inside and waits for each reply.'],
 ['engineering','支柱下沉，旧墙出现新裂纹。今晚的卧室要搬走，记忆不需要跟墙一起埋下。','A pillar sinks and the wall cracks. Tonight’s bedroom must move; its memories need not be buried with the wall.'],
 ['genetics','污染警报持续响着。它拒绝走旧手术通道，Jack 找到了另一条撤离路线。','The contamination alarm continues. It refuses the old surgical corridor; Jack finds another evacuation route.'],
 ['genetics','样本柜碎了。Jack 停下追逐飘出的资料，先把手伸向跌倒的同伴。','The sample cabinet shatters. Jack stops chasing papers and reaches toward his fallen companion.'],
 ['containment','袭击者叫它武器。Jack 没用它的力量回答，先打开另一侧的避难门。','The attackers call it a weapon. Jack opens the shelter door before answering with its strength.'],
 ['containment','外墙烧焦了，编号也烧掉一半。Jack 留下残牌，提醒自己这里需要保护的是谁。','The wall and half its number burn. Jack keeps the damaged plate to remember who needs protection here.']
 ],hidden:[
 ['nursery','育成室录音里的第一句话不是编号，是一句“等我”。录音到这里就停了。','The nursery recording begins with “wait for me,” not a number. It stops there.'],
 ['series','柜门里藏着一张餐单。有人曾认真记下某个实验体不喜欢太烫的汤。','A menu is hidden in a cabinet door. Someone carefully noted that one specimen disliked hot soup.'],
 ['stairs','楼梯背面画着一只手，指向回去的方向。Jack 没把它当作通关提示。','A painted hand beneath the stairs points back. Jack does not treat it as a puzzle instruction.'],
 ['core','核心旁的维修签名与 Jack 的字迹相同，日期却比他的入职早。今天没有足够证据解释它。','The maintenance signature matches Jack’s hand but predates his arrival. Today offers no explanation.'],
 ['unnumbered','无编号房间的相框背面写着 Jasmine。Jack 没有仅凭一个名字宣布找到她。','Jasmine is written behind a frame. Jack does not declare her found on the strength of a name.']
 ]};
 for(const [category,records]of Object.entries(rows))records.forEach(([room,zh,en],i)=>D.scenes.push({id:'home_'+category+'_'+i,room,category,text:t(zh,en)}));
 function play(s,category,room){const scene=D.scenes.find(e=>e.category===category&&e.room===room&&!s.home.seen.includes(e.id));if(!scene)return false;s.home.seen.push(scene.id);Abyss.Home.remember(s,room,scene.text);return true;}
 Abyss.I18n.register(D.english);return {play};
})();
