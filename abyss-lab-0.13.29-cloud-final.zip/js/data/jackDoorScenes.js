'use strict';
(()=>{const X=Abyss.JackData,{replace:R,C,tr,lines}=X;
R('project_open_door',`
N|Jack 又把门锁试了一遍。没有卡住。也没有人要求他试这一遍。|Jack tested the lock again. It wasn't jammed. Nobody had asked him to test it again.
B|你每晚都检查门。|You check the door every night.
J|这是我的工作。|It's my job.
B|不。|No.
N|它等着。Jack 没有立即去找下一件工具。|It waited. Jack did not immediately look for another tool.
B|已经很久没人付你工资了。|You stopped being paid a long time ago.
T|我想笑。那样这句就会变成一个玩笑，不必再往下说。|I wanted to laugh. Then the sentence could become a joke, and we wouldn't have to keep talking.
J|是。|Yes.
B|你喂我。害怕的时候，你留下。|You feed me. You stay when I'm afraid.
B|你让我知道你的名字。|You let me know your name.
N|它说得很慢，没有把每件事接成一份账单。|It spoke slowly, without joining those things into an invoice.
B|为什么还要锁门？|Why do you still lock the door?
T|我有答案。污染。捕食者。别的幸存者。它的突变。我的安全。每一个都是真的。|I had answers. Contamination. Predators. Other survivors. Its mutations. My safety. Every one was true.
N|Jack 的手已经在钥匙上。|Jack's hand was already resting on the key.
T|没有一个答案解释了这只手为什么这么快。|None of the answers explained why that hand had moved so quickly.
J|我开过——没开过另一扇门。|I opened—I didn't open another door.
B|旧走廊。|The old corridor.
J|对。有人敲。报警说对面有污染。我等了。我照着协议。|Yes. People were pounding. The alarm reported contamination. I waited. I followed protocol.
N|他把“他们死了”留在下一次呼吸里，终于说了。|He held they died until the next breath, and finally said it.
T|我仍不知道，如果开门，会死更多人，还是少几个人。事情没有为了让我舒服而留下正确答案。|I still don't know whether opening it would have killed more people or saved a few. The event didn't leave a correct answer for my comfort.
B|我不是那条走廊。|I am not that corridor.
J|我知道。|I know.
B|你把我留活了。|You kept me alive.
J|是。|Yes.
B|你把我留在这里。|You kept me here.
J|……是。|...Yes.
B|别再说它们是同一件事。|Stop saying those are the same thing.
N|Jack 的脸热起来。这一次，他不是在想如何把话说漂亮。|Jack's face grew hot. This time he wasn't thinking of how to make his answer sound good.
J|你以为有一个完美答案等着我？我不知道还怎么办，所以我先让你活着。|Do you think there was a perfect answer waiting? I didn't know what else to do, so I kept you alive first.
B|我也不知道。|Neither did I.
N|它停了两次才说完。|It paused twice before finishing.
B|可我在里面。|But I was the one inside.
N|发电机的振动一直没停。这间屋子没有替他们把争执变成一场表演。|The generator kept vibrating. The room didn't turn their argument into a performance.
T|我想说我累。我想说没人教过我。那都是真的。可累的人仍拿着钥匙。|I wanted to say I was tired. Nobody had taught me. Both true. The tired person still held the key.
J|对不起。|I'm sorry.
B|我知道。|I know.
J|就这样？|That's it?
B|你想让我说什么？|What do you want me to say?
J|我不知道。|I don't know.
B|也许你终于开始懂了。|Maybe you're finally beginning to understand.
N|他没有让它证明自己已经原谅。钥匙仍在他手中。|He did not ask it to prove it had forgiven him. The key remained in his hand.
T|我要选择的是现在做什么，不是让它把刚才的话撤回去。|My choice was what to do now. Not how to make it take back what it had said.
`,{group:'project',nextNode:null,title:Abyss.NarrativeData.chapters.find(c=>c.id==='open_door').title,choices:[
 C('not_ready','“你还没准备好。”','“You are not ready.”',{jack:{control:3,fear:1},jackJournal:'lock',nextNode:'p8_lock_after'}),
 C('not_me','“是我没准备好。”','“I am not ready.”',{jack:{honesty:3,fear:2},jackJournal:'lock',nextNode:'p8_lock_after'}),
 C('world','“我怕外面的世界伤害你。”','“I am afraid the world will hurt you.”',{jack:{compassion:1,fear:2},jackJournal:'lock',nextNode:'p8_lock_after'}),
 C('hurt','“我怕你会伤害别人。”','“I am afraid you will hurt someone.”',{jack:{honesty:2,pragmatism:1},jackJournal:'lock',nextNode:'p8_lock_after'}),
 C('leave','“我怕你会离开。”','“I am afraid you will leave.”',{jack:{honesty:3,attachment:3,fear:2},jackFlag:'fear_leave_admitted',jackJournal:'lock',nextNode:'p8_lock_after'}),
 C('unlock','打开门，把内侧的解锁柄也交给它','Unlock the door and give it the inside release',{openContainment:true,jack:{sacrifice:1},philosophy:{autonomy:3},jackFlag:'shared_release',jackJournal:'lock',nextNode:'p8_threshold'}),
 C('silence','……','...',{jackJournal:'lock',nextNode:'p8_lock_after'})]});
const argument=Abyss.NarrativeData.nodes.find(n=>n.id==='project_open_door').lines[28];argument.language={clean:argument.text,mild:tr('你以为有个该死的完美答案等着我？我不知道还怎么办，所以我先让你活着。','Do you think some damn perfect answer was waiting? I kept you alive because I did not know what else to do.'),full:tr('你以为有个他妈的完美答案等着我？我不知道还怎么办，所以我先让你活着！','You think there was some perfect fucking answer waiting? I kept you alive because I did not know what else to do!')};argument.exposure='argument';
const lock=Abyss.NarrativeData.nodes.find(n=>n.id==='project_open_door');lock.lines[11].variants=[{requirements:{'narrative.door':{min:1}},text:tr('你那时为什么一直锁着门？','Why did you keep it locked back then?')}];
R('p8_lock_after',`
N|Jack 把钥匙从锁里抽出来，没有拿它遮住自己的回答。|Jack drew the key out without using it to hide his answer.
B|你说怕我离开，不等于我欠你留下。|Being afraid I'll leave doesn't mean I owe you staying.
J|我知道。至少……我现在听见这句话了。|I know. At least... I hear that sentence now.
T|我想把“我也怕”当成一张免罚单。它没有接。它没有接是对的。|I wanted I'm afraid too to work like an exemption. It hadn't accepted it. It was right not to.
B|我也可能想回来。|I might want to come back.
N|Jack 抬头。他差点把“可能”听成一个承诺。|Jack looked up. He almost heard might as a promise.
J|那是之后的选择。不是现在这把钥匙的价钱。|That is a later choice. Not the price of this key now.
N|它看了看内侧没有把手的门板。|It looked at the door panel with no handle on its side.
T|我可以继续锁着。游戏不会替我把手掰开。可它已经知道，我的理由里有我自己。|I could keep it locked. Nothing would prise my hand open for me. But it knew now that my reasons included myself.
J|让我把内侧的释放装置接好。你可以看着我。|Let me wire the inside release. You can watch.
`,{group:'major',title:tr('回答之后','AFTER THE ANSWER'),choices:[C('open','完成内侧解锁装置，打开门','Complete the inside release and open the door',{openContainment:true,jackFlag:'shared_release',jack:{honesty:1},philosophy:{autonomy:2},nextNode:'p8_threshold'}),C('keep','仍然锁着，明确承认这是 Jack 的选择','Keep it locked, explicitly acknowledging it is Jack’s choice',{jack:{control:3},jackFlag:'lock_retained',nextNode:'project_open_door_response'})]});
R('p8_threshold',`
N|门锁响了一声。没有音乐，也没有新的警报。|The lock clicked. There was no music, and no new alarm.
J|开了。|It's open.
B|我知道。|I know.
N|它没有动。Jack 把身子从门口移开。|It didn't move. Jack moved himself out of the doorway.
T|我在等一个扑过来的身体，一个证明我终于做对的动作。这也是一种要求。|I was waiting for a body to rush toward me, a gesture proving I had finally done the right thing. That too was a demand.
J|不用现在出来。|You don't have to come out now.
N|门外地面有三条电缆。Jack 把它们贴牢，没有把整个走廊宣称为安全。|Three cables lay on the floor outside. Jack taped them down without declaring the entire corridor safe.
B|可以不喜欢外面吗？|Can I dislike outside?
J|当然。你可以讨厌地板，灯，味道。可以讨厌我没换过的那条臭滤芯。|Of course. You can dislike the floor, the lights, the smell. The awful filter I haven't replaced.
B|也可以回来？|And come back?
J|可以。门不会因为你回来，就再变成我一个人的决定。|Yes. Coming back won't make the door my decision alone again.
N|它抬起一只脚，放下。又抬起。Jack 看见自己的脚也往前挪了半寸。|It raised a foot, put it down, raised it again. Jack noticed his own foot had shifted half an inch forward.
T|别扶它。先问。可我已经太习惯把别人差一点摔倒，看成我必须动手的命令。|Don't support it. Ask first. I was far too used to treating somebody's near fall as an order for my hands to act.
J|要我靠近一点吗？|Would you like me a little closer?
B|先别。|Not yet.
N|他停下。这个小动作比转钥匙难。|He stopped. That small action was harder than turning the key.
B|外面声音很多。|There are a lot of sounds outside.
J|水管。风机。那一下是我鞋底。有些我也分不清。|Pipes. The fan. That one was my shoe. Some I can't tell apart either.
N|它的指尖碰到门槛，又收回。Jack 没有把这记成“探索失败”。|Its fingertips touched the threshold and withdrew. Jack did not record exploration failed.
T|它可以害怕。害怕不能自动把选择退回我手里。|It could be afraid. Fear couldn't automatically return its choice to my hand.
B|里面以前比较安全。|Inside used to be safer.
J|是。|Yes.
B|也比较小。|And smaller.
J|也是。|That too.
N|Jack 坐在走廊边，留出足够的通道。他的膝盖和它的膝盖不在同一侧。|Jack sat beside the corridor, leaving the passage clear. Their knees were on different sides of the threshold.
T|我想起父亲修电视时，能听见机壳里一根松线。母亲却能听见饭桌上没人说的事。我一直学了前一种本事。|My father could hear a loose wire inside a television casing. My mother could hear what nobody said at the dinner table. I'd always learned the first skill.
J|如果你要我进去坐，也可以说。|You can ask me to sit inside, too.
B|你会进去？|Would you?
J|会。但你不用为让我舒服才叫我。|Yes. You don't have to ask just to make me feel better.
N|灯光落在门槛上。没有把里面照成坏的，也没有把外面照成好的。|Light fell across the threshold. It didn't make inside bad or outside good.
B|我要自己试一次。|I want to try once by myself.
N|Jack 点头。点头之后，他仍花了很久才放松肩膀。|Jack nodded. Even after nodding, it took a long time for his shoulders to relax.
T|我不是突然成为一个不害怕的人。我只是得在害怕的时候，也听见它。|I hadn't suddenly become somebody without fear. I needed to hear it even while afraid.
N|它终于把脚放在门外。另一只脚仍在门内。|It finally placed one foot outside. The other remained inside.
B|不是你把我推出去。|You didn't push me out.
J|不是。|No.
N|它停在这个位置，把一口气完整地呼出来。|It stayed there and let out one complete breath.
`,{group:'major',title:tr('门槛','THE THRESHOLD'),nextNode:'p8_first_steps',choices:[]});
R('p8_first_steps',`
N|走廊没有为第一次出门特意变安静。|The corridor did not become quiet for a first departure.
B|你每天从这里来？|You come from here every day?
J|大多数时候。有时候从泵房绕回来，身上有一股更糟的味道。|Most days. Sometimes I come around through the pump room and smell even worse.
N|它沿墙走，摸了摸一个没有用途的旧标牌。Jack 没有告诉它那不值得看。|It walked along the wall and touched an obsolete sign. Jack didn't tell it the sign wasn't worth looking at.
T|我看见的是漏点、负载、可能割伤皮肤的毛边。它看见的东西，没有按照维修清单排队。|I saw leaks, loads and sharp edges that could cut skin. What it saw wasn't lining up on a maintenance checklist.
B|这里可以停吗？|Can we stop here?
J|可以。|Yes.
N|他们在一块普通的地砖旁停下。什么都没被找到，什么也没被解锁。|They stopped beside an ordinary floor tile. Nothing was found. Nothing was unlocked.
T|那块砖没有帮我们拯救世界。它只是第一块不用我开喂食口就能摸到的砖。|The tile wasn't helping us save the world. It was simply the first tile it could touch without me opening a feeding hatch.
B|你还拿着钥匙。|You're still holding the key.
N|Jack 低头。他一直攥着，没有察觉。|Jack looked down. He'd been gripping it without noticing.
J|习惯。|Habit.
B|习惯也可以改？|Can habits change too?
J|能改。有时候改得很慢。慢不该是你的罚单。|They can. Sometimes slowly. That slowness shouldn't become your sentence.
N|他把钥匙放在两个人都能拿到的工具盘里。|He put the key in a tool tray both could reach.
B|我现在想回去。|I want to go back now.
N|他说“好”之前先吸了一口气。那口气暴露了他期待过更多。|He drew a breath before saying yes. The breath revealed that he'd hoped for more.
J|好。|All right.
T|回来不是我赢。出去也不是我输。可我脑子里那套糟糕的计分系统还没拆完。|Coming back wasn't my victory. Going out wasn't my defeat. I hadn't finished dismantling the terrible scoring system in my head.
N|它在回去之前又看了一次走廊。|It looked at the corridor once more before returning.
B|明天，也有？|Will it be here tomorrow too?
J|只要楼没塌。不能说永远。但不是只给你看这一次。|Unless the building collapses. I can't say forever. But this isn't a one-time showing.
N|Jack 把门撑住。里面的床铺没有被撤走。|Jack held the door. The bedding inside hadn't been removed.
T|要走的人不该因为可能回来，就被剥掉一个能回来坐的地方。|Somebody who might leave shouldn't lose a place to sit if they return.
B|今天我可以自己决定最后一步。|Today I can choose the last step myself.
N|Jack 等它。没有替它做出那个动作。|Jack waited. He did not make that movement for it.
`,{group:'major',title:tr('第一段走廊','THE FIRST CORRIDOR'),nextNode:'project_open_door_response',choices:[]});
const after=Abyss.NarrativeData.nodes.find(n=>n.id==='project_open_door_response');after.text=tr('Jack 没要求今天成为一个完美的纪念日。明天仍需要修管道，也仍需要问它的意见。','Jack did not demand a perfect anniversary from today. Tomorrow would still need repaired pipes, and its opinion.');after.choices=[C('honest','把之后的门禁规则写成两人都能修改的约定','Write access rules that both can revise',{jack:{honesty:2},jackFlag:'shared_release',philosophy:{autonomy:2}}),C('unknown','“我还会怕。你不用替我保证你永远不走。”','“I will still be afraid. You do not have to promise never to leave.”',{jack:{honesty:2,fear:1}}),C('silence','让它决定今天最后待在哪里','Let it choose where to spend the rest of today',{philosophy:{freedom:1}})];
})();
