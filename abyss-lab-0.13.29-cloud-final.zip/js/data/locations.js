'use strict';
Abyss.Data.locations = [
 {id:'sewer',name:'下水道',symbol:'≈',desc:'潮湿管道中的低风险搜寻。',unlock:1,difficulty:12,stat:'agility',reward:[12,23],food:['ration','mushroom'],bias:'feral'},
 {id:'factory',name:'废弃工厂',symbol:'⚙',desc:'回收旧设备，谨防锋利碎片。',unlock:3,difficulty:24,stat:'strength',reward:[20,36],food:['meat','mineral'],bias:'armored'},
 {id:'forest',name:'地下森林',symbol:'♧',desc:'裂隙之外，植物仍在呼吸。',unlock:5,difficulty:28,stat:'agility',reward:[18,32],food:['fruit','mushroom'],bias:'gentle'},
 {id:'city',name:'城市夜晚',symbol:'▥',desc:'避开巡逻，在霓虹下寻找补给。',unlock:8,difficulty:36,stat:'intelligence',reward:[28,45],food:['meat','fruit'],bias:'radiant'},
 {id:'ruins',name:'实验废墟',symbol:'⌬',desc:'失落的研究区充满未知基因。',unlock:12,difficulty:45,stat:'intelligence',reward:[35,60],food:['gene','mineral'],bias:'void'}
];
