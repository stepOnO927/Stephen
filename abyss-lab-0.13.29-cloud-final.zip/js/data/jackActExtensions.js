'use strict';
// Quiet extensions belong to their act; no generic repeated advance choices.
(()=>{
 const {lines,tr}=Abyss.JackData,D=Abyss.NarrativeData;
 const extra={
 survival:`N|Jack 把汤碗放在一张不平的桌上。|Jack put the soup on an uneven table.
T|父亲会塞一张折好的发票在桌脚。我也这么干。|Dad would put a folded receipt under the leg. So did I.
N|它看着桌子稳下来，靠近了半步。|It watched the table settle and came half a step closer.
J|不是魔法。纸。|Not magic. Paper.
N|他把纸角露出来给它看。|He showed it the exposed corner.
T|我可以教这个。别的先不假装。|I could teach that. No pretending about the rest yet.
N|应急灯的定时器响了一声。|The emergency light timer clicked.
J|灯要暗一点，不是坏了。|It will dim. Not broken.
N|小身体没有再缩到最远的角落。|The small body did not retreat to the farthest corner.
T|今晚不需要更多证明。|Tonight didn't need more proof.`,
 jack_name:`N|工作证照片里的衬衫过于宽大。|The shirt in the badge photograph was too large.
T|第一天上班。我还想以后换一张好照片。|First day at work. I thought I'd replace it with a better photo later.
J|照片不太像现在。名字一样。|Photo isn't much like me now. Same name.
N|他指着姓名栏，没有指向门禁等级。|He pointed to the name, not the clearance level.
T|“谁能进哪扇门”和“这是谁”不是同一栏。|Who may enter a door and who someone is aren't the same field.
N|它用鼻尖碰了碰塑料套。|It touched the plastic sleeve with its nose.
J|想看可以看。别吃。|You can look. Don't eat it.
N|Jack 把证件放在桌边。|Jack placed the badge at the edge of the desk.
T|这回没有收起来当作只有我能看的过去。|This time I didn't put it away as a past only I could see.
N|照片和它的倒影一起留在玻璃上。|The photograph and its reflection remained together on the glass.`,
 first_word:`N|Jack 没有立即让它再说一次。|Jack did not immediately ask it to repeat itself.
J|我听见了。|I heard you.
N|记录按钮在他手边。他没有按。|The record button was within reach. He did not press it.
T|先回应，再保存。不是每个声音都得先变成样本。|Answer first. Save later. Not every sound has to become a sample first.
N|它看着他，又看向碗。|It looked at him, then the bowl.
B|{firstWord}。|{firstWord}.
J|嗯。|Yes.
N|没有新的奖章出现在它能理解的位置。|No new medal appeared anywhere it could understand.
T|它想说的也许很简单。对我来说却很大。我不能把这份大压回它身上。|What it meant might be simple. It was enormous to me. I couldn't press that weight back onto it.
N|他留在那里，等下一声自己到来。|He stayed, waiting for the next sound to come on its own.`,
 sky:`B|外面也有灯？|Lights outside too?
J|有一种不用我换电池的。|One kind doesn't need me to change batteries.
B|很好。|Good.
J|通常是。|Usually.
N|它望着通风口那一点亮。|It watched the light at the vent.
T|我的维修范围只有几层楼。它的世界不该只有几层楼。|My maintenance area was a few floors. Its world shouldn't be only a few floors.
B|你会带我看？|Will you show me?
J|我想。但我不能说今天就行。|I want to. Can't promise today.
N|他没有把“以后”当成已经做完的事情。|He did not treat later as something already done.
T|我得记得自己说过，而不是等它忘记。|I had to remember saying it, rather than wait for it to forget.`,
 wasteland:`D|你是这里的研究员？|Are you the researcher here?
J|修东西的。|I fix things.
D|那先看看水泵？|Then could you look at the pump first?
N|这个请求让他松了一口气。|The request let him breathe easier.
T|一个明确坏掉的东西。一把明确能用的工具。|Something clearly broken. A tool clearly usable.
N|旁边还有一个人等着换绷带。|Someone beside it waited for a fresh bandage.
T|不能因为泵好懂，就先假装没看见那个人。|I couldn't pretend not to see the person just because the pump was easier to understand.
B|两个都要。|Both need help.
J|对。先问医生。|Right. Ask the doctor first.
N|他把工具递给它，转身去问名字。|He handed it the tool and turned to ask a name.`,
 red_thread:`B|会疼吗？|Does it hurt?
J|线不会。|The thread doesn't.
N|他在第二个答案之前停住。|He stopped before the second answer.
T|一个技师式的答复。材料没问题，就假装别的也没问题。|A technician's answer. Material fine, therefore pretend everything else is fine.
B|我问的不是线。|Not asking about the thread.
J|我知道。|I know.
N|Jack 把手放平，没让手环藏进袖口。|Jack laid his hand flat instead of hiding the bracelet in his sleeve.
T|Jasmine 是一个人。不能只让她变成我悲伤时拿出的物件。|Jasmine was a person. Not just an object I brought out when sad.
N|无线电里又传来一个陌生姓氏。|Another unfamiliar surname came from the radio.
N|他听完，没有把失望藏在调频声里。|He listened to the end without hiding disappointment in the tuning noise.`,
 abandoned:`N|旧墙上还贴着手动覆盖说明。|Manual override instructions still hung on the old wall.
J|我会用这个。|I know how to use this.
B|那天也会？|You knew that day too?
J|会。|Yes.
N|他没有把“会”改成“权限不足”。|He did not turn yes into insufficient clearance.
T|这是最难留在记录里的那部分。我知道怎么开。|That was the hardest part to keep in the record. I knew how to open it.
J|我怕报错的是对的。也怕是错的。|I feared the alarm was right. And feared it was wrong.
B|然后等了。|Then waited.
J|然后等了。|Then waited.
N|他们没有触碰那扇废门。|They did not touch the abandoned door.`,
 bseries:`B|“必要”是谁写的？|Who wrote necessary?
J|签名缺了一半。|Half the signature is missing.
B|你也说过。|You said it too.
J|说过。|I have.
N|Jack 没有马上解释自己的情况更复杂。|Jack did not immediately explain that his case was more complicated.
T|也许确实更复杂。这句话仍不能抢在它的那句话前面。|Maybe it was more complicated. That still couldn't push ahead of what it said.
N|他圈出记录里没有受试者回答的位置。|He circled the blank place where the subject's answer should have been.
J|这里没有记下他们怎么说。|Nothing here says how they answered.
B|我们记下。|We write it down.
J|包括你不同意的。|Including when you disagree.`,
 mia:`B|你找了多久？|How long did you look?
J|几个月。后来还一直查名单。|Months. Kept checking lists after that.
N|他说得平静，手却绕紧红线。|He spoke calmly while tightening the thread around his wrist.
B|你不需要给我一个好结尾。|You don't have to give me a good ending.
T|我也不需要用它的回答，把 Jasmine 的空白填上。|Nor did I need its answer to fill Jasmine's absence.
J|她会取笑我这台收音机修得太慢。|She'd tease me for fixing this radio so slowly.
B|很慢？|That slowly?
J|极其。|Extremely.
N|他笑了一下，又安静下来。两件事都没有取消对方。|He laughed once, then grew quiet. Neither canceled the other.
N|他没有要求它替她坐到照片里的位置。|He did not ask it to take her place in the photograph.`,
 zero:`B|编号会证明什么？|What does a number prove?
J|东西放在哪个架子上。有时连这个都错。|Which shelf something belongs on. Sometimes not even that.
N|Jack 把异常日期和自己的出生日期分开写。|Jack wrote the anomalous date separately from his birth date.
T|一个档案看起来像谜底，不代表我可以拿它改掉全部过去。|A file looking like an answer doesn't let me replace my whole past with it.
B|你还是修门的人。|You're still the person who fixes doors.
J|今天是。|Today I am.
N|他们检查了一根真正断开的电缆。|They checked an actual disconnected cable.
J|这个至少能确认。|At least this is confirmed.
B|别的写不知道。|Write unknown for the rest.
J|好。|All right.`,
 incident:`N|记录中的操作员也有一张工作证。|The operator in the record had a badge too.
T|我不喜欢这一点。不是证据，只是我不喜欢。|I disliked that. Not evidence. Just dislike.
B|你会照做吗？|Would you follow it?
J|以前可能会。|Once, maybe.
B|现在？|Now?
J|我得先知道谁被关在里面。|I need to know who is being shut inside first.
N|他用铅笔写，不用不可擦的审批印。|He wrote in pencil, not an indelible approval stamp.
T|能修改一条意见，不等于能倒转发生过的事。|Being able to revise an opinion doesn't reverse what happened.
B|把我的意见也放进去。|Put my answer there too.
J|这次有位置。|There's room this time.`,
 eden:`N|幼苗长在一段废弃电缆槽里。|A seedling grew in an abandoned cable tray.
J|按标准，这里不该有土。|By the manual, there shouldn't be soil here.
B|它不知道标准。|It doesn't know the manual.
J|看得出来。|Apparently.
N|他绕过幼苗，没有把它拔掉方便检查。|He went around it instead of pulling it up to simplify inspection.
T|设施恢复标准，生活就得先让路。这种次序以前太容易。|Restore standards; life makes room first. That order used to be too easy.
B|他们住这里。|They live here.
J|我看见了。|I see them.
N|居民把水桶提到跟前。今天仍需要水。|A resident brought a bucket forward. They still needed water today.
N|计划书没有替他提起那个桶。|The project document didn't lift the bucket for him.`,
 black:`B|你想进去。|You want to go in.
J|很想。|Very much.
B|我不想今天进去。|I don't want to go in today.
N|Jack 的回答到了嘴边，又停下。|Jack's reply reached his mouth and stopped.
T|“差一步了。”我差一步，它还得走几步？|One more step for me. How many more for it?
J|告诉我你担心哪一段。|Tell me which part worries you.
B|你听到答案前就走。|That you walk before hearing the answer.
J|那我先停在这里。|Then I stop here first.
N|权限灯仍亮着。他没有因此失去权限。|The clearance light stayed on. Stopping did not revoke it.
T|原来等别人说完，不会让一张卡失效。|Apparently hearing someone out didn't invalidate a badge.`,
 second_abyss:`B|把手放这儿。|Put your hand here.
J|我能握稳。|I can hold it steady.
B|没有问你能不能。|Didn't ask whether you could.
N|他终于把抖动的手放在桌面。|He finally put his trembling hand on the desk.
T|母亲值夜班回来，会先看我们有没有发烧。我现在却想把温度计藏起来。|Mom checked us for fever after night shifts. Now I wanted to hide the thermometer.
J|我怕你发现后不肯让我去。|I fear you'll stop me going once you know.
B|你也会这样。|You do that too.
J|是。|Yes.
N|它没有用这一次反过来给他上锁。|It did not use this moment to lock him in return.
N|他们把测量值和下一步分开讨论。|They discussed the reading separately from the next step.`,
 chamber:`N|核心泵的磨损声很熟。|The core pump's worn sound was familiar.
J|这我修过类似的。|I've fixed something like this.
B|只修这个？|Only this?
J|只敢保证这个。|Only thing I can promise.
N|他没有宣称理解了整个项目。|He did not claim to understand the whole project.
T|普通技能也能有用，不必把自己改写成秘密的发明者。|Ordinary skills can matter. I don't need to rewrite myself as its secret inventor.
B|如果不修呢？|What if you don't fix it?
J|先看看谁还靠它呼吸。|Find who still relies on it to breathe first.
N|他们沿着气管走，没有先碰最后的开关。|They followed the air line without touching the final switch first.
N|管道另一端有未被编号的生活。|At the other end of the pipe was life without a number.`,
 between:`B|“养大”之后呢？|After raised?
J|不知道。|I don't know.
B|不能一直用以前回答现在。|Can't always answer now with before.
J|对。|Right.
N|他给两杯水留出一样的间距。|He left equal space for two cups of water.
T|我想要一个词保护我们。它可能需要那个词别再替它决定。|I wanted a word to protect us. It might need the word to stop deciding for it.
J|你不用今天回答我想要的那个。|You don't have to give the answer I want today.
B|我可以有自己的词。|I can have my own word.
J|可以。|Yes.
N|他们的杯子没有因此靠得更近，也没有被撤走。|The cups neither moved closer nor were taken away.`,
 last_door:`N|Jack 检查了外侧锁舌，又绕到里面。|Jack checked the outside latch, then went inside.
B|这边呢？|This side?
J|也能开。|Opens too.
N|他把手放开，让它试。|He let go and let it test the handle.
T|我可以确认设备。不能靠设备替它确认愿意。|I can confirm hardware. Hardware cannot confirm willingness for it.
B|今晚我想先睡。|I want to sleep first tonight.
J|可以。|All right.
N|他没有把地图贴到床头催促。|He did not hang the map by its bedding to hurry it.
N|路仍在外面。休息没有让路消失。|The road was still outside. Rest didn't erase it.
T|这一次，“明天”得是约定，不是借口。|This time tomorrow had to be an agreement, not an excuse.`,
 final:`B|你想怎样？|What do you want?
J|想活。想知道。想你在。|To live. To know. For you to be here.
N|他说完才听见第三句的重量。|Only after speaking did he hear the weight of the third wish.
J|第三个不能只听我的。|The third doesn't depend only on me.
B|我也想活。|I want to live too.
T|活下来以后，仍得决定怎么过一天。终端不会替我洗那个碗。|After survival, we still have to decide how to live a day. The terminal won't wash that bowl for me.
N|他把维修单折进旧包。|He folded the maintenance form into the old bag.
N|Jasmine 的照片留在里面，没有被新照片替换。|Jasmine's photograph remained inside, not replaced by a new one.
J|我们先把每条路看清。|Let's look at each road first.
N|他们读完了最后一页。|They finished the final page.`
 };
 for(const [id,raw]of Object.entries(extra)){const n=D.nodes.find(n=>n.id==='project_'+id);n.lines.push(...lines(raw));}
 // Jack's choices change his private voice; no tendency meters are shown.
 const n=D.nodes.find(n=>n.id==='project_last_door');n.lines[4].variants=[{requirements:{'narrative.jack.tendencies.control':{min:6}},text:tr('我的手仍想先检查锁。先停下来。让它碰到把手。','My hand still wanted to check the lock first. Stop. Let it reach the handle.')},{requirements:{'narrative.jack.tendencies.honesty':{min:8}},text:tr('我没有许诺不怕。我许诺不再把怕藏成权限错误。','I did not promise fearlessness. I promised not to hide fear as an access error.')}];
})();
