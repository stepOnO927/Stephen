'use strict';
(()=>{const t=Abyss.HomeData.t,D=Abyss.JourneyData;const rows=[
 ['Jack 补好背包带，问它是否还愿意继续。它的沉默意味着暂停，不是自动答应。','Jack mends the strap and asks if it wants to continue. Silence means a pause, not automatic agreement.'],
 ['风把地图翻过去，露出旧购物清单。它问哪些东西还买得到。Jack 指了指他们的水壶。','Wind flips the map to an old shopping list. It asks what can still be bought. Jack points to their flask.'],
 ['它把湿帽子挂在火边，Jack 挪开自己的袜子。两种生活需要占据真实的位置。','It hangs a wet hat by the fire. Jack moves his socks aside. Both lives need real space.'],
 ['小路上的灯看起来像星星。Jack 承认自己也分不清方向，先等天亮。','Road lights resemble stars. Jack admits he has lost direction too and waits for dawn.'],
 ['它数着远处的列车声。Jack 说，有些机器会在没人乘坐之后继续执行承诺。','It counts distant train sounds. Jack says some machines keep promises after nobody remains to ride.'],
 ['Jack 梦里喊了一声 Jasmine。它没有立刻问，醒后先把水壶推给他。','Jack calls Jasmine in his sleep. It waits until he wakes, then pushes the flask toward him.'],
 ['他们讨论明天绕路，直到它指出地图上没有给不能爬梯子的身体留路。Jack 改了计划。','Planning a detour, it notes the map excludes bodies that cannot climb ladders. Jack changes the plan.'],
 ['营火快灭了，它没有被叫去添柴。Jack 问它想看一会儿黑暗，还是再点亮一点。','The fire fades. Jack asks if it wants to watch the dark or light it again, instead of ordering more wood.'],
 ['饭碗碰在一起发出很轻的声音。今天的记录只写“都吃过了”，不写“实验成功”。','Their bowls touch softly. The report says both have eaten, not experiment successful.'],
 ['风停了以后，Jack 听见它自己的呼吸节奏。今晚他没有让它配合任何测量。','After the wind stops Jack hears its own breathing rhythm. Tonight he asks for no measurement.']
 ];rows.forEach(([zh,en],i)=>D.camps.push({id:'camp_exp_'+i,text:t(zh,en)}));Abyss.I18n.register(Abyss.HomeData.english);})();
