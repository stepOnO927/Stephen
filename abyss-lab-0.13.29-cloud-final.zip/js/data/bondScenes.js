'use strict';
// Authored dialogue beats: separate from simulation and relationship statistics.
(()=>{
 const D=Abyss.NarrativeData;
 const line=(speaker,text)=>({speaker,text});
 const intro=D.nodes.find(n=>n.id==='project_b07');
 if(intro){intro.lines=[line('narrator','地下三层。通风口的声音断了一拍，玻璃后的身体随之缩紧。'),line('player','我先把灯调暗。它退到了最靠近我的角落。也许这里只剩我不会突然发出声响。'),line('narrator','你把食盆放在舱门内侧。它等你的手退出去，才慢慢靠近。'),line('player','我在记录上写：适应良好。写完，才发现它一直看着我的手。'),line('narrator','钥匙在那只手里。你转了一圈，门锁发出很轻的一声。'),line('player','暂时还不能开。外面有电缆，有消毒液，有我自己也不明白的危险。'),line('narrator','它没有看食盆。它看着你。'),line('player','我想让它相信我。可是现在，需要它相信的人，也是把门锁上的人。')];}
 const add=(id,title,requirements,lines,choices)=>D.nodes.push({id,title,group:'relationship',speaker:'narrator',text:lines[0].text,lines,requirements,priority:75,once:true,choices});
 add('bond_heater','暖气旁的位置',{day:{min:4}},[
 line('narrator','暖气终于恢复。你把自己的椅子拖近玻璃，袖口沾着维修时留下的灰。'),
 line('narrator','它在另一侧挪了一小步，直到你们的影子靠在一起。'),
 line('player','今天没有测试。我甚至不想再打开记录本。'),
 line('narrator','它闭上眼。尾部仍贴着门的方向。'),
 line('player','它在我旁边睡着了。这是真的。那扇门仍然锁着，也是真的。'),
 line('narrator','暖气响了三下。你没有把这次靠近写成服从。')],
 [{id:'stay',label:'留下来，等它睡稳',flag:'bond_shared_warmth'},{id:'blanket',label:'把毯子留在它能自己取到的位置',flag:'bond_reachable_blanket'},{id:'leave',label:'轻声告别，去休息'}]);
 add('bond_safe_person','它来找你',{stage:3,day:{min:15}},[
 line('narrator','走廊里响起陌生人的脚步。它先退了一步，随后抓住你的袖子。'),
 line('creature','别走。'),line('player','我下意识把它挡在身后。它的手没有松开。'),
 line('narrator','脚步远去。它仍握着你，却抬头看向门锁。'),
 line('creature','有你，安全。没有你……门也不开。'),
 line('player','我差点说：所以你需要我。这句话突然变得很难听。'),
 line('creature','你能留下。也能让我出去吗？')],
 [{id:'admit',label:'“你害怕的时候可以找我。门的事，我也欠你一个回答。”',flag:'bond_admitted_lock'},{id:'explain',label:'解释门外的风险，告诉它哪些仍不确定',flag:'bond_explained_risk'},{id:'avoid',label:'“今天先不谈门。”',flag:'bond_avoided_lock'}]);
 add('bond_first_i','第一次把自己放在句首',{stage:3,day:{min:18}},[
 line('narrator','你把它的杯子放到惯常的位置。它没有接，先把杯子移到另一边。'),
 line('player','不是那里。我正想伸手，又停住。'),line('creature','我……想放这里。'),
 line('narrator','它等了一会儿，像在确认刚才那个声音确实属于自己。'),
 line('creature','我。不想你拿回去。'),
 line('player','它已经学会许多词。直到这一刻，我才听见一个不能替它说出来的主语。'),
 line('narrator','杯子离开了你画好的标记。桌面上没有发生其他事。')],
 [{id:'respect',label:'收回手，让杯子留在那里',milestone:'first_i_event',flag:'bond_first_i'},{id:'ask',label:'“你为什么喜欢那里？”然后听它说完',milestone:'first_i_event',flag:'bond_first_i'},{id:'correct',label:'仍把杯子放回标记内',milestone:'first_i_event',flag:'bond_first_i_corrected'}]);
 add('bond_forgiveness','靠近不是撤回',{stage:4,flag:['bond_admitted_lock'],day:{min:25}},[
 line('narrator','它又坐到你的椅子旁。你给它让出一点位置，谁也没提昨天的争执。'),
 line('creature','我还是想坐这里。'),line('player','我松了一口气。那口气太明显，它听见了。'),
 line('creature','我没有说，你做得对。'),line('narrator','你的手停在半空。它没有躲，也没有主动碰上来。'),
 line('creature','想靠近你，和想让你开门，不会互相消失。'),
 line('player','我想道歉，又怕自己的道歉也在要求它给一个让我好过的回答。')],
 [{id:'hear',label:'“我听见了。你不用先原谅我。”',flag:'bond_no_forgiveness_demand'},{id:'ask',label:'“今晚你想让我离远一些吗？”',flag:'bond_asked_distance'},{id:'quiet',label:'放下手，安静地坐着'}]);
 add('bond_jack_background','记录上的人',{stage:3,day:{min:20}},[
 line('narrator','它把旧工作证从你的记录本里抽出来。照片上的你年轻一些，姓名栏写着 jack。'),line('creature','这个，是你？'),line('player','是我。不是实验体的编号，也不是一项职务。来这里以前，我就叫这个名字。'),line('narrator','你告诉它证件何时拍摄，哪些事情你愿意谈，哪些还需要一点时间。它听完，把证件还给你。'),line('creature','我知道了。你也有……以前。')],[{id:'share',label:'回答它关于工作证的问题',flag:'knows_jack'},{id:'limited',label:'说明不愿谈的部分，把能确认的经历告诉它',flag:'knows_jack'}]);
 const nameNode=D.nodes.find(x=>x.id==='relation_name_call');if(nameNode)nameNode.requirements={...nameNode.requirements,flag:['knows_jack']};
 if(!D.milestones.includes('first_i_event'))D.milestones.push('first_i_event');
 if(!Abyss.Phase2State.memoryIds.includes('first_i_event'))Abyss.Phase2State.memoryIds.push('first_i_event');
})();
