'use strict';
Abyss.LegacyScenes=(()=>{
 const t=Abyss.HomeData.t;
 const legacy=[
 ['Jack 把旧名字写在档案首页，新名字另起一页。纸没有要求他比较。','Jack writes the old name on its first page. The new name starts another. Paper asks for no comparison.'],
 ['旧碗洗干净了，新个体把它推到了另一边。Jack 第一次忍住没有摆回原处。','The old bowl is clean. The new individual pushes it aside. Jack does not put it back.'],
 ['Jack 叫错了名字。他停下来道歉，没有解释两双眼睛有多相像。','Jack uses the wrong name. He apologizes without explaining how alike their eyes seem.'],
 ['档案记录了一次喜欢海的生命。面前这个更喜欢管道里的回声。两份喜好都是真的。','The archive records a life that loved the sea. This one prefers pipe echoes. Both preferences are real.'],
 ['上一代留下的刻痕比它高。Jack 没有在同一根刻度上画新线。','The old height mark is taller. Jack chooses a different scale for the new marks.'],
 ['遗物柜的玻璃擦了一半。Jack 发现自己并不需要今天把所有灰尘擦完。','The keepsake glass is half cleaned. Jack realizes he need not remove every speck today.'],
 ['今天的晚饭太安静。Jack 想起另一种咀嚼声，随后听清了眼前这一种。','Dinner is quiet. Jack remembers a different chewing sound, then listens to this one.'],
 ['新个体把旧门推开了。门轴认识力气，不认识名字。','The new individual opens the old door. Hinges recognize force, not names.'],
 ['Jack 翻看生命档案，发现自己记下了第一次说话，却漏掉了第一次拒绝。今天补上。','Jack recorded the first word but omitted the first refusal. Today he adds it.'],
 ['有人问是不是“又养了一只”。Jack 说是认识了另一个，不是把谁补回来。','Someone asks whether he raised another. Jack says he met someone different, not filled a vacancy.'],
 ['旧照片没有被新照片盖住。它们各自占了一块墙。','The new portrait does not cover the old. Each has its own part of the wall.'],
 ['Jack 准备了曾经最受欢迎的食物。它闻了一下就离开，他把偏好表重新留白。','Jack prepares an old favorite. It sniffs and leaves. He makes the preference sheet blank again.'],
 ['生日不沿用旧日期。这个生命第一次睁眼的那天，已经足够成为开始。','The birthday is not reused. The day these eyes opened is enough of a beginning.'],
 ['同一件外套扣不上了。Jack 改了衣缝，没把新身体当成尺寸错误。','The old coat will not close. Jack alters the seam, not the new body.'],
 ['新个体在档案柜前停下。Jack 只说这里曾住过谁，没有要求它替自己怀念。','It pauses at the archive. Jack tells it who lived here without asking it to grieve for him.'],
 ['工具少了一件。Jack 笑了一下，又发现这次藏工具的地方完全不同。','A tool is missing. Jack smiles, then finds it hidden somewhere entirely different.'],
 ['世界日期继续增加，年龄从新的第一天计算。两种时间没有互相取消。','The world date advances. Age begins at a new first day. Neither clock cancels the other.'],
 ['Jack 把旧承诺标成仍未完成。他不会用新个体的答应替上一段关系结账。','Jack marks an old promise unfinished. The new individual’s agreement cannot settle that relationship.'],
 ['一位老朋友在空椅子旁坐下。今天没人说“幸好还有新的”。','An old friend sits beside an empty chair. Nobody says at least there is a new one.'],
 ['档案柜又多了一层。Jack 没有称它为成绩，只把每一层的灯单独关好。','The archive gains a shelf. Jack does not call it an achievement. He switches each lamp separately.']
 ];
 const objects=[
 ['新个体把旧玩具倒过来玩。另一种玩法没有损坏过去。','It plays with the old toy upside down. A different game does not damage the past.'],
 ['玩具的一只脚磨平了。它摸了摸那个地方，随后把玩具放进自己的角落。','One foot of the toy is worn smooth. It touches the wear, then takes the toy to its own corner.'],
 ['Jack 没有演示旧游戏。它自己找到了一个完全不同的规则。','Jack does not demonstrate the old game. It finds an entirely different rule.'],
 ['旧玩具被留在窗边。没有被玩，不等于被遗忘。','The old toy stays by the window. Not playing with it is not forgetting it.'],
 ['它问玩具以前属于谁。Jack 回答了名字，随后等它自己的下一句话。','It asks who owned the toy. Jack gives the name and waits for its next question.'],
 ['旧识别牌的背面没有编号。Jack 那时终于学会把名字写到前面。','The tag has no code on its reverse. Jack had finally learned to put the name first.'],
 ['它把识别牌放在桌上，不愿戴。Jack 把这个决定也记了下来。','It leaves the tag on the table, unwilling to wear it. Jack records that decision too.'],
 ['金属牌碰到杯沿，响了一声。Jack 认得声音，没有把它认成来人。','The tag rings against a cup. Jack recognizes the sound, not a returning person.'],
 ['识别牌的绳子换了。旧绳收在盒底，没有被当成新生命的束带。','The tag gets a new cord. The old one stays in the box, not around a new life.'],
 ['它认不出旧名字的字母，却知道 Jack 看那些字时会放慢呼吸。','It cannot read the old name, but notices Jack breathing more slowly when he does.'],
 ['衣料的折痕没有摊平。新个体把它当作小毯子，而不是旧衣服。','The fabric keeps its creases. It becomes a small blanket rather than old clothing.'],
 ['布角留着一段未拆的缝线。Jack 把新的补丁缝在另一处。','A corner keeps its old seam. Jack stitches the new patch elsewhere.'],
 ['它闻了闻旧衣料。熟悉的实验室气味没有让它拥有另一个生命的记忆。','It smells the old fabric. Familiar lab scents do not give it another life’s memories.'],
 ['Jack 原想把布料收回去。它已经用那块布给自己的石头盖了被子。','Jack means to put the fabric away. It has already made a blanket for its own stone.'],
 ['旧衣料被剪成了两块。保存并不总意味着保持原样。','The old fabric is cut in two. Keeping something need not mean leaving it unchanged.']
 ];
 const anomalies=[
 ['档案上的日期短暂错了一天。Jack 拿出原记录核对，没有把错字当成归来。','An archive date shifts by a day. Jack checks the original, not a supposed return.'],
 ['旧录音停在一段呼吸声上。新个体没有跟着呼吸，只问机器为什么停了。','A recording stops on a breath. The new individual does not match it. It asks why the machine stopped.'],
 ['玻璃里有两道影子，走廊里只有一个身体。Jack 先检查了反光角度。','Glass shows two shadows and the corridor one body. Jack checks the reflection first.'],
 ['旧玩具滚到了另一个房间。没人知道是谁推的，这不构成任何人的记忆。','The old toy rolls into another room. An unknown cause is not someone’s memory.'],
 ['档案终端自动补出了旧名字。Jack 把当前姓名重新输入，保留了错误记录。','The terminal completes the old name. Jack enters the current name and retains the error log.'],
 ['梦里响过的敲门节奏出现在管道里。Jack 没有把两者写成同一个事实。','A pipe repeats a knock heard in a dream. Jack does not record them as the same fact.'],
 ['旧照片的一角亮了一下。它问 Jack 是灯坏了，还是人太想看见什么。','A portrait corner flashes. It asks whether the light is faulty or someone wants to see something.'],
 ['回声先叫了旧名字，随后叫了新名字。Jack 要求系统把两条记录分开。','An echo calls the old name and then the new. Jack demands separate records.'],
 ['同一段录像有两种结束时间。Jack 留下两个版本，没有选更安慰人的那个。','A recording has two end times. Jack keeps both, not the more comforting one.'],
 ['档案柜里多了一页空白。新个体没有在上面签字，也不欠过去一个签名。','A blank page appears in the archive. The new individual does not sign. It owes the past no signature.']
 ];
 const entries=[...legacy.map((r,i)=>({id:'legacy_scene_'+i,kind:'legacy',text:t(...r)})),...objects.map((r,i)=>({id:'object_scene_'+i,kind:'object',objectType:['toy','tag','fabric'][Math.floor(i/5)],text:t(...r)})),...anomalies.map((r,i)=>({id:'memory_anomaly_'+i,kind:'anomaly',text:t(...r)}))];
 function record(s,e){s.legacy.seen.push(e.id);Abyss.Home.remember(s,'quarters',e.text);}
 function observe(s){const l=s.legacy;if(!l.archive.length||s.mode!=='raising')return;
  const type=s.day%13===0&&s.continuity.echoes.length?'anomaly':s.day%5===0?'object':'legacy';
  const entry=entries.find(e=>e.kind===type&&!l.seen.includes(e.id)&&(e.kind!=='object'||l.objects.some(o=>o.kept&&o.found&&(o.type||'toy')===e.objectType)));
  if(entry&&(s.day%3===0||type==='anomaly'))record(s,entry);
 }
 Abyss.I18n.register(Abyss.HomeData.english);return {entries,observe};
})();
