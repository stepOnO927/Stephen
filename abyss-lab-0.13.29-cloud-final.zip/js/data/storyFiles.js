'use strict';
Abyss.StoryFiles=(()=>{const t=(a,b)=>Abyss.HomeData.t(a,b);const raw=[
 ['profile',0,'B-07 私人记录','B-07 Private Record','观察记录没有写下它望向门口的原因。','The observation record never says why it looks at the door.',{B07_IDENTITY:2}],
 ['radio',3,'旧无线电','Old Radio','静电之间，一位陌生人说今晚有雨。Jack 没有把收听写成任务。','Between bursts of static, a stranger says rain is coming. Jack does not record listening as a task.',{WORLD_HUMANITY:3}],
 ['sea',4,'海岸旧地图','Old Coastal Map','地图的边角沾着盐。它问那片空白是不是水。','Salt marks the map’s edge. It asks whether the blank space is water.',{B07_HOPE:4}],
 ['thread',6,'旧红线','Old Red Thread','红线还在。Jasmine 的名字不再只是一个删去的栏位。','The red thread remains. Jasmine’s name is no longer just a deleted field.',{MIA_TRUTH_PROGRESS:4}],
 ['b03',8,'B-03 录音','B-03 Recording','录音里先有人呼吸，随后有人说：不要替我选择我的名字。','Someone breathes in the recording, then says: do not choose my name for me.',{WORLD_ABYSS_KNOWLEDGE:6,B07_IDENTITY:4}],
 ['jasmine',10,'Jasmine 的传输','Jasmine’s Transmission','信号中有停顿。停顿既不能证明她活着，也不能证明她死了。','There is a pause in the signal. A pause proves neither life nor death.',{MIA_TRUTH_PROGRESS:6}],
 ['zero',11,'零号观察日志','Zero Observation Log','两份记录使用相同编号，却没有相同的身体。','Two records use the same number, but not the same body.',{ZERO_AWARENESS:6,WORLD_ABYSS_KNOWLEDGE:4}],
 ['continuity',12,'连续性碎页','Continuity Fragment','那行字被誊写过。Jack 不记得自己见过原稿。','The line has been copied. Jack does not remember seeing the original.',{CONTINUITY_SCORE:6}],
 ['eden',13,'修复计划意见书','Restoration Plan Memorandum','修复一片土地的代价，被写成了一列没有名字的对象。','The cost of restoring a landscape is a list of subjects without names.',{WORLD_EDEN_SUPPORT:5,WORLD_ABYSS_KNOWLEDGE:4}],
 ['black',14,'黑级权限钥匙','Black Clearance Key','它允许你打开门。它没有说明谁允许你让别人进去。','It lets you open doors. It does not say who permits you to make others enter.',{BLACK_CLEARANCE_PROGRESS:6}],
 ['mirror',16,'裂开的镜面','Cracked Mirror','镜面将你的轮廓切开。背后还有一道磨损的刻痕。','The mirror splits your outline. There is another worn mark behind it.',{HOST_ROUTE_INSTABILITY:2}],
 ['photo',17,'未编号的照片','Unnumbered Photograph','你们都在照片里。没有一个人被写成成果。','You are both in the photograph. Neither is labeled a result.',{B07_ATTACHMENT:4}]];
 const items=raw.map(([id,chapter,zh,en,text,english,effects])=>({id,chapter,name:t(zh,en),text:t(text,english),response:t('Jack 收起记录，给它留了一段不被追问的安静。','Jack puts away the record and leaves it a quiet interval without questions.'),effects}));items.push({id:'familiar',chapter:0,ngPlus:true,name:t('位置不对的记录','A Misplaced Record'),text:t('Jack 伸手去拿第二层的文件。那里原本不该有东西。纸边的折痕却让他停了一下。','Jack reaches for a file on the second shelf. Nothing should be there. A fold in the paper makes him pause.'),response:t('他没有为那种熟悉感编造一个解释。','He does not invent an explanation for that familiarity.'),effects:{CONTINUITY_SCORE:3}});Abyss.I18n.register(Abyss.HomeData.english);return {items};})();
