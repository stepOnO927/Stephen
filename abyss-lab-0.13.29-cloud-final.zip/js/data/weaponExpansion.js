'use strict';
// Individual provenance and silhouettes. Rarity affects base damage, not invincibility.
Abyss.WeaponExpansion=(()=>{
 const t=(a,b)=>Abyss.HomeData.t(a,b),D=Abyss.WeaponData,tiers=['common','uncommon','rare','epic','legendary','anomalous'];
 const stories=[
 ['排水工把断管磨尖，护送最后一班撤离者穿过淹水隧道。','A drainage worker sharpened a broken pipe to escort the last evacuees through flooded tunnels.'],
 ['汤铺老板打磨的厚刀，刀背仍刻着每日领饭的人数。','A soup-shop owner ground this blade. The spine still counts daily diners.'],
 ['桥梁工人的锤柄缠着护栏钢筋，救援队曾用它敲开埋住的门。','A bridge worker wrapped its grip in rebar. Rescuers used it to open a buried door.'],
 ['医院安保留下的电棍，保险开关被改为必须双手确认。','Hospital security left this baton. Its safety now requires both hands to confirm.'],
 ['起重机驾驶员用它拖回困在灰潮里的同事。','A crane operator used this hook to drag a colleague out of the grey tide.'],
 ['木匠的射钉工具被加装护手，弹匣上贴着孩子画的房子。','A carpenter added a handguard. A child’s house drawing remains on the magazine.'],
 ['营地猎人用自行车片簧组装，扳机上包着防滑麻线。','A camp hunter built this crossbow from bicycle springs and bound its trigger in hemp.'],
 ['线圈来自失效磁共振仪，每一枪都让表头颤动。','The coil came from a failed MRI scanner. Each shot shakes its gauge.'],
 ['焊接员为了不再烧伤同行者，为电弧加了一圈陶瓷遮挡。','A welder added a ceramic shroud to keep the arc away from companions.'],
 ['切割机停转后，工人把锯片装到能握稳的长柄上。','After the cutter stopped, workers mounted its disc on a steady long grip.'],
 ['铁路检修员留下的最后一枚轨钉，有一面已经磨成镜面。','A rail inspector’s final spike has one face polished to a mirror.'],
 ['急救队切开车门用的等离子切割器，喷口带着玻璃冷却套。','Paramedics cut car doors with this plasma tool. A glass sleeve cools its nozzle.'],
 ['从废弃培养槽中长出的刺，柄部保留了活组织的呼吸。','A spike grew inside an abandoned culture tank. Living tissue still breathes in its grip.'],
 ['广播站技术员用失真的扬声器驱退猎群，铭牌写着请勿对准耳朵。','A radio engineer repelled packs with a distorted speaker. Its plate says never aim at ears.'],
 ['玻璃田守望者将旧木弓修好，弓腹上的芽形刻纹没有涂漆。','A Glassfield watcher repaired this wooden bow. Its bud-shaped carvings remain unpainted.'],
 ['井盖背面写着地下住户的姓名，他们轮流为盾带缝补。','Names of underground residents cover the back. They take turns mending the shield strap.'],
 ['拾荒者用货梯轴承护住指节，握拳时仍能听见细小的滚动声。','A scavenger protected their knuckles with elevator bearings that still quietly roll.'],
 ['熔炉工留下一副长钳，钳口的热色记录了一千次炉门开合。','A furnace worker left these tongs. Heat stains mark a thousand openings of the furnace door.'],
 ['送信人以旧皮带编成投索，绳结里藏着寄不出去的邮票。','A courier braided this sling from belts. Undelivered stamps are tucked into its knots.'],
 ['旧勘测队的标尺改成护送长杆，每一道刻度都还准确。','A survey team turned its ruler into an escort lance. Every graduation remains accurate.'],
 ['护士把维修臂架变成前臂护具，内衬是一块柔软的病号布。','A nurse made this guard from a repair brace and lined it with soft hospital cloth.'],
 ['拾取的颚片经过钝化处理，使用者宁愿它挡住攻击而不是咬人。','The recovered jaw was blunted. Its owner preferred stopping a strike to biting.'],
 ['救援束带反复打结留下白痕，用力时会自动收紧。','Repeated rescue knots left pale marks. The tether tightens under load.'],
 ['水闸救援员的钩枪附带回收轮，枪托上有救过多少人的划痕。','A sluice rescuer’s harpoon has a retrieval reel and marks for every rescued person.'],
 ['死频道工程师把敌方追踪频段标在外壳里侧。','A Dead Channel engineer marked hostile tracking bands inside the casing.'],
 ['门框焊工做的便携撞架，握把间距按两个人一起使用设计。','A frame welder made this portable ram with grips for two people working together.'],
 ['观察厅碎镜被磨成飞盘，外缘刻着不要相信反射的警告。','Observation-hall mirror shards became this disc. Its rim warns against trusting reflections.'],
 ['甲壳修复时脱落的刺被收集成束，它只愿意把它交给 Jack。','Spines shed during shell repair were bound together. It would give them only to Jack.'],
 ['电网维修员的绝缘杖保留了三道安全环，握持处永远干燥。','An electrical worker’s staff retains three safety rings and a permanently dry grip.'],
 ['撤离仪式上无人领取的礼仪刃，银饰里夹着一段蓝色丝线。','No one claimed this ceremonial blade at evacuation. Blue thread remains inside its silverwork.'],
 ['装配厂技师将报废齿轮挂在链上，重量恰好能敲碎堵路砖墙。','A factory technician chained a discarded gear heavy enough to break a blocked brick passage.'],
 ['这颗牙是它主动留下的。穿线孔磨得很圆，避免伤到佩戴者。','It left this tooth willingly. The thread hole was carefully rounded to spare the wearer.'],
 ['维修组的万能钩经历了太多拆卸，弯曲部位每次都被重新校直。','This repair hook survived countless dismantlings. Its curve was straightened every time.'],
 ['中继无人机的四片叶片重装成防护阵列，它仍等待返航的编号。','Four relay-drone vanes became a guard array. It still waits for a return-flight designation.'],
 ['一扇不存在的错误窗口。第一次关闭它时，目标忘记了自己的下一步。','An error window that does not exist. Closing it once made its target forget its next move.'],
 ['曾经像一个悬空箭头的记录，现在被封进无指向的银环。没人知道它究竟指向何处。','A record once shaped like a hovering cursor was sealed into a directionless silver ring. No one knows where it points.'],
 ['它把红线系在你手腕上，之后所有越界的攻击都先撞上那个结。','It tied red thread around your wrist. Since then, trespassing strikes hit the knot first.'],
 ['广播塔钟表丢失了一次滴答。这根秒针重复的总是已经发生的伤害。','A radio-tower clock lost a tick. This second hand repeats damage that has already happened.'],
 ['枪膛是空的，声音却从下一分钟传来。记录员始终不肯把它称作枪。','The chamber is empty, but its sound arrives from the next minute. Archivists refuse to call it a gun.'],
 ['工具的轮廓会随同行者的距离改变，库存终端无法保存它的名称。','Its outline changes with the distance between companions. The inventory terminal cannot save its name.']
 ];
 const additions=[
 ['crescent','月牙猎弓','Crescent Bow','ranged','first','rare','bow','玻璃田弓匠用两片弯曲银叶围住弓弦，送给愿意留下修屋顶的人。','A Glassfield bowyer framed the string with two silver leaves for someone who stayed to mend roofs.'],
 ['thorn','荆棘反曲弓','Thorn Recurve','ranged','poison','epic','bow','黑花根系沿着弓腹长成护手，箭矢只在离弦后显露绿色脉络。','Black-flower roots became its handguard. Green veins appear on an arrow only after release.'],
 ['dawn','黎明长剑','Dawn Longsword','melee','first','legendary','sword','城门守卫将熔炉里第一块新钢留给回来的同伴，剑柄缠着暖色布。','The gate guard saved the furnace’s first new steel for a returning companion and bound its grip in warm cloth.'],
 ['tide','潮汐短刀','Tide Dagger','melee','crit','uncommon','dagger','湖边渔人磨出单侧弯刃，用来切网，也用来带同伴脱离缠绕。','A lakeside fisher ground its curved edge to cut nets and free tangled companions.'],
 ['glassfang','玻璃獠牙','Glass Fang','melee','pierce','epic','dagger','观察窗碎片被层压成透明匕首，中间保存一滴从未干涸的培养液。','Observation glass was laminated into a dagger with a drop of culture fluid that never dries.'],
 ['service','夜巡手枪','Night Patrol Pistol','ranged','combo','rare','pistol','夜巡员给每一颗螺丝做了定位线，承诺枪口永远先朝地面。','A night patrol officer marked every screw and promised to point the muzzle at the ground first.'],
 ['railgun','银轨步枪','Silver Rail Rifle','synthetic','pierce','legendary','rifle','铁炉城把两根导轨磨成银色，枪身携带一枚写着返航的陶瓷牌。','Ironhaven polished twin rails silver and attached a ceramic tag reading return home.'],
 ['scatter','灰堡霰弹枪','Grey Bastion Shotgun','ranged','break','epic','shotgun','避难所维修工保留木制枪托；它的任务是阻止闯入，而不是追赶逃跑的人。','A shelter mechanic kept the wooden stock. Its task is stopping intruders, not chasing those who flee.']
 ];
 additions.forEach(([id,zh,en,category,trait,rarity,shape,lore,english],i)=>D.weapons.push({id:'weapon_'+id,name:t(zh,en),en,category,trait,rarity,attack:0,bonus:{[trait==='first'?'crit':trait==='break'?'pierce':trait]:4},forge:{scrap:45+i*6,material:4+i%3,boss:['epic','legendary'].includes(rarity)?1:0},visual:{kind:shape,variant:i,asset:null},lore:t(lore,english)}));
 D.weapons.forEach((w,i)=>{const r=tiers.indexOf(w.rarity);w.attack=[3,5,8,11,14,15][r]+(i%3)*.35;if(i<stories.length)w.lore=t(...stories[i]);w.visual.palette=i%8;w.fx={kind:w.category==='anomalous'?'fracture':['bow','crescent','thorn','crossbow','sling','needle'].includes(w.id.slice(7))?'arrow':['nail','coil','plasma','harpoon','empty','service','railgun','scatter'].includes(w.id.slice(7))?'shot':w.category==='synthetic'?'arc':w.category==='heavy'?'impact':'slash',color:['#a8bdac','#c5b490','#8dafc6','#ae9abe','#d9c28a','#be8295'][r],rays:3+r,variant:i,power:r};});
 Abyss.I18n.register(Abyss.HomeData.english);return {additions};
})();
