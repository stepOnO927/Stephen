
'use strict';
// 60 authored silhouettes. Unlocks use the existing shop / exploration / milestone rules.
Abyss.AtelierData={
 palettes:[
 ['#566c84','#a6bfd3','#233747','#ecd9ab','#bf9763'],['#8b4e5d','#dcaaa7','#452d3c','#ecdcc2','#bd976b'],['#547863','#a2c59c','#213f36','#e6dec0','#bca45e'],['#b89853','#ecdca1','#645031','#efe7d1','#c8b5a2'],['#686084','#bdb0db','#302d47','#e8dce6','#acaec4'],['#365661','#88b8bf','#182d38','#d7dfd2','#bdb69c']],
 rows:{
 head:[['dock_beret','Dockside Beret','码头画家贝雷帽','斜戴的帽檐和铜制别针，来自为船只重画名字的画师。'],['winter_ushanka','Winter Ushanka','雪谷绒耳帽','救援队留下的羊绒护耳，把寒风挡在玻璃外。'],['fern_bonnet','Fern Bonnet','蕨叶兜帽','Glassfield 的裁缝把嫩叶轮廓缝成不遮角的帽顶。'],['sand_turban','Sandrunner Turban','沙行者头巾','一条能挡沙的长布，曾随商队走过三座废城。'],['astronomer_hat','Astronomer Hat','观星者软帽','宽檐内绣着旧时代的星图，缺了一颗星。'],['branch_diadem','Branch Diadem','银枝冠冕','把折断的银枝重新焊好的人，坚持说它不是王冠。']],
 face:[['pilot_frames','Pilot Frames','飞行员镜框','透明镜片来自坠落飞行器的观察窗，仍能看清彼此。'],['cat_frames','Cat-eye Frames','猫眼玳瑁镜','旧书店老板把夸张的尖角磨圆，避免碰伤眼眶。'],['archive_monocle','Archive Monocle','档案员单片镜','细链末端留着图书馆的编号，镜片没有度数。'],['lace_halfmask','Lace Halfmask','夜宴半面罩','褪色邀请函藏在衬里，眼孔始终留得很宽。'],['snow_goggles','Snow Goggles','雪线护目镜','蓝灰色镜片不遮住瞳孔，皮带经过柔软包边。'],['prism_veil','Prism Veil','棱镜纱幕','极薄的晶片像一场尚未落下的雨，随视线轻响。']],
 neck:[['harbor_scarf','Harbor Scarf','海港条纹围巾','海员拆开自己的旧围巾，给它留了一段暖和的长度。'],['velvet_cravat','Velvet Cravat','酒红丝绒领结','没有仪式需要它出席，这条领结只为今天。'],['seed_pendant','Seed Pendant','种子玻璃坠','玻璃里封着一粒仍能发芽的种子。'],['ranger_collar','Ranger Collar','巡林软革领圈','没有锁孔，只有可以自行解开的搭扣。'],['chain_mantle','Chain Mantle','月色链肩饰','细链分散重量，戴上时不会勒住呼吸。'],['aurora_torque','Aurora Torque','极光开口颈环','两端并不相接，设计者认为任何环都该留一道出口。']],
 body:[['sailor_blouse','Sailor Blouse','海风水手衫','宽大的领口，缝着回港航线的浅蓝织纹。'],['indigo_kimono','Indigo Wrap','靛蓝交领衣','两片布交叠，长大后仍能调整衣襟。'],['ranger_poncho','Ranger Poncho','巡林披衫','下摆剪成叶片般的层次，方便尾巴伸出。'],['mechanic_overalls','Mechanic Overalls','维修工背带裤','口袋里没有工具，只有 Jack 留下的布尺。'],['quilted_coat','Quilted Coat','绗缝远行大衣','拼缝记着不同聚落的布料，袖口留了生长余量。'],['prism_cuirass','Prism Cuirass','晶片礼装','不是战斗装甲。每片晶体都用柔软的丝带固定。']],
 back:[['trail_bedroll','Trail Bedroll','旅人卷毯','一床认真卷好的毯子，为没有墙的夜晚准备。'],['lantern_carrier','Lantern Carrier','萤灯背架','遮光罩把光投向前方，不刺它的眼睛。'],['dragonfly_sails','Dragonfly Sails','蜻蜓薄翼','两对薄帆取代沉重的金属翼，风过时会颤动。'],['harbor_sail','Harbor Sail','归港小帆','用废船的帆布补成，印着一条仍有人走的航线。'],['fern_planter','Fern Planter','苔庭背篮','篮里有一小株蕨，浇水的时间由它自己记着。'],['orbital_astrolabe','Orbital Astrolabe','星环背仪','转动的不是命运，只是观测夜空的一组铜环。']],
 tail:[['silk_tassel','Silk Tassel','朱砂丝穗','细线比尾端更轻，在转身时留下柔和的弧。'],['watch_tailring','Watch Tail Ring','旧表尾环','停在六点的表盘，主人说那是大家回家的时候。'],['fern_tailpin','Fern Tail Pin','蕨叶尾扣','扣子顺着尾巴的弯曲打开，不会夹住鳞片。'],['signal_tailflag','Signal Tail Flag','航标尾旗','一面很小的旗，只有同伴能认出它的方向。'],['tidal_finbrace','Tidal Fin Brace','潮汐尾鳍饰','薄片绕开鱼鳍，给游动留出了空间。'],['comet_tailchain','Comet Tail Chain','彗尾银链','星形坠饰没有尖角，像落在尾梢的一段夜空。']],
 charm:[['mail_envelope','Letter Charm','未寄出的信','信封里没有收件地址，只有一句“等你回来”。'],['porcelain_fox','Porcelain Fox','瓷狐挂坠','修复的裂缝用了金漆，没有假装它从未碎过。'],['seed_hourglass','Seed Hourglass','种砂漏','漏下的不是沙，而是经过烘干的微小种壳。'],['harbor_anchor','Harbor Anchor','归港锚章','锚尖被磨钝，背面写着一个已经消失的港名。'],['music_capsule','Music Capsule','八音胶囊','发条只够转完一小段摇篮曲。'],['tiny_observatory','Tiny Observatory','微型星台','小窗能旋开，里面是一片手绘的夜空。']],
utility:[["map_case", "Survey Map Case", "勘测地图筒", "密封皮筒里留下了手绘路线，也留出下一条路的位置。"], ["tea_flask", "Travel Tea Flask", "旅途茶壶", "小壶的把手裹了布，不烫手，壶盖仍有旧家里的花纹。"], ["field_camera", "Field Camera", "野外折叠相机", "折叠皮腔修过三次，照片里的废土却从来没有重复。"], ["glass_lantern", "Glass Lantern", "磨砂提灯", "灯罩把刺眼的光揉散，照亮脚下而不是逼问眼睛。"], ["survey_sextant", "Survey Sextant", "航路六分仪", "不再寻找旧海岸，而是测量天边尚未抵达的地方。"], ["letter_radio", "Letter Radio", "信笺收音机", "黄铜线圈接收陌生声音，侧面留着可以写回信的纸。"]],
weapon:[["reed_bow", "Reed Bow", "芦苇长弓", "弓弦已经卸下，木身记着河边的一段安静生活。"], ["carved_saber", "Carved Saber", "木雕佩刀", "刀刃是圆滑的木头，刀鞘刻着送礼者的家乡。"], ["harbor_dagger", "Harbor Dagger", "港口礼仪匕首", "封住刃口的护套不能拆掉，留下的只是纪念。"], ["brass_flare", "Brass Flare Pistol", "黄铜信号枪", "无法发射的陈列品，仍保留呼唤同伴的形状。"], ["tide_trident", "Tide Trident", "潮纹仪式叉", "三道圆钝的叉尖来自废船栏杆，只作仪式装饰。"], ["star_rapier", "Star Rapier", "星枝细剑", "水晶枝条包在软鞘里，透光时像一条没有伤口的星线。"]],
effect:[["paper_swirl", "Paper Swirl", "信纸轻旋", "折好的纸页随呼吸微动，写着未曾寄出的问候。"], ["dew_motes", "Dew Motes", "露珠微光", "细小水光沿脚边流动，像清晨温室里的露水。"], ["fern_drift", "Fern Drift", "蕨叶飘落", "叶片缓慢转落，没有一片挡住它看向外面的视线。"], ["compass_orbit", "Compass Orbit", "方位环轨", "一圈浅淡的方位刻度，不为它指定唯一方向。"], ["moon_ribbons", "Moon Ribbons", "月光丝带", "淡紫的细线在身后舒展，不束缚任何一个动作。"], ["constellation_halo", "Constellation Halo", "星座回声", "星点连接又分开，每次停驻都会留下不同的天空。"]]
 }};
for(const [slot,rows]of Object.entries(Abyss.AtelierData.rows))rows.forEach(([id,name,zh,description],design)=>{
 const rarity=['common','common','uncommon','rare','epic','legendary'][design],place={head:'city',face:'factory',neck:'forest',body:'city',back:'ruins',tail:'sewer',charm:'ruins',utility:'factory',weapon:'ruins',effect:'forest'}[slot];
 const unlock=design<3?{type:'shop',price:28+design*18,hint:'衣橱 · 补给商店'}:design===3?{type:'explore',place,visits:6,hint:'累计探索相关地点 6 次'}:{type:'milestone',rules:{day:{min:design===4?16:32},'history.care':{min:design===4?15:40}},hint:design===4?'第 16 天后，累计照护 15 次':'第 32 天后，累计照护 40 次'};
 Abyss.Data.accessories.push({id:'atelier_'+id,name,zh,description,rarity,slot,unlock,alternatives:[],lore:description,type:design===5?'mysterious':'soft',secret:false,collectionExpansion:true,visual:{layer:'accessory-'+slot,renderer:'atelier',design,palette:design,asset:null,optical:slot==='face'&&[0,1,2,3,4].includes(design)}});
});

// Names and lore are translated through the same local catalog as existing items.
Abyss.AtelierEnglish={};
for(const rows of Object.values(Abyss.AtelierData.rows))for(const row of rows)Abyss.AtelierEnglish[row[2]]=row[1];
Abyss.I18n.register(Abyss.AtelierEnglish);

{ const t=(zh,en)=>(Abyss.AtelierEnglish[zh]=en,zh);
t("斜戴的帽檐和铜制别针，来自为船只重画名字的画师。","A tilted brim and copper pin, kept by a painter who renamed ships.");
t("救援队留下的羊绒护耳，把寒风挡在玻璃外。","A rescue team left these wool ear flaps to keep the cold outside the glass.");
t("Glassfield 的裁缝把嫩叶轮廓缝成不遮角的帽顶。","A Glassfield tailor stitched fern leaves into a hood that leaves room for horns.");
t("一条能挡沙的长布，曾随商队走过三座废城。","A long strip of cloth that crossed three ruined cities with a caravan.");
t("宽檐内绣着旧时代的星图，缺了一颗星。","An old star chart is stitched inside the brim. One star is missing.");
t("把折断的银枝重新焊好的人，坚持说它不是王冠。","The maker welded broken silver branches together and insists it is not a crown.");
t("透明镜片来自坠落飞行器的观察窗，仍能看清彼此。","Clear lenses salvaged from an aircraft window still let you see each other.");
t("旧书店老板把夸张的尖角磨圆，避免碰伤眼眶。","A bookseller rounded the dramatic corners so they would not hurt the eyes.");
t("细链末端留着图书馆的编号，镜片没有度数。","A library number remains on the chain. The lens has no prescription.");
t("褪色邀请函藏在衬里，眼孔始终留得很宽。","A faded invitation hides in the lining. The eye holes are deliberately wide.");
t("蓝灰色镜片不遮住瞳孔，皮带经过柔软包边。","Blue-grey lenses leave the pupils visible, with a soft-edged strap.");
t("极薄的晶片像一场尚未落下的雨，随视线轻响。","Crystal slivers hang like rain that has not yet fallen, whispering with each glance.");
t("海员拆开自己的旧围巾，给它留了一段暖和的长度。","A sailor unstitched an old scarf and kept a warm length for this new wearer.");
t("没有仪式需要它出席，这条领结只为今天。","No ceremony demands this bow tie. It is simply for today.");
t("玻璃里封着一粒仍能发芽的种子。","A seed that could still sprout is sealed inside the glass.");
t("没有锁孔，只有可以自行解开的搭扣。","There is no keyhole, only a clasp the wearer can undo.");
t("细链分散重量，戴上时不会勒住呼吸。","Fine chains distribute their weight without tightening around a breath.");
t("两端并不相接，设计者认为任何环都该留一道出口。","The ends never meet. Its maker believed every ring should leave an exit.");
t("宽大的领口，缝着回港航线的浅蓝织纹。","A broad collar woven with the pale blue lines of a homeward route.");
t("两片布交叠，长大后仍能调整衣襟。","Two overlapping panels leave room to adjust as the wearer grows.");
t("下摆剪成叶片般的层次，方便尾巴伸出。","Leaf-shaped hems leave space for a tail to move.");
t("口袋里没有工具，只有 Jack 留下的布尺。","There are no tools in the pocket, only the measuring tape Jack left there.");
t("拼缝记着不同聚落的布料，袖口留了生长余量。","Patchwork seams remember different settlements, with room to grow at the cuffs.");
t("不是战斗装甲。每片晶体都用柔软的丝带固定。","Not combat armor. Each crystal is attached with a soft ribbon.");
t("一床认真卷好的毯子，为没有墙的夜晚准备。","A carefully rolled blanket for nights with no walls.");
t("遮光罩把光投向前方，不刺它的眼睛。","A shade directs the light forward instead of into the eyes.");
t("两对薄帆取代沉重的金属翼，风过时会颤动。","Four thin sails replace heavy metal wings and tremble in the wind.");
t("用废船的帆布补成，印着一条仍有人走的航线。","Patched from an old sail, bearing a route that people still travel.");
t("篮里有一小株蕨，浇水的时间由它自己记着。","A small fern lives in this basket. The wearer remembers when to water it.");
t("转动的不是命运，只是观测夜空的一组铜环。","These brass rings track the sky, not destiny.");
t("细线比尾端更轻，在转身时留下柔和的弧。","Fine threads lighter than the tail tip trace a soft arc when it turns.");
t("停在六点的表盘，主人说那是大家回家的时候。","The watch stopped at six, the hour its owner said everyone came home.");
t("扣子顺着尾巴的弯曲打开，不会夹住鳞片。","The clasp opens along the curve of the tail without pinching scales.");
t("一面很小的旗，只有同伴能认出它的方向。","A tiny flag whose direction only a companion would recognize.");
t("薄片绕开鱼鳍，给游动留出了空间。","Thin plates leave the fins free to swim.");
t("星形坠饰没有尖角，像落在尾梢的一段夜空。","Rounded star charms resemble a fragment of night resting on the tail.");
t("信封里没有收件地址，只有一句“等你回来”。","There is no address inside, only a line asking someone to come back.");
t("修复的裂缝用了金漆，没有假装它从未碎过。","Gold paint repairs the cracks without pretending it was never broken.");
t("漏下的不是沙，而是经过烘干的微小种壳。","Tiny dried seed husks trickle through instead of sand.");
t("锚尖被磨钝，背面写着一个已经消失的港名。","The anchor tips are blunt. A vanished harbor is named on the reverse.");
t("发条只够转完一小段摇篮曲。","The spring lasts for just one short lullaby.");
t("小窗能旋开，里面是一片手绘的夜空。","A small window opens onto a hand-painted night sky.");
t("密封皮筒里留下了手绘路线，也留出下一条路的位置。","A sealed leather tube holds hand-drawn routes and space for the next one.");
t("小壶的把手裹了布，不烫手，壶盖仍有旧家里的花纹。","A cloth-wrapped handle stays cool, and the lid keeps a pattern from an old home.");
t("折叠皮腔修过三次，照片里的废土却从来没有重复。","The folding bellows were repaired three times. No two wasteland photos are alike.");
t("灯罩把刺眼的光揉散，照亮脚下而不是逼问眼睛。","Frosted glass softens the light to illuminate the ground instead of interrogating eyes.");
t("不再寻找旧海岸，而是测量天边尚未抵达的地方。","It no longer seeks the old coast, but measures places still beyond the horizon.");
t("黄铜线圈接收陌生声音，侧面留着可以写回信的纸。","Brass coils catch unfamiliar voices. A paper panel leaves space for a reply.");
t("弓弦已经卸下，木身记着河边的一段安静生活。","The string is removed. The wood remembers quiet days beside a river.");
t("刀刃是圆滑的木头，刀鞘刻着送礼者的家乡。","A rounded wooden blade and a scabbard carved with the giver's hometown.");
t("封住刃口的护套不能拆掉，留下的只是纪念。","The sealed blade cover cannot be removed. Only the keepsake remains.");
t("无法发射的陈列品，仍保留呼唤同伴的形状。","An inert display piece shaped to call companions back.");
t("三道圆钝的叉尖来自废船栏杆，只作仪式装饰。","Three rounded prongs from an old ship railing serve as ceremonial decoration.");
t("水晶枝条包在软鞘里，透光时像一条没有伤口的星线。","A crystal branch in a soft sheath catches light like a star without a wound.");
t("折好的纸页随呼吸微动，写着未曾寄出的问候。","Folded paper moves with each breath, bearing greetings never sent.");
t("细小水光沿脚边流动，像清晨温室里的露水。","Tiny reflections drift near the feet like greenhouse dew at dawn.");
t("叶片缓慢转落，没有一片挡住它看向外面的视线。","Leaves descend slowly, leaving the view toward the outside unobstructed.");
t("一圈浅淡的方位刻度，不为它指定唯一方向。","A faint ring of bearings refuses to prescribe one direction.");
t("淡紫的细线在身后舒展，不束缚任何一个动作。","Pale violet threads stretch behind without binding a movement.");
t("星点连接又分开，每次停驻都会留下不同的天空。","Stars connect and drift apart, leaving a different sky at every pause.");
t("衣橱 · 补给商店","Wardrobe \u00b7 Supply shop");
t("累计探索相关地点 6 次","Explore the associated location six times");
t("第 16 天后，累计照护 15 次","After day 16, provide care 15 times");
t("第 32 天后，累计照护 40 次","After day 32, provide care 40 times");
t("远行裁缝工坊","Wayfarer Atelier");
Abyss.I18n.register(Abyss.AtelierEnglish); }
