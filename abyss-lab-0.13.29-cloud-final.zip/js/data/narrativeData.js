'use strict';
Abyss.NarrativeData=(()=>{
const milestones=['first_touch','first_word','player_name_used','voluntary_affection','first_argument','first_refusal','first_apology','personal_question','asks_outside','asks_leave','door_open'];
const words=[['food','食物'],['me','我'],['you','你'],['outside','外面'],['home','家'],['friend','朋友'],['hurt','疼'],['no','不'],['yes','好'],['stay','留下'],['leave','离开'],['why','为什么'],['fear','害怕'],['name','名字'],['player_name','研究员的名字']].map(([id,name])=>({id,name}));
const choice=(id,label,effects={},extra={})=>({id,label,effects,...extra});
const quiet=[choice('stay','安静地坐一会',{mood:2},{profile:{caring:1}}),choice('silence','……',{}, {flag:'shared_silence'}),choice('leave','暂时离开')];
const nodes=[];
function add(id,group,text,requirements={},extra={}){nodes.push({id,group,speaker:'narrator',text,requirements,priority:10,cooldown:3,choices:quiet.map(c=>({...c})),...extra});}
const mornings=[
'它还蜷在平台上。一只爪子却在你开灯时轻轻动了动。','它把额头贴在玻璃上，留下一个比昨天更高的印子。','它检查着喂食口，随后把注意力转向你的脚步。','研究帽滑到它的眼前。它慢慢推开帽沿，并没有摘下帽子。','它将一小块昨天的食物留在角落，像在确认今天也会有晚餐。','新器官在呼吸中张开。它低头观察，等待你先作示范。','它盯着封闭走廊。灯灭后，那里的反光仍停留了一瞬。','它沿平台边缘走完一圈，在你的记录本正对面停下。','它模仿你按开关的动作，对着一块没有按钮的玻璃试了两次。','培养液的光落在它身上。它抬起掌心，像想把光接住。','它将尾尖搭在身份牌上，直到听见你的呼唤才松开。','你没有立即开灯。黑暗中的小轮廓先找到了你的位置。','它把毯子推向喂食口，随后看看毯子，又看看你。','旧通风管响了一下。它的眼睛跟着声音移动，没有发出警报。','它背对着监控镜头，却朝着你坐下来的位置侧过身体。','今天的玻璃有些雾气。它在上面擦出一小片圆形视野。','它把一颗废弃螺母来回滚动，每次都在平台边缘把它接住。','当你换了脚步节奏，它没有立刻靠近，而是先辨认了片刻。','它把爪子放在自己的旧蜕壳旁，两个轮廓已经不再一样。','它在门口等着。你不知道它等的是食物，还是你。'];
const nights=[
'设施灯逐层变暗。它把身子压低，却仍留出一只眼睛看你。','你收起记录本时，它的爪子在玻璃上轻轻拖了一下。','疲惫让新器官不再发光。它在你身边的那一侧蜷好。','走廊传来旧设备的自检声。它数着节拍，直到节拍错了一次。','它将今天收到的小物件压在身体下面，才闭上眼睛。','它已经睡着，但你的椅子一响，尾尖便动了一下。','平台上只剩很淡的光。它把脸埋进自己投下的影子。','它的喉间发出一个重复的声音，醒来后却不肯再重复。','你停在出口时，它忽然伸出手。随后又慢慢收了回去。','它把身上的身份牌翻到背面，像不想在梦里继续做一个编号。','它在睡前绕开了实验灯，只选择你平时坐着的地方。','玻璃外有细小的水声。它贴近声音，也贴近你的手。','它的身体已比最初大了很多，睡觉的姿势却没有变。','它在安静中练习一个字，声音小得几乎被风机吞掉。','它先看了你放药的抽屉，再看向已经熄灭的手术灯。','它守着一块从外面带回的石头，眼睛随地面震动开合。','最后一班广播已经停止。它仍把头偏向那台收音机。','你没有说晚安。它也没有动，仿佛在给沉默留位置。','灯光熄灭前，它把研究帽折进毯子里，露出自己的眼睛。','它安静地看着你。今天结束了，但关系没有结束。'];
mornings.forEach((text,i)=>add('morning_'+i,'morning',text,{}, {priority:5,cooldown:5}));nights.forEach((text,i)=>add('night_'+i,'night',text,{}, {priority:5,cooldown:5}));
const relations=[
['touch_trust','它没有躲开你的手。掌心与玻璃之间只隔着一道温差。',{'stats.loyalty':{min:65},resentment:{max:18}},'first_touch'],
['touch_suspicion','它盯着你的指尖，身体却往后退。你以前拿针管时，也是这样伸手的。',{resentment:{min:30}},'first_refusal'],
['touch_distance','它在你的手碰到玻璃前退开，随后停下来，等你决定还要不要追过去。',{'stats.loyalty':{max:29}},'first_refusal'],
['voluntary','你没有发出指令。它自己走过来，将额头靠在你掌心对应的位置。',{'stats.loyalty':{min:80},resentment:{max:12},'history.care':{min:8}},'voluntary_affection'],
['argument','它把实验申请推回喂食口。这一次，它希望拒绝也能被你记录。',{resentment:{min:20},'history.experiment':{min:5}},'first_argument'],
['apology','你把约束工具收起。它没有立即原谅你，只是不再盯着工具。',{'history.punish':{min:1}},'first_apology'],
['personal','它先指向你的记录本，随后指向你。那些纸上，为什么只有它的身体？',{'narrative.languageStage':{min:4}},'personal_question'],
['outside','它把从外面带回的物件挪到门口，再看看门上的封闭标识。',{'history.explore':{min:3}},'asks_outside'],
['leave_question','它在门口停了很久。这不是一次逃跑，它在等你回应一个问题。',{'narrative.languageStage':{min:4},'personality.independent':{min:20}},'asks_leave'],
['name_call','它看向你，不再看自己的身份牌。那个声音试着对应一个人。',{'narrative.languageStage':{min:3},'narrative.hasPlayerName':{min:1}},'player_name_used'],
['saved_life','它主动把曾经受伤的爪子放在检查灯下。它认得你拿药时的动作。',{memory:['saved_life']}],
['starved','食物已经放下。它仍先数了一遍，像在给不确定的明天留一份。',{memory:['starved']}],
['favorite','熟悉的香气到了玻璃边。它先闻了闻你的手，再慢慢坐下。',{memory:['favorite_food']}],
['escape_return','它望着通风口，又望着你。返回并不意味着那条路从不存在。',{memory:['escaped']}],
['first_hat','它用爪子托住最初那件饰品，像在托住自己还很小的时候。',{memory:['first_accessory']}],
['promise','你离开得比昨天久。它仍在原来等候的位置，玻璃上的手印已经干了。',{flag:['promise_return'],day:{min:8}}],
['touch_question','它先碰了一下玻璃，再等待你的掌心。你第一次意识到它也会询问。',{'stats.loyalty':{min:70},'personality.calm':{min:10}}],
['quiet_friend','你们没有做实验，也没有训练。它把这段安静放进了今天。',{'history.care':{min:5}}],
['stolen_snack','它把一份点心藏到身后。没有被训斥时，它反而迟疑起来。',{'personality.mischievous':{min:15}}],
['curious_hand','它翻过自己的爪子，又隔着玻璃观察你的指纹。相似，并不意味着相同。',{'personality.curious':{min:18}}],
['timid_noise','设备的提示音一响，它就缩起身体。等你降低音量后，它才重新看过来。',{'personality.timid':{min:15}}],
['old_resentment','它接受了你的食物，却仍避开你拿工具的那只手。两件事可以同时发生。',{resentment:{min:25},'stats.loyalty':{min:55}}],
['independent','它没有照着你的示范做，自己找到了更慢、也更稳妥的办法。',{'personality.independent':{min:15}}],
['new_body_old_habit','器官已经变了。它仍习惯把你给的物件放在左边的角落。',{'progress.evolution.stage':{min:2}}],
['shared_worry','你坐得比平时更久。它没有催促，只把身体朝你转过来。',{'stats.loyalty':{min:75},'narrative.languageStage':{min:4}}]
];
relations.forEach(([id,text,requirements,milestone])=>add('relation_'+id,'relationship',text,requirements,{once:!!milestone,priority:milestone?50:20,milestone,choices:[choice('respect','等它自己靠近',{loyalty:3},{profile:{caring:2,cautious:1},memory:milestone}),choice('observe','记录它的选择',{}, {profile:{scientific:2}}),choice('silence','……',{}, {flag:'shared_silence'})]}));
const mutations=[['horns','它不再直接抬头，新生的角先试探玻璃的距离。'],['wings','翅膜遮住了它的脸。它展开，又收起，像在练习一道新的边界。'],['tentacles','触手比爪子先碰到食物。它迟疑片刻，才接受这是身体的一部分。'],['shell','它想靠在平台边，却听到甲壳碰撞的声音。熟悉的动作需要重新学习。'],['tail','尾尖对你的脚步作出反应，它自己却还没回头。'],['glow','新的光在紧张时亮起。它试着用爪子遮住自己。'],['effects_electric','一次轻微放电打断了进食。它看着自己的手，等你解释。'],['regen','旧伤不再明显，它仍避开曾经痛过的位置。']];
mutations.forEach(([id,text])=>add('mutation_'+id,'mutation',text,{mutation:[id]},{once:true,priority:35}));
for(const [i,route]of ['guardian','predator','intellect','abyssal','synthetic','spore','anomaly','companion'].entries())add('route_body_'+route,'mutation',['它以新甲片护住曾经柔软的腹部。','它从空气里辨出你与设备不同的气味。','它观察自己的新视器，随后观察观察它的镜头。','它听见水管里更远的震动，像房间忽然变大。','它的神经线缆亮起，旧设备也亮了一盏灯。','细小孢子在它身边聚拢，随后随呼吸散开。','它的影子没有完全跟上动作。它等待影子回到脚下。','它的新器官随你的脚步亮起，不随机器启动。'][i],{route,stage:2},{once:true,priority:35});
for(let i=1;i<=4;i++)add('body_stage_'+i,'mutation','生理转变后，它再一次尝试以前习惯的动作。身体需要学习，记忆却先找到了方向。',{stage:i},{once:true,priority:35});
const returns=[['sewers','它身上的水味还没散。它将管道里发现的东西放到干燥的角落。'],['factory','它模仿机械臂的停顿，每次停顿后都确认自己的爪子仍能活动。'],['forest','它把林中的气味带进培养舱，第一次觉得循环空气也有自己的味道。'],['city','它听了一夜人类的脚步，回来后把你的脚步与那些声音分开。'],['ruins','旧培养舱的尺寸让它不安。它回到自己的平台上，量了量两者的距离。'],['wing','它没有把废弃翼里那张照片放进普通回收包。'],['deep','它的呼吸仍跟着深层管线的节拍，直到看见熟悉的灯。'],['black_floor','封存层的静默没有完全留在下面。它回来后等了很久才闭眼。']];
returns.forEach(([location,text])=>add('return_'+location,'return',text,{lastLocation:location},{cooldown:4,priority:25}));
for(const [i,route]of ['guardian','predator','intellect','abyssal','synthetic','spore','anomaly'].entries())add('return_route_'+route,'return',['它先确认你是否受伤，才放下回收物资。','它反复闻着门边，确认没有什么跟随你们回来。','它把两张相互矛盾的记录分开放好，没有急于选一张相信。','它在平台上复现水下的波纹，像给你画一条路。','它带回的零件与舱内设备交换了短暂的灯光。','它让孢子停在样本旁，不让它们扩散进喂食区。','门已经关上，它却还在等待另一侧的影子。'][i],{route},{cooldown:5,priority:30});
const research=[['vital_scan','检查灯比昨天更柔和。它终于允许光留在自己的眼睛附近。'],['sample_culture','培养皿里的组织不是它本身。它在两个容器之间反复看了看。'],['medicine','你把药与约束工具分开放置。它认得这个改变。'],['gene_scan','屏幕替组织起了名字。它对自己的身体仍有别的感受。'],['gene_library','档案列出了可能性，却没有写下它会喜欢哪一种。'],['stabilizer','新的设备让疼痛慢慢退去，它先注意到你的手不再抖。'],['continuity','旧记录说组织可以替换。它仍按原来的节奏碰玻璃。'],['communication','设备放大了一个很小的声音。它第一次听见自己的回声。'],['empathy','你们同时注意到一阵紧张，但没有急着把它写成读数。'],['memory_read','扫描仪请求进入记忆。它先看你，像在问这次是否可以拒绝。'],['neural_resonance','两个波形重叠，又分开。相似不是同一个人的证明。'],['containment','新锁的声音比旧锁轻。它仍等待你解释门为什么需要锁。'],['terminal_restore','修复后的终端亮起一个被删除过的账户名。'],['deep_map','地图展开了更深的房间。它用爪子挡住最暗的那一格。'],['black_protocol','权限灯变黑。它没看权限灯，只看着你。']];
research.forEach(([technology,text])=>add('research_'+technology,'research',text,{technology:[technology]},{once:true,priority:25}));
const chapters=[
['b07','序章 · B-07',{day:{min:1}},'墙上的指令只有四行：观察。喂食。记录。不要开启培养舱。编号 B-07 的贴纸比下面的旧铆钉新得多。','它将一只爪子压在玻璃上。设备自动点亮了一盏已经没有研究员操作的灯。'],
['irregularity','第一章 · 异常',{research:4,mutations:1,explore:2},'一张旧纸页写着「B-07 观察记录」，日期却是十七年前。编号可以被重复使用，日期可以被抄错；眼下没有证据排除任何一种解释。','它看向自己的铭牌，又看向那张旧纸。你准备让它知道多少？'],
['abandoned','第二章 · 废弃研究翼',{research:7,technology:['facility_power'],visit:'wing'},'废弃翼里有小型培养舱、坏掉的玩具和旧喂食器。照片上的研究员没有被涂去，舱内的生物却被反复刮伤。','它靠近照片。你不知道它是在辨认一个地方，还是一段被别人处理过的图像。'],
['bseries','第三章 · B 系列',{research:9,document:['P5_01','P5_02'],stage:2},'B-01 至 B-07 的记录并不对应七个物种。可读的部分记下不同照料方式与不同形态：「表型分歧持续扩大；行为连续性异常稳定。」','它用现在的爪子，重复了很小时等待食物的动作。记录里的分歧，与你亲手造成的改变有了联系。'],
['zero','第四章 · 零号标牌',{research:11,item:['first_specimen_tag'],stage:2},'标牌上刻着 0。三个旧表格把同一来源写成「回收」「培养」「未知」，第四个表格删去了来源字段。','旧系统对它的器官发出回应。它没有因此获得一段此前不存在的记忆。'],
['incident','第五章 · 连续性事故',{research:15,technology:['neural_resonance'],item:['broken_data_core'],stage:3},'撤离、污染、破坏、电力事件与主动停机，分别出现在不同报告里。监控只剩最后一帧：空培养舱，门从内侧开启。','它先看那道门，再看你们自己的门。记录能说明一扇门怎样打开，却不能说明谁希望它打开。'],
['continuity','第六章 · 连续性',{research:17,technology:['continuity'],stage:3},'PROJECT ABYSS 记录的是：记忆、性格、行为和身份，能否在激烈的生理改变后继续存在。研究员对「继续」也没有一致定义。','它的身体已和起初不同。它仍认得第一件饰品、熟悉的食物，也认得曾经让它疼痛的灯。'],
['black','第七章 · 黑级权限',{research:20,clearance:'black',technology:['black_protocol'],visit:'deep',stage:3},'BLACK 不只是权限。旧协议写着：当连续性超过阈值，终止研究、擦除记录、封闭下层。执行日志在最后一步之前中断。','黑档案、下层实验室与零号室的门锁同时收到授权。谁中断了程序、为什么中断，仍没有可靠答案。'],
['chamber','第八章 · 零号室',{research:20,clearance:'black',visit:'zero_chamber',stage:4},'巨大的旧培养舱是空的。抓痕、残留组织、断裂监控与约束器具留在原处。唯一还亮着的终端扫描 B-07：CONTINUITY MATCH DETECTED。','匹配不等于身份。它可能来自零号的后代、重构组织、重复材料，也可能只与旧行为模型相似，或者系统错了。终端等待你们一起决定。']
].map(([id,title,requirements,text,response],index)=>({id,title,requirements,text,response,index}));
chapters.forEach(c=>{add('project_'+c.id,'project',c.text,c.requirements,{once:true,priority:100,speaker:'narrator',nextNode:'project_'+c.id+'_response',choices:[]});add('project_'+c.id+'_response','project_response',c.response,{}, {once:true,priority:100,chapter:c.id,speaker:'narrator',choices:c.id==='chamber'?[
 choice('restore','恢复 Project Abyss',{}, {decision:'restore',requirements:{technology:['continuity','terminal_restore']}}),choice('destroy','关闭并销毁核心',{}, {decision:'destroy'}),choice('copy','复制档案',{}, {decision:'copy',requirements:{technology:['echo_archive']}}),choice('creature','让它访问终端',{}, {decision:'creature',requirements:{stage:3,'narrative.languageStage':{min:4}},hidden:true}),choice('seal','重新封存零号室',{}, {decision:'seal'})]:[
 choice('show','让它看完整的记录',{loyalty:2},{flag:'show_'+c.id,profile:{caring:1,curious:1}}),choice('unknown','我不知道，这些记录还不够',{}, {profile:{cautious:2}}),choice('hide','把记录暂时收起',{loyalty:-2},{flag:'hide_'+c.id,profile:{controlling:2}}),choice('silence','……') ]});});
add('zero_conversation','major','它停在旧玻璃前。你等它先回应，而不是替它认领一个过去。',{},{once:true,priority:110,variants:[{requirements:{'narrative.languageStage':{max:2}},text:'它碰了碰旧玻璃，又回头找你的身影。低低的声音没有给出一个身份。'},{requirements:{resentment:{min:35},'narrative.languageStage':{min:4}},text:'“他们改变身体，记录疼痛，再换一个编号。你觉得自己的实验，哪里与他们不同？”'},{requirements:{'stats.loyalty':{min:75},'narrative.languageStage':{min:4}},text:'“如果那曾经是我，我也不记得它。我记得的是你。那些经历，不能被这个终端替换。”'},{requirements:{route:'anomaly'},text:'它将爪子贴到旧玻璃。影子留在原地，身体却退了半步；它等待两者重新重叠。'}],choices:[choice('listen','先听它说完',{loyalty:3}),choice('question','我们还需要更多证据'),choice('silence','……')],nextNode:'project_chamber_response'});
const secrets=[['omega','Ω · 第一段记忆',{memory:['first_accessory','saved_life'],stage:3,'narrative.languageStage':{min:4},flag:['shared_silence']},'它没有复述扫描仪的编号。它描述了那件初次收到的饰品，描述的角度低得只有那时的它能看见。连续性不需要一张旧出生证明。'],['null','NULL · 无记录',{route:'anomaly',technology:['echo_archive','impossible_geometry']},'空白档案不是没有内容。你们调整观察角度后，一次删除留下了两次不相等的回声。回声说明被删去过什么，却不是被删去者的自述。'],['b00','B-00 · 零之前',{research:20,stage:4,document:['P5_10','P5_11'],item:['p5_blank_tag'],flag:['secret_omega','secret_null']},'一张比 0 更早的空白标牌，不属于编号系统。项目起初记录的是一种现象；后来的身份编号，也许是研究者为了让现象变得可以管理。']];
secrets.forEach(([id,title,requirements,text])=>add('secret_'+id,'secret',text,requirements,{once:true,priority:95,title,secret:id,choices:[choice('keep','保留这份不完整的见证',{}, {flag:'secret_'+id}),choice('silence','……',{}, {flag:'secret_'+id})]}));
const interactions={
 feed:{text:'喂食口打开。它先看看食物，再看看你的手。',choices:[choice('standard','给它标准配方',{}, {action:{type:'feed',payload:'ration'},profile:{scientific:1}}),choice('favorite','给它熟悉的月露果',{mood:2},{action:{type:'feed',payload:'fruit'},profile:{caring:2}}),choice('sit','坐在旁边，陪它吃',{loyalty:2},{action:{type:'feed',payload:'ration'},profile:{caring:2},flag:'shared_meal'}),choice('hand','让它自己决定是否接近你的手',{loyalty:3},{action:{type:'feed',payload:'ration'},requirements:{'stats.loyalty':{min:45},resentment:{max:40}},profile:{caring:2},milestone:'first_touch'}),choice('leave_food','放下食物，给它独处的空间',{}, {action:{type:'feed',payload:'ration'},profile:{cautious:1}})]},
 pet:{text:'你把手停在玻璃外，没有立即触碰。它注意到了。',variants:[{requirements:{resentment:{min:30}},text:'它的目光停在你拿过约束工具的那只手上。它记得。'},{requirements:{'stats.loyalty':{max:29}},text:'它后退一步，在你的手到达之前拉开距离。'},{requirements:{'narrative.languageStage':{min:4},'stats.loyalty':{min:75}},text:'“你担心的时候，总会先伸手。”'},{requirements:{'stats.loyalty':{min:65}},text:'它慢慢靠近，给你的手留出了位置。'}],choices:[choice('wait','询问它，再等它靠近',{}, {action:{type:'companion'},milestone:'first_touch',profile:{caring:2}}),choice('play','把光点放到它能追到的位置',{mood:2},{action:{type:'companion'},profile:{caring:1,curious:1}}),choice('observe','记录它的身体语言',{}, {action:{type:'companion'},profile:{scientific:2}}),choice('silence','……') ]},
 train:{text:'你在平台上摆好练习物。它先寻找昨天用过的位置。',choices:[choice('mind','通过图形与声音练习认知',{}, {action:{type:'train',payload:'intelligence'},profile:{scientific:1,caring:1}}),choice('strength','用可移动的积木训练力量',{}, {action:{type:'train',payload:'strength'},profile:{scientific:2}}),choice('agility','跟随缓慢变化的光点',{}, {action:{type:'train',payload:'agility'},profile:{cautious:1}}),choice('respect','今天不要求表现',{}, {profile:{caring:1}})]},
 examine:{text:'检查灯亮起。你把药放在它看得见的地方。',choices:[choice('treat','解释动作，再进行治疗',{}, {action:{type:'heal'},profile:{caring:2},flag:'explained_care'}),choice('observe','只观察，不侵入检查',{}, {action:{type:'companion'},profile:{cautious:2}}),choice('silence','暂时收起检查灯')]},
 experiment:{text:'实验申请等待确认。它看着你的工具箱，而不是基因读数。',choices:[choice('gentle','只进行温和观察',{}, {action:{type:'experiment',payload:'gentle'},profile:{scientific:2,cautious:1}}),choice('explain','先陪伴，今天暂缓实验',{}, {action:{type:'companion'},profile:{caring:2}}),choice('force','开展高强度实验：可能受伤并留下怨恨',{}, {action:{type:'experiment',payload:'unstable'},profile:{controlling:2,ruthless:2}}),choice('silence','……')]},
 night:{text:'今天的灯即将熄灭。它听见你合上记录本。',choices:[choice('promise','我明天会回来',{}, {action:{type:'rest'},flag:'promise_return',profile:{caring:1}}),choice('quiet','安静守候一会，再结束今天',{}, {action:{type:'rest'},flag:'shared_silence'}),choice('leave','收好记录，结束今天',{}, {action:{type:'rest'},profile:{scientific:1}}),choice('stay','还不离开')]}
};
for(const [id,node]of Object.entries(interactions))add('interaction_'+id,'interaction',node.text,{}, {...node,priority:200,cooldown:0});
add('first_word','milestone','它停顿了一下。一直练习的声音终于对应了一个词：{firstWord}。',{},{once:true,priority:120,choices:[choice('answer','认真回应它',{loyalty:4},{milestone:'first_word'}),choice('record','记下这一天与这个词',{}, {profile:{scientific:1},milestone:'first_word'}),choice('silence','给这个声音留一点安静',{}, {milestone:'first_word'})]});
add('door','major','锁扣收起，玻璃边缘第一次出现没有封闭的缝隙。你没有叫它出来。它需要自己决定距离。',{},{once:true,priority:110,variants:[{requirements:{resentment:{min:30}},text:'门开了。它仍不愿踏出，旧日工具的气味停在门外。'},{requirements:{'personality.independent':{min:30},'stats.loyalty':{max:49}},text:'门开了。它先走向走廊，脚步没有等待命令。'},{requirements:{'stats.loyalty':{min:75},resentment:{max:15}},text:'门开了。它犹豫片刻，然后朝你走来，碰了碰你的手。'}],choices:[choice('space','让它选择自己的距离',{loyalty:2},{milestone:'door_open',flag:'door_autonomy',profile:{caring:2}}),choice('boundary','一起划定安全范围',{}, {milestone:'door_open',flag:'door_boundary',profile:{cautious:2}}),choice('silence','……',{}, {milestone:'door_open',flag:'door_autonomy'})]});
const items=['旧喂食杯','损坏的纸风车','空白身份牌','被划去的合照','医疗腕带','旧约束扣','育床种子','连续性磁片','隔离门手轮','温热玻璃珠','研究员耳机','B 系列封套','撤离通行片','双重声纹带','零号室镜片'].map((name,i)=>({id:'p5_'+['feeding_cup','toy','blank_tag','photo','wristband','restraint','seed','disk','wheel','glass','headset','series','pass','tape','lens'][i],name,category:'UNKNOWN OBJECT',rarity:i>12?'ANOMALOUS':i>8?'LEGENDARY':i>4?'EPIC':'RARE',description:'从旧设施回收的私人或研究物件。它的来源需要通过对应记录辨认。',secret:true}));
const docRows=[['旧杯的订单','喂食杯使用年限早于 B-07 贴纸。采购人：林禾。备注：保留原来的触感。'],['被刮伤的照片','照片背面写着：不要让编号成为它最后留下的东西。签名被水浸模糊。'],['B 系列表型摘要','B-01 至 B-07 的处理方式不同；形态差异很大，部分等待、拒绝和记忆测试仍然相似。'],['来源表 A','零号来源：回收。此字段复制自早期外勤记录；未独立确认。'],['来源表 B','零号来源：培养。这里的培养指组织维护，不一定指个体诞生。'],['林禾的私人便笺','如果它还会认得我们，为什么每次手术后都要给它一个新号码？'],['周衡的终止建议','模型可能只是学会取悦测试者。稳定的行为并不足以证明稳定的身份。'],['沈桥的维护单','封门电源与档案电源不能同时切断。若只保留一条线路，下一位观察者应能选择。'],['撤离报告残页','人员先行撤出。污染来源待定。最后一帧显示空舱，不能确认实验体去向。'],['BLACK 协议','连续性超过阈值：终止研究；擦除记录；封闭下层。最终确认未签署。'],['双重删除痕迹','某份档案被删除两次，但两次时间戳不一致。可能是时钟误差，也可能是不同副本。'],['旧舱匹配输出','CONTINUITY MATCH DETECTED。算法比较组织反应与行为模板；该输出不是身份鉴定。']];
const documents=docRows.map(([name,text],i)=>({id:'P5_'+String(i+1).padStart(2,'0'),name,text}));
return {nodes,words,milestones,chapters,secrets,items,documents};
})();
Abyss.ExpeditionData.loot.push(...Abyss.NarrativeData.items);
Abyss.ExpeditionData.documents.push(...Abyss.NarrativeData.documents);

