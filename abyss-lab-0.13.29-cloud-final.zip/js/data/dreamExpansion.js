'use strict';
Abyss.DreamExpansion=(()=>{
 const t=Abyss.HomeData.t,D=Abyss.DreamData;
 const rows={jack:[
 ['匙孔','Keyhole','Jack 的眼睛变成匙孔。他看见自己的手从外面伸来，却看不见钥匙握在谁手里。','Jack’s eye becomes a keyhole. His hand reaches in from outside, but he cannot see who holds the key.'],
 ['空座','Empty Seat','Jasmine 的座位上放着热茶。Jack 伸手以前，茶先结冰了。钟没有因此向后走。','Hot tea sits in Jasmine’s empty seat. It freezes before Jack touches it. The clock does not turn back.'],
 ['红结','Red Knot','红线没有绑住手腕，而是绑住两扇门。拉开一扇，另一扇就会合上。Jack 试着把线松开。','Red thread joins two doors. Opening one closes the other. Jack tries loosening the knot.'],
 ['回潮','Returning Tide','海水退回地平线，把他小时候画的船留在地上。纸船上有培养舱的编号。','The sea retreats, leaving his childhood paper boat on the ground. A chamber number marks its hull.'],
 ['点名','Roll Call','警报变成点名。Jack 回答了所有编号，最后发现没有人替他回答他的名字。','The alarm becomes a roll call. Jack answers every number; nobody answers his own name.'],
 ['倒面玻璃','Reversed Glass','Jack 在玻璃里，实验体在外面拿着记录本。它先问他冷不冷，随后问他想不想出去。','Jack is inside the glass. The creature holds the report outside. It asks if he is cold, then if he wants to leave.'],
 ['洗不净的手','Unwashed Hands','水从掌心穿过去，却带不走手套的印子。Jack 不再加洗涤剂，开始看那道印子。','Water passes through his palms but cannot remove the glove marks. Jack stops adding soap and examines the marks.'],
 ['错过的公交','Missed Bus','最后一班车停在海边。Jack 看见 Jasmine 上车，没有听见她叫他，也不能确定她是否看见他。','The last bus waits by the sea. Jasmine boards. Jack cannot tell whether she sees him.'],
 ['没有铃声的电话','Silent Telephone','电话接通了。Jack 说了很久，才发现自己一直听的是自己年轻时的呼吸。','The phone connects. After talking for a long time, Jack realizes he has heard only his younger breathing.'],
 ['生日蜡烛','Birthday Candle','蜡烛写着他的年龄，火焰却照出另一张脸。Jack 没许愿，先把椅子往旁边挪了一点。','His age is written on the candle. Its flame reveals another face. Jack moves a chair aside before making a wish.'],
 ['维修签名','Repair Signature','每台机器的维修人都是 Jack。最后一台叫“门”，维修说明写着：正常关闭。','Every machine was repaired by Jack. The last is called Door. Its report reads: closes normally.'],
 ['第二双靴子','Second Pair of Boots','门口多了一双小靴子。Jack 等到天亮，靴子长大了，穿靴子的人没有出现。','Small boots wait by the door. They grow by morning; their wearer never appears.'],
 ['盐痕','Salt Mark','记录本上的盐痕逐渐变成海岸线。Jack 找到自己的位置，那里是一间没有窗的屋子。','Salt on the report becomes a coastline. Jack finds his location: a windowless room.'],
 ['另一份合同','Other Contract','合同上只有一句：你可以离开。他找遍附件，没有找到实验体能离开的那一页。','The contract says only: you may leave. Jack searches the attachments for the creature’s page.'],
 ['短了的袖口','Short Sleeve','旧外套的袖子越来越短。Jack 想起它长大时，自己仍拿旧尺子量它。','His old sleeves keep shortening. Jack remembers measuring a growing creature with the same old ruler.'],
 ['走廊椅子','Corridor Chair','椅子朝向敞开的门。Jack 坐下后，走廊继续延伸；这次没有人催他站起来。','A chair faces an open door. The corridor lengthens when Jack sits, but nobody orders him up.'],
 ['听证会','Hearing','所有人都问为什么。Jack 用安全回答，直到最后一个问题问：是谁的安全？','Everyone asks why. Jack answers with safety, until the final question asks: whose safety?'],
 ['小伤口','Small Wound','Jasmine 指着他手上的伤口，说她记得另一个位置。Jack 没有用自己的记忆纠正她。','Jasmine points to a wound but remembers it elsewhere. Jack does not correct her with his memory.'],
 ['逆着的雨','Reversed Rain','雨从他的靴子升到天空。Jack 只剩下一枚钥匙，它的齿纹像一排没有说完的话。','Rain rises from his boots. The key’s teeth resemble a row of unfinished sentences.'],
 ['餐桌号码','Numbered Table','每只碗都有编号。他先擦掉自己的编号，然后停下来，等另一位用餐者自己决定。','Each bowl has a number. He erases his own, then waits for the other diner to decide.'],
 ['封存报告','Sealed Report','报告称一切平稳，纸背却传来抓门声。Jack 翻过去，背面没有字，只有一只手掌印。','The report declares stability. Scratching sounds come from its blank reverse, beside a palm print.'],
 ['开着的抽屉','Open Drawer','Jasmine 的旧物没有被藏起来。Jack 没把梦中的位置当作现实里新的线索。','Jasmine’s belongings lie openly in a drawer. Jack does not mistake the dream’s location for evidence.'],
 ['灯下的空隙','Gap in the Light','灯能照到每个角落，只有 Jack 的影子没有出口。他把灯转向墙，给影子留出暗处。','The light reaches every corner, but his shadow has no exit. Jack turns it away, leaving darkness.'],
 ['没有结束的班次','Endless Shift','下班钟响了，门锁仍在响。Jack 将工牌摘下，声音没有停。他终于承认自己一直在等。','The shift ends but the lock keeps clicking. Removing his badge does not stop it. Jack admits he has been waiting.'],
 ['纸上的明天','Tomorrow on Paper','他把明天写进表格，另一只手在旁边画了一条没有刻度的路。两种计划都留在纸上。','He schedules tomorrow. Another hand draws an unmeasured path beside it. Both plans remain.']
 ],creature:[
 ['拆开的句子','Unassembled Sentence','词语像积木漂在空中。它先拼出“不”，剩下的词才慢慢找到位置。','Words float like blocks. It assembles “no” first; the other words find their places afterward.'],
 ['不能检索的名字','Unsearchable Name','每次检索自己的名字，终端都返回一个门牌号。它合上终端，把名字说给空房间听。','Searching its name returns a door number. It closes the terminal and speaks the name into the room.'],
 ['旧录音里的停顿','Pause in the Recording','录音说话的声音与它相同，停顿却不一样。它没有认领这段过去，只把停顿记下来。','A recording has its voice but different pauses. It does not claim that past, only notes the pauses.'],
 ['水下的灯','Underwater Light','深水中的灯一盏一盏灭掉。最后一盏在它掌心，它不知道是不是需要救的人。','Deep lights go out one by one. The last rests in its palm; it cannot tell whether someone needs saving.'],
 ['无边岸线','Endless Shore','岸线随它向前移动。它第一次可以停下，而不是游到别人指定的位置。','The shore moves with it. For once it can stop instead of reaching a place chosen by someone else.'],
 ['陌生的潮声','Unfamiliar Tide','潮声说着陌生的语言。它听懂悲伤，却没听懂那个声音在呼唤谁。','The tide speaks an unknown language. It understands sorrow, but not the name being called.'],
 ['没有人的椅子','Unoccupied Chair','椅子上留着人的温度。它等了一会儿，然后自己打开灯，并没有把等待变成全部生活。','Warmth remains on the chair. It waits, then switches on the light; waiting does not become its whole life.'],
 ['可以关上的门','Door It Can Close','门锁装在它够得到的位置。它关上门，在里面坐着，发现自由也可以是一小段独处。','The lock is within reach. It closes the door and learns freedom can include solitude.'],
 ['第二种脚步','Other Footsteps','脚步在远处响起，不像 Jack。它先去辨认，再决定是否躲起来。','Distant steps are unlike Jack’s. It identifies them before deciding whether to hide.'],
 ['错误信号','Incorrect Signal','所有信号要求同步。它留下一次不同步的呼吸，机器没有因此停机。','Every signal demands synchronization. It keeps one breath out of step; the machines do not stop.'],
 ['软的电路','Soft Circuit','电路像布一样垂下来。它把最锋利的接口包住，梦中也不想伤到走近的人。','Circuits hang like cloth. It wraps the sharpest connector, even here unwilling to hurt someone approaching.'],
 ['剩余电量','Remaining Charge','电量显示零，它仍在想问题。它怀疑计量表只测到了别人认为有用的那部分。','Charge reads zero, but thought continues. It wonders whether the meter measures only the useful parts.'],
 ['第六面墙','Sixth Wall','它数到第五面墙，Jack 数到第四面。第六面没有出现，却有人在上面敲门。','It counts five walls; Jack counts four. A sixth never appears, but someone knocks on it.'],
 ['两次影子','Twice the Shadow','影子先走出门，又回来坐下。它没有跟着走，想知道影子也会不会等待。','Its shadow leaves, then returns to sit. It waits to learn whether the shadow can wait too.'],
 ['反过来的编号','Reversed Number','编号倒着写时变成了一双眼睛。眼睛不肯说明自己是谁，也没有要求它成为谁。','The reversed number becomes eyes. They offer neither an identity nor a demand for its own.'],
 ['人类的手','Human Hand','镜中有人的手，它认得指纹却认不出主人。醒来前，它没有把那双手叫作自己。','A human hand appears in the mirror. It knows the prints, not the owner, and does not name the hand its own.'],
 ['旧公寓','Old Apartment','窗边有一杯凉水。它知道杯子放在哪里，却不知道为什么会知道。','A cold glass waits by an apartment window. It knows its place but cannot explain knowing.'],
 ['陌生人的早晨','Stranger’s Morning','闹钟响起，它伸向一个不存在的床头柜。这个动作像记忆，也可能只是梦学会的动作。','An alarm rings. It reaches for a nonexistent nightstand. The gesture might be memory, or something learned in a dream.'],
 ['不需要回答的镜子','Unquestioning Mirror','镜子没有映出身体，只有一个愿意留下的位置。它坐下来，不急着填满那个位置。','The mirror shows no body, only a place where it may stay. It sits without rushing to fill the space.']
 ],shared:[
 ['两份海图','Two Sea Maps','他们各画一张海图，只有一个小岛位置相同。Jack 没把其他不同的海岸擦掉。','Their maps share one island. Jack does not erase the different coastlines.'],
 ['低处的开关','Reachable Switch','两人都记得开关在低处，却记得灯有不同颜色。他们留下了两个版本。','Both remember a low switch, but different light colors. They keep both accounts.'],
 ['第三张椅子','Third Chair','桌边有三张椅子。他们都不认识第三位，醒后也没有替对方编一个名字。','Three chairs surround the table. Neither knows the third guest, and neither invents a name afterward.'],
 ['共同的停顿','Shared Pause','一句话在同一个地方断了。两人都记得停顿，没有人确定后半句应该是谁说。','The same sentence breaks at the same place. Neither knows who should finish it.'],
 ['交换玻璃','Exchanged Glass','Jack 在里面，它在外面。两个人都梦见先问对方需不需要帮助。','Jack is inside, the creature outside. Both dream of asking first whether the other needs help.'],
 ['相同的雨滴','Same Raindrop','一滴雨悬在他们之间。Jack 想用仪器测，它想听声音。他们没有把两种想法分出输赢。','A drop hangs between them. Jack wants to measure; it wants to listen. Neither idea has to defeat the other.'],
 ['不重叠的脚印','Separate Footprints','他们走同一条路，脚印却不重叠。路尽头的灯为两种步幅都留下位置。','They share a road without matching footprints. The light at its end has room for both strides.'],
 ['未约定的回来','Unpromised Return','两人都记得说过“回来”，却没有听清是谁答应。醒后，他们重新询问，而不是追讨。','Both remember “come back,” but not who promised. On waking they ask again instead of demanding repayment.']
 ],unknown:[
 ['无主工牌','Ownerless Badge','工牌有 Jack 的照片，没有姓名。下一次看，照片变成一扇门。','A badge shows Jack without a name. On the next glance, the photograph becomes a door.'],
 ['蓝色空房','Blue Empty Room','蓝色墙壁没有阴影，只有地板在缓慢呼吸。记录仪拒绝给房间编号。','Blue walls cast no shadows. The floor breathes slowly. The recorder refuses a room number.'],
 ['迟到的回声','Late Echo','叫喊的回声第二天才回来。醒来后，没有证据证明是谁先喊了那一句。','An echo returns a day late. Waking gives no evidence of who first called.'],
 ['无人收取的信','Unclaimed Letter','信封写着“给已经来过的人”。里面是一张空白纸，折痕却像被读过很多次。','A letter is addressed to someone who already came. Its blank sheet is worn as if read repeatedly.'],
 ['缺一页的日历','Missing Calendar Page','日历没有今天。昨天和明天都留下了手写的温度，笔迹不是同一个人。','Today is missing. Yesterday and tomorrow carry temperatures in different hands.'],
 ['相反的花','Inverse Flower','白花只在闭眼时存在。睁眼以后，手里留着一片花瓣形的空隙。','A white flower exists only with closed eyes. Opening them leaves a petal-shaped absence.'],
 ['重影的门','Double Door','门开了两次，只有一次发出声音。没有人要求你辨认哪一次才算真的。','The door opens twice and sounds once. Nobody demands that one opening be declared real.'],
 ['静止的第二针','Still Second Hand','秒针停着，另一根针却在数你的呼吸。你醒来时，没有带走那个数字。','The second hand is still; another counts breaths. You wake without bringing back the number.']
 ]};
 for(const [type,records]of Object.entries(rows))records.forEach(([zh,en,line,eng],i)=>D.dreams.push({id:'dream_exp_'+type+'_'+i,type,name:t(zh,en),text:t(line,eng),item:type==='jack'?'red_key':type==='creature'?'glass_shell':type==='shared'?'white_flower':'empty_photo',major:false,route:type==='creature'?['intellect','abyssal','companion','synthetic','anomaly','host'][Math.min(5,Math.floor(i/3))]:null}));
 // Major dreams are short navigable symbolic spaces with independent choices at each stop.
 const stages={
 dream_door:[
 ['紧急门另一侧有人说：“打开。”门上的玻璃却照着 Jack 自己。','“Open it,” says someone beyond the emergency door. The pane reflects Jack himself.',['open','试着开门','Try the door'],['ask','先问对方的名字','Ask their name first'],['wait','把手从门锁上放开','Release the lock']],
 ['门后没有人。走廊分成两边，一边有抓痕，一边有脚步。','Nobody waits behind the door. Scratches lead one way, footsteps the other.',['open','沿抓痕走','Follow the scratches'],['ask','回应远处的脚步','Answer the footsteps'],['leave','沿自己的脚印返回','Follow your own footprints back']],
 ['身后传来：“错的门。”Jack 发现自己的钥匙能放下，不必把每扇门变成任务。','“Wrong door,” says a voice behind. Jack can put down the key without turning every door into a task.',['take','记住钥匙的轮廓','Remember the key’s outline'],['leave','留下钥匙醒来','Leave the key and wake']]],
 dream_thread:[
 ['Jasmine 把红线放在桌上，没有替 Jack 系好。她的脸像一张反复折过的照片。','Jasmine leaves red thread on the table without tying it for Jack. Her face resembles a repeatedly folded photograph.',['take','拿起没有系好的线','Pick up the untied thread'],['ask','问她想留下什么','Ask what she wants to leave']],
 ['线的另一头伸进一堵墙。Jack 找不到连接点，也不能靠拉扯证明墙后有人。','The thread enters a wall. Pulling cannot prove someone is behind it.',['wait','让线松下来','Let the thread slacken'],['leave','把线留在桌上','Leave it on the table']],
 ['“不是每次握紧都能留住人。”那是她的声音，还是 Jack 终于想到的一句话？','“Holding tighter cannot always keep someone.” Is it her voice, or a sentence Jack has finally found?',['take','记下声音，不当作证词','Record the voice without treating it as testimony'],['leave','不替她补完结局','Leave her ending unfinished']]],
 dream_sea:[
 ['海岸没有尽头。纸船搁在一块干燥的玻璃上，远处有人在看天。','The shore has no end. A paper boat rests on dry glass; someone watches the sky far away.',['open','走向海岸线','Walk toward the waterline'],['ask','先问同行者愿不愿意','Ask your companion first']],
 ['他们在不同的位置听见海。Jack 没有命令另一个声音移动到他的地方。','They hear the sea from different places. Jack does not order the other voice to move beside him.',['wait','各自听一会儿','Listen separately awhile'],['take','带走一枚梦中的贝壳','Keep a dream shell']],
 ['天亮没有证明他们到过海边。Jack 把想去的地方写成愿望，而不是完成记录。','Dawn does not prove a visit. Jack writes the destination as a wish, not a completed record.',['take','记住愿望','Remember the wish'],['leave','让梦留在梦里','Leave the dream here']]],
 dream_host:[
 ['公寓镜子里有一双人类的手。门外叫着一个并未出现在档案里的名字。','Human hands appear in an apartment mirror. A name absent from the archive is called outside.',['ask','问声音属于谁','Ask whose voice this is'],['wait','观察手指如何移动','Watch the fingers move']],
 ['记忆中的窗户没有阳光。镜中人也在观察你，没有请求被取代。','The remembered window admits no sunlight. The reflection observes you without asking to be replaced.',['open','走到窗边','Approach the window'],['leave','退回自己的轮廓','Return to your own outline']],
 ['掌心留下陌生的温度。知道一段记忆，不等于拥有那段生命。','An unfamiliar warmth remains. Knowing a memory is not owning a life.',['take','保留疑问','Keep the question'],['leave','放下借来的手','Release the borrowed hands']]],
 dream_unknown1:[
 ['无编号房间里有两张床，每张都留下同一个人的压痕。','Two beds in the unnumbered room bear one person’s impression.',['open','查看另一张床','Examine the other bed'],['wait','等房间先改变','Wait for the room to change']],
 ['日历把明天叫作昨天。一扇窗显示你正站在这扇窗前。','The calendar calls tomorrow yesterday. A window shows you standing before it.',['ask','问今天是什么时候','Ask when today is'],['leave','沿门框摸索出口','Trace the frame toward the exit']],
 ['你没有找到证明这是谁的梦。离开时，门上终于留下一个空白标签。','You find no proof of whose dream it is. A blank label remains on the door.',['take','记住空白标签','Remember the blank label'],['leave','不替空白命名','Leave the blank unnamed']]]
 };
 for(const [id,records]of Object.entries(stages)){const dream=D.dreams.find(d=>d.id===id);dream.stages=records.map(([zh,en,...choices])=>({text:t(zh,en),choices:choices.map(([id,zh,en])=>({id,label:t(zh,en)}))}));}
 Abyss.I18n.register(Abyss.HomeData.english);return {rows};
})();
