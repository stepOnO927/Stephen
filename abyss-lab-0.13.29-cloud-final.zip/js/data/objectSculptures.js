'use strict';
// Authored semantic silhouettes in a 170×160 object stage. No category fallback for catalogued loot.
Abyss.ObjectSculptures=(()=>{
 const M=Abyss.ArtMaterials,P=M.path,L=M.line,C=M.circle,R=M.rect;
 const leaf=(x,y,c)=>P(`M${x} ${y}q-29-31-13-40q31 4 13 40`,c)+L(`M${x} ${y}l-12-31`,'#c5d8a0');
 const tape=(m,double=false)=>R(33,48,105,69,9,m.dark)+P('m33 48 13-9h80l12 9',m.metal)+R(42,57,87,36,4,m.fill)+[60,110].map(x=>C(x,75,13,m.metal)+C(x,75,6,m.dark)+L(`M${x-10} 75h20M${x} 65v20`,m.light,1)).join('')+P('m60 107 8-11h36l8 11',m.metal)+(double?L('M47 61h18m24 28h31','#b8767f',3):L('M48 107h11m60 0h9',m.light));
 const card=(m,kind)=>P('m44 35 75-9 7 94-75 9z',m.fill)+P('m44 35-6 4 7 94 6-4',m.dark)+P('m52 44 57-7 2 24-57 7z',m.dark)+(kind==='badge'?C(69,53,7,m.light)+L('M61 66q8-11 16-2',m.light,5):L('M61 51l35-4M62 59l21-3',m.light,2))+L('M60 84l43-6M61 92l31-4M62 101l40-5',m.dark,2)+R(91,102,15,10,2,m.metal);
 const vial=(m,kind)=>P('M66 34h37v15l13 13v58q-30 16-59 0V62l9-13z',m.glass)+P('M60 87q25-8 53 0v31q-28 14-53 0z',m.fill)+R(64,26,41,15,4,m.metal)+L('M67 61v44','#e4f1e7',3)+(kind==='spore'?[C(82,87,9,'#c2c47f'),C(98,105,6,'#a9ba78'),L('M82 96v17','#b6d09d',2)].join(''):P('M79 101q-13-19 3-23 23 8 16 29l-9 8z','#c1909c'));
 const gear=(m)=>Array.from({length:12},(_,i)=>`<g transform="rotate(${i*30} 85 79)">${R(78,28,14,20,2,m.metal)}</g>`).join('')+C(85,79,42,m.metal)+C(85,79,29,m.dark)+C(85,79,19,m.fill)+C(85,79,10,m.dark)+M.rivets([[61,64],[109,64],[85,106]],m);
 const models={
 cv_chess:m=>P('m30 55 70-25 43 63-76 37z',m.dark)+Array.from({length:6},(_,r)=>Array.from({length:6},(_,c)=>P(`m${33+c*11+r*6} ${56-c*4+r*10} 11-4 6 10-11 4z`,(r+c)%2?m.light:m.fill)).join('')).join('')+C(83,63,7,m.metal)+P('M77 66l-5 24h24l-7-24',m.metal),
 cv_comic:m=>P('m36 32 75 11 18 85-78-13z',m.fill)+P('m36 32-7 7 15 85 7-9',m.dark)+P('m49 49 53 6 6 30-52-5z',m.light)+P('m57 78 14-22 10 13 10-15 15 22',m.dark)+L('M57 100l39 5m-37 5 28 4',m.light,3),
 cv_dice:m=>P('m46 48 48-17 36 35-48 22z',m.light)+P('m46 48 36 40v42l-36-36z',m.fill)+P('m82 88 48-22v42l-48 22z',m.metal)+[[75,50],[99,63],[59,78],[70,100],[93,100],[114,83],[114,108]].map(([x,y])=>C(x,y,4,m.dark)).join(''),
 cv_music:m=>R(48,26,77,104,12,m.metal)+R(58,39,57,29,4,m.dark)+C(86,95,22,m.light)+C(86,95,10,m.fill)+L('M72 44h28m-26 8h15',m.light)+L('M49 114q-34 1-24-48q4-19 18-9',m.dark,4)+C(40,55,7,m.fill),
 cv_console:m=>R(25,50,120,68,13,m.metal)+R(61,62,49,39,4,m.dark)+P('M67 91l16-19 23 19',m.fill)+L('M42 73v24m-12-12h24',m.dark,6)+C(128,77,6,'#b86e6c')+C(120,96,5,m.light),
 cv_camera:m=>R(28,58,116,64,8,m.fill)+R(42,43,35,18,3,m.metal)+R(107,51,24,10,3,m.dark)+C(86,87,32,m.metal)+C(86,87,24,m.dark)+C(86,87,17,m.glass)+C(79,81,7,m.light)+R(33,67,15,12,2,m.light),
 cv_tape:m=>tape(m,true),
 cv_coffee:m=>P('m53 26 54 3 16 94-67 9-16-90z',m.fill)+P('m53 26 54 3-5 9-51-2z',m.metal)+R(60,55,45,39,3,m.dark)+P('M80 63q-21 8-10 21 23 12 26-7-1-21-16-14',m.metal)+L('M81 64q-9 7 3 20',m.dark,2),
 cv_chocolate:m=>P('m34 54 81-21 25 71-86 25z',m.dark)+P('m34 54 55-15 18 52-53 19z',m.light)+Array.from({length:6},(_,i)=>R(90+i%2*16,45+Math.floor(i/2)*19,13,16,2,'#765343')).join('')+L('M42 65l33-9m-30 19 24-7',m.fill,4),
 cv_fruit:m=>P('M32 97l107-7-12 39-76 7z',m.metal)+L('M41 102l89-8m-84 19 80-9',m.dark,3)+[[-20,0],[20,4],[0,-17]].map(([x,y])=>C(84+x,80+y,19,x<0?'#ad665f':'#c6ac63')+leaf(85+x,66+y,'#5e957a')).join(''),
 cv_medicine:m=>R(35,39,98,84,8,m.light)+P('m35 39 9-9h82l7 9',m.metal)+R(72,56,22,51,2,'#b1716e')+R(58,71,51,20,2,'#b1716e')+L('M41 115h83',m.dark),
 cv_soap:m=>R(43,57,87,47,18,'#b9c9bb')+P('M45 68q40-25 81-6v10q-47-16-81 9z',m.light)+L('M58 88h49',m.dark,2)+P('m34 102 104-8-9 22-88 6z',m.fill),
 cv_socks:m=>P('M46 34h26v55l28 12q13 18-10 26L46 108z',m.fill)+P('M92 25h25v55l26 13q13 17-9 25L92 102z',m.metal)+L('M47 44h24M93 35h23',m.light,4)+L('M47 86h23m23-10h22',m.dark),
 cv_paper:m=>P('m32 47 87-16 26 84-90 22z',m.dark)+P('m32 42 87-16 24 82-90 22z',m.light)+L('M57 120l84-18M56 124l85-18',m.metal)+P('m119 26-13 25 20 2z',m.fill),
 cv_pen:m=>P('m44 122 42-91 15 5-44 89-13 12z',m.metal)+P('m44 122 13 3-13 12z',m.dark)+P('m87 31 7-17 16 7-8 15z',m.fill)+L('M104 28l10 5-15 30',m.light,3)+L('M49 125l-5 12',m.light),
 cv_battery:m=>P('m53 41 49-9 20 18-48 11z',m.light)+P('m53 41 21 20v71l-21-20z',m.dark)+P('m74 61 48-11v71l-48 11z',m.fill)+R(67,26,17,16,2,m.metal)+R(97,29,12,13,2,m.dark)+L('M84 77h26m-13-13v26',m.light,4),
 cv_radio:m=>R(30,48,110,76,9,m.fill)+C(63,88,25,m.dark)+Array.from({length:6},(_,i)=>L('M43 '+(72+i*6)+'h39',m.metal)).join('')+R(96,62,32,15,2,m.light)+C(104,99,8,m.metal)+C(124,99,5,m.dark)+L('M119 49l17-32',m.metal,3),
 cv_cigarettes:m=>P('m43 38 67 8 12 79-68 9z',m.light)+P('m43 38 67 8-8-17-64-6z',m.fill)+P('m50 78 64-8 8 55-68 9z',m.fill)+L('M61 50v27m10-25v23m10-22v20',m.metal,4)+L('M66 101l33-4',m.light,3),
 cv_alcohol:m=>P('M74 28h24v27l15 16v52q-27 13-53 0V71l14-16z',m.glass)+R(72,20,28,13,3,m.dark)+P('M63 83h47v38q-24 10-47 0z','#997657')+R(67,87,40,26,3,m.light)+L('M76 101h22',m.dark,3),
 cv_tomorrow:m=>R(38,41,90,80,7,m.dark)+R(48,51,70,24,3,m.glass)+L('M54 62h10l4-7 5 16 8-14 7 7h20',m.light,2)+C(61,99,13,m.metal)+C(108,99,8,m.fill)+L('M96 41l-5-23m5 23 19-27',m.metal,3),
 cv_sealed:m=>P('m32 54 60-25 48 25-54 22z',m.metal)+P('m32 54 54 22v60l-54-24z',m.dark)+P('m86 76 54-22v57l-54 25z',m.fill)+L('M57 43l55 23v60M41 76l39 18',m.light,4)+R(95,89,17,21,3,m.dark)+C(103,94,4,m.metal),
 cv_watch:m=>L('M76 34q-40-18-32 10t29-1',m.metal,3)+C(87,33,9,'none',`stroke="${m.metal}" stroke-width="5"`)+C(87,84,44,m.metal)+C(87,84,35,m.light)+L('M87 84V57m0 27 21 12',m.dark,3)+[0,90,180,270].map(a=>'<g transform="rotate('+a+' 87 84)">'+L('M87 52v7',m.dark,2)+'</g>').join(''),
 cv_projector:m=>R(40,63,81,49,5,m.fill)+C(61,43,24,m.metal)+C(109,42,26,m.metal)+[61,109].map(x=>C(x,42,8,m.dark)+C(x-12,36,5,m.dark)+C(x+8,55,5,m.dark)).join('')+P('m121 74 19-6v31l-19-7z',m.dark)+L('M48 112l-7 18m68-18 9 18',m.metal,4),
 cv_ammo:m=>R(35,75,101,49,5,m.dark)+Array.from({length:5},(_,i)=>P(`M${45+i*17} 75V47l5-14 6 14v28z`,m.metal)).join('')+P('m35 75 101-1-15 13H48z',m.fill)+L('M48 112h73',m.light,3),
 cv_repair:m=>R(31,70,112,56,8,m.fill)+P('M61 70V52h50v18','none',`stroke="${m.metal}" stroke-width="8"`)+L('M35 91h102',m.dark,3)+R(57,86,10,19,2,m.metal)+R(106,86,10,19,2,m.metal)+P('m39 50 36-22-5 14-13 10-3 13-13 6z',m.metal),
 cv_parts:m=>P('m35 63 65-19 36 20-62 18z',m.light)+P('m35 63 39 19v47l-39-16z',m.dark)+P('m74 82 62-18v49l-62 16z',m.fill)+L('M50 55l20-23m30 26 11-34',m.metal,10)+C(94,51,14,m.dark)+C(94,51,7,m.metal),
 cv_armor:m=>P('m52 32 65 9 15 51-47 39-48-54z',m.metal)+P('m60 45 45 7 13 37-32 26-34-38z',m.dark)+L('M68 57l30 5m-23 17 27 5m-18 17 16-12',m.light,3),
 cv_furniture_chair_1:m=>P('m49 37 62-12 6 53-62 14z',m.fill)+P('m43 92 72-14 24 19-72 18z',m.metal)+L('M47 97v34m21-19v27m46-56v35m21-19v30',m.dark,6)+L('M53 42l-1 37m54-47 4 35',m.light,3),
 cv_furniture_lamp_1:m=>P('m48 129 40-12 39 9-40 12z',m.dark)+L('M86 122V70l-28-26',m.metal,6)+P('m43 29 30-8 30 34-43 16z',m.fill)+P('m60 71 43-16-9 15-34 8z',m.light),
 cv_furniture_table_1:m=>P('m26 69 76-30 47 31-76 30z',m.light)+P('m26 69 47 31 76-30v8l-76 31-47-31z',m.fill)+L('M34 83v47m43-16v26m61-57v45m-36-83v33',m.dark,7),
 cv_object_radio:m=>R(30,49,110,73,9,m.dark)+C(63,85,26,m.glass)+P('M48 86q16-24 30 0-14 27-30 0',m.fill)+C(63,86,6,m.light)+R(98,63,30,13,2,m.metal)+L('M119 49l14-24-9-12',m.fill,4)+L('M98 94l8 8 8-16 9 18',m.light,2),

 fish:m=>P('M43 87q36-59 75-8l29-20-5 57-24-26q-46 47-75-3',m.fill)+P('m75 63 15-28 16 31M80 104l21 21 3-25',m.metal)+L('M59 79q-12 9 2 19M72 75l4 26m7-29 4 31m7-28 4 22',m.light)+C(55,82,4,'#cad3bd'),
 gel:m=>P('m42 43 69-12 20 89-75 12z',m.fill)+P('m42 43 69-12-3-8-67 12zm14 89 75-12 2 8-75 12z',m.metal)+P('m57 68 48-8 8 39-48 8z',m.light)+L('M70 83l26-5m-24 13 19-4',m.dark,3),
 berry:m=>L('M86 100V53m0 13-22-9m22 6 25-17',m.dark,5)+leaf(85,57,'#648478')+[[-15,3],[10,1],[-6,23],[22,23],[-23,26],[1,44]].map(([x,y])=>C(85+x,68+y,13,m.fill)+C(81+x,63+y,3,'#cfdfa8')).join(''),
 scrap:m=>P('m37 62 60-28 12 16-57 30z',m.metal)+P('m52 80 57-30-6 11-51 30z',m.dark)+P('m56 104 18-43 25 20-21 47z',m.fill)+P('m96 82 39 10-8 20-37-10z',m.metal)+L('M77 84l-7 26m34-15 15 4','#bc9475',3),
 gear:m=>gear(m),
 servo:m=>R(45,56,69,62,8,m.fill)+P('m45 56 19-15h66l-16 15z',m.metal)+P('m114 56 16-15v62l-16 15',m.dark)+C(79,84,22,m.metal)+C(79,84,12,m.dark)+R(75,66,8,26,2,m.light)+L('M53 112q-20 30 55 16',m.base,4)+M.rivets([[53,63],[106,64],[53,109],[106,109]],m),
 spore:m=>vial(m,'spore'),tissue:m=>vial(m,'tissue'),
 seed:m=>P('M85 33q50 35 18 83-23 28-43-7-26-42 25-76',m.dark)+P('M85 33q-21 47 1 96',m.fill)+L('M83 48q-9 32 4 57',m.light,2)+leaf(84,39,'#6e9178'),
 reagent:m=>P('M71 30h26v35l29 47q7 21-42 21t-42-21l29-47z',m.glass)+P('m54 101 61 0 9 15q-1 15-40 15t-39-15z',m.fill)+R(67,24,34,11,3,m.metal)+L('M69 79l-15 29','#d3e7df',3)+L('M95 87h10m-4 10h10m-3 10h8',m.light),
 crystal:m=>P('m83 22 32 37-11 59-27 22-25-36 3-57z',m.fill)+P('m83 22-8 64-23 18 3-57z',m.metal)+P('m75 86 40-27-11 59-27 22z',m.glass)+L('M83 22l-8 64 2 54m-2-54 40-27',m.light),
 core:m=>R(45,43,79,88,12,m.dark)+P('m45 43 16-15h77l-14 15z',m.metal)+P('m124 43 14-15v88l-14 15',m.fill)+C(85,85,29,m.glass)+C(85,85,16,m.fill)+L('M85 57v55M58 85h54M66 66l38 38m0-38-38 38',m.light,2)+M.rivets([[53,51],[115,51],[53,121],[115,121]],m),
 coin:m=>`<ellipse cx="85" cy="92" rx="45" ry="31" fill="${m.dark}"/><ellipse cx="85" cy="86" rx="45" ry="31" fill="${m.metal}"/><ellipse cx="85" cy="86" rx="35" ry="23" fill="none" stroke="${m.dark}"/>`+P('m85 64 8 13 17 1-13 10 3 14-15-8-15 8 3-14-13-10 17-1z',m.fill),
 watch:m=>R(70,21,30,120,8,m.dark)+R(74,24,22,18,3,m.fill)+C(85,81,39,m.metal)+C(85,81,31,m.dark)+L('M85 55v25l19 12M85 54v5m27 22h-5m-22 26v-5m-27-21h5',m.light,3)+P('m95 53-13 18 10 11-12 22','none','stroke="#818fab"')+R(124,74,7,13,2,m.metal),
 key:m=>C(68,55,23,m.metal)+C(68,55,13,m.dark)+P('m81 72 41 45-11 10-41-44z',m.metal)+L('M90 91l18 20',m.light,2),
 object17:m=>P('m46 48 53-22 29 43-28 49-54-15 24-40 30 17-15 26-11-18-15 13 34 15 21-35-22-23z',m.metal)+L('M44 126h24m47-90h17',m.light,2),
 badge:m=>card(m,'badge'),tape:m=>tape(m),
 wire:m=>[0,1,2,3,4,5].map(i=>`<ellipse cx="${73+i*5}" cy="${78-i*2}" rx="34" ry="47" fill="none" stroke="${i%2?m.base:m.metal}" stroke-width="6"/>`).join('')+L('M69 121q-36 13-39-13m80-69 28-13',m.dark,6)+L('M135 26l8-5',m.light,4),
 moss:m=>P('m39 105 20-28 62 6 18 29-41 19z',m.dark)+Array.from({length:9},(_,i)=>leaf(54+i*7,109-i%3*8,['#678870','#91a078','#486b64'][i%3])).join(''),
 glass:m=>P('m50 41 66-14 13 90-68 17z',m.glass)+P('m50 41-8 4 13 90 6-1z',m.fill)+L('M60 53l13 65m4-73 6 24',m.light,4),
 map:m=>P('m29 46 36-11 36 13 35-12v86l-34 10-37-12-36 10z',m.light)+P('m65 35 36 13v84l-36-12z',m.fill)+L('M40 61l18 10 22-12 20 26 24-20M44 110l35-26 20 24 23-14',m.dark,2)+C(100,85,5,'#a96569'),
 pod:m=>P('M51 69q0-40 34-40t34 40v35q0 30-34 30t-34-30z',m.glass)+P('M50 62h70v13H50zm0 48h70v12H50z',m.metal)+P('M91 77q-30-23-24 15 6 21 27 10 15-17-3-25',m.fill)+L('M57 83v17',m.light,3),
 junk:m=>P('m30 105 25-43 29 13 26-27 26 65-46 20z',m.dark)+P('m48 99 3-39 30 13-10 41z',m.fill)+C(105,101,24,m.metal)+C(105,101,12,m.dark)+P('m76 102 25 19-38 12z',m.light),
 bio_sample:m=>P('M43 75q40-21 84 0v27q-42 30-84 0z',m.glass)+`<ellipse cx="85" cy="75" rx="42" ry="18" fill="${m.glass}" stroke="${m.light}"/>`+P('M57 91q-2-21 23-10 24-10 29 6-8 23-52 4',m.fill)+L('M57 103q26 12 55-2',m.light,2),
 p5_feeding_cup:m=>P('M49 51h66v62q-33 25-66 0z',m.fill)+`<ellipse cx="82" cy="51" rx="33" ry="11" fill="${m.dark}"/>`+P('M115 62q42-6 27 38l-27 7','none',`stroke="${m.metal}" stroke-width="10"`)+L('M59 70v37',m.light,3)+C(84,89,13,m.light)+P('m80 85 4-6 5 6-5 8z',m.base),
 p5_toy:m=>L('M83 69v71',m.dark,7)+P('m83 69-41-39 5 42 36-3 35-39-1 43-34-4 35 41-43-2 8-39-40 33 1-40z',m.fill)+P('m83 69-36 3-5-42zm0 0 35-39-1 43z',m.light)+C(83,69,6,m.metal),
 p5_blank_tag:m=>P('M58 40q27-35 53 0','none',`stroke="${m.metal}" stroke-width="4"`)+R(47,40,73,85,12,m.metal)+R(55,55,57,58,6,m.fill)+C(84,48,4,m.dark),
 p5_photo:m=>P('m41 33 87 8-9 94-87-8z',m.light)+P('m50 45 66 6-6 62-68-6z',m.dark)+C(64,72,12,m.fill)+C(98,75,12,m.fill)+P('M48 105q12-35 32 0m1 2q16-35 26 0',m.fill)+L('M50 50l50 58m-44-6 54-43','#b6867d',4),
 p5_wristband:m=>P('M34 62q50-44 99 0v41q-48-44-99 0z',m.fill)+P('M34 62v41q48 41 99 0V62q-48 40-99 0',m.light)+R(52,83,49,21,3,m.fill)+L('M61 90h28m-28 7h19',m.dark,2),
 p5_restraint:m=>P('M37 53q44-19 96 0v26q-50-18-96 0z',m.dark)+P('M37 53v44q49 35 96 0V53q-48 35-96 0',m.metal)+R(67,77,37,32,5,m.dark)+R(73,83,25,20,2,m.fill)+L('M69 95h29',m.light,3),
 p5_seed:m=>P('m42 48 77-12 12 94-78 8z',m.light)+P('m46 48 36 23 35-33',m.fill)+P('M86 110q-26-25-8-37 24 2 8 37',m.dark)+leaf(86,105,'#8d9d7b')+L('M61 126l41-5',m.dark,2),
 p5_disk:m=>C(85,81,51,m.metal)+C(85,81,39,m.glass)+C(85,81,15,m.dark)+C(85,81,7,m.light)+P('M85 30a51 51 0 0 1 49 36l-34 9z',m.fill)+L('M46 96l16 23m47-72 11 14',m.light,3),
 p5_wheel:m=>C(85,81,46,'none',`stroke="${m.metal}" stroke-width="12"`)+[0,120,240].map(a=>`<g transform="rotate(${a} 85 81)">${L('M85 81V38',m.fill,11)}</g>`).join('')+C(85,81,15,m.metal)+R(78,74,14,14,2,m.dark),
 p5_glass:m=>C(85,81,43,m.glass)+C(73,66,16,'#dcccad55')+P('M66 97q15-45 33-13-14-11-25 14',m.fill)+L('M59 70q6-18 21-20',m.light,4),
 p5_headset:m=>P('M41 99V70q0-49 44-49t44 49v29','none',`stroke="${m.dark}" stroke-width="15"`)+P('M41 77v-7q0-49 44-49t44 49v7','none',`stroke="${m.metal}" stroke-width="5"`)+R(31,70,23,47,8,m.fill)+R(116,70,23,47,8,m.fill)+L('M129 113q-5 23-33 18',m.metal,4)+R(80,126,21,9,4,m.dark),
 p5_series:m=>P('m33 52 35-23 67 22v66l-44 18-58-27z',m.fill)+P('m33 52 57 21 45-22-67-22z',m.light)+P('M90 73v62l45-18V51z',m.dark)+L('M45 69l31 12m-31-3 31 12m-31-3 31 12',m.light,3)+P('m60 47 10-7 31 10-11 7z',m.dark),
 p5_pass:m=>P('m43 36 84 14-17 82-83-16z',m.fill)+P('m43 36 84 14-4 18-85-15z',m.light)+L('M56 76l40 7m-41 3 39 7m-29 9 21 4',m.dark,3)+C(97,108,10,m.metal),
 p5_tape:m=>tape(m,true),
 p5_lens:m=>C(85,82,47,m.metal)+C(85,82,37,m.glass)+C(85,82,22,'none',`stroke="${m.light}" stroke-width="1"`)+L('M85 43v12m39 27h-12m-27 39v-12M46 82h12',m.light,2)+P('m53 68 26-19 32 47-24 16z','#a9badf22')
 };
 function draw(item,m){return models[item.id]?.(m)||Abyss.Data.itemModels[item.model||item.id]||null;}
 return {models,draw};
})();
