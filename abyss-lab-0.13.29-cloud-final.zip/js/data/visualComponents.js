'use strict';
Abyss.Data.visualComponents=(()=>{
 const groups={
 body:['slim','bulky','elongated','compact','asymmetrical','armored','aquatic','amorphous'],
 eyes:['large','small','vertical','compound','blind','asymmetrical','glowing','wide','amber','rings','multiple','star'],
 head:['crest','long_skull','sensory','fangs','beak','soft','crown','mouthplate','gills','whiskers'],
 horns:['curved','antlers','antennae','broken','defensive','spiral','forked','crystal','feather','sensor','floating','buds'],
 tail:['long','club','fin','segmented','prehensile','multiple','ribbon','barbed','root','mist'],
 back:['wings','spines','shell','vents','sacs','petals','cables','orbit'],
 skin:['smooth','scaled','plated','translucent','scarred','fungal','metallic','bioluminescent','darkened','pale'],
 limbs:['long_arms','strong_legs','extra_limbs','claws','webbed','digitigrade','reduced','soft_paws'],
 effects:['particles','electric','spores','frost','heat','distortion','embers','rain','halo','echo']
 };
 const labels={slim:'流线体态',bulky:'厚实体态',elongated:'修长躯干',compact:'团簇体态',asymmetrical:'偏侧组织',armored:'骨板躯干',aquatic:'水生体态',amorphous:'柔性凝体',large:'放大眼睛',small:'小型眼睛',vertical:'纵向瞳孔',compound:'复眼',blind:'退化视器',glowing:'荧光虹膜',wide:'横向瞳孔',amber:'琥珀瞳',rings:'环纹虹膜',multiple:'多重视器',star:'星斑虹膜',crest:'头部脊冠',long_skull:'延长颅骨',sensory:'颅感知器',fangs:'尖牙',beak:'角质喙',soft:'柔软面颊',crown:'冠状组织',mouthplate:'口部甲片',gills:'鳃裂',whiskers:'触须口器',curved:'弯角',antlers:'分叉鹿角',antennae:'双触角',broken:'断角',defensive:'护额双角',spiral:'螺旋角',forked:'叉状角',crystal:'晶角',feather:'羽状感角',sensor:'神经感角',floating:'漂浮角片',buds:'芽状感角',long:'长尾',club:'锤尾',fin:'鳍尾',segmented:'分节尾',prehensile:'卷握尾',ribbon:'带状尾',barbed:'棘尾',root:'根须尾',mist:'雾尾',wings:'大型翼膜',spines:'背棘',shell:'背甲',vents:'排热孔',sacs:'共生囊',petals:'花瓣背膜',cables:'神经线缆',orbit:'轨道背环',smooth:'光滑皮肤',scaled:'鳞皮',plated:'板皮',translucent:'透明皮肤',scarred:'瘢痕',fungal:'菌纹皮肤',metallic:'金属皮肤',bioluminescent:'发光皮肤',darkened:'深色皮肤',pale:'苍白皮肤',long_arms:'长臂',strong_legs:'强壮后肢',extra_limbs:'附加肢体',claws:'爪肢',webbed:'蹼足',digitigrade:'趾行腿',reduced:'短肢',soft_paws:'柔软足垫',particles:'浮游微粒',electric:'电弧',spores:'孢子',frost:'冷雾',heat:'热扰动',distortion:'异常折射',embers:'温热粒子',rain:'凝露',halo:'生物光轮',echo:'回声重影'};
 return Object.entries(groups).flatMap(([category,variants])=>variants.map((variant,index)=>({id:category+'_'+variant,category,variant,index,name:labels[variant]||variant,asset:null})));
})();
(()=>{
 const D=Abyss.Data,routeFor=c=>/aquatic|gills|fin|darkened|bioluminescent|mist|webbed/.test(c.variant)?'abyssal':/metallic|cables|sensor|vents|armored|mouthplate/.test(c.variant)?'synthetic':/fungal|root|spores|buds|petals|amorphous/.test(c.variant)?'spore':/distortion|floating|orbit|echo|asymmetrical|translucent/.test(c.variant)?'anomaly':/fangs|claws|vertical|slim|barbed|digitigrade/.test(c.variant)?'predator':/bulky|plated|defensive|strong_legs|shell|club/.test(c.variant)?'guardian':/sensory|compound|long_skull|multiple|rings|elongated/.test(c.variant)?'intellect':'companion';
 for(const m of D.mutations){m.category=({horns:'horns',wings:'back',eye:'eyes',shell:'skin',tail:'tail',tentacles:'limbs',glow:'effects',regen:'skin'})[m.id];m.rarity='common';m.visualComponent=null;m.compatibilityTags=[m.affinity];m.conflicts=m.id==='shell'?['back_wings']:m.id==='wings'?['body_bulky','body_armored','back_shell']:[];m.evolutionTags=[({feral:'predator',gentle:'companion',radiant:'intellect',armored:'guardian',void:'abyssal'})[m.affinity]];m.gameplayEffects=m.effects;m.discoveryRequirements=m.rules;}
 D.mutations.push(...D.visualComponents.map(c=>{
  const route=routeFor(c),rare=route==='anomaly';const stat=({guardian:'strength',predator:'strength',intellect:'intelligence',abyssal:'pollution',synthetic:'intelligence',spore:'stability',anomaly:'pollution',companion:'loyalty'})[route];
  const min=route==='companion'?65:route==='spore'?60:20+c.index*3;
  const abilities=[/aquatic|gills|fin|webbed/.test(c.variant)?'aquatic':null,/wings/.test(c.variant)?'flight':null,/metallic|cables|sensor/.test(c.variant)?'machine':null,/compound|sensory|long_skull/.test(c.variant)?'terminal':null,/bulky|strong_legs|claws/.test(c.variant)?'obstacle':null,rare?'anomaly':null].filter(Boolean);
  return {id:c.id,name:c.name,category:c.category,rarity:rare?'anomalous':c.index>7?'epic':c.index>4?'rare':'uncommon',layer:'evolution-'+c.category,visualComponent:c.id,compatibilityTags:[c.category,route,...abilities],conflicts:[...(c.variant==='wings'?['body_bulky','body_armored','back_shell']:[])],evolutionTags:[route],abilities,desc:`${c.name}改变了${({body:'身体轮廓',eyes:'感知方式',head:'头部组织',horns:'头部轮廓',tail:'尾部支撑',back:'背部结构',skin:'表皮结构',limbs:'移动方式',effects:'周围的微环境'})[c.category]}。${abilities.length?'由此发现新的环境交互。':'保留原有个体的识别特征。'}`,rules:{['stats.'+stat]:{min}},technology:rare?'forbidden_protocol':c.index>7?'compatibility':c.index>3?'gene_library':null,affinity:({guardian:'armored',predator:'feral',intellect:'radiant',abyssal:'void',synthetic:'armored',spore:'gentle',anomaly:'void',companion:'gentle'})[route],effects:{},gameplayEffects:{abilities},discoveryRequirements:{stat,min,technology:rare?'forbidden_protocol':c.index>3?'gene_library':null}};
 }));
})();
