'use strict';
(()=>{
 const D=Abyss.ExpeditionData;
 const locations=[['wing','废弃实验翼','ABANDONED WING','facility_power',54],['deep','深层管线','DEEP FACILITY','deep_map',62],['black_floor','黑级封存层','BLACK FLOOR','black_floor',76]];
 for(const [id,name,en,technology,danger]of locations){D.locations.push({id,name,en,technology,danger,unlock:1,cost:2,duration:3,rooms:['观察站','封存走廊','终端室'],discoveries:'机密文件 / 历史标牌 / 未知物质',recommend:'需研究权限与健康 50'});D.tables[id]=id==='wing'?['bio_sample','classified_data','unknown_keycard','first_specimen_tag']:id==='deep'?['mechanical_component','unknown_material','broken_data_core','black_glass']:['classified_data','object_redacted','first_specimen_tag'];
 for(let i=0;i<3;i++)D.events.push({id:id+'_encounter_'+i,location:id,name:['未结束的观察','门后的脚步','旧终端'][i],text:['一台仍在记录的设备对准了它，却没有发出警报。','地上的痕迹不属于人。它停下来，仔细听了听。','终端请求一个名字。你没有在任职资料里见过这条协议。'][i],weight:3,room:['观察站','封存走廊','终端室'][i],choices:[{id:'inspect',label:'仔细检查',stat:'intelligence',threshold:35+i*8,risky:true,success:{item:D.tables[id][i+1],certain:true,doc:'P3_'+id},failure:{effects:{health:-5},hazard:'exhaustion'}},{id:'collect',label:'只收取安全样本',success:{item:i%2?'mechanical_component':'bio_sample'}},{id:'retreat',label:'返回信标',retreat:true}]});
 D.documents.push({id:'P3_'+id,name:name+'的观察副本',text:'实验体不是被创造的，它是在一次共同记忆里被认出的。授权记录与实际观察存在差异。'});
 }
 const options={sewers:{id:'adapt_water',label:'沿淹水通路潜行',ability:'aquatic',technology:'aquatic_survey',success:{item:'unknown_keycard'}},city:{id:'adapt_roof',label:'滑翔至屋顶信标',ability:'flight',technology:'roof_survey',success:{item:'classified_data'}},factory:{id:'adapt_machine',label:'与旧机械接口共振',ability:'machine',technology:'machine_link',success:{item:'broken_data_core'}},forest:{id:'adapt_obstacle',label:'移开根系下的石门',ability:'obstacle',success:{item:'bio_sample'}},ruins:{id:'adapt_terminal',label:'解析非人类终端',ability:'terminal',technology:'communication',success:{item:'first_specimen_tag'}}};
 for(const e of D.events){const extra=options[e.location];if(extra)e.choices.push({...extra,success:{...extra.success,certain:true}});if(e.location==='black_floor')e.choices.push({id:'adapt_anomaly',label:'触碰不可能的门',ability:'anomaly',technology:'impossible_geometry',success:{item:'object_redacted',certain:true}});}
})();

for(const e of Abyss.ExpeditionData.events){if(['ruins','wing','black_floor'].includes(e.location))e.choices.push({id:'adapt_archive',label:'由档案适应器官复原残页',ability:'archive',success:{item:'classified_data',certain:true}});if(e.location==='factory')e.choices.push({id:'adapt_protect',label:'在护印庇护下回收样本',ability:'protect',success:{item:'mechanical_component',certain:true,effects:{mood:2}}});}

Abyss.ExpeditionData.documents.push({id:'P3_zero',name:'零号协议的原始见证',text:'记录中的零并不是编号，它是留给下一位观察者的空位。生命的名字属于生命本身。'});
Abyss.ExpeditionData.events.push({id:'deep_hidden_zero',location:'deep',name:'折影观测室',text:'异常组织与旧隔离墙同步变形，一份仍在生长的原始记录出现在门后。',weight:.7,rare:true,requires:['anomaly_gate_open'],room:'终端室',choices:[{id:'read',label:'读取零号原始记录',ability:'anomaly',success:{doc:'P3_zero',item:'first_specimen_tag',certain:true}},{id:'retreat',label:'保留隔离并返回',retreat:true}]});
