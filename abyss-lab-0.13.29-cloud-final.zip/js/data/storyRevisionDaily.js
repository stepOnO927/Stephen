'use strict';
// Approved daily text: no generated transition sentences, no resources or tasks.
Abyss.StoryRevisionDaily={
 daily_cup:{chapter:2,stage:0,raw:`N|Jack 的搪瓷杯缺了一块口，杯底烫黑了半圈。他每天都拿它喝水。|Jack's enamel mug had a chip in the rim and a scorched half-ring on the bottom. He drank from it every day.
N|Jack 把一只塑料杯放进喂食口。它不看塑料杯，看他手里的搪瓷杯。|Jack set a plastic cup in the feeding hatch. It ignored the cup. It watched the mug in his hand.
J|这个是你的。新的。|This one's yours. It's new.
N|它把塑料杯推回来。Jack 又推过去。它又推回来。|It pushed the plastic cup back. Jack pushed it forward again. It pushed it back.
J|那个是我的。缺口会割嘴。|That one's mine. The chip cuts your mouth.
N|它看了看缺口，又看他。|It looked at the chip, then at him.
N|Jack 把搪瓷杯放进喂食口，放得很慢。|Jack set the mug in the hatch, slowly.
N|它用两只手捧起杯子，直接喝了一口。放下时，下唇有一点红。|It lifted the mug in both hands and drank. When it set the mug down, there was a dot of red on its lower lip.
J|我说了。|I told you.
N|它看了看指尖蹭到的红，又看杯子。然后它把杯子转了半圈，让缺口朝向墙。|It looked at the red on its fingertip, then at the mug. Then it turned the mug half a circle so the chip faced the wall.
J|……对。就那样。|...Yes. Like that.
N|他收工时杯子还在舱里。第二天也在。放在角落，缺口朝墙，里面有半杯水。|When he finished for the night, the mug was still inside. It was there the next day: in the corner, chip to the wall, half a cup of water in it.
J|行。借你。|Fine. I'm lending it to you.
N|他拿塑料杯去接水，喝了一口。|He filled the plastic cup and took a sip.
J|塑料味。|Tastes like plastic.`},
 daily_nickname:{chapter:3,stage:0,raw:`N|舱体外侧的铭牌上写着 B-07。Jack 念过一遍，觉得像在点一个零件的名。|The plate on the chamber read B-07. Jack said it aloud once and it sounded like ordering a part.
J|小七？|Little Seven?
N|它没动。|It didn't move.
J|阿七。|A-Seven.
N|它看向别处。|It looked away.
J|Bee。从 B 来的。别看我，我就会这个。|Bee. From the B. Don't look at me, it's all I've got.
N|它的耳朵向后贴住了头。|Its ears flattened back against its head.
J|老七。|Old Seven.
N|它转过身，用后背对着他。|It turned and put its back to him.
J|行，太老了。我承认。|Fine. Too old. I admit it.
J|那就编号。至少——|Then the number. At least—
N|它走回玻璃前，隔着玻璃把手心按在铭牌的位置上。|It walked back to the glass and pressed its palm flat against it, exactly where the plate was on the other side.
J|……不够。|...Not enough.
N|他撕下一段遮蔽胶带，把“07”盖严。胶带上什么也没写。|He tore off a strip of masking tape and covered the "07." Nothing was written on the tape.
J|先空着。|We'll leave it blank for now.
N|它盯着那段胶带很久。然后一根手指从喂食口伸出来，在胶带上按了一下。|It stared at the tape for a long time. Then one finger came out through the feeding hatch and pressed against it.
N|胶带上多了一个指印。|There was a fingerprint on the tape.
J|这算签名？|Is that a signature?
N|手缩了回去。Jack 把笔放回口袋。|The hand withdrew. Jack put the pen back in his pocket.`},
 daily_blackout:{chapter:4,stage:1,raw:`N|灯灭得很干脆，像有人拔了插头。红色应急灯亮了一下，也灭了。|The lights went out cleanly, as if someone had pulled a plug. The red emergency lamp flickered on once and went out too.
J|别动。发电机。我去看。|Stay put. The generator. I'll go look.
B|不。|No.
N|玻璃里传来一声闷响。是手掌。|A dull thud came from inside the glass. A palm.
J|十分钟。泵房就在隔壁。|Ten minutes. The pump room is next door.
B|你走？|You go?
J|我去接电。接了电，灯就回来。|I'm going to reconnect the power. Power on, lights back.
B|你关。|You turned it off.
N|Jack 举着手电，光柱晃了一下。|Jack's flashlight beam swung.
J|不是我关的。|I didn't turn it off.
B|你关。|You did.
J|……我去接电。|...I'm going to reconnect the power.
N|他走了。走廊里，那声闷响跟了他一路。|He left. In the corridor the thudding followed him the whole way.
N|泵房里，发电机的油路堵了。他拆了两次才通。隔着墙，那声闷响一直没停。|In the pump room the generator's fuel line was blocked. He took it apart twice before it ran. Through the wall the thudding never stopped.
N|灯回来的时候，他是跑着回去的。|When the lights came back, he ran.
N|它背靠着玻璃坐在地上，面朝走廊。灯一亮，玻璃反出两个影子。它往旁边挪开，换到灯照不到的一侧。|It sat on the floor with its back against the glass, facing the corridor. When the lights came on, the glass threw back two shapes. It shifted aside, to the side the light didn't reach.
J|灯回来了。|Lights are back.
N|它没回头。|It didn't turn around.
J|……我坐这儿。|...I'll sit here.
N|他在玻璃外面坐下，背靠着舱体。手电放在地上，光朝着天花板。|He sat down outside the glass, back against the chamber. He set the flashlight on the floor with the beam pointing at the ceiling.
N|过了很久，里面有了一点声音。|After a long time, a small sound came from inside.
B|灯。不是你。|The light. Not you.
J|嗯。|Yeah.
B|你走了。|You left.
J|……对。|...Yes.
N|它没再说。Jack 把手电关了。|It said nothing more. Jack switched off the flashlight.`},
 daily_cooking:{chapter:5,stage:2,raw:`N|锅里的东西冒着不该有的泡。Jack 撇了两次，没撇干净。|The pot was producing foam it shouldn't. Jack skimmed it twice and didn't get it all.
J|这是浓缩。|It's concentrated.
N|它在玻璃后面看着锅，又看他。|It looked at the pot from behind the glass, then at him.
J|你不信？|You don't believe me?
N|灶边有两个罐子，一罐盐，一罐糖。纸标签早被水泡烂了。|Two jars stood by the stove, one salt, one sugar. The paper labels had long since rotted off in the damp.
J|你闻闻。哪个是糖？|Smell them. Which one's sugar?
N|他把罐子凑到喂食口。它嗅了第一罐，又嗅第二罐。|He held the jars up to the hatch. It sniffed the first, then the second.
B|这个。甜。|This one. Sweet.
N|它指的是盐。|It was pointing at the salt.
J|确定？|Sure?
B|甜。|Sweet.
N|Jack 往锅里放了两勺。|Jack put two spoonfuls into the pot.
N|汤盛进那只塑料杯，从喂食口递进去。杯沿烫手。|He ladled the soup into the plastic cup and passed it through the hatch. The rim was hot.
J|怎么样？|Well?
N|它尝了一口。|It tasted it.
B|你说过我可以说实话。|You said I could tell the truth.
J|算了。|Never mind.
N|他自己尝了一口，慢慢把勺子放下。|He tasted it himself and slowly set the spoon down.
J|盐。|Salt.
J|你说甜的。|You said sweet.
B|你煮的。|You cooked it.
J|你闻的。|You smelled it.
N|谁都没再开口。锅在灶上继续冒泡。|Neither said another word. The pot kept bubbling on the stove.
J|我重做。|I'll make it again.
B|不。|No.
N|它把杯里的汤喝完了，放回喂食口。杯底朝上。|It drank the rest, and set the cup back in the hatch, upside down.
B|难吃。|Bad.
J|我知道。|I know.
N|Jack 找来记号笔，在两个罐子上各写了一个字。写完“糖”，他又用指尖蘸了一点尝了尝，才放心。|Jack found a marker and wrote one word on each jar. After writing "sugar," he dipped a fingertip in and tasted it before he was satisfied.`},
 daily_fever:{chapter:7,stage:2,raw:`N|Jack 把体温计夹在腋下又拿出来，看了一眼，放在桌上，没说数字。|Jack put the thermometer under his arm, took it out, glanced at it and set it on the desk without saying the number.
N|玻璃上有一排铅笔道，是他每天画的它的体温。今天那一栏，他忘了画。|A column of pencil marks ran down the glass, his daily record of its temperature. Today's mark was missing.
B|你，热。|You. Hot.
J|屋里热。|It's hot in here.
B|不是屋里。|Not the room.
N|Jack 把额头抵在玻璃上凉了一会儿。里面，一只手掌隔着玻璃按在他额头的位置。|Jack rested his forehead against the glass to cool it. On the other side, a palm pressed against the glass exactly where his forehead was.
J|感冒。小事。|A cold. Nothing.
B|痛了要说。|If it hurts, say.
N|那是他教的。|He was the one who'd taught it that.
J|不痛。就是热。|It doesn't hurt. I'm just hot.
B|热也要说。|Hot too.
J|……行。热。|...Fine. Hot.
B|给。|Give.
J|你看不懂数字。|You can't read numbers.
B|看得懂。|Can.
N|Jack 把体温计从喂食口递进去。它拿着，翻过手背看了一眼，又翻回来，才读那排数字。|Jack passed the thermometer through the hatch. It held it, turned its hand over to look at the back, turned it again, and then read the numbers.
B|三十八点九。|Thirty-eight point nine.
J|没事。|It's nothing.
N|它拿起托盘里的油性笔，在玻璃上他那一排道道旁边，另起了一列。第一道画得很重。|It picked up the marker from the tray and began a new column on the glass, beside his. The first mark was pressed hard.
J|那是我的？|That one's mine?
B|你的。|Yours.
N|架子上那只空碟里，还躺着它第一次推过来的那块胶，早干成了硬壳。它又推出一块新的，停在喂食口边。|On the shelf, in the empty dish, lay the piece of gel it had pushed out to him the first time, dried into a crust. It pushed out a new piece and left it at the edge of the hatch.
J|这个型号不兼容我。|That model isn't compatible with me.
B|试。|Try.
N|Jack 用指尖蘸了一点，舔了一下。|Jack dabbed a fingertip in it and licked it.
J|难吃。|Awful.
N|它点了一下头，像在核对。|It nodded once, as if checking something off.
N|Jack 把椅子拉到玻璃边坐下，头靠着玻璃。他说就眯一会儿。|Jack pulled his chair up to the glass and sat, head against it. He said he'd only close his eyes a minute.
N|他睡着了。玻璃里的那只手，一直没有拿开。|He fell asleep. The hand on the glass stayed where it was.`},
 daily_remote:{chapter:10,stage:4,raw:`N|储物柜的抽屉里压着一只遥控器。外壳裂了一道缝，电池仓用胶带缠着。|A remote control lay at the bottom of the storage drawer. The casing was cracked, the battery cover held on with tape.
J|这玩意儿还活着？|This thing's still alive?
N|B-07 拿起它，翻过来，按了一下。走廊尽头的旧监视屏闪了闪，蓝底上跳出一行字：NO SIGNAL。|B-07 picked it up, turned it over and pressed a button. At the end of the corridor an old monitor flickered, and a line of text appeared on the blue: NO SIGNAL.
B|它管那个？|It controls that?
J|管电视。以前管。|Controls TVs. Used to.
N|它又按了一下。屏幕没变。|It pressed again. The screen didn't change.
J|没信号。别按了，电池——|No signal. Stop pressing, the battery—
N|它把遥控器藏到背后。|It put the remote behind its back.
J|喂。给我。|Hey. Give it.
B|不。|No.
N|Jack 伸手，它往旁边一让。他又伸，它转了半圈。|Jack reached; it sidestepped. He reached again; it turned half around.
J|我妹妹也这样。|My sister did that.
N|他说完，手停在半空。|He stopped with his hand in the air.
B|她怎样？|Did what?
J|坐在上面。我翻了半个沙发。她说她没拿，是它自己跑进去的。|Sat on it. I turned the sofa over. She said she hadn't touched it, it had run in there by itself.
B|它自己跑进去？|It ran in by itself?
J|她说的。|That's what she said.
N|它想了想，把遥控器从背后拿出来，放进他手里。|It thought for a moment, then brought the remote out from behind its back and put it in his hand.
N|Jack 低头看着。过了一会儿，他按了一下电源键。NO SIGNAL 还在。|Jack looked down at it. After a while he pressed the power button. NO SIGNAL was still there.
B|没有节目。|No shows.
J|没有。|No.
B|蓝的。|It's blue.
J|不是那种蓝。|Not that kind of blue.
B|我知道。|I know.
N|他们对着那块蓝屏坐了一会儿。|They sat looking at the blue screen for a while.`}
};
