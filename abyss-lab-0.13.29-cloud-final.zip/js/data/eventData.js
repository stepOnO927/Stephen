'use strict';
// Chance is resolved by Events; effects use the same schema as actions.
Abyss.Data.events = [
 {id:'sick',name:'异常体温',desc:'零号缩在培养舱角落。一次感染正在消耗它的体力。',rules:{'stats.health':{max:65}},weight:3,cooldown:4,choices:[{label:'购买抗体 · ₵ 12',money:-12,effects:{health:17,loyalty:4},history:{care:1}},{label:'保温观察',effects:{health:-5,mood:-3}}]},
 {id:'blackout',name:'备用电源告警',desc:'灯光熄灭，它在黑暗中寻找你的手。',weight:1,cooldown:5,choices:[{label:'留在它身边',effects:{loyalty:6,mood:5},history:{care:1}},{label:'抢修设备 · ₵ 6',money:-6,effects:{stability:7}}]},
 {id:'accident',name:'培养液泄漏',desc:'实验后出现了意外反应。必须控制污染。',rules:{'history.experiment':{min:2}},weight:2,cooldown:5,choices:[{label:'更换过滤器 · ₵ 10',money:-10,effects:{pollution:-12,stability:5}},{label:'手动封闭管线',effects:{pollution:5,health:-5,stability:-4}}]},
 {id:'merchant',name:'地下商人来访',desc:'门外的人带来一颗用银纸包裹的月露果。',weight:2,cooldown:5,choices:[{label:'购买月露果 · ₵ 7',money:-7,food:{fruit:1}},{label:'礼貌谢绝',effects:{}}]},
 {id:'gene',name:'神秘基因',desc:'废弃档案里有一支仍然活跃的样本。',rules:{'history.explore':{min:2}},weight:2,cooldown:7,once:true,choices:[{label:'封存为食物样本',food:{gene:1}},{label:'研究荧光反应',effects:{intelligence:4},bias:{radiant:2}}]},
 {id:'speech',name:'第一个词',desc:'它指着你，发出了一个清晰的音节：“你。”',rules:{'stats.intelligence':{min:22},'stats.loyalty':{min:50}},weight:4,once:true,choices:[{label:'轻声回应它',effects:{loyalty:10,mood:8},history:{care:1}}]},
 {id:'room',name:'墙后的房间',desc:'它在通风管旁停下。墙后藏着一间旧材料库。',rules:{'history.explore':{min:3}},weight:2,once:true,choices:[{label:'一起打开暗门',money:32,food:{mineral:1},effects:{mood:5}}]},
 {id:'gift',name:'床边的小礼物',desc:'它把一块发亮的金属片放在你的工作台上。',rules:{'stats.loyalty':{min:65}},weight:2,cooldown:6,choices:[{label:'认真收下',money:9,effects:{loyalty:3,mood:5}}]},
 {id:'dream',name:'深渊的梦',desc:'它的身体在睡梦中闪烁。某种远处的声音正在回应。',rules:{'stats.pollution':{min:25}},weight:2,cooldown:5,choices:[{label:'播放熟悉的声音',effects:{stability:8,pollution:-3}},{label:'记录共鸣',effects:{intelligence:5,stability:-5},bias:{void:2}}]},
 {id:'food',name:'意外的补给',desc:'一台维修无人机送来一箱被遗忘的营养凝胶。',weight:2,cooldown:4,choices:[{label:'接收补给',food:{ration:2}}]},
 {id:'leak',name:'水滴声',desc:'天花板渗水。它用小小的爪子替你接住一滴。',weight:1,cooldown:5,choices:[{label:'一起修好它',effects:{mood:4,loyalty:4},history:{care:1}}]},
 {id:'rare',name:'孢子开花',desc:'舱边长出了一朵微光菌，它好奇地嗅了嗅。',weight:1,cooldown:6,choices:[{label:'收集幽光菌菇',food:{mushroom:1}},{label:'让它留在舱内',effects:{mood:8},bias:{radiant:1}}]}
];
Abyss.Data.achievements = [
 {id:'firstmeal',name:'第一顿晚餐',desc:'第一次喂食。',rules:{'history.feed':{min:1}}},
 {id:'trust',name:'伸出的手',desc:'忠诚达到 85。',rules:{'stats.loyalty':{min:85}}},
 {id:'mutation',name:'生命的分岔',desc:'发现第一个突变。',special:'mutation'},
 {id:'explorer',name:'黑暗中的足迹',desc:'完成 5 次探索。',rules:{'history.explore':{min:5}}},
 {id:'week',name:'第七次日出',desc:'抵达第 7 天。',rules:{day:{min:7}}},
 {id:'mature',name:'它自己的模样',desc:'见证一个成熟形态。',special:'mature'}
];
