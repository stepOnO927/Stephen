'use strict';
(()=>{
 const X=Abyss.JackData,D=Abyss.NarrativeData,{tr,replace,C}=X;
 const badge=D.nodes.find(n=>n.id==='bond_jack_background');badge.lines[0].text=tr('它把旧工作证从 Jack 的记录本里抽出来。照片上的他年轻一些，姓名栏写着 Jack。','It draws the old badge from Jack’s notebook. He is younger in the photograph. The name field reads Jack.');
 tr('它需要先了解 Jack 的背景，才能把这个名字对应到你。','It needs to learn Jack’s background before connecting the name with you.');
 // Ordinary personnel file, deliberately separate from speculative Project records.
 X.biography=[['身份','Identity','Jack，男，27 岁。初级维护技师／生物设施系统操作员。','Jack, male, 27. Junior maintenance technician / biological facility systems operator.'],['工作','Work','维护门禁、供电、泵、空气与环境控制。旧证件只有维护权限，不是研究主管。','Maintains doors, power, pumps, air and environmental controls. His old badge grants maintenance access, not research authority.'],['家庭','Family','工业小镇长大。父亲修电器，母亲在医院值夜班。妹妹 Jasmine 在第一次灰潮时 17 岁。','Grew up in an industrial town. His father repaired electrical equipment; his mother worked hospital night shifts. His sister Jasmine was 17 at the first Grey Tide.'],['灰潮','Grey Tide','三年前撤离时与 Jasmine 失散，寻找数月。官方记录：失踪。没有经确认的遗体。','Separated from Jasmine during evacuation three years ago. Searched for months. Official status: missing. No confirmed body.'],['红线','Red thread','Jasmine 给他的廉价红线手环。他说是为了辨认身份，也知道自己没有说完真正的原因。','A cheap red-thread bracelet from Jasmine. He calls it identification, knowing that is not the whole reason.'],['旧门','The old door','污染报警时，他迟疑并遵守规程，没有及时使用手动覆盖。门后有人死去；打开是否能救人或扩大污染，仍不能确定。','During a contamination alarm he hesitated and followed protocol rather than using the manual override in time. People died behind the door. Whether opening would have saved them or spread contamination remains uncertain.'],['海岸','The coast','想买旧车、去海岸、取得工程资格。每次都推迟。到故事开始，他从未亲眼见过海。','Wanted an old car, the coast, engineering qualifications. Kept postponing. At the start he has never actually seen the sea.']].map(([title,en,text,eng])=>({title:tr(title,en),text:tr(text,eng)}));
 for(const [zh,en]of [['Jack · 内心','Jack · Internal thought'],['人物档案','Personnel file'],['Jack 的日记','Jack’s journal'],['当前目标','Current objective'],['活下去','Survive'],['保护 B-07','Protect B-07'],['寻找 Jasmine','Look for Jasmine'],['抵达海岸','Reach the coast'],['理解 Project Abyss','Understand Project Abyss'],['一起离开','Leave together'],['完成这一次告别','Finish this farewell'],['保留这段经历','Keep this experience'],['失踪，去向未证实','Missing; whereabouts unconfirmed'],['已确认遇难','Confirmed deceased'],['曾在撤离后存活，现况未知','Survived evacuation; current whereabouts unknown'],['语言强度','Language intensity'],['清洁 · 无粗口','Clean · No profanity'],['轻度 · 默认','Mild · Default'],['完整 · 情境粗口','Full · Contextual profanity'],['只改变措辞，不改变剧情、关系或结果。','Changes wording only, not plot, relationships or outcomes.'],['还没有写下日记。它会出现在重要经历之后。','No journal entries yet. They appear after important experiences.'],['已发现的 Jasmine 线索','Discovered Jasmine evidence'],['这不是实验日志。','This is not an experiment log.']])tr(zh,en);
 // New acts do not hand out the old index-based classified rewards early.
 for(const ch of D.chapters){const idx=X.oldOrder.indexOf(ch.id);ch.rewardIndex=idx>=0?idx:null;}
 const first=D.nodes.find(n=>n.id==='project_first_word');for(const b of first.lines)if(b.speaker==='creature'){b.minLanguage=2;b.simple=b.text;}
 D.nodes.find(n=>n.id==='project_second_abyss_response').text=tr('第二灰潮正在逼近。旧档案的日期不能证明 Jack 是被选中的人；现在的抖动与污染才需要处理。','The second Grey Tide is approaching. An old file date cannot prove Jack is chosen; his present tremor and contamination need attention.');
 D.nodes.find(n=>n.id==='project_zero_response').text=tr('重复的编号与材料记录不能证明 Jack 的身世。它问的是：这些记录会不会再次替一个活着的人决定去留？','Repeated codes and material records cannot prove Jack’s origin. It asks whether these records will again decide where a living person may go.');
 D.nodes.find(n=>n.id==='project_open_door_response').choices[0].jackFlag='shared_rules';
 const lock=D.nodes.find(n=>n.id==='p8_lock_after');lock.lines[0].variants=[{requirements:{'narrative.jack.flags.fear_leave_admitted':{min:1}},text:tr('“怕你离开”没有让门打开。Jack 看着手里的钥匙。','“Afraid you’ll leave” had not opened the door. Jack looked at the key in his hand.')}];
 const threshold=D.nodes.find(n=>n.id==='p8_threshold');
 threshold.lines[2].variants=[
 {requirements:{resentment:{min:45}},text:tr('它退得更远，先看他的手，再看门。Jack 没有把这叫作不知感恩。','It backed farther away, checking his hand before the door. Jack did not call it ungrateful.')},
 {requirements:{'personality.timid':{min:30}},text:tr('它留在床边，耳朵贴低。门开了，身体却还没准备好。','It stayed by the bedding, ears low. The door was open; its body was not ready.')},
 {requirements:{'stats.loyalty':{min:80}},text:tr('它走到他旁边，又停在门内。靠近他和离开房间，是两件不同的事。','It came beside him, stopping inside the door. Approaching him and leaving the room were different things.')},
 {requirements:{'personality.independent':{min:35}},text:tr('它的目光越过他，沿走廊的风向移动。Jack 往旁边退了一步。','Its gaze moved past him, following the wind in the corridor. Jack stepped aside.')}];
 replace('p8_stay_threshold',`N|它没有跨出去。|It did not step outside.
B|今天先到这里。|This far today.
J|好。门还开着。|All right. The door stays open.
T|我不可以用它没出去，证明锁本来就不重要。|I cannot use its staying inside to prove the lock never mattered.
N|Jack 把椅子搬到门边，留出通道。|Jack moved the chair beside the door, leaving the passage clear.
N|它自己选了可以看见走廊的位置。|It chose a place from which it could see the corridor.`,{group:'major',nextNode:'project_open_door_response',choices:[]});
 replace('p8_ask_inside',`B|先到这边来。|Come to this side first.
N|Jack 停了一下，走进玻璃以内。|Jack paused, then walked inside the glass.
T|我知道它不能替我重演过去。可这边看钥匙的角度，和椅子上不一样。|It cannot reenact my past for me. But the key looks different from this side than from the chair.
J|你决定从哪边走。|You decide which way to go.
N|它绕过他，停到开着的门边。|It went around him and stopped by the open door.`,{group:'major',nextNode:'p8_first_steps',choices:[]});
 replace('p8_walk_alone',`N|它走出门槛，没有等 Jack 先迈步。|It crossed the threshold without waiting for Jack to go first.
B|我想自己看。|I want to look by myself.
J|好。我把信标留着。你可以回应，也可以先不回应。|All right. I'll leave the beacon on. You can answer, or not answer yet.
N|它走得很快，到了转角才停一下。|It walked quickly, pausing only at the corner.
T|我的手想伸出去。它不是掉下桌边的工具。|My hand wanted to reach. It wasn't a tool falling off a table.
N|Jack 把手收回。门仍然开着。|Jack withdrew his hand. The door remained open.
N|下一段走廊的声音属于它自己的脚步。|The next corridor's sounds belonged to its own footsteps.`,{group:'major',title:tr('自己的第一段路','Its first road'),choices:[C('respect','让它先独自探索，保留可返回的地方','Let it explore alone and keep a place to return to',{leaveAlone:true,philosophy:{autonomy:2},nextNode:'project_open_door_response'})]});
 threshold.nextNode=null;threshold.choices=[C('wait','让它自己决定第一步','Let it decide its first step',{doorReaction:true})];
 threshold.choices[0].jackJournal='threshold';
 for(const d of X.dreams)D.nodes.find(n=>n.id===d.id).lines.at(-1).journal='dream';
 for(const [id,journal]of [['project_b07','arrival'],['project_jack_name','name'],['project_red_thread','thread'],['project_bseries','necessary']])D.nodes.find(n=>n.id===id).lines.at(-1).journal=journal;
 X.journals.sky={title:tr('天空的约定','The sky promise'),default:tr('我说要让它看见天空。不能把说过当成做过。','I said I would let it see the sky. Saying it does not mean doing it.')};
 D.nodes.find(n=>n.id==='project_between_response').choices.push(C('control','“有时我说照顾，其实是在替你决定。”','“Sometimes I say care when I mean deciding for you.”',{hidden:true,requirements:{'narrative.jack.tendencies.control':{min:4}},jack:{honesty:3,compassion:1},jackJournal:'between',philosophy:{autonomy:2}}));
 const we=D.nodes.find(n=>n.id==='p6_ending_we');we.lines[20].variants=[{requirements:{'narrative.jack.flags.fear_leave_admitted':{min:1}},text:tr('我已经说过怕它离开。现在仍怕。它不需要替我把这个怕变成保证。','I already admitted fearing it would leave. I still feared it. It did not need to turn my fear into a promise.')},{requirements:{'narrative.jack.tendencies.control':{min:6}},text:tr('我差点去摸钥匙。没有人提醒。我把那只手停在桌边。','I nearly reached for the key. Nobody reminded me. I stopped my hand at the edge of the desk.')}];
 const sea=D.nodes.find(n=>n.id==='p6_ending_sea');sea.lines[24].variants=[{requirements:{'narrative.jack.tendencies.honesty':{min:8}},text:tr('不知道海是什么样，原来也可以说出来。它还站在旁边。','I could admit not knowing what the sea would look like. It was still beside me.')},{requirements:{'narrative.jack.tendencies.nihilism':{min:4}},text:tr('海没有替我们洗掉任何事。但今天我没有要求它消失。','The sea washed none of it away. Today I did not ask it to disappear.')}];
 threshold.lines.push({speaker:'creature',voice:'dialogue',text:tr('外面还有什么？','What else is outside?'),variants:[{requirements:{'narrative.jack.flags.promise_sky':{min:1}},text:tr('你答应过天空。不是玻璃上的图片。','You promised the sky. Not a picture on the glass.')}],simple:tr('天空？','Sky?'),minLanguage:3});
 const dream=D.nodes.find(n=>n.id==='p8_dream_inside');dream.lines[3].variants=[{requirements:{'narrative.jack.tendencies.control':{min:6}},text:tr('他想解释门外的危险。解释从玻璃另一侧听起来很远。','He wanted to explain the dangers outside. Explanation sounded distant from the other side of the glass.')}];
 for(const id of ['project_first_word'])for(const b of D.nodes.find(n=>n.id===id).lines)if(b.speaker==='creature'){b.minLanguage=2;b.simple=b.text;}
 for(const n of D.nodes.filter(n=>n.id.startsWith('p8_mia_'))){delete n.requirements['campaign.flags.hospital'];delete n.requirements['campaign.flags.medicine_return'];if(n.id.endsWith('confirmed_death'))Object.assign(n.requirements,{'campaign.flags.first_rescue':{min:1},'campaign.flags.medicine_given':{min:1}});if(n.id.endsWith('survived'))Object.assign(n.requirements,{'campaign.flags.medicine_given':{min:1},explore:8});n.requirements['narrative.jack.miaEvidence.length']={max:0};}
 tr('它用爪尖轻触玻璃，没有开口。','It touches the glass with a claw tip, without speaking.');tr('……你。','…You.');tr('我在听。慢一点。','Listening. Slowly.');
 for(const n of D.nodes.filter(n=>n.jackScene))for(const b of n.lines)if(b.speaker==='creature'&&!b.minLanguage){b.minLanguage=4;b.simple=b.text.length<13?b.text:'我在听。慢一点。';}
 for(const node of D.nodes){if(node.jackScene&&node.group==='project_response')node.group='project_response';for(const c of node.choices||[]){if(node.chapter){c.jack={...({honest:{honesty:2},show:{honesty:2},hide:{control:1,pragmatism:1},protect:{compassion:2},ask:{curiosity:2},silence:{fear:1},destroy:{nihilism:2},restore:{ambition:2},copy:{curiosity:2}}[c.id]||{}),...c.jack};}if(c.p6decision)c.jack={...({sacrifice:{sacrifice:4},continue:{ambition:3},autonomy:{compassion:2},settle:{attachment:2},destroy:{nihilism:3}}[c.p6decision]||{}),...c.jack};}
 if(node.jackScene){node.soloLines=[{speaker:'narrator',voice:'narration',text:tr('Jack 独自读完这份记录。旁边的椅子没有回答。','Jack read this record alone. The chair beside him did not answer.')},{speaker:'player',voice:'thought',text:tr('我仍能调查。不能把调查说成它仍在这里。','I can still investigate. I cannot make investigation mean it is still here.')}];}}
 // Hidden self-reflection, discovered through the control/attachment conflict.
 replace('p8_infinity',`N|权限表没有写 Jack 的名字。只有一行反复回到原处的维护请求。|The access sheet did not name Jack. Just a maintenance request returning to the same line.
T|修好系统，然后再走。我用了这个理由多久？|Repair the system, then leave. How long have I used that reason?
N|他把“等待授权”划掉，没有替自己填上答案。|He crossed out WAITING FOR AUTHORIZATION. He did not fill in an answer for himself.
B|你也在等人开门？|Are you waiting for someone to open your door too?
J|也许。我得自己看清这一点。|Maybe. I have to see that for myself.`,{group:'secret',secret:'infinity',priority:85,title:tr('隐藏档案 ∞ · 内侧','Hidden file ∞ · Inside'),requirements:{day:{min:112},'narrative.jack.tendencies.control':{min:3},'narrative.jack.tendencies.attachment':{min:3},'narrative.languageStage':{min:4}},choices:[C('read','不把这个发现当成控制它的理由','Do not turn this discovery into a reason to control it',{jack:{honesty:2},jackJournal:'between'})]});
 X.flagIds=[...new Set(['learned_swear','swear_tool','swear_alarm','swear_argument','door_unlocked',...D.nodes.flatMap(n=>n.choices.map(c=>c.jackFlag)).filter(Boolean)])];
 X.beatIds=D.nodes.filter(n=>n.jackScene).flatMap(n=>n.lines.map((b,i)=>n.id+':'+i));
 // All authored variants map to the chosen wording even in previously recorded history.
 X.wording=new Map();for(const node of D.nodes)for(const b of node.lines||[])if(b.language)for(const t of Object.values(b.language))X.wording.set(t,b.language);
 Abyss.I18n.register(X.english);
})();
