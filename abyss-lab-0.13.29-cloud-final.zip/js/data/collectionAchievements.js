'use strict';
// Thirty measurable discoveries; ownership grants never count as successful sales.
Abyss.CollectionAchievements=(()=>{
 const t=(a,b)=>Abyss.HomeData.t(a,b),items=[],add=(id,name,en,desc,de,rules)=>items.push({id:'life_'+id,name:t(name,en),desc:t(desc,de),category:'FIELD COLLECTION',rules});
 for(const n of [1,5,10,20,35,50,75,100])add('find_'+n,'遗物见证者 · '+n,'Relic Witness · '+n,'实际回收 '+n+' 种变卖物。','Recover '+n+' distinct salvage items.',{'salvage.discovered.length':{min:n}});
 for(const n of [1,10,25,50,100,250])add('sell_'+n,'重获用途 · '+n,'Useful Again · '+n,'累计变卖 '+n+' 件遗物。','Sell '+n+' salvage items.',{'salvage.sold':{min:n}});
 for(const n of [30,100,300,1000,3000])add('earn_'+n,'下一顿晚饭 · '+n,'The Next Dinner · '+n,'变卖收入达到 '+n+'。','Earn '+n+' credits from salvage.',{'salvage.earnings':{min:n}});
 for(const n of [1,5,10,25,50])add('trip_'+n,'带回一点过去 · '+n,'Bring Back the Past · '+n,'完成 '+n+' 次有效遗物回收。','Complete '+n+' successful salvage recoveries.',{'salvage.expeditions':{min:n}});
 for(const n of [1,2,3,4,5])add('regions_'+n,'不同的失物 · '+n,'Different Lost Things · '+n,'在 '+n+' 个不同地区找到变卖物。','Find salvage in '+n+' distinct regions.',{'salvage.locations.length':{min:n}});
 add('all_tiers','不可能的收件人','The Impossible Recipient','亲自发现六个稀有等级的遗物。','Discover salvage of all six rarities.',{'salvage.tiers.length':{min:6}});
 Abyss.Data.achievements.push(...items);Abyss.Phase6Data.achievements.push(...items);return {items};
})();
