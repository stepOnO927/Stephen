'use strict';
(()=>{
 const X=Abyss.JackData,{tr,replace,C}=X;
 const entry=(id,title,en,zh,english)=>X.journals[id]={title:tr(title,en),default:tr(zh,english)};
 entry('arrival','维修记录之外','Beyond maintenance','空气接上了。它仍然怕我。两件事都是真的。','The air is connected. It is still afraid of me. Both are true.');
 entry('name','我的名字','My name','我把名字告诉了它，不是权限等级，也不是职位。Jack。','I told it my name. Not a clearance level or job title. Jack.');
 entry('thread','红线','The thread','Jasmine 的记录仍是失踪。我可以告诉它我知道的事，不能把希望写成证据。','Jasmine is still listed as missing. I can tell it what I know. I cannot write hope down as evidence.');
 entry('lock','钥匙','The key','我说了很多理由。钥匙一直在我手里。不能只记下理由。','I gave many reasons. The key was in my hand throughout. I must not record only the reasons.');
 X.journals.lock.leave=tr('我承认我怕它离开。说出来没有让这个怕变得正当。','I admitted I am afraid it will leave. Saying it did not make that fear a justification.');
 X.journals.lock.keep=tr('今天我仍把门关着。保护不是这件事唯一的名字。','Today I still kept the door shut. Protection is not the only name for that.');
 entry('threshold','门槛','The threshold','门开着时，我仍想替它决定第一步。我把手收了回来。','With the door open, I still wanted to decide its first step. I drew my hand back.');
 entry('between','称呼','What to call us','我选了一个词。它没有义务用同一个词回答。','I chose a word. It has no obligation to answer with the same one.');
 entry('injury','被看见','Being seen','我想把手抖藏起来。它先看见了。维修手册没有教过怎么让别人照顾我。','I tried to hide my shaking hands. It noticed first. The maintenance manual never taught me how to let someone care for me.');
 entry('sea','没去过的地方','Somewhere I have never been','我终于承认没见过海。我想带它去的地方，也得第一次自己走过去。','I finally admitted I have never seen the sea. The place I want to take it is somewhere I must reach for the first time too.');
 entry('necessary','必要','Necessary','“有必要。”旧记录里有这句话。我的嘴里也有过。语气相似不代表情况相同，但我不能假装没听见。','“Necessary.” The old record said it. So have I. A similar tone does not mean the circumstances are identical. But I cannot pretend I did not hear it.');
 entry('dream','醒来之后','After waking','我记得梦里的门。先喝水，再检查今天的供电。没有人替这个梦写结论。','I remember the door in the dream. Water first, then today’s power supply. No one has written a conclusion for that dream.');
 entry('evidence','证据不是愿望','Evidence is not a wish','记录多了一页，Jasmine 的去向仍不能靠我想要什么来决定。','Another page in the record. What happened to Jasmine still cannot be decided by what I want.');
 entry('exit','离开','Leaving','我把门从两边都试过了。接下来不是设施能替我们选的事。','I tested the door from both sides. What comes next is something the facility cannot choose for us.');
 const dreams=[
 ['old',9,2,`N|他又站在那扇应急门前。|He stood before the emergency door again.
T|先核对污染数值。先核对权限。先……|Check contamination first. Check clearance first. First...
N|锁孔里没有钥匙。他的手里却很重。|The keyhole was empty. His hand was heavy.
N|门后有人敲了三下。|Someone knocked three times on the other side.
T|我听见了。|I heard it.
N|敲门声停了。警报还在。|The knocking stopped. The alarm continued.
N|Jack 醒来，杯子里的水已经凉了。|Jack woke. The water in his cup had gone cold.`],
 ['mia',32,6,`N|Jasmine 在门后叫他。声音像她十七岁那年。|Jasmine called from behind the door. She sounded seventeen.
J|我在找钥匙。|I'm finding the key.
N|他翻遍每一个口袋。口袋里只有红线。|He searched every pocket. There was only red thread.
N|她没有再催他。|She did not hurry him again.
T|别不说话。|Don't stop talking.
N|他醒来时已经坐起，指甲陷进掌心。|He woke sitting up, his nails pressed into his palm.
N|无线电仍只有底噪。|The radio still carried only static.`],
 ['b07',59,10,`N|这次门后叫他的不是 Jasmine。|This time the voice behind the door was not Jasmine's.
B|Jack。|Jack.
N|他知道钥匙在哪里，却走不到那张桌子。|He knew where the key was, but could not reach the table.
J|等一下。|Wait.
B|你上次也是这样说的。|You said that last time too.
N|门没有变形，走廊也没有变长。|The door did not warp. The corridor did not grow longer.
N|他醒来，先听见培养舱的呼吸。|He woke, and first heard breathing in the chamber.`],
 ['inside',108,17,`N|Jack 站在玻璃里面。|Jack stood inside the glass.
N|外面是一把椅子。{name} 坐在那里，钥匙放在膝上。|Outside was a chair. {name} sat there, the key in its lap.
J|我可以出来吗？|May I come out?
N|它没有回答。不是愤怒，也不是宽恕。|It did not answer. Neither anger nor forgiveness.
N|Jack 等着。|Jack waited.
N|灯管响了一声。他醒来。|A light tube clicked. He woke.
N|他没有立刻去检查锁。|He did not immediately check the lock.`]
 ];
 for(const [id,day,chapter,raw] of dreams){const key='p8_dream_'+id;replace(key,raw,{group:'dream_story',priority:120,title:tr('梦 · 门','Dream · The door'),choices:[],requirements:{day:{min:day}}});X.dreams.push({id:key,day,chapter});}
 replace('p8_tool',`N|扳手从桌边滑落，正好砸在他的脚上。|The wrench slipped off the table and landed on his foot.
J|该死。|Damn.
N|舱里竖起一只耳朵。|An ear rose inside the chamber.
B|新词？|New word?
J|不太有用的词。一般说明我把事情搞砸了。|Not a very useful one. Usually means I messed something up.
N|它把空碗慢慢推下台阶，发出一声轻响。|It slowly pushed its empty bowl down a step. It clinked.
B|该死？|Damn?
J|你倒是学得快。|You learn fast.
T|我花了三天教“谢谢”。这下好了。|Three days teaching “thank you.” Of course this stuck.
N|他捡起碗，没有把这个词从它嘴里罚掉。|He picked up the bowl. He did not punish the word out of its mouth.`,{group:'jack_daily',priority:35,requirements:{day:{min:15},'narrative.languageStage':{min:3}},choices:[C('laugh','笑一下，把工具收好','Laugh once and put the tools away',{jack:{compassion:1},jackFlag:'tool_shared'})]});
 const tool=Abyss.NarrativeData.nodes.find(n=>n.id==='p8_tool');tool.lines[1].exposure='tool';tool.lines[1].language={clean:tr('哎，砸得真准。','Ow. Perfect aim.'),mild:tr('该死。','Damn.'),full:tr('操。','Shit.')};tool.lines[6].language={clean:tr('……砸得真准？','...Perfect aim?'),mild:tr('该死？','Damn?'),full:tr('……操？','...Shit?')};
 replace('p8_sea_admission',`N|它用爪尖指出墙上的海岸照片。|It pointed at the coastal photograph.
B|你去过？|Have you been there?
J|没。|No.
B|一次也没有？|Not once?
J|一次也没有。以前想买辆旧车，沿公路开过去。|Not once. I wanted an old car. Drive down the coast road.
N|他停下，觉得自己的理由忽然很小。|He stopped. His reasons suddenly sounded small.
J|先交房租，先换工作，先考工程资格。后来没有后来了。|Rent first. A different job first. Engineering qualifications first. Then there wasn't a later.
B|所以你也不知道。|So you don't know either.
J|对。我那天讲得像懂很多，其实是临时瞎编。|Right. I sounded knowledgeable that day. I improvised.
B|有自信地撒谎。|Lying with confidence.
J|通常叫维修经验。|Usually called maintenance experience.
N|它看了他一会儿。Jack 没有再替这个笑话解释。|It watched him a while. Jack did not explain the joke away.
B|我们可以一起第一次去。|We could both go for the first time.
T|“一起”不能再变成我替它签的承诺。|“Together” must not become another promise I sign on its behalf.
N|照片里的海很蓝。纸边已经发黄。|The sea in the photo was blue. The edges of the paper had yellowed.
J|我想去。你呢？|I want to go. Do you?
B|我想看了再说。|I want to see it before deciding.
J|行。这很公平。|All right. That's fair.
N|他把地图移到两个人都能碰到的位置。|He moved the map where both could reach it.
T|不是带它去我的回忆里。我们都还没有那段回忆。|Not taking it into my memories. Neither of us has that memory yet.`,{group:'jack_daily',priority:40,requirements:{day:{min:22},'narrative.languageStage':{min:3}},choices:[C('promise','“有路的时候，我们自己决定。”','“When there is a road, we decide for ourselves.”',{jackFlag:'promise_sea',campaignFlag:'promise_sea',jackJournal:'sea',philosophy:{autonomy:1}}),C('uncertain','“我还不知道能不能到，但我不再装作去过。”','“I don’t know if we can reach it. I won’t pretend I’ve been.”',{jack:{honesty:2},jackJournal:'sea'})]});
 replace('p8_alarm',`N|污染报警把屏幕染红。Jack 的手指停在复位键上。|A contamination alarm turned the screen red. Jack's finger stopped over RESET.
T|不是那一天。先看哪个传感器。|Not that day. Find the sensor first.
J|该死，备用通道又卡了。|Damn, the backup line is jammed again.
B|你在怕。|You're afraid.
J|嗯。先别靠门。我查一下。|Yes. Stay clear of the door while I check.
N|他终于看清那是一根断开的探头线。|He finally saw the disconnected sensor wire.
J|故障。不是污染。|A fault. Not contamination.
N|警报停了。他却没有立刻松开桌沿。|The alarm stopped. He did not immediately release the edge of the desk.
B|我可以在这里。|I can stay here.
J|谢谢。不是你的工作，但谢谢。|Thank you. Not your job. But thank you.`,{group:'jack_daily',priority:35,requirements:{day:{min:40},'narrative.languageStage':{min:3}},choices:[C('admit','承认那声警报让我想起过去','Admit what the alarm reminded me of',{jack:{honesty:2,fear:1},jackJournal:'injury'})]});
 const alarm=Abyss.NarrativeData.nodes.find(n=>n.id==='p8_alarm');alarm.lines[2].exposure='alarm';alarm.lines[2].language={clean:tr('备用通道又卡了。先看哪里坏了。','The backup line is jammed. Find the fault first.'),mild:alarm.lines[2].text,full:tr('操，备用通道又卡了。','Shit, the backup line is jammed again.')};
 const evidence=[['confirmed_death','撤离登记附页','Evacuation registry addendum','双重身份核验与医院记录都指向 Jasmine。记录注明她在撤离当日遇难。这份证据属于这条调查路线，不是所有周目的真相。','Two identity checks and a hospital record identify Jasmine. The record states she died on evacuation day. This evidence belongs to this investigation, not every playthrough.'],['survived','后续配给签收','Later ration receipt','手写笔迹和生日都吻合。灰潮两年后，Jasmine 曾领取配给。她现在在哪里，记录没有说。','The handwriting and birth date match. Jasmine collected rations two years after Grey Tide. The record does not say where she is now.'],['transmission','未确认电台呼号','Unconfirmed radio call sign','呼号和她常用的缩写相近。声音经过中继变形，没有足够证据确认说话的人。','The call sign resembles her initials. The relay distorted the voice. There is not enough evidence to identify the speaker.'],['project','幸存者迁移目录','Survivor transfer directory','Project Abyss 处理过一批撤离者资料，其中一条身份残缺的记录包含她的生日。不能直接认定是她。','Project Abyss processed evacuee records. One incomplete identity contains her birth date. That alone does not identify her.']];
 for(const [id,title,en,zh,eng]of evidence){X.evidence.push({id,title:tr(title,en),text:tr(zh,eng)});const req=id==='confirmed_death'?{'campaign.flags.hospital':{min:1}}:id==='survived'?{'campaign.flags.medicine_return':{min:1}}:id==='transmission'?{'campaign.flags.radio_fixed':{min:1}}:{'narrative.hiddenChapters.length':{min:1}};replace('p8_mia_'+id,`N|${zh}|${eng}
T|先读完。不要先选自己想信的那句话。|Read to the end. Don't choose the sentence I want to believe first.
N|Jack 把日期、来源和缺失的部分分别抄下来。|Jack copied the date, source, and missing portions separately.
B|你要停一下吗？|Do you need to stop?
J|要。陪我坐一会儿，好吗？|Yes. Sit with me a while?
N|记录没有替他回答明天该去哪里。|The record did not answer where he should go tomorrow.`,{group:'secret',secret:'m',title:tr('隐藏档案 M · '+title,'Hidden file M · '+en),priority:90,requirements:{day:{min:60},'narrative.languageStage':{min:4},...req},choices:[C('keep','保留证据，注明它能证明什么','Keep the evidence and note what it can establish',{miaEvidence:id,jackJournal:'evidence',jack:{honesty:2}})]});}
})();
