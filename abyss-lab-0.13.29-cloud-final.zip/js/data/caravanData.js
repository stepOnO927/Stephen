'use strict';
Abyss.CaravanData=(()=>{
 const english={},t=(zh,en)=>(english[zh]=en,zh),tiers=['common','uncommon','rare','epic','legendary','anomalous'];
 const rows=[
 ['cards','扑克牌','Playing Cards','uncommon','comfort',45,'五十二张塑封纸。文明曾经为了更奇怪的理由活下来。','Fifty-two laminated cards. Civilization survived for stranger reasons.'],
 ['chess','缺角棋盘','Chipped Chess Set','uncommon','comfort',60,'缺掉的马用螺帽代替。谁先走仍值得争论。','A nut replaces the missing knight. Who moves first still matters.'],
 ['comic','旧漫画','Old Comic','common','comfort',18,'最后三页被人拿去垫窗。英雄的结局暂时没有了。','The final three pages seal a window. The hero has no ending yet.'],
 ['dice','骨白骰子','Bone-White Dice','common','comfort',20,'边角磨圆，有人每天把它放在同一个口袋。','Rounded edges; someone kept it in the same pocket every day.'],
 ['music','完整音乐播放器','Intact Music Player','rare','electronics',260,'耳机一侧不响，但那首歌还能唱完。','One ear is silent, but the song reaches its end.'],
 ['console','旧掌机','Old Handheld Console','epic','electronics',640,'只剩一个存档，名字被磨掉了。','One save remains. Its name has worn away.'],
 ['camera','胶片相机','Film Camera','rare','electronics',220,'取景框里没有辐射读数，只有远处的人。','The viewfinder shows no radiation readings, only distant people.'],
 ['tape','广播剧磁带','Radio Drama Tape','uncommon','comfort',70,'雨声是录制的。Jack 仍把窗关上。','The rain is recorded. Jack shuts the window anyway.'],
 ['coffee','密封咖啡','Sealed Coffee','rare','food',120,'香味让排队的人突然都想起自己的厨房。','Its scent makes the queue remember their kitchens.'],
 ['chocolate','未融化巧克力','Unmelted Chocolate','uncommon','food',55,'包装承诺幸福。里面只有糖，可今晚也足够。','The wrapper promises happiness. There is only sugar, enough for tonight.'],
 ['fruit','温室鲜果','Greenhouse Fruit','uncommon','food',40,'摸起来没有金属的温度。','It does not feel like metal.'],
 ['medicine','封存药包','Sealed Medicine','uncommon','medicine',65,'批号还在。护士坚持先检查封口。','The batch number remains. The nurse checks the seal first.'],
 ['soap','干净肥皂','Clean Soap','common','supplies',25,'不是消毒剂。洗完以后只是像一个普通人。','Not disinfectant. Afterwards you simply smell like a person.'],
 ['socks','干净袜子','Clean Socks','common','supplies',28,'不必解释它为什么比勋章更受欢迎。','No explanation is needed for why these beat a medal.'],
 ['paper','打印纸','Printer Paper','common','supplies',15,'行政员数了两遍，画画的孩子只看颜色。','A clerk counts twice. A child only sees blank space.'],
 ['pen','防漏钢笔','Sealed Pen','uncommon','supplies',48,'它还能写出没有批准过的句子。','It can still write sentences nobody authorized.'],
 ['battery','军用电池','Military Battery','rare','electronics',180,'外壳满是贴纸，容量比所有承诺可靠。','Covered in stickers, its capacity outlasts most promises.'],
 ['radio','修复收音机','Repaired Radio','rare','electronics',200,'调到空频段时，它终于很安静。','On an empty band it is finally quiet.'],
 ['cigarettes','旧世界香烟','Old-World Cigarettes','rare','adult',150,'伤肺，适合易物。干燥的烟丝不能治疗焦虑。','Bad for lungs, useful for barter. Dry tobacco does not cure anxiety.'],
 ['alcohol','烈酒小瓶','Small Spirits Bottle','uncommon','adult',50,'标签劝你庆祝。瓶口闻起来像逃避。','The label invites celebration. The neck smells of avoidance.'],
 ['field','野外电脑','Rugged Field Computer','rare','computer',900,'为了撑过战争制造。看起来它成功了。','Built to survive war. Apparently it succeeded.'],
 ['laptop','能用的笔记本','Working Laptop','epic','computer',1800,'电池能撑十一分钟。在废土，这叫奢侈。','Eleven minutes of battery. Here that counts as luxury.'],
 ['gaming','旧世界游戏电脑','Old-World Gaming PC','legendary','computer',4800,'开机声比这间屋子的历史更早。','Its startup sound predates this room.'],
 ['server','军用野外服务器','Military Field Server','legendary','computer',5400,'加固外壳保护的，也许只是一个人的工资表。','Its armor may protect nothing more than somebody’s payroll.'],
 ['terminal','研究终端核心','Research Terminal Core','legendary','computer',6000,'档案入口还在，授权人却不在了。','The archive door remains; its authorizer does not.'],
 ['jack','Jack 的账户','Computer: JACK Account','anomalous','computer',9500,'密码框在你碰键盘前就消失了。','The password box disappears before you touch the keyboard.'],
 ['tomorrow','明日广播接收器','Tomorrow Receiver','anomalous','electronics',8200,'预报的是明天，却在你的回答之前播完。','It forecasts tomorrow and finishes before your reply.'],
 ['sealed','不可扫描封箱','Unscannable Box','anomalous','collectible',7600,'检验单写着空。搬运的人没有同意。','The inspection calls it empty. The porter disagrees.'],
 ['watch','古董怀表','Antique Watch','epic','collectible',760,'秒针走着，刻在背面的名字已经不走了。','The second hand moves. The engraved name does not.'],
 ['projector','能用的放映机','Working Projector','epic','electronics',1200,'需要一面白墙，还有愿意坐下来的人。','Needs a white wall and people willing to sit.'],
 ['ammo','封装弹药','Packed Ammunition','uncommon','combat',90,'商队防卫储备，只以抽象战斗补给使用。','Caravan defense supplies, used only as abstract combat resources.'],
 ['repair','维修套件','Repair Kit','uncommon','tools',80,'没有新零件，只有把旧东西留下来的办法。','No new parts, only ways to keep old things.'],
 ['parts','武器零件箱','Weapon Parts','rare','tools',180,'件件来自不同年份，仍能用于既有装备维修。','Different years, still usable for existing gear repairs.'],
 ['armor','护甲板','Armor Plates','rare','combat',240,'上一位主人写了回家的地址。','The last owner wrote a home address on them.']
 ];
 const goods=rows.map(([key,name,en,rarity,category,price,lore,englishLore],i)=>({id:'cv_'+key,key,name,en,rarity,category,price,lore,englishLore,visual:{family:category,variant:i},gate:tiers.indexOf(rarity)>=4?55:tiers.indexOf(rarity)>=3?35:0}));
 const caravans=[['ashline','灰线商队','Ashline','civic','Mara Voss',['glassfield','ironhaven','switchyard'],['supplies','tools'],2,0],['ironmule','铁骡','Iron Mule','iron','Gray',['ironhaven','switchyard','hollowwing'],['combat','tools','weapon'],4,20],['last','最后经销人','Last Dealer','independent','Old June',['lantern','hollowwing','glassfield'],['computer','collectible','electronics'],3,15],['sunset','落日行商','Sunset Traders','garden','June Harrow',['glassfield','lantern','ironhaven'],['food','medicine','comfort'],2,0],['frequency','死频率','Dead Frequency','signal','Ricket',['deadchannel','switchyard','hollowwing'],['electronics','computer'],3,10],['black','黑车厢','Black Wagon','black','Worm',['hollowwing','deadchannel','lantern'],['adult','collectible','computer','weapon'],4,0]].map(([id,name,en,faction,merchant,route,specialties,security,gate])=>({id,name:t(name,en),en,faction,merchant,route,specialties,security,gate}));
 const situations=[['late','断桥让车队晚了两天。','A broken bridge delayed the caravan.','delay'],['attack','路边有人呼救，武装车辆堵住了前车。','A cry comes from the road; armed vehicles block the lead wagon.','attack'],['wounded','车上多了几个伤员，药价牌被翻过去。','Wounded travelers ride inside; medicine price tags are reversed.','epidemic'],['stolen','封条被割开，司机拒绝猜测是谁做的。','The seal is cut. The driver refuses to guess who did it.','loss'],['apprentice','学徒拿着旧账簿，座位上的外套没人穿。','An apprentice carries the ledger. Nobody wears the coat on the seat.','successor'],['find','一个旧箱里传来开机的轻响。','A crate makes a quiet startup sound.','stock'],['storm','黑市灯在灰尘里亮起，又很快被帆布盖住。','Black-market lamps glow in dust, then vanish under canvas.','hide'],['remember','商人认出了 Jack，先问上一次那些人还好吗。','The merchant recognizes Jack and asks about the people from last time.','relation'],['route','旧路不再安全，车队换了一张路线图。','The old road is unsafe. The caravan replaces its map.','route'],['recognize','B-07 在一个旧物前停下来，Jack 没有替它解释。','B-07 pauses before an old object. Jack does not explain for it.','memory']];
 const details=[['司机把水分给最后一辆车。','The driver shares water with the final wagon.'],['账簿夹着一张家庭合照。','A family photo lies inside the ledger.'],['守卫检查轮胎，没看你的钱袋。','The guard checks tires, not your purse.'],['有个纸箱写着不要丢掉。','A crate says do not throw away.'],['车上的灯留了一盏给后来的人。','One wagon light is left for late arrivals.']];
 const events=situations.flatMap(([key,zh,en,kind])=>details.map(([a,b],i)=>({id:'road_'+key+'_'+i,kind,text:t(zh+' '+a,en+' '+b)})));
 for(const g of goods){english[g.name]=g.en;english[g.lore]=g.englishLore;Abyss.ExpeditionData.loot.push({id:g.id,name:g.name,category:'CARAVAN',rarity:g.rarity.toUpperCase(),description:g.lore});}
 const weapons=[['weapon_service','rare',600],['weapon_scatter','epic',1500],['weapon_railgun','legendary',4400]].map(([weapon,rarity,price])=>({id:'cv_'+weapon,weapon,name:Abyss.WeaponData.weapons.find(w=>w.id===weapon).name,rarity,price,category:'weapon',gate:rarity==='legendary'?60:20,visual:{family:'weapon'},lore:t('随车队修复并留下序列记录的防卫装备。','Repaired caravan defense gear with a recorded provenance.')}));
 goods.push(...weapons);for(const id of ['furniture_chair_1','furniture_lamp_1','furniture_table_1','object_radio']){const d=[...Abyss.ContainmentData.furniture,...Abyss.ContainmentData.objects].find(x=>x.id===id);if(!d)continue;const g={id:'cv_'+id,name:d.name,en:d.en,rarity:d.rarity,category:id.startsWith('object_')?'collectible':'tools',price:d.cost*3,furniture:id,gate:15,lore:d.lore||d.description,visual:{family:d.kind,variant:d.variant}};goods.push(g);Abyss.ExpeditionData.loot.push({id:g.id,name:g.name,category:'CARAVAN',rarity:g.rarity.toUpperCase(),description:g.lore});}

 for(const g of goods.filter(g=>g.category==='computer')){g.furniture='computer_'+g.key;Abyss.ContainmentData.furniture.push({id:g.furniture,name:g.name,en:g.en,kind:'computer',variant:goods.indexOf(g),rarity:g.rarity,cost:g.price,description:g.lore,englishDescription:g.englishLore,boundingBox:[.8,.5,.65],floorFootprint:[.8,.5],height:.65,placementType:'surface',surfaceRequirement:true,rotationAllowed:true,supportHeight:0,stackable:false,caravanOnly:true});}
 const conditions=['damaged','worn','working','good','pristine','unknown'];
 const achievements=[['trade','第一笔交易','First Trade'],['regular','商队常客','Caravan Regular'],['luxury','旧世界奢侈品','Old-World Luxury'],['favorite','经销人的熟客','Dealer’s Favorite'],['black','黑市顾客','Black Market Customer'],['computer','它还能工作','Still Works'],['cards','完整一副','Full Deck'],['cigarettes','坏习惯','Bad Habit'],['guardian','道路守护者','Road Guardian'],['stolen','来路不明','That’s Stolen']].map(([id,name,en])=>({id:'cv_achievement_'+id,name:t(name,en),desc:t('留下一段商队交往记录。','A record of life with the caravans.'),rules:{'caravan.never':{min:1}}}));Abyss.Data.achievements.push(...achievements);
 Abyss.I18n.register(english);return {goods,caravans,tiers,conditions,events,achievements,english};
})();
