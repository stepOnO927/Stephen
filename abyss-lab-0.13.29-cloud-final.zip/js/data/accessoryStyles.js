'use strict';
// Art direction is independent of rarity. All palettes remain replaceable data.
Abyss.Data.accessoryStyles={
 lab:{label:'深海研究制服',base:'#344c67',light:'#708ba4',shade:'#1a2b42',trim:'#eee5ca',metal:'#c6a16a'},
 rain:{label:'雨夜邮差',base:'#d1a348',light:'#f4d785',shade:'#896529',trim:'#fff0c7',metal:'#795739'},
 forest:{label:'苔庭手作',base:'#62856c',light:'#a3bd89',shade:'#304d43',trim:'#e9dfbf',metal:'#c0a46d'},
 vintage:{label:'旧时光藏品',base:'#945361',light:'#d49a99',shade:'#512b42',trim:'#f0d8b2',metal:'#d1a76d'},
 lunar:{label:'月潮仪式',base:'#777699',light:'#bbb5d6',shade:'#36384f',trim:'#eee8dc',metal:'#d2bb82'},
 industrial:{label:'退役工业标本',base:'#475961',light:'#8caaa9',shade:'#23313c',trim:'#d9d9c5',metal:'#d29c60'},
 void:{label:'无名回声',base:'#4d3b67',light:'#9985b9',shade:'#211d36',trim:'#d1c1da',metal:'#9798b9'}
};
Abyss.AccessoryStyle={
 get(a){if(a.visual.renderer==='atelier'){const [base,light,shade,trim,metal]=Abyss.AtelierData.palettes[a.visual.palette];return {label:'远行裁缝工坊',base,light,shade,trim,metal,family:'atelier'};}const r=a.visual.renderer;
 const family=a.rarity==='anomalous'?'void':/halo|moonmask|prism|compass|apparatus|voidcrown/.test(r)||['oracle_lens','guardian_mantle','ceremonial_cloth'].includes(a.id)?'lunar':/rain/.test(a.id)||a.id==='paper_crown'?'rain':/mushroom|woven|friendship|ribbon_crown/.test(a.id)?'forest':/ribbon|scarf|bell|monocle|tophat|sweater|key/.test(r)?'vintage':/helmet|restraint|harness|armor|tank|container|goggles|ring/.test(r)?'industrial':'lab';
 return {...Abyss.Data.accessoryStyles[family],family};
 }
};
