'use strict';
Abyss.Data.rarities = [
 {id:'common',name:'COMMON',zh:'常见',color:'#9eaaa9',rank:0},
 {id:'uncommon',name:'UNCOMMON',zh:'少见',color:'#90b49c',rank:1},
 {id:'rare',name:'RARE',zh:'稀有',color:'#8cbbcf',rank:2},
 {id:'epic',name:'EPIC',zh:'史诗',color:'#b5a0ce',rank:3},
 {id:'legendary',name:'LEGENDARY',zh:'传说',color:'#ceb780',rank:4},
 {id:'anomalous',name:'ANOMALOUS',zh:'异常',color:'#b4b6ca',rank:5}
];
Abyss.Data.slots = {head:'头部',face:'面部',neck:'颈部',body:'身体',back:'背部',tail:'尾部',charm:'挂饰'};
// Definitions are immutable content; ownership/equipment are derived from save state.
// visual.renderer selects replaceable procedural art; visual.asset may point to PNG/WebP.
Abyss.Data.accessories = (() => {
 const starter={type:'starter',hint:'实验室迎新物资'};
 const shop=price=>({type:'shop',price,hint:'衣橱 · 补给商店'});
 const explore=(place,visits)=>({type:'explore',place,visits,hint:`${{sewer:'下水道',factory:'废弃工厂',forest:'地下森林',city:'城市夜晚',ruins:'实验废墟'}[place]} · 累计探索 ${visits} 次`});
 const milestone=(rules,hint)=>({type:'milestone',rules,hint});
 const event=(id,hint)=>({type:'event',event:id,hint});
 const achievement=id=>({type:'achievement',achievement:id,hint:'完成相关研究成就'});
 const rows=[
 ['research_cap','Research Cap','研究帽','common','head','cap',starter,'帽沿上缝着一个小小的零号标记。','soft'],
 ['paper_crown','Paper Crown','纸皇冠','common','head','crown',shop(12),'用报废观察表折成，背面仍有研究员的笔迹。','silly'],
 ['round_glasses','Round Glasses','圆框眼镜','common','face','glasses',shop(18),'没有度数；它只是想看上去和你一样。','silly'],
 ['plain_collar','Plain Collar','素色项圈','common','neck','collar',starter,'柔软的织带，没有锁扣。','soft'],
 ['id_tag','Identification Tag','身份铭牌','common','charm','tag',starter,'铭牌上写的是名字，而不只是编号。','familiar'],
 ['lab_vest','Laboratory Vest','实验室马甲','common','body','vest',shop(25),'口袋尺寸刚好能装下一颗月露果。','practical'],
 ['cotton_sweater','Cotton Sweater','棉线毛衣','common','body','sweater',shop(20),'袖口略大，穿起来有一点笨拙。','soft'],
 ['canvas_pack','Canvas Backpack','帆布背包','common','back','pack',explore('sewer',1),'第一次走入管道时，在旧检修站找到的小背包。','practical'],
 ['tail_ribbon','Tail Ribbon','尾尖丝带','common','tail','ribbon',shop(10),'会随着它的每一次转身轻轻摆动。','soft'],
 ['tail_marker','Research Marker','尾部标记','common','tail','tag',explore('factory',1),'工厂的旧标签，已经改写成零号的名字。','practical'],
 ['tin_bell','Tin Bell','小锡铃','common','neck','bell',shop(14),'声音很轻，不会惊扰它的梦。','noisy'],
 ['button_charm','Dinner Button','晚餐纽扣','common','charm','button',achievement('firstmeal'),'第一顿晚餐之后，在围巾里发现的小纽扣。','familiar'],
 ['rain_hood','Rain Hood','防雨兜帽','common','head','hood',explore('forest',1),'林地观察员留下的防水布。','soft'],
 ['dust_scarf','Dust Scarf','防尘围巾','common','neck','scarf',explore('city',1),'带着城市夜风气味的旧围巾。','soft'],
 ['sample_pouch','Sample Pouch','样本小袋','common','charm','pouch',explore('ruins',1),'里面没有样本，只有一枚干净的石子。','practical'],
 ['mushroom_hat','Mushroom Hat','菌菇帽','uncommon','head','mushroom',explore('forest',3),'柔软菌盖制成的帽子，仍保留着林地的清香。','strange'],
 ['tiny_top_hat','Tiny Top Hat','迷你礼帽','uncommon','head','tophat',shop(45),'像是为一位很小的绅士准备的。','silly'],
 ['cracked_goggles','Cracked Goggles','裂纹护目镜','uncommon','face','goggles',explore('factory',3),'一道裂纹记录了旧工厂里的某次意外。','practical'],
 ['red_ribbon','Old Red Ribbon','旧红丝带','uncommon','neck','ribbon',explore('sewer',3),'发现时系在废弃管道上。它似乎格外不愿取下这条丝带。','familiar'],
 ['raincoat','Raincoat','黄色雨衣','uncommon','body','raincoat',shop(40),'在漫长雨夜里像一小片温暖的灯光。','soft'],
 ['oxygen_tank','Oxygen Tank','微型氧气罐','uncommon','back','tank',explore('sewer',5),'指针停在绿色区域，只作为纪念品佩戴。','practical'],
 ['tail_bell','Tail Bell','尾铃','uncommon','tail','bell',shop(32),'轻轻走路时不会响，开心时却会暴露心情。','noisy'],
 ['copper_monocle','Copper Monocle','铜框单片镜','uncommon','face','monocle',shop(38),'一根细链绕过耳侧，带着古怪的庄重。','silly'],
 ['key_charm','Hidden Room Key','暗室钥匙','uncommon','charm','key',event('room','发现并处理墙后房间事件'),'钥匙再也打不开别的门，但它记得那次发现。','familiar'],
 ['woven_cape','Woven Cape','手织披肩','uncommon','body','cape',milestone({'history.care':{min:8}},'累计照护 8 次'),'耐心与棉线一起织成的披肩。','soft'],
 ['safety_helmet','Safety Helmet','安全帽','uncommon','head','helmet',explore('factory',5),'边缘有擦痕，里面却贴着可爱的名字标签。','practical'],
 ['friendship_knot','Friendship Knot','友谊结','uncommon','charm','knot',milestone({'stats.loyalty':{min:80},'history.care':{min:5}},'忠诚达到 80，并累计照护 5 次'),'它用笨拙的爪子把两根线系在了一起。','familiar'],
 ['respirator','Respirator','呼吸面罩','rare','face','mask',shop(75),'更换了软垫的旧面罩，只保留装饰用途。','practical'],
 ['restraint_collar','Restraint Collar','实验约束环','rare','neck','restraint',milestone({'stats.loyalty':{max:20},'history.experiment':{min:3}},'信任极低且经历多次实验；也可在工厂探索 8 次找回旧样本'),'锁已拆除，环内的划痕仍然清晰。','restraint'],
 ['containment_harness','Containment Harness','收容束带','rare','body','harness',milestone({'history.experiment':{min:6}},'完成 6 次实验观察'),'一副退役的安全束带，不再限制它的行动。','restraint'],
 ['artificial_wings','Artificial Wings','人造双翼','rare','back','wings',explore('city',5),'商店橱窗里的舞台道具，被它当成了飞行的梦想。','silly'],
 ['brass_tail_ring','Brass Tail Ring','铜质尾环','rare','tail','ring',explore('ruins',3),'内侧刻着已无人认识的研究编号。','practical'],
 ['lunar_mask','Lunar Mask','月相面具','rare','face','moonmask',event('dream','回应深渊之梦'),'面具上的月相与地面的月亮并不一致。','strange'],
 ['specimen_container','Specimen Container','标本匣','rare','back','container',explore('ruins',5),'透明匣内装着它收集的无害发光苔。','strange'],
 ['navigator_star','Navigator Star','领航星','rare','charm','star',achievement('explorer'),'为五次共同归来而留下的纪念。','familiar'],
 ['ribbon_crown','Ribbon Crown','丝带花冠','rare','head','crown',milestone({'stats.loyalty':{min:90},'history.care':{min:12}},'忠诚达到 90，并累计照护 12 次'),'你编好最后一个结时，它把头轻轻低了下来。','soft'],
 ['ceremonial_cloth','Ceremonial Cloth','成长礼衣','rare','body','robe',achievement('mature'),'记录第一次成熟的日期，布料仍带着新裁的味道。','familiar'],
 ['containment_helmet','Containment Helmet','收容头盔','epic','head','helmet',milestone({'history.experiment':{min:10}},'完成 10 次实验观察'),'退役头盔的灯光，像一圈安静的星。','restraint'],
 ['cyber_visor','Cybernetic Visor','义体视镜','epic','face','visor',milestone({'stats.intelligence':{min:60},'history.train':{min:10}},'智力达到 60，累计训练 10 次'),'显示的不是数据，而是它画下的简单符号。','practical'],
 ['memory_chain','Memory Chain','记忆链','epic','neck','chain',{type:'memory',memory:'saved_life',hint:'在它重伤时亲手治疗它'},'每个链环都刻着一次仍然留在身边的选择。','familiar'],
 ['experimental_armor','Experimental Armor','实验装甲','epic','body','armor',explore('factory',10),'拆去了所有动力单元，只留下漂亮的外壳。','practical'],
 ['mechanical_apparatus','Mechanical Apparatus','机械观测架','epic','back','apparatus',milestone({'history.experiment':{min:16}},'完成 16 次实验观察'),'缓缓转动的观察环不再测量任何东西。','strange'],
 ['phosphor_tail','Phosphor Tail Cuff','荧光尾扣','epic','tail','ring',milestone({'mutations.length':{min:3}},'发现 3 种突变'),'随着呼吸变亮的微光，不来自电源。','strange'],
 ['prism_charm','Merchant Prism','商人棱镜','epic','charm',{renderer:'prism'},{type:'merchant',price:95,hint:'商人来访后的两天内，在衣橱补给商店购买'},'商人说它没有价值，离开时却回头看了三次。','strange'],
 ['broken_halo','Broken Halo','破碎光环','legendary','head','halo',explore('ruins',12),'从第四实验舱回收。断口始终无法靠拢。','strange'],
 ['oracle_lens','Oracle Lens','先知目镜','legendary','face','visor',{type:'form',form:'oracle',hint:'见证星瞳先知成熟形态'},'镜片背面刻着它尚未说出口的话。','strange'],
 ['guardian_mantle','Guardian Mantle','守护者披风','legendary','body','robe',{type:'form',form:'guardian',hint:'见证翡翠守护者成熟形态'},'它第一次替你挡住冷风时，你知道尺寸刚刚好。','familiar'],
 ['night_compass','Night Compass','无夜罗盘','legendary','charm','compass',{type:'form',form:'wanderer',hint:'见证夜幕游灵成熟形态'},'指针永远指向它认得的家。','familiar'],
 ['absent_crown','Absent Crown','不存在的王冠','anomalous','head','voidcrown',{type:'form',form:'abyss',hint:'未知'},'照片中没有这顶王冠。只有它的影子在点头。','strange'],
 ['echo_thread','Echo Thread','回声之线','anomalous','tail','thread',{type:'memory',memory:'escaped',rules:{'stats.loyalty':{min:80}},hint:'未知'},'它回来很久以后，你才发现尾尖系着一段没有尽头的线。','strange']
 ];
 const colors=['#98aaa4','#a4b59a','#94b8c7','#b3a3c8','#cdb788','#aaa5c1'];
 return rows.map(([id,name,zh,rarity,slot,art,unlock,description,type],i)=>({
  id,name,zh,description,rarity,slot,unlock,type,secret:rarity==='anomalous',
  lore:description,visual:{layer:`accessory-${slot}`,renderer:typeof art==='string'?art:art.renderer,asset:null,color:colors[Abyss.Data.rarities.findIndex(r=>r.id===rarity)],accent:i%2?'#9dbcc0':'#c4b2a3',variant:i%3},
  alternatives:({
   restraint_collar:[explore('factory',8)],
   oracle_lens:[milestone({day:{min:30},'stats.intelligence':{min:85}},'第 30 天后，智力达到 85')],
   guardian_mantle:[milestone({day:{min:30},'stats.loyalty':{min:95},'history.care':{min:40}},'第 30 天后，忠诚达到 95，累计照护 40 次')],
   night_compass:[milestone({day:{min:30},'history.explore':{min:40}},'第 30 天后，累计探索 40 次')],
   absent_crown:[milestone({day:{min:40},'stats.pollution':{min:80},'stats.intelligence':{min:70}},'未知')]
  })[id]||[]
 }));
})();
Abyss.Data.outfitSets = [
 {id:'lab',name:'小小研究助理',items:['research_cap','round_glasses','lab_vest','id_tag'],effect:'lab',text:'它把马甲口袋拍平，认真模仿你记录数据的动作。'},
 {id:'containment',name:'收容档案',items:['restraint_collar','containment_harness','id_tag'],effect:'containment',text:'舱壁识别出旧式标记，点亮了过去的诊断刻度。束带已经没有锁。'},
 {id:'rain',name:'雨天同行',items:['rain_hood','raincoat','canvas_pack'],effect:'rain',text:'它晃了晃背包，像在等你说出发。玻璃上亮起细小的雨光。'},
 {id:'home',name:'温暖的归途',items:['cotton_sweater','red_ribbon','friendship_knot'],effect:'home',text:'它在柔软的毛衣里缩了缩，丝带随着安心的呼吸轻轻摆动。'}
];
