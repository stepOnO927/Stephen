'use strict';
Abyss.Actions = (() => {
 const costs={feed:1,train:1,companion:1,experiment:2,explore:2,heal:1,reward:1,punish:1,search:2,rest:0};
 const result=(ok,message)=>({ok,message});
 function refuse(s,type){
   if(!['train','experiment','explore'].includes(type)||s.stats.loyalty>=30)return false;
   if(Abyss.Util.random(s)>.18+(30-s.stats.loyalty)*.007+Math.min(.04,s.personality.independent*.0004))return false;
   s.ap--;Abyss.State.log(s,'它退后了几步，拒绝这次命令。安抚它或许比继续施压更好。消耗 1 AP，未收取费用。','warning');return true;
 }
 function rest(s){
   if(s.mode==='story'&&s.campaign?.creatureAlive===false){s.day++;s.age++;s.ap=5;s.money+=22;Abyss.State.log(s,'空实验室的又一天。你保留它的物件，继续调查。','story');return result(true,'独自继续的一天');}
   const ignored=!s.caredToday&&!s.fedToday;
   Abyss.State.effects(s,{hunger:18,health:4,mood:-3,stability:3});
   if(s.mutations.includes('regen'))Abyss.State.effects(s,{health:5});
   if(ignored){Abyss.State.effects(s,{loyalty:-5,mood:-4});s.history.neglect++;s.resentment=Abyss.Util.clamp(s.resentment+2);}
   if(s.stats.hunger>=75){Abyss.State.effects(s,{health:-14,loyalty:-8,mood:-8});s.resentment=Abyss.Util.clamp(s.resentment+3);Abyss.State.log(s,'饥饿让它彻夜不安：健康、心情与忠诚下降。','warning');}
   if(s.stats.pollution>60)Abyss.State.effects(s,{health:-Math.ceil((s.stats.pollution-60)/5),stability:-5});
   s.day++;s.age++;s.ap=5;s.money+=22;s.experimentsToday=0;s.caredToday=false;s.fedToday=false;
   Abyss.State.log(s,'新的一天。行动点恢复为 5，到账研究补助 ₵ 22。');
   if(s.stats.health<=12&&!(s.mode==='story'&&s.stats.health<=0)){s.stats.health=30;s.stats.hunger=Math.min(s.stats.hunger,60);s.money=Math.max(0,s.money-12);Abyss.State.log(s,'紧急医疗介入：健康恢复至 30，提供应急营养，扣除最多 ₵ 12。','warning');}
   const rescued=!!s.awaySince&&s.day-s.awaySince>=2;
   if(rescued){s.awaySince=null;Abyss.State.effects(s,{loyalty:8,health:5});Abyss.State.log(s,'救援队找到了零号。它回到培养舱，但重新建立信任仍需要时间。','story');}
   if(!rescued)Abyss.Events.incident(s);
   if(!s.awaySince){Abyss.Mutations.attempt(s);Abyss.Mutations.mature(s);Abyss.Events.trigger(s);}
   return result(true,'新的一天 · 行动点已恢复');
 }
 function run(s,type,payload){
   if(!(type in costs))return result(false,'未知操作。');
   if(s.pendingEvent)return result(false,'请先处理正在发生的事件。');
   if(s.awaySince&&!['search','rest'].includes(type))return result(false,'零号尚未回来。请先寻找它。');
   if(type==='search'&&!s.awaySince)return result(false,'零号就在培养舱中。');
   if(s.ap<costs[type])return result(false,'行动点不足，休息后再继续。');
   let item=null,price=0;
   if(type==='feed'){
     item=Abyss.Data.foods.find(f=>f.id===payload);if(!item)return result(false,'未知食物。');price=s.inventory[item.id]>0?0:item.price;
   }
   if(type==='train'){item=Abyss.Data.training.find(t=>t.id===payload);if(!item)return result(false,'未知训练。');if(s.stats.health<20)return result(false,'健康过低，先治疗或休息。');}
   if(type==='experiment'){item=Abyss.Data.experiments.find(e=>e.id===payload);if(!item)return result(false,'未知实验。');price=item.price;if(s.stats.health<25)return result(false,'健康过低，无法安全开展实验。');}
   if(type==='explore'){item=Abyss.Data.locations.find(l=>l.id===payload);if(!item)return result(false,'未知地点。');if(s.day<item.unlock)return result(false,`第 ${item.unlock} 天开放此区域。`);if(s.stats.health<25)return result(false,'健康过低，先治疗或休息。');}
   if(type==='feed'&&price&&s.climate)price=Math.ceil(price*Abyss.Climate.factor(s,item.id==='fruit'?'fruit':'food'));if(type==='heal')price=s.climate?Math.ceil(16*Abyss.Climate.factor(s,'medicine')):16;if(type==='reward')price=8;
   if(item?.technology&&!Abyss.Research.has(s,item.technology))return result(false,'研究协议未解锁。');
   if(item?.huntRecipe&&!s.hunt.recipes.includes(item.id)&&!(s.inventory[item.id]>0))return result(false,Abyss.HomeData.t('先发现远征食谱。','Discover this expedition recipe first.'));
   if(s.money<price)return result(false,'资金不足。休息可获得补助，已有库存可免费喂食。');
   if(type==='rest')return rest(s);
   if(refuse(s,type))return result(true,'它拒绝了命令 · 消耗 1 AP');
   s.ap-=costs[type];s.money-=price;
   switch(type){
    case 'feed':
     if(!price)s.inventory[item.id]--;Abyss.State.effects(s,item.effects);s.bias[item.bias]++;s.history.feed++;s.fedToday=true;
     Abyss.State.log(s,`喂食${item.name}。${price?`购买花费 ₵ ${price}。`:'使用库存 1 份。'}`);break;
    case 'train':Abyss.State.effects(s,item.effects);s.history.train++;Abyss.State.log(s,`完成${item.name}，${Abyss.Data.training.find(x=>x.id===payload).desc}`);break;
    case 'companion':
     Abyss.State.effects(s,{loyalty:9,mood:12,stability:4});s.history.care++;s.caredToday=true;s.bias.gentle++;Abyss.State.log(s,'你坐在培养舱旁，耐心听它咕噜咕噜地说话。忠诚 +9，心情 +12。');break;
    case 'heal':
     Abyss.State.effects(s,{health:25,loyalty:5,pollution:-6});s.history.care++;s.caredToday=true;Abyss.State.log(s,'完成治疗与污染清理。健康 +25，忠诚 +5，污染 −6。');break;
    case 'reward':
     Abyss.State.effects(s,{loyalty:7,mood:10,hunger:-5});s.history.care++;s.caredToday=true;Abyss.State.log(s,'你奖励了它一份甜味小点心。忠诚 +7，心情 +10。');break;
    case 'experiment':
     Abyss.State.effects(s,item.effects);s.resentment=Abyss.Util.clamp(s.resentment+item.resentment);s.history.experiment++;s.bias[item.bias]++;s.experimentsToday++;
     if(s.experimentsToday>1){Abyss.State.effects(s,{loyalty:-6,stability:-5});s.resentment=Abyss.Util.clamp(s.resentment+6);Abyss.State.log(s,'当日重复实验令它更加恐惧。忠诚与稳定性额外下降。','warning');}
     Abyss.State.log(s,`进行了${item.name}。基因表达发生波动。`,'warning');Abyss.Mutations.attempt(s,item.mutationBonus);break;
    case 'explore':return result(true,Abyss.Exploration.run(s,item));
    case 'punish':Abyss.State.effects(s,{loyalty:-16,mood:-18,stability:3});s.resentment=Abyss.Util.clamp(s.resentment+18);s.history.punish++;Abyss.State.log(s,'强制约束暂时提高了稳定性，却留下了深刻的恐惧。','warning');break;
    case 'search':
     if(Abyss.Util.random(s)<.75){s.awaySince=null;Abyss.State.effects(s,{loyalty:7,mood:4});Abyss.State.log(s,'你在通风井里找到了零号。它犹豫片刻，还是走向了你。','story');}
     else Abyss.State.log(s,'找到了一些足迹，但零号还在躲藏。可以再次寻找，救援队会在逃跑两天后带它回来。','warning');break;
   }
   return result(true,'操作完成 · 已记录');
 }
 return {run,costs};
})();

