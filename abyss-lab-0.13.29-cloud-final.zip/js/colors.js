'use strict';
// Palette ownership is account-level; worn color belongs to each creature's timeline.
Abyss.Colors=(()=>{
const D=Abyss.ColorData,find=id=>D.colors.find(c=>c.id===id);
function eligible(s,c,source){const rank=D.tiers.findIndex(t=>t.id===c.rarity);if(rank>=1&&source==='daily')return false;if(rank>=3&&source==='daily')return false;if(rank===4&&(s.day<20||s.progress.evolution.stage<2))return false;if(rank===5&&(source!=='experiment'||s.history.experiment<10||s.stats.pollution<70||s.stats.stability>40))return false;return true;}
function observe(before,s,command){const source=before.exploration.active&&!s.exploration.active?'exploration':command.type==='experiment'&&s.history.experiment>before.history.experiment?'experiment':command.type==='rest'?'daily':null;if(!source)return;const random=()=>{const holder={rng:s.colorRng||(s.rng^0x7412abcd)>>>0||1};const value=Abyss.Util.random(holder);s.colorRng=holder.rng;return value;};const rate=source==='exploration'?.35:source==='experiment'?.25:.15;if(random()>=rate)return;const roll=random()*100;let acc=0,tier;for(const t of D.tiers){acc+=t.chance;if(roll<acc){tier=t;break;}}const pool=D.colors.filter(c=>c.rarity===tier.id&&eligible(s,c,source));if(!pool.length)return;const c=pool[Math.floor(random()*pool.length)];if(Abyss.Meta.colorUnlocked(c.id))return;if(Abyss.Meta.grantColor(c.id)){Abyss.State.log(s,'发现新的外观色素：'+c.name+'。已收入衣橱改色收藏。','rare');Abyss.UI?.toast('新颜色 · '+c.name);}}
function command(s,type,id){const c=find(id);if(type==='clear'){s.color=null;return {ok:true,message:'恢复皮肤原色'};}if(!c)return {ok:false,message:'未知颜色'};if(type==='buy'){const price=c.rarity==='common'?8:c.rarity==='uncommon'?35:null;if(price===null)return {ok:false,message:'此颜色需要通过探索或实验发现'};if(Abyss.Meta.colorUnlocked(id))return {ok:false,message:'已经收藏此颜色'};if(s.money<price)return {ok:false,message:'资金不足'};if(!Abyss.Meta.grantColor(id))return {ok:false,message:'收藏保存失败，本次未扣款'};s.money-=price;return {ok:true,message:'颜色已收入收藏'};}if(type==='equip'&&Abyss.Meta.colorUnlocked(id)){s.color=id;return {ok:true,message:'已换色：'+c.name};}return {ok:false,message:'尚未获得此颜色'};}
function render(s,root){
 const c=find(s.color),creature=root.querySelector('[data-creature]'),ns='http://www.w3.org/2000/svg';root.dataset.colorMotion=c?.motion||'still';
 let fill=root.querySelector('[data-body-fill]');if(!fill)return;
 const tag=c?'linearGradient':'radialGradient';if(fill.tagName!==tag){const replacement=document.createElementNS(ns,tag);replacement.id=fill.id;replacement.setAttribute('data-body-fill','');fill.replaceWith(replacement);fill=replacement;}
 for(const a of ['gradientTransform','gradientUnits','x1','x2','y1','y2','cx','cy','r'])fill.removeAttribute(a);fill.innerHTML='';
 const skin=Abyss.Phase6Data.skins.find(k=>k.id===s.skin)?.color||Abyss.Data.forms.find(f=>f.id===s.form)?.color||'#99edc2';
 let edge=root.querySelector('[data-dye-edge]');if(!edge){edge=document.createElementNS(ns,'linearGradient');edge.id=fill.id+'-edge';edge.setAttribute('data-dye-edge','');root.querySelector('defs').appendChild(edge);}
 const shade=(hex,amount)=>'#'+hex.slice(1).match(/../g).map(x=>Math.round(parseInt(x,16)*amount).toString(16).padStart(2,'0')).join('');
 if(c){
  for(const g of [fill,edge]){g.setAttribute('gradientUnits','userSpaceOnUse');g.setAttribute('x1','95');g.setAttribute('y1','115');g.setAttribute('x2','430');g.setAttribute('y2','375');}
  fill.innerHTML=c.stops.map((v,i)=>'<stop offset="'+i/(c.stops.length-1)*100+'%" stop-color="'+v+'"/>').join('');
  edge.innerHTML=c.stops.map((v,i)=>'<stop offset="'+i/(c.stops.length-1)*100+'%" stop-color="'+shade(v,.62)+'"/>').join('');
  if(s.settings.motion&&['flow','prism'].includes(c.motion))for(const g of [fill,edge])g.insertAdjacentHTML('beforeend','<animateTransform attributeName="gradientTransform" type="rotate" from="0 240 245" to="360 240 245" dur="'+(c.motion==='prism'?14:22)+'s" repeatCount="indefinite"/>');
 }else {fill.setAttribute('cx','35%');fill.setAttribute('cy','25%');fill.setAttribute('r','80%');fill.innerHTML='<stop stop-color="'+skin+'"/><stop offset=".45" stop-color="#47a794"/><stop offset="1" stop-color="#163e49"/>';edge.innerHTML='';}
 // One continuous pigment field across every biological layer, including stroke-only organs.
 const biological=['body','limbs','tail','shell','horns','wings','tentacles','organs','glow'];
 const groups=[...creature.children].filter(g=>biological.includes(g.dataset.layer)||g.hasAttribute('data-skin-overlay')||g.hasAttribute('data-evolution-layer')&&g.dataset.evolutionLayer!=='eyes');
 for(const group of groups)for(const el of [group,...group.querySelectorAll('*')]){
  if(['image','text'].includes(el.tagName)||el.closest('[data-dye-detail]'))continue;
  for(const attr of ['fill','stroke']){const original='data-original-dye-'+attr;let value=el.getAttribute(original);if(value===null){value=el.getAttribute(attr);if(value===null)continue;el.setAttribute(original,value);}if(value==='none'||value==='transparent')continue;
   el.setAttribute(attr,c?'url(#'+(attr==='stroke'?edge.id:fill.id)+')':value);
  }
  if(el.getAttribute('data-original-dye-fill')?.includes('belly-fill')){if(!el.hasAttribute('data-original-dye-opacity'))el.setAttribute('data-original-dye-opacity',el.getAttribute('opacity')||'1');el.setAttribute('opacity',c?'.12':el.getAttribute('data-original-dye-opacity'));}
 }
 let errors=root.querySelector('[data-color-errors]');if(!errors){errors=document.createElementNS(ns,'g');errors.setAttribute('data-color-errors','');}creature.appendChild(errors);
 errors.innerHTML=c?.motion==='error'?Array.from({length:24},(_,i)=>{const x=160+(i*37)%145,y=155+(i*29)%185;return '<g transform="translate('+x+' '+y+')" opacity=".8"><rect x="-6" y="-6" width="12" height="12" rx="2" fill="#681827" stroke="#ffc2c8" stroke-width=".6"/><path d="M-2-2L2 2M2-2L-2 2" stroke="#ffe3e5" stroke-width="1.4"/>'+(i%4===0?'<text x="8" y="3" fill="#ffd1d7" font-size="6" font-family="monospace">ERR</text>':'')+'</g>';}).join(''):'';
}

return {find,observe,command,render,eligible};
})();
