'use strict';
// Quiet synthesized ambience; starts only after a player gesture, respects sound settings.
Abyss.ClimateAudio=(()=>{
 let context=null,source=null,gain=null,filter=null,last='',state=null;
 function update(s){state=s;if(!context)return;const w=Abyss.Climate.conditions(s,Abyss.Climate.here(s),false),enabled=s.settings.sound&&!document.hidden&&s.mode==='raising',id=enabled?w.id:'off';if(id===last)return;last=id;if(source){source.stop();source.disconnect();source=null;filter?.disconnect();gain?.disconnect();}if(!enabled||w.id==='clear'){gain?.gain.setTargetAtTime(0,context.currentTime,.2);return;}
 try{const buffer=context.createBuffer(1,context.sampleRate*2,context.sampleRate),values=buffer.getChannelData(0);let previous=0;for(let i=0;i<values.length;i++){previous=(previous+(Math.random()*2-1)*.09)/1.05;values[i]=['rain','heavy_rain','acid_rain'].includes(id)?Math.random()*2-1:previous;}
 source=context.createBufferSource();source.buffer=buffer;source.loop=true;filter=context.createBiquadFilter();filter.type='lowpass';filter.frequency.value=['rain','heavy_rain'].includes(id)?1700:id==='sandstorm'?2300:650;gain=context.createGain();gain.gain.value=s.road.mode==='home'?.016:.025;source.connect(filter).connect(gain).connect(context.destination);source.start();
 }catch(_){source=null;}}
 function bind(){document.addEventListener('pointerdown',()=>{const s=Abyss.Engine.snapshot();if(!s?.settings.sound)return;try{if(!context)context=new (window.AudioContext||window.webkitAudioContext)();context.resume().catch(()=>{});update(s);}catch(_){/* Audio is optional. */}});document.addEventListener('visibilitychange',()=>state&&update(state));Abyss.Engine.subscribe(update);}
 return {bind,update};
})();
