'use strict';
Abyss.Garden=(()=>{
 const D=Abyss.PlantData,find=id=>D.find(p=>p.id===id),t=(a,b)=>Abyss.HomeData.t(a,b),clamp=v=>Math.max(0,Math.min(100,v));
 const capacity=g=>[0,10,15,25,35,45,55,65,80][g.level];
 const used=g=>g.plants.reduce((n,p)=>n+find(p.plantId).slots,0);
 const fail=()=>({ok:false,message:t('条件不足，请检查种子、水、空间、行动点或资金。','Check seeds, water, space, action points and credits.')}),ok=message=>({ok:true,message});
 function seed(s,id,n=1){const g=s.greenhouse;g.seeds[id]=(g.seeds[id]||0)+n;if(!g.discovered.includes(id))g.discovered.push(id);}
 function command(s,action,p={}){
 const g=s.greenhouse,d=find(p.id),plant=g.plants.find(x=>x.uid===Number(p.uid));
 if(s.pendingEvent)return {ok:false,message:t('先完成当前事件。','Resolve the current event first.')};
 if(action==='plantCare')return Abyss.PlantHealth.care(s)?ok(t('已清理发现的病斑；后续恢复需要几天，仍需改善环境。','Observed damage has been cleaned. Recovery takes several days; improve the environment too.')):fail();
 if(action==='unlock'){if(g.unlocked||s.money<40)return fail();s.money-=40;g.unlocked=true;for(const id of ['plant_1','plant_26','plant_50'])seed(s,id,3);return ok(t('温室开放，三袋基础种子已入库。','Greenhouse opened. Three starter seed packets are stored.'));}
 if(!g.unlocked)return fail();
 if(action==='process')return Abyss.PlantProcessing.command(s,p);if(action==='breed')return Abyss.PlantBreeding.breed(s,p);if(action==='renameCultivar'){const c=g.cultivars.find(c=>c.id===p.cultivar);if(!c||typeof p.name!=='string'||!p.name.trim())return fail();c.name=p.name.trim().slice(0,32);return ok(t('品系已命名。','Cultivar named.'));}if(action==='buy'){if(!d||d.source!=='shop'||s.money<d.price*2)return fail();s.money-=d.price*2;seed(s,d.id);}
 else if(action==='plant'){const cultivar=g.cultivars.find(c=>c.id===p.cultivar);if(cultivar&&cultivar.plantId!==p.id)return fail();if(!d||!(cultivar?cultivar.seeds:g.seeds[d.id])||used(g)+d.slots>capacity(g)||s.ap<1||d.rarity==='ANOMALOUS'&&g.level<8)return fail();s.ap--;if(cultivar)cultivar.seeds--;else g.seeds[d.id]--;g.plants.push({uid:g.nextId++,plantId:d.id,growth:0,water:85,health:100,plantedDay:s.day,generation:cultivar?.generation||1,cultivar:cultivar?.id||null,traits:cultivar?{...cultivar.traits}:{water:0,yield:0,resilience:0}});if(g.firstPlant===null){g.firstPlant=g.plants.at(-1).uid;Abyss.Memory?.remember(s,'first_plant',t('Jack把第一包种子交给它看，然后一起把土压平。','Jack showed it the first seed packet, then they flattened the soil together.'));}}
 else if(action==='water'){const need=g.plants.filter(x=>x.health>0&&x.water<80);const cost=need.length*.5;if(!need.length||s.climate.labResources.water<cost)return fail();s.climate.labResources.water-=cost;need.forEach(x=>x.water=100);}
 else if(action==='harvest'){if(!plant||plant.health<=0||plant.growth<100)return fail();const def=find(plant.plantId);g.harvest.push({plantId:def.id,quantity:Math.max(1,Math.floor((plant.traits?.yield||0)+def.yieldMin+(def.yieldMax-def.yieldMin)*plant.health/100+(g.ecology.pollination>=45&&def.category==='fruit'?1:0))),day:s.day,quality:Math.round((plant.health+g.ecology.soil)/2),contamination:g.ecology.contamination});if(plant.cultivar){const c=g.cultivars.find(c=>c.id===plant.cultivar);if(c)c.seeds++;}else seed(s,def.id);g.xp+=5;if(def.regrow)plant.growth=45;else g.plants=g.plants.filter(x=>x!==plant);}
 else if(action==='clear'){if(!plant||plant.health>0)return fail();g.plants=g.plants.filter(x=>x!==plant);g.compost++;}
 else if(action==='soil'){if(g.compost<1)return fail();g.compost--;g.ecology.soil=clamp(g.ecology.soil+15);}
 else if(action==='upgrade'){const cost=g.level*100;if(g.level>=8||s.money<cost)return fail();s.money-=cost;g.level++;}
 else if(action==='auto'){if(g.level<4||g.automation||s.money<150)return fail();s.money-=150;g.automation=true;}
 else if(['sell','feed','compost','sample'].includes(action)){const b=g.harvest[Number(p.batch)];if(!b||b.quantity<1)return fail();const def=find(b.plantId),spoiled=Abyss.PlantProcessing.spoiled(s,b);
 if(action==='feed'){if(s.campaign?.creatureAlive===false||!s.legacy.active||spoiled||b.contamination>25||!def.tags.includes('FOOD')||s.ap<1)return fail();s.ap--;Abyss.State.effects(s,{hunger:-14,mood:2});}
 if(action==='sell'){if(spoiled||b.contamination>25)return fail();s.money=Math.min(1e7,s.money+Math.round(def.price*(.5+b.quality/100)*(s.climate.currentSeason==='winter'?1.3:1)*(Abyss.PlantProcessing.methods.find(m=>m.id===b.process)?.value||1)));}
 if(action==='sample')g.xp+=3;if(action==='compost')g.compost++;b.quantity--;g.harvest=g.harvest.filter(x=>x.quantity>0);
 }else return fail();Abyss.PlantHealth.prune(s);return ok(t('温室记录已更新。','Greenhouse record updated.'));
 }
 function observe(before,s,command){const g=s.greenhouse;if(!g.unlocked)return;
 if(before.exploration?.active?.steps>0&&!before.exploration.active.forceReturn&&!s.exploration?.active&&command.type==='exp:advance'){const candidates=D.filter(x=>x.source==='exploration'),weights={RARE:12,EPIC:3,LEGENDARY:.5,ANOMALOUS:.1};s.rng=(Math.imul(s.rng,1664525)+1013904223)>>>0||1;let roll=s.rng/4294967296*candidates.reduce((n,p)=>n+weights[p.rarity],0);const found=candidates.find(p=>(roll-=weights[p.rarity])<=0)||candidates[0];seed(s,found.id);Abyss.State.log(s,t('整理探索物资时发现一袋植物种子。','A seed packet is found among the expedition supplies.'));}
 if(s.day<=g.lastDay)return;
 for(let day=g.lastDay+1;day<=s.day;day++){
 const alive=g.plants.filter(p=>p.health>0),species=new Set(alive.map(p=>p.plantId)),cats=new Set(alive.map(p=>find(p.plantId).category)),e=g.ecology;
 e.biodiversity=clamp(species.size*8);e.pollination=clamp(alive.filter(p=>find(p.plantId).category==='flower').length*15+(Abyss.HomesteadTraits?.pollination(s,day)||0));e.pests=clamp(e.pests+(alive.length>3&&species.size===1?6:-2));e.soil=clamp(e.soil-(alive.length?1: -2)+(species.has('plant_69')?2:0));e.contamination=clamp(e.contamination+(alive.some(p=>find(p.plantId).rarity==='ANOMALOUS')?2: -1)-(species.has('plant_62')?2:0));
 if(species.has('plant_46')&&species.has('plant_3'))e.pests=clamp(e.pests-4);
 const resources=s.climate.labResources,temp=Abyss.Climate.conditions(s).temperature;
 for(const p of alive){const d=find(p.plantId);if(g.automation&&p.water<40&&resources.water>=.5&&Abyss.LabOperations.powered(s,'greenhouse')&&s.operations.equipment.hydroponics.condition>=20){resources.water-=.5;p.water=100;}p.water=clamp(p.water-d.waterNeed*(1-(p.traits?.water||0)*.08));const suitable=temp>=d.tempMin&&temp<=d.tempMax,damage=(p.water<10?12:0)+(!suitable?5:0)+(e.pests>65?5:0);p.health=clamp(p.health-Math.max(0,damage-(p.traits?.resilience||0))+(damage?0:1));if(p.health>0&&p.water>=10)p.growth=clamp(p.growth+100/d.growthTime*(suitable?1:.4)*(Abyss.LabOperations.powered(s,'greenhouse')?1:.5)*(s.operations.equipment.growLight.condition<20?.7:1)*(s.roomSystems.rooms.greenhouse.specialization==='medicine'&&d.category==='herb'?1.08:s.roomSystems.rooms.greenhouse.specialization==='food'&&['fruit','vegetable'].includes(d.category)?1.08:1)*(e.soil>25?1:.65));if(p.health===0)Abyss.State.log(s,t(d.name+'枯萎了，种植槽可以清理。',d.en+' withered. The bed can be cleared.'),'warning');}
 Abyss.PlantHealth.day(s,day);
 if(cats.size>=3&&alive.length>=4){Abyss.State.effects(s,{mood:1});}
 }
 g.lastDay=s.day;
 }
 return {command,observe,find,capacity,used,seed};
})();

