'use strict';
// Exposure rules contain gameplay conditions, never narrative/Host deductions.
Abyss.DiseaseRisks = (() => {
 const ranges = [
  ['dust',[1,6,10,32,69]], ['cold',[2,9,33,67,68]],
  ['pollution',[3,7,20,37,47,51,52,56,57,60,61,63,64]],
  ['damp',[4,11,14,40,44,45,49,70]], ['infection',[13,15]],
  ['food',[16,17,18,19,21,22,23,24,25,27,28]],
  ['thirst',[26,71]], ['stress',[29,76,77,78,79,80,81,82,84,85,86,87,88,89,90]],
  ['travel',[30,72,73]], ['acid',[31]], ['heat',[34,66]],
  ['hygiene',[35,36,41,42,43,46,48]], ['spores',[12,38,39,50]],
  ['mutation',[53,54,55,58,59,62,65]], ['sleep',[5,8,74,75,83]]
 ];
 const result=Object.fromEntries(ranges.flatMap(([kind,ids])=>ids.map(n=>['disease_'+n,kind])));
 const diets={22:'gel',23:'predator',24:'prey'};
 function eligible(s,p,d,context={}) {
  const host=p.hostType||(p.id==='jack'?'HUMAN':'B07');
  if(!d.hostTypes.includes(host))return false;
  const kind=result[d.diseaseId], id=d.number;
  const w=s.climate?.weatherByRegion?.[context.region||Abyss.Climate.here(s)]||{};
  const pet=s.pets?.find(x=>x.id===p.id),species=pet&&Abyss.ContainmentData.species.find(x=>x.id===pet.species);
  const pollution=host==='B07'?s.stats.pollution:context.pollution||0;
  const air=s.home?.conditions?.air??100, sleep=p.sleep??60, stress=p.stress??20;
  if(diets[id]&&context.food!==diets[id])return false;
  if(id===48&&species&&!/fur|furry|mammal/.test(species.category+' '+species.id))return false;
  if(kind==='infection')return !!context.outbreak;
  if(kind==='dust')return ['sandstorm'].includes(w.id)||context.region==='industrial'||air<30;
  if(kind==='cold')return w.temperature<2||['blizzard','cold_snap'].includes(w.id);
  if(kind==='heat')return w.temperature>35||w.id==='heatwave';
  if(kind==='acid')return w.id==='acid_rain'&&context.outside;
  if(kind==='pollution')return pollution>=55;
  if(kind==='damp')return ['dense_fog','heavy_rain','flash_flood'].includes(w.id)&&context.outside;
  if(kind==='spores')return (s.greenhouse?.ecology?.pests||0)>65&&(s.greenhouse?.plants?.length||0)>0;
  if(kind==='hygiene')return air<25||pet?.hunger>85;
  if(kind==='food')return context.foodPoor===true;
  if(kind==='thirst')return (s.climate?.labResources?.water??100)<15;
  if(kind==='travel')return context.distance>8;
  if(kind==='mutation')return host==='B07'&&s.stats.stability<25&&context.experiment===true;
  if(kind==='sleep')return sleep<30;
  if(kind==='stress')return stress>80&&(context.stressor===id||context.stressors?.includes(id));
  return false;
 }
 return {kinds:result,eligible};
})();
