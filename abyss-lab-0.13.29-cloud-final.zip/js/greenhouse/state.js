'use strict';
// Additive sub-schema; never back-simulate a newly migrated garden.
Abyss.GardenState=(()=>{
 const num=(v,d=0,max=100)=>Number.isFinite(v)?Math.max(0,Math.min(max,v)):d;
 const ids=new Set(Abyss.PlantData.map(p=>p.id));
 function fresh(day=1){return {version:1,plantHealth:Abyss.PlantHealth.fresh(day),unlocked:false,level:1,lastDay:day,nextId:1,seeds:{},cultivars:[],plants:[],harvest:[],discovered:[],xp:0,automation:false,compost:0,ecology:{soil:75,pests:0,contamination:0,biodiversity:0,pollination:0},firstPlant:null};}
 function read(raw,s){const g=fresh(s.day),r=raw.greenhouse;if(r?.version!==1)return g;
 g.unlocked=r.unlocked===true;g.level=Math.max(1,Math.floor(num(r.level,1,8)));g.lastDay=s.day;g.nextId=Math.max(1,Math.floor(num(r.nextId,1,1e9)));g.xp=num(r.xp,0,1e7);g.compost=num(r.compost,0,1e5);g.automation=r.automation===true;
 for(const id of ids)if(r.seeds?.[id]>0)g.seeds[id]=Math.floor(num(r.seeds[id],0,1e5));
 g.cultivars=Abyss.PlantBreeding?.read(r.cultivars)||[];g.discovered=Array.isArray(r.discovered)?[...new Set(r.discovered.filter(id=>ids.has(id)))]:[];
 const used=new Set();for(const p of (Array.isArray(r.plants)?r.plants:[]).slice(0,80)){if(!ids.has(p?.plantId)||!Number.isInteger(p.uid)||p.uid<1||used.has(p.uid))continue;used.add(p.uid);g.nextId=Math.max(g.nextId,p.uid+1);g.plants.push({uid:p.uid,plantId:p.plantId,growth:num(p.growth),health:num(p.health,100),water:num(p.water,75),plantedDay:Math.min(s.day,Math.max(1,Math.floor(num(p.plantedDay,s.day,s.day)))),generation:Math.max(1,Math.floor(num(p.generation,1,1000))),cultivar:g.cultivars.some(c=>c.id===p.cultivar)?p.cultivar:null,traits:{water:Math.floor(num(p.traits?.water,0,3)),yield:Math.floor(num(p.traits?.yield,0,3)),resilience:Math.floor(num(p.traits?.resilience,0,3))}});}
 let newsBatchMarked=false;g.harvest=(Array.isArray(r.harvest)?r.harvest:[]).filter(b=>ids.has(b?.plantId)&&b.quantity>0).slice(0,400).map(b=>({plantId:b.plantId,quantity:Math.floor(num(b.quantity,0,1e5)),day:Math.min(s.day,Math.floor(num(b.day,s.day,s.day))),quality:num(b.quality,50),contamination:num(b.contamination),...(b.newsChainId==='news_batch_10'&&!newsBatchMarked&&(newsBatchMarked=true)?{newsChainId:b.newsChainId}:{}),...(Abyss.PlantProcessing?.methods.some(m=>m.id===b.process)?{process:b.process,shelfLife:Abyss.PlantProcessing.methods.find(m=>m.id===b.process).life,sourceDay:Math.floor(num(b.sourceDay,b.day,s.day))}:{})}));
 for(const k in g.ecology)g.ecology[k]=num(r.ecology?.[k],g.ecology[k]);g.plantHealth=Abyss.PlantHealth.read(r.plantHealth,{...s,greenhouse:g});g.firstPlant=Number.isInteger(r.firstPlant)&&r.firstPlant>0&&r.firstPlant<g.nextId?r.firstPlant:null;return g;}
 return {fresh,read};
})();
