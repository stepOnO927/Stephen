'use strict';
Abyss.Outbreaks = (() => {
 const places=()=>Abyss.WastelandData.settlements.map(x=>x.id);
 const adjacent={glassfield:['switchyard','ironhaven'],ironhaven:['glassfield','lantern'],switchyard:['glassfield','deadchannel'],deadchannel:['switchyard','hollowwing'],lantern:['ironhaven','hollowwing'],hollowwing:['deadchannel','lantern']};
 const valid=new Set(['disease_4','disease_11','disease_15','disease_41','disease_45','disease_50']);
 const clamp=(x,a,b)=>Number.isFinite(x)?Math.max(a,Math.min(b,x)):a;
 function fresh(day){return {lastDay:day,nextId:1,active:[],history:[],quarantineStations:{}};}
 function read(raw,day){const v=fresh(day);if(!raw||typeof raw!=='object')return v;
  v.lastDay=day;v.nextId=Math.floor(clamp(raw.nextId,1,1e9));
  const parse=x=>x&&valid.has(x.diseaseId)&&places().includes(x.originRegion)&&Array.isArray(x.regions);
  const item=x=>({id:String(x.id).slice(0,40),diseaseId:x.diseaseId,originRegion:x.originRegion,firstKnownCase:Math.floor(clamp(x.firstKnownCase,1,999)),started:Math.floor(clamp(x.started,1,day)),age:Math.floor(clamp(x.age,0,30)),regions:x.regions.filter(r=>places().includes(r.id)).slice(0,6).map(r=>({id:r.id,cases:Math.floor(clamp(r.cases,1,250)),contained:r.contained===true})),routeSpread:(x.routeSpread||[]).filter(r=>places().includes(r)).slice(0,12)});
  v.active=(Array.isArray(raw.active)?raw.active:[]).filter(parse).slice(0,3).map(item);
  v.history=(Array.isArray(raw.history)?raw.history:[]).filter(parse).slice(-16).map(item);
  for(const id of places())v.quarantineStations[id]=raw.quarantineStations?.[id]===true;
  return v;
 }
 function start(s,place,diseaseId){const w=s.infirmary.worldHealth;if(!places().includes(place)||!valid.has(diseaseId)||w.active.length>=3||w.active.some(x=>x.diseaseId===diseaseId))return false;
  const cases=2+Math.floor(Abyss.Util.random(s)*7);w.active.push({id:'outbreak_'+w.nextId++,diseaseId,originRegion:place,firstKnownCase:cases,started:s.day,age:0,regions:[{id:place,cases,contained:false}],routeSpread:[place]});return true;
 }
 function risk(s,place){return (s.infirmary?.worldHealth?.active||[]).flatMap(o=>o.regions.filter(r=>r.id===place).map(r=>({diseaseId:o.diseaseId,cases:r.cases,risk:r.cases>20?'HIGH':r.cases>8?'MODERATE':'LOW',originRegion:o.originRegion,routeSpread:o.routeSpread,hostSpecies:Abyss.DiseaseData.find(d=>d.diseaseId===o.diseaseId).hostTypes})));}
 function price(s,category,place){const active=risk(s,place).length;return active?['medicine','serum'].includes(category)?1.25:['water','drink','food'].includes(category)?1.12:1:1;}
 function tick(s){const w=s.infirmary.worldHealth;if(s.day<=w.lastDay)return;
  // Sparse outbreaks only after settling in, tied to resource or pest pressure.
  if(s.day>7&&w.active.length<3&&Abyss.Util.random(s)<.08){const pool=places().filter(id=>s.wasteland.places[id]?.phase!=='gone'&&(s.climate.settlementResources[id]?.water<50||s.climate.settlementResources[id]?.medicine<50));if(pool.length)start(s,Abyss.Util.pick(s,pool),Abyss.Util.pick(s,[...valid]));}
  for(const o of w.active){o.age++;for(const r of [...o.regions]){const resources=s.climate.settlementResources[r.id],station=w.quarantineStations[r.id];r.contained=station&&resources.medicine>=20;
    r.cases=Math.max(0,Math.min(250,r.cases+(r.contained?-3:resources.medicine>=60?-1:2)));
    if(!r.contained&&r.cases>=8&&Abyss.Util.random(s)<.18){const to=(adjacent[r.id]||[]).find(id=>!o.regions.some(r=>r.id===id)&&s.wasteland.places[id]?.phase!=='gone');if(to){o.regions.push({id:to,cases:2,contained:false});o.routeSpread.push(to);}}
   }
   o.regions=o.regions.filter(r=>r.cases>0);
  }
  const expired=w.active.filter(o=>!o.regions.length||o.age>=18);w.history.push(...expired);w.history=w.history.slice(-16);w.active=w.active.filter(o=>!expired.includes(o));w.lastDay=s.day;
 }
 function exposure(s,p,place){for(const r of risk(s,place)){if(p.quarantine)continue;if(Abyss.Util.random(s)<(r.risk==='HIGH'?.12:r.risk==='MODERATE'?.06:.025))Abyss.Illness.expose(s,p,r.diseaseId,place);}}
 return {fresh,read,start,risk,price,tick,exposure,places};
})();
