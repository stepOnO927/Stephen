'use strict';
// Approved disease roster; durations and severities are provisional fictional game balance.
Abyss.DiseaseData = [
  {
    "diseaseId": "disease_1",
    "number": 1,
    "name": "灰尘热",
    "en": "Dust Fever",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER"
    ],
    "incubation": 0,
    "symptoms": [
      "低热",
      "疲劳",
      "咳嗽",
      "食欲下降"
    ],
    "severity": "MILD",
    "transmission": "非传染，粉尘暴露",
    "treatmentType": "休息、补液、医务室观察、Clean Moss辅助",
    "plantSupports": [
      "plant_163"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_2",
    "number": 2,
    "name": "冷舱咳",
    "en": "Cold-Chamber Cough",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "干咳",
      "睡眠差",
      "活动减少"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "保暖、休息、Warmroot辅助",
    "plantSupports": [
      "plant_157"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_3",
    "number": 3,
    "name": "蓝肺综合征",
    "en": "Blue Lung Syndrome",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "MONSTER"
    ],
    "incubation": 0,
    "symptoms": [
      "呼吸急促",
      "耐力下降",
      "轻微发冷"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "医务室监测、污染过滤、Grey Lungwort辅助",
    "plantSupports": [
      "plant_168"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_4",
    "number": 4,
    "name": "湿雾感染",
    "en": "Damp-Mist Infection",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": true,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 2,
    "symptoms": [
      "咳嗽",
      "疲惫",
      "轻微发热"
    ],
    "severity": "MILD",
    "transmission": "中等传染性",
    "treatmentType": "隔离观察、医疗药品、Clearleaf辅助",
    "plantSupports": [
      "plant_158"
    ],
    "recoveryDays": 7,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": true
  },
  {
    "diseaseId": "disease_5",
    "number": 5,
    "name": "夜咳症",
    "en": "Night Cough",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "白天较轻，夜间咳嗽和睡眠中断"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "睡眠环境、Herbal Steam抽象制剂、Clearleaf",
    "plantSupports": [
      "plant_158"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_6",
    "number": 6,
    "name": "铁尘炎",
    "en": "Iron-Dust Irritation",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "咳嗽",
      "眼部不适",
      "体力下降"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "离开工业区、过滤空气、Clean Moss",
    "plantSupports": [
      "plant_163"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_7",
    "number": 7,
    "name": "灰潮呼吸反应",
    "en": "Grey-Tide Respiratory Reaction",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "MONSTER"
    ],
    "incubation": 0,
    "symptoms": [
      "呼吸困难",
      "疲劳",
      "污染值升高"
    ],
    "severity": "SEVERE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "抗污染治疗、隔离、Grey Lungwort",
    "plantSupports": [
      "plant_168"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_8",
    "number": 8,
    "name": "密闭舱热",
    "en": "Cabin Fever Infection",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "低热",
      "头昏",
      "食欲差"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "休息、通风、补液",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_9",
    "number": 9,
    "name": "冻风肺",
    "en": "Frostwind Lung",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "寒战",
      "呼吸耐力下降",
      "睡眠差"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "保温、Warmroot、恢复室",
    "plantSupports": [
      "plant_157"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_10",
    "number": 10,
    "name": "炉灰咳",
    "en": "Furnace Cough",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "干咳",
      "喉部不适",
      "活动后疲劳"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "脱离污染区、补水、Clearleaf",
    "plantSupports": [
      "plant_158"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_11",
    "number": 11,
    "name": "黑霉热",
    "en": "Black Mold Fever",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": true,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 2,
    "symptoms": [
      "发热",
      "乏力",
      "食欲下降"
    ],
    "severity": "MILD",
    "transmission": "接触或共同环境暴露（游戏抽象）",
    "treatmentType": "隔离污染源、医务室处理、Clean Moss",
    "plantSupports": [
      "plant_163"
    ],
    "recoveryDays": 7,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": true
  },
  {
    "diseaseId": "disease_12",
    "number": 12,
    "name": "温室孢子反应",
    "en": "Greenhouse Spore Reaction",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "喷嚏",
      "眼部不适",
      "疲劳"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "移除过敏植物、空气过滤",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_13",
    "number": 13,
    "name": "灰喉",
    "en": "Grey Throat",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": true,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 2,
    "symptoms": [
      "吞咽不适",
      "声音变化",
      "低热"
    ],
    "severity": "MILD",
    "transmission": "接触或共同环境暴露（游戏抽象）",
    "treatmentType": "休息、补液、Herbal Support",
    "plantSupports": [],
    "recoveryDays": 7,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_14",
    "number": 14,
    "name": "冷凝感染",
    "en": "Condensation Infection",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": true,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 2,
    "symptoms": [
      "发热",
      "怕冷",
      "睡眠差"
    ],
    "severity": "MILD",
    "transmission": "接触或共同环境暴露（游戏抽象）",
    "treatmentType": "抗感染类虚构药、休息",
    "plantSupports": [],
    "recoveryDays": 7,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": true
  },
  {
    "diseaseId": "disease_15",
    "number": 15,
    "name": "荒原流感",
    "en": "Wasteland Flu",
    "category": "RESPIRATORY",
    "rarity": "COMMON",
    "infectious": true,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 2,
    "symptoms": [
      "发热",
      "肌肉酸痛",
      "食欲低",
      "疲劳"
    ],
    "severity": "MILD",
    "transmission": "接触或共同环境暴露（游戏抽象）",
    "treatmentType": "休息、补液、隔离、医生NPC",
    "plantSupports": [],
    "recoveryDays": 7,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": true
  },
  {
    "diseaseId": "disease_16",
    "number": 16,
    "name": "罐头胃",
    "en": "Canned Gut",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "胃痛",
      "恶心",
      "食欲下降"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "清淡饮食、Digestive Mix",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_17",
    "number": 17,
    "name": "腐食反应",
    "en": "Spoiled-Food Reaction",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "腹痛",
      "呕吐",
      "脱水"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "补液、休息、医务室观察",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_18",
    "number": 18,
    "name": "盐负荷",
    "en": "Salt Overload",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "口渴",
      "疲劳",
      "食欲异常"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "补水、调整饮食",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_19",
    "number": 19,
    "name": "苦根不耐",
    "en": "Bitterroot Intolerance",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "恶心",
      "拒食"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "停用该草药、换配方",
    "plantSupports": [
      "plant_159"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_20",
    "number": 20,
    "name": "灰瓜反应",
    "en": "Grey Melon Reaction",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "胃痛",
      "污染轻微上升"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "停止食用、观察",
    "plantSupports": [
      "plant_31",
      "plant_42"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_21",
    "number": 21,
    "name": "菌类失衡",
    "en": "Fungal Gut Imbalance",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "腹胀",
      "低食欲",
      "情绪变差"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "饮食调整、医务室",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_22",
    "number": 22,
    "name": "生物胶不耐",
    "en": "Bio-Gel Intolerance",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "B07",
      "MONSTER"
    ],
    "incubation": 0,
    "symptoms": [
      "拒食",
      "腹部不适"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "更换营养来源",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_23",
    "number": 23,
    "name": "肉食失衡",
    "en": "Carnivore Imbalance",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "PET",
      "MONSTER"
    ],
    "incubation": 0,
    "symptoms": [
      "疲劳",
      "食欲紊乱"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "营养结构调整",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_24",
    "number": 24,
    "name": "草食失衡",
    "en": "Herbivore Imbalance",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "PET",
      "MONSTER"
    ],
    "incubation": 0,
    "symptoms": [
      "体力差",
      "异常啃食"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "补充合适植物",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_25",
    "number": 25,
    "name": "糖果热",
    "en": "Sugar Rush Syndrome",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "短暂兴奋后疲劳",
      "睡眠差"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "减少甜食、休息",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_26",
    "number": 26,
    "name": "脱水综合征",
    "en": "Dry Gut",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "虚弱",
      "口渴",
      "活动下降"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "补液、Watermelon/Cucumber辅助",
    "plantSupports": [
      "plant_10",
      "plant_30",
      "plant_31"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_27",
    "number": 27,
    "name": "高蛋白负荷",
    "en": "Protein Overload",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "食欲差",
      "疲劳"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "降低浓缩食物比例",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_28",
    "number": 28,
    "name": "食物恐惧",
    "en": "Food Aversion",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "拒绝某类食物"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "换食、慢慢恢复信任",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_29",
    "number": 29,
    "name": "胃部应激",
    "en": "Stress Gut",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "紧张时不吃东西",
      "腹部不适"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "降低压力、Comfort Bloom、规律饮食",
    "plantSupports": [
      "plant_162"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_30",
    "number": 30,
    "name": "旅行恶心",
    "en": "Motion Sickness",
    "category": "DIGESTIVE",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "乘车后恶心",
      "拒食",
      "烦躁"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "休息、减少旅行、Ginger类游戏配方",
    "plantSupports": [
      "plant_53"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_31",
    "number": 31,
    "name": "酸雨灼伤",
    "en": "Acid-Rain Dermatitis",
    "category": "DERMAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "皮肤刺激",
      "疼痛"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "清洗、Recovery Gel、隔离酸雨",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_32",
    "number": 32,
    "name": "灰尘皮炎",
    "en": "Dust Dermatitis",
    "category": "DERMAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "瘙痒",
      "烦躁",
      "抓挠"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "清洁、Aloe类制剂",
    "plantSupports": [
      "plant_52"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_33",
    "number": 33,
    "name": "冻裂",
    "en": "Frost Crack",
    "category": "DERMAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "疼痛",
      "行动降低"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "保暖、Recovery Gel",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_34",
    "number": 34,
    "name": "热斑",
    "en": "Heat Rash",
    "category": "DERMAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "不适",
      "烦躁"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "降温、Coolgrass",
    "plantSupports": [
      "plant_156"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_35",
    "number": 35,
    "name": "生物膜炎",
    "en": "Biofilm Irritation",
    "category": "DERMAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "B07",
      "MONSTER"
    ],
    "incubation": 0,
    "symptoms": [
      "B07/Monster表皮暗淡",
      "抓挠"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "清洁、隔离污染环境",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_36",
    "number": 36,
    "name": "油污反应",
    "en": "Grease Rash",
    "category": "DERMAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "PET"
    ],
    "incubation": 0,
    "symptoms": [
      "Jack/Pet皮肤刺激"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "清洗、换衣、Aloe",
    "plantSupports": [
      "plant_52"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_37",
    "number": 37,
    "name": "灰潮斑",
    "en": "Grey Tide Spotting",
    "category": "DERMAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "表皮出现异常色斑"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "污染控制、观察",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_38",
    "number": 38,
    "name": "药草接触反应",
    "en": "Herb Contact Reaction",
    "category": "DERMAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "发红",
      "烦躁"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "停用对应植物",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_39",
    "number": 39,
    "name": "孢子皮炎",
    "en": "Spore Dermatitis",
    "category": "DERMAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "瘙痒",
      "细小斑点"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "空气过滤、清洁",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_40",
    "number": 40,
    "name": "干裂病",
    "en": "Dry-Skin Syndrome",
    "category": "DERMAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "外皮干裂",
      "舒适度下降"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "湿度调整、护理凝胶",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_41",
    "number": 41,
    "name": "灰虱",
    "en": "Grey Lice",
    "category": "PARASITIC",
    "rarity": "COMMON",
    "infectious": true,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 2,
    "symptoms": [
      "抓挠",
      "睡眠下降"
    ],
    "severity": "MILD",
    "transmission": "接触或共同环境暴露（游戏抽象）",
    "treatmentType": "清洁、隔离寝具、医务室处理",
    "plantSupports": [],
    "recoveryDays": 7,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": true
  },
  {
    "diseaseId": "disease_42",
    "number": 42,
    "name": "废土螨",
    "en": "Wasteland Mites",
    "category": "PARASITIC",
    "rarity": "COMMON",
    "infectious": true,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 2,
    "symptoms": [
      "烦躁",
      "皮肤不适"
    ],
    "severity": "MILD",
    "transmission": "接触或共同环境暴露（游戏抽象）",
    "treatmentType": "寝具清洁、温室益虫隔离",
    "plantSupports": [],
    "recoveryDays": 7,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": true
  },
  {
    "diseaseId": "disease_43",
    "number": 43,
    "name": "甲壳寄生虫",
    "en": "Shell Parasite",
    "category": "PARASITIC",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "B07",
      "MONSTER"
    ],
    "incubation": 0,
    "symptoms": [
      "外皮疼痛",
      "疲劳"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "医务室清除、恢复",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_44",
    "number": 44,
    "name": "根菌孢子",
    "en": "Root Mold Exposure",
    "category": "PARASITIC",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "疲劳",
      "咳嗽"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "移除感染植物、过滤空气",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_45",
    "number": 45,
    "name": "黑孢感染",
    "en": "Black Spore Infection",
    "category": "PARASITIC",
    "rarity": "COMMON",
    "infectious": true,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 2,
    "symptoms": [
      "低热",
      "虚弱"
    ],
    "severity": "MILD",
    "transmission": "接触或共同环境暴露（游戏抽象）",
    "treatmentType": "隔离、医务室、Clean Moss",
    "plantSupports": [
      "plant_163"
    ],
    "recoveryDays": 7,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": true
  },
  {
    "diseaseId": "disease_46",
    "number": 46,
    "name": "肠道寄生虫",
    "en": "Gut Parasite",
    "category": "PARASITIC",
    "rarity": "COMMON",
    "infectious": true,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 2,
    "symptoms": [
      "食欲大但体重下降",
      "疲劳"
    ],
    "severity": "MILD",
    "transmission": "接触或共同环境暴露（游戏抽象）",
    "treatmentType": "虚构抗寄生药物、隔离",
    "plantSupports": [],
    "recoveryDays": 7,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": true
  },
  {
    "diseaseId": "disease_47",
    "number": 47,
    "name": "血苔寄生",
    "en": "Blood Moss Parasite",
    "category": "PARASITIC",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "虚弱",
      "污染升高"
    ],
    "severity": "SEVERE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "医务室高级处理",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": true
  },
  {
    "diseaseId": "disease_48",
    "number": 48,
    "name": "毛皮真菌",
    "en": "Fur Fungus",
    "category": "PARASITIC",
    "rarity": "COMMON",
    "infectious": true,
    "hostTypes": [
      "PET",
      "MONSTER"
    ],
    "incubation": 2,
    "symptoms": [
      "掉毛",
      "抓挠"
    ],
    "severity": "MILD",
    "transmission": "接触或共同环境暴露（游戏抽象）",
    "treatmentType": "清洁、隔离、护理",
    "plantSupports": [],
    "recoveryDays": 7,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": true
  },
  {
    "diseaseId": "disease_49",
    "number": 49,
    "name": "足部菌感染",
    "en": "Paw Fungus",
    "category": "PARASITIC",
    "rarity": "COMMON",
    "infectious": true,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 2,
    "symptoms": [
      "走路不适"
    ],
    "severity": "MILD",
    "transmission": "接触或共同环境暴露（游戏抽象）",
    "treatmentType": "干燥环境、护理凝胶",
    "plantSupports": [],
    "recoveryDays": 7,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_50",
    "number": 50,
    "name": "温室虫媒热",
    "en": "Greenhouse Vector Fever",
    "category": "PARASITIC",
    "rarity": "COMMON",
    "infectious": true,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 2,
    "symptoms": [
      "低热",
      "乏力"
    ],
    "severity": "MILD",
    "transmission": "接触或共同环境暴露（游戏抽象）",
    "treatmentType": "隔离、虫害控制、医务室",
    "plantSupports": [],
    "recoveryDays": 7,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": true
  },
  {
    "diseaseId": "disease_51",
    "number": 51,
    "name": "轻度污染症",
    "en": "Mild Contamination",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "疲劳",
      "头晕"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "脱离污染区、Clean Moss、休息",
    "plantSupports": [
      "plant_163"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_52",
    "number": 52,
    "name": "灰潮后反应",
    "en": "Post-Grey Reaction",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "睡眠差",
      "疲劳",
      "食欲低"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "恢复室、污染治疗",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_53",
    "number": 53,
    "name": "变异负荷",
    "en": "Mutation Strain",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "疼痛",
      "疲劳",
      "属性波动"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "休息、监测、稳定剂",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_54",
    "number": 54,
    "name": "组织不稳定",
    "en": "Tissue Instability",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "行动表现波动"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "医务室扫描、减少实验",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_55",
    "number": 55,
    "name": "代谢漂移",
    "en": "Metabolic Drift",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "食欲异常",
      "冷热敏感"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "饮食调整、观察",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_56",
    "number": 56,
    "name": "灰源性发热",
    "en": "Grey-Origin Fever",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "高热",
      "污染值上升"
    ],
    "severity": "SEVERE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "隔离、高级医务室",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": true
  },
  {
    "diseaseId": "disease_57",
    "number": 57,
    "name": "荧光组织反应",
    "en": "Glow Tissue Reaction",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "外皮微光",
      "疲劳"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "观察、降低污染",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_58",
    "number": 58,
    "name": "异常再生负荷",
    "en": "Regeneration Overload",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "恢复快但疲劳严重"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "停止刺激、休息",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_59",
    "number": 59,
    "name": "生物结构漂移",
    "en": "Morphic Drift",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "短暂外形变化",
      "疼痛"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "稳定环境、医务监测",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_60",
    "number": 60,
    "name": "灰潮记忆错乱",
    "en": "Grey Memory Distortion",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "短暂记忆混乱",
      "错误熟悉感"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "安静环境、观察",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_61",
    "number": 61,
    "name": "异常温度反应",
    "en": "Thermal Anomaly Syndrome",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "体温不符合环境"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "医疗监测、环境稳定",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_62",
    "number": 62,
    "name": "细胞疲劳",
    "en": "Cellular Exhaustion",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "极度疲劳",
      "恢复慢"
    ],
    "severity": "SEVERE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "休息、营养、医务室",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_63",
    "number": 63,
    "name": "污染性失眠",
    "en": "Contamination Insomnia",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "睡不着",
      "烦躁"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "降低污染、Moonrest Flower辅助",
    "plantSupports": [
      "plant_166"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_64",
    "number": 64,
    "name": "灰潮食欲异常",
    "en": "Grey Appetite Shift",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "突然偏爱或排斥某食物"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "饮食调整、时间",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_65",
    "number": 65,
    "name": "变异疼痛",
    "en": "Mutation Pain",
    "category": "CONTAMINATION",
    "rarity": "RARE",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "不愿活动",
      "烦躁"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "Pain Support、休息、医务室",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": true,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_66",
    "number": 66,
    "name": "热衰竭",
    "en": "Heat Exhaustion",
    "category": "ENVIRONMENTAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "虚弱",
      "口渴",
      "行动慢"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "降温、补液、Coolgrass",
    "plantSupports": [
      "plant_156"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_67",
    "number": 67,
    "name": "冷应激",
    "en": "Cold Stress",
    "category": "ENVIRONMENTAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "发抖",
      "行动慢"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "保暖、Warmroot",
    "plantSupports": [
      "plant_157"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_68",
    "number": 68,
    "name": "暴雪疲劳",
    "en": "Blizzard Fatigue",
    "category": "ENVIRONMENTAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "极度疲劳"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "休息、热食",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_69",
    "number": 69,
    "name": "沙暴刺激",
    "en": "Sandstorm Irritation",
    "category": "ENVIRONMENTAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "眼部不适",
      "咳嗽"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "过滤、休息",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_70",
    "number": 70,
    "name": "高湿疲劳",
    "en": "High-Humidity Stress",
    "category": "ENVIRONMENTAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "睡眠差",
      "烦躁"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "除湿、换环境",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_71",
    "number": 71,
    "name": "干燥脱水",
    "en": "Dry-Air Dehydration",
    "category": "ENVIRONMENTAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "口渴",
      "疲劳"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "补液、调湿",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_72",
    "number": 72,
    "name": "长途疲劳",
    "en": "Long-Haul Fatigue",
    "category": "ENVIRONMENTAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "睡眠差",
      "反应下降"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "休息、暂停旅行",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_73",
    "number": 73,
    "name": "晕车",
    "en": "Motion Stress",
    "category": "ENVIRONMENTAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "恶心",
      "焦虑"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "停车、休息、Ginger Support",
    "plantSupports": [
      "plant_53"
    ],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_74",
    "number": 74,
    "name": "光照紊乱",
    "en": "Light-Cycle Disorder",
    "category": "ENVIRONMENTAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "睡眠时间错乱"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "调整温室/基地光照周期",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_75",
    "number": 75,
    "name": "地下生活综合征",
    "en": "Underground Fatigue",
    "category": "ENVIRONMENTAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "低动力",
      "睡眠乱",
      "烦躁"
    ],
    "severity": "MILD",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "温室、户外活动、规律作息",
    "plantSupports": [],
    "recoveryDays": 4,
    "afterEffects": [
      "恢复期疲劳"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_76",
    "number": 76,
    "name": "警报惊跳",
    "en": "Alarm Startle Response",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "警报一响就躲",
      "攻击性或逃跑"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "安全环境、渐进适应、Comfort Bloom",
    "plantSupports": [
      "plant_162"
    ],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_77",
    "number": 77,
    "name": "门焦虑",
    "en": "Door Anxiety",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "反复检查门",
      "睡在门边"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "自主权、门保持可控、时间",
    "plantSupports": [],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_78",
    "number": 78,
    "name": "医疗恐惧",
    "en": "Medical Fear",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "拒绝进入医务室",
      "躲避检查"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "medicalTrust、熟悉环境、陪伴",
    "plantSupports": [],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_79",
    "number": 79,
    "name": "分离焦虑",
    "en": "Separation Anxiety",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "Jack离开时躁动"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "建立规律、独立活动、宠物陪伴",
    "plantSupports": [],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_80",
    "number": 80,
    "name": "过度警觉",
    "en": "Hypervigilance",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "睡浅",
      "频繁检查声音"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "安静区、温室、长期安全感",
    "plantSupports": [],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_81",
    "number": 81,
    "name": "战斗后应激",
    "en": "Post-Combat Stress",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "拒绝战斗",
      "易怒",
      "睡眠差"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "休息、低刺激活动、音乐、温室",
    "plantSupports": [],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_82",
    "number": 82,
    "name": "哀伤",
    "en": "Grief State",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "低食欲",
      "低动力",
      "寻找死者"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "时间、陪伴、纪念植物",
    "plantSupports": [],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_83",
    "number": 83,
    "name": "睡眠紊乱",
    "en": "Sleep Disturbance",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "夜醒",
      "白天困"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "规律作息、Moonrest Flower、安静环境",
    "plantSupports": [
      "plant_166"
    ],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_84",
    "number": 84,
    "name": "身体异化",
    "en": "Body Alienation",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "B07",
      "MONSTER"
    ],
    "incubation": 0,
    "symptoms": [
      "回避镜子",
      "观察手脚",
      "厌恶身体"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "自主活动、低刺激环境、长期支持",
    "plantSupports": [],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_85",
    "number": 85,
    "name": "身份困扰",
    "en": "Identity Distress",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "对名字/编号/镜子反应异常"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "关系支持、自主选择、时间",
    "plantSupports": [],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_86",
    "number": 86,
    "name": "封闭空间恐惧",
    "en": "Confinement Fear",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "关门后紧张",
      "拒绝隔离"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "可见出口、对讲、medicalTrust",
    "plantSupports": [],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_87",
    "number": 87,
    "name": "黑暗恐惧",
    "en": "Darkness Response",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "停电时恐慌"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "安全灯、陪伴、逐步适应",
    "plantSupports": [],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_88",
    "number": 88,
    "name": "食物控制焦虑",
    "en": "Feeding-Control Anxiety",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "拒绝由Jack指定的食物"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "让患者自己选择食物",
    "plantSupports": [],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_89",
    "number": 89,
    "name": "失控反应",
    "en": "Loss-of-Control Response",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "检查/治疗前异常抵触"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "解释流程、允许停止、增加Autonomy",
    "plantSupports": [],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  },
  {
    "diseaseId": "disease_90",
    "number": 90,
    "name": "家园丧失应激",
    "en": "Home-Loss Stress",
    "category": "PSYCHOLOGICAL",
    "rarity": "COMMON",
    "infectious": false,
    "hostTypes": [
      "HUMAN",
      "B07",
      "PET",
      "MONSTER",
      "NPC"
    ],
    "incubation": 0,
    "symptoms": [
      "基地被毁/搬家后睡眠和食欲下降"
    ],
    "severity": "MODERATE",
    "transmission": "非传染；相关环境或经历触发",
    "treatmentType": "恢复熟悉物件、植物、宠物、建立新空间",
    "plantSupports": [],
    "recoveryDays": 14,
    "afterEffects": [
      "需要持续安全感与支持"
    ],
    "newsReportable": false,
    "quarantineRequired": false
  }
];
