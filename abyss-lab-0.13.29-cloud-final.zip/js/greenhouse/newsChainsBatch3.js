'use strict';
// Sources/effects live separately from authored text and the shared stage machine.
Abyss.NewsChainsBatch3=(()=>{
 Abyss.I18n.register({'寻访信标已检修，尚未确认返回。':'The search beacon was serviced; return is unconfirmed.'});
 const roadKey=e=>[e.a,e.b].sort().join(':'),places=()=>Abyss.Outbreaks.places();
 const receiver=reg=>places().find(p=>Abyss.Climate.region(p)===reg)||'ironhaven';
 const placeOf=(s,d)=>{const p=Abyss.Caravans.location(s,d).place;return places().includes(p)?p:'ironhaven';};
 function discover(before,s,c,add){
  for(const [reg,w]of Object.entries(s.climate.weatherByRegion)){
   const old=before.climate.weatherByRegion[reg];if(!old||old.id===w.id)continue;
   const number={grey_front:56,acid_rain:58,thunderstorm:59,sandstorm:60,blizzard:61,heatwave:62,flash_flood:64}[w.id];
   const snowRoad=Abyss.RoadNetwork.edges.find(e=>Abyss.Climate.region(e.b)===reg&&Abyss.Climate.road(s,e).id==='snowed');
   if(number&&(number!==61||snowRoad))add(s,number,{place:receiver(reg),source:reg+':'+w.id,...(number===61?{road:roadKey(snowRoad)}:{})});
   if(old.id==='grey_front'&&w.id!=='grey_front')add(s,57,{place:receiver(reg),source:reg+':grey_front>'+w.id});
  }
  for(const [place,r]of Object.entries(s.climate.settlementResources)){
   const old=before.climate.settlementResources[place];if(!old)continue;
   if(r.refugees>old.refugees)add(s,37,{place,source:'shelter register '+r.refugees});
   if(r.losses>old.losses)add(s,38,{place,source:'recorded losses '+r.losses});
   if(r.food<25&&old.food>=25)add(s,68,{place,source:'food reserve '+Math.round(r.food)});
   for(const [category,number,direction]of [['food',70,-1],['serum',71,1]]){
    const item=Abyss.UndergroundData.catalog.find(d=>d.category===category);if(!item)continue;
    const prior=Abyss.UndergroundMarket.price(before,item,place),current=Abyss.UndergroundMarket.price(s,item,place);
    if((current-prior)*direction>=1)add(s,number,{place,source:item.id+':'+prior+'>'+current});
   }
  }
  for(const p of s.pets){const old=before.pets.find(x=>x.id===p.id);if(p.alive&&p.escaped&&old&&!old.escaped&&!c.type?.endsWith(':release'))add(s,35,{source:p.id});}
  if(s.greenhouse.ecology.contamination>=50&&before.greenhouse.ecology.contamination<50)add(s,67,{source:'greenhouse contamination '+s.greenhouse.ecology.contamination});
  const total=x=>x.greenhouse.harvest.reduce((n,b)=>n+b.quantity,0);
  if(c.type==='garden:harvest'&&total(s)-total(before)>=4)add(s,69,{source:'completed harvest +'+(total(s)-total(before))});
  for(const d of Abyss.CaravanData.caravans){const r=s.caravan.routes[d.id],old=before.caravan.routes[d.id];if(!r||!old||!r.alive)continue;
   if(d.id==='black'&&r.index!==old.index)add(s,40,{place:placeOf(s,d),source:d.id});
   if(old.arrival>s.day&&r.arrival>old.arrival)add(s,83,{place:placeOf(s,d),source:d.id});
   if(r.arrival<old.arrival&&r.arrival>=s.day)add(s,84,{place:placeOf(s,d),source:d.id});
  }
  if(s.road.vehicle&&s.road.ownedVehicles.includes(s.road.vehicle)&&s.road.condition<8&&before.road.condition>=8)add(s,82,{place:places().includes(s.road.location)?s.road.location:'ironhaven',source:s.road.vehicle});
 }
 function availability(s,r,c){const op=c[4];
  if(op==='news_beacon')return s.pets.some(p=>p.id===r.source&&p.alive&&p.escaped);
  if(op==='news_spares')return s.road.vehicle===r.source&&s.road.ownedVehicles.includes(r.source)&&s.road.condition<8;
  if(op==='news_roof')return s.climate.maintenance.roof<100;
  if(op==='news_filter')return s.climate.maintenance.filter<100;
  if(op==='news_entry_light')return s.home.conditions.power<100;
 }
 function apply(s,r,c){const op=c[4];
  if(op==='news_roof')s.climate.maintenance.roof=Math.min(100,s.climate.maintenance.roof+15);
  if(op==='news_filter')s.climate.maintenance.filter=Math.min(100,s.climate.maintenance.filter+12);
  if(op==='news_entry_light')s.home.conditions.power=Math.min(100,s.home.conditions.power+5);
  if(op==='news_beacon'){const pet=s.pets.find(p=>p.id===r.source);pet.memories.push({day:s.day,text:Abyss.HomeData.t('寻访信标已检修，尚未确认返回。','The search beacon was serviced; return is unconfirmed.')});pet.memories=pet.memories.slice(-30);}
  if(op==='news_spares')s.road.condition=Math.min(100,s.road.condition+4);
 }
 return {discover,availability,apply};
})();
