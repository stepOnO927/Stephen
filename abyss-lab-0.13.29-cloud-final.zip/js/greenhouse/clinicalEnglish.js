'use strict';
// English presentation of the approved Chinese roster; IDs and canonical save text are unchanged.
Abyss.ClinicalEnglish=(()=>{
 const rows=`Low fever, fatigue, coughing, reduced appetite|Rest, hydration, infirmary observation; Clean Moss support
Dry cough, poor sleep, reduced activity|Warmth, rest; Warmroot support
Rapid breathing, reduced endurance, chills|Infirmary monitoring, pollution filtration; Grey Lungwort support
Coughing, exhaustion, mild fever|Isolation observation, medical supplies; Clearleaf support
Milder by day; night coughing interrupts sleep|A suitable sleep environment, fictional Herbal Steam preparation; Clearleaf
Coughing, eye irritation, reduced energy|Leave the industrial area, filter air; Clean Moss
Breathing difficulty, fatigue, rising contamination|Pollution care, isolation; Grey Lungwort
Low fever, dizziness, poor appetite|Rest, ventilation and hydration
Shivering, reduced breathing endurance, poor sleep|Warmth, Warmroot and recovery room
Dry cough, throat irritation, fatigue after activity|Leave polluted areas, hydrate; Clearleaf
Fever, weakness, reduced appetite|Isolate the contamination source, infirmary care; Clean Moss
Sneezing, eye irritation, fatigue|Remove the triggering plant and filter air
Discomfort swallowing, altered voice, low fever|Rest, hydration; Herbal Support
Fever, chills, poor sleep|Fictional infection-care supplies and rest
Fever, muscle pain, low appetite, fatigue|Rest, hydration, isolation and a doctor NPC
Stomach pain, nausea, reduced appetite|Gentler food; Digestive Mix
Abdominal pain, vomiting, dehydration|Hydration, rest and infirmary observation
Thirst, fatigue, unusual appetite|Hydration and diet adjustment
Nausea, food refusal|Stop that herb and change the preparation
Stomach pain, mild contamination increase|Stop eating the food and observe
Bloating, low appetite, worsening mood|Diet adjustment and infirmary care
Food refusal, abdominal discomfort|Change the nutrient source
Fatigue, disrupted appetite|Adjust nutritional balance
Low energy, unusual gnawing|Provide suitable plants
Brief excitement followed by fatigue, poor sleep|Reduce sweets and rest
Weakness, thirst, reduced activity|Hydration; Watermelon or Cucumber support
Poor appetite, fatigue|Reduce concentrated food
Refusal of certain food|Change food and gradually rebuild trust
Not eating under stress, abdominal discomfort|Reduce stress, Comfort Bloom and regular meals
Nausea after travel, food refusal, irritability|Rest, less travel; fictional Ginger preparation
Skin irritation, pain|Clean the affected area, Recovery Gel; shelter from acid rain
Itching, irritability, scratching|Cleaning; Aloe preparation
Pain, reduced movement|Warmth and Recovery Gel
Discomfort, irritability|Cooling; Coolgrass
Dull B-07 or monster surface, scratching|Cleaning and separation from polluted environments
Skin irritation in Jack or pets|Cleaning, change clothes; Aloe
Unusual patches on the surface|Contamination control and observation
Redness, irritability|Stop using the triggering plant
Itching, small spots|Air filtration and cleaning
Cracked surface, reduced comfort|Adjust humidity; care gel
Scratching, reduced sleep|Clean and isolate bedding; infirmary care
Irritability, skin discomfort|Clean bedding and separate greenhouse insects
Surface pain, fatigue|Infirmary removal and recovery
Fatigue, coughing|Remove infected plants and filter air
Low fever, weakness|Isolation, infirmary care; Clean Moss
Increased appetite but weight loss, fatigue|Fictional parasite-care supplies and isolation
Weakness, increased contamination|Advanced infirmary care
Fur loss, scratching|Cleaning, isolation and care
Discomfort walking|Dry surroundings and care gel
Low fever, weakness|Isolation, pest control and infirmary care
Fatigue, dizziness|Leave contaminated areas, Clean Moss and rest
Poor sleep, fatigue, low appetite|Recovery room and pollution care
Pain, fatigue, attribute fluctuation|Rest, monitoring and fictional stabilizers
Variable movement performance|Infirmary scans and fewer experiments
Unusual appetite, heat and cold sensitivity|Diet adjustment and observation
High fever, rising contamination|Isolation and advanced infirmary care
Faint surface glow, fatigue|Observation and reduced contamination
Fast recovery but severe fatigue|Stop stimulation and rest
Temporary changes in shape, pain|Stable surroundings and medical monitoring
Brief confusion, misplaced familiarity|Quiet surroundings and observation
Temperature does not match surroundings|Medical monitoring and stable surroundings
Severe fatigue, slow recovery|Rest, nutrition and infirmary care
Sleeplessness, irritability|Reduce contamination; Moonrest Flower support
Sudden food preferences or aversions|Diet adjustment and time
Avoiding activity, irritability|Fictional Pain Support, rest and infirmary care
Weakness, thirst, slow movement|Cooling, hydration; Coolgrass
Shivering, slow movement|Warmth; Warmroot
Severe fatigue|Rest and warm food
Eye irritation, coughing|Filtration and rest
Poor sleep, irritability|Reduce damp and change surroundings
Thirst, fatigue|Hydration and humidity adjustment
Poor sleep, slower reactions|Rest and a break from travel
Nausea, anxiety|Stop driving, rest; Ginger Support
Disrupted sleep timing|Adjust greenhouse or base lighting cycles
Low motivation, disrupted sleep, irritability|Greenhouse, outdoor activity and a regular routine
Hiding at alarms; aggression or escape reactions|Safe surroundings, gradual adjustment; Comfort Bloom
Repeated door checks, sleeping beside the door|Autonomy, control over the door and time
Avoiding examination or entering the infirmary|Medical trust, familiar surroundings and company
Agitation when Jack leaves|Regular routines, independent activities and pet company
Light sleep, repeatedly checking sounds|Quiet areas, greenhouse and sustained safety
Avoiding combat, irritability, poor sleep|Rest, gentle activity, music and greenhouse
Low appetite, low motivation, searching for the deceased|Time, company and memorial plants
Waking at night, daytime sleepiness|Regular routine, Moonrest Flower and quiet surroundings
Avoiding mirrors, watching limbs, discomfort with the body|Self-directed activity, gentle surroundings and sustained support
Unusual reactions to names, numbers or mirrors|Relationship support, independent choices and time
Distress after doors close, refusing isolation|Visible exits, intercom and medical trust
Panic during blackouts|Safe lighting, company and gradual adjustment
Refusing food selected by Jack|Let the patient choose food
Strong resistance before checks or care|Explain the process, allow stopping and increase autonomy
Poor sleep and appetite after losing or moving home|Restore familiar objects, plants and pets; build a new space`.split('\n').map(row=>row.split('|'));
 if(rows.length!==90)throw Error('Clinical English roster length mismatch');
 const catalog={},records={};for(const d of Abyss.DiseaseData){const row=rows[d.number-1];records[d.diseaseId]={symptoms:row[0],treatment:row[1]};catalog[d.name]=d.en;catalog[d.symptoms.join(' · ')]=row[0];catalog[d.treatmentType]=row[1];catalog[d.transmission]=d.transmission.includes('粉尘')?'Non-infectious; dust exposure':d.transmission.includes('中等')?'Moderately infectious':d.infectious?'Contact or shared environmental exposure (game abstraction)':'Non-infectious; related environments or experiences';}
 Abyss.I18n.register(catalog);return {records,catalog};
})();
