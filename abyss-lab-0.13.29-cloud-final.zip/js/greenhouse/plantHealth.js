'use strict';
// Fictional botanical conditions. Existing watering, growth and ecology stay authoritative.
Abyss.PlantHealth=(()=>{
 const catalog=[
  {id:'root_rot',name:'根部腐败',en:'Root rot',incubation:3,symptom:['根颈颜色偏暗，土层迟迟不干。','The root collar darkens; the soil stays wet.'],early:['盆底有异味，根颈还没有明显变色。','An unusual smell at the pot base; no obvious root-collar discoloration yet.'],risk:(p,e)=>e.soil<30&&p.water>=80},
  {id:'grey_mold',name:'灰斑霉害',en:'Grey mold',incubation:3,symptom:['叶缘出现灰色薄斑。','A thin grey patch appears along the leaf edge.'],early:['叶缘有一小片湿痕。','A small damp mark along the leaf edge.'],risk:(p,e)=>e.contamination>=35&&p.water>=65},
  {id:'leaf_spot',name:'叶斑病害',en:'Leaf spot',incubation:3,symptom:['叶面出现小斑点，部分边缘卷起。','Small spots on the leaves; some edges curl.'],early:['叶背出现针尖大小的浅点。','Pinpoint pale marks on the underside of a leaf.'],risk:(p,e)=>e.pests>=65&&p.water>=50}
 ];
 const fresh=day=>({version:1,lastDay:day,cases:[]});
 function read(raw,s){const out=fresh(s.day),used=new Set();if(raw?.version!==1)return out;
  for(const c of (Array.isArray(raw.cases)?raw.cases:[]).slice(0,80)){
   if(!c||!Number.isInteger(c.uid)||used.has(c.uid)||!s.greenhouse.plants.some(p=>p.uid===c.uid&&p.health>0)||!catalog.some(d=>d.id===c.id)||!Number.isInteger(c.since)||c.since<1||c.since>s.day||!Number.isFinite(c.progress)||c.progress<0||c.progress>100)continue;
   used.add(c.uid);out.cases.push({uid:c.uid,id:c.id,since:c.since,progress:c.progress,detectedDay:Number.isInteger(c.detectedDay)&&c.detectedDay>=c.since&&c.detectedDay<=s.day?c.detectedDay:0,careUntil:Number.isInteger(c.careUntil)&&c.careUntil>=c.since&&c.careUntil<=s.day+3?c.careUntil:0});
  }return out;
 }
 function day(s,day){const g=s.greenhouse,h=g.plantHealth;if(s.mode!=='raising'||!g.unlocked||!h||day<=h.lastDay||day>s.day)return;
   h.cases=h.cases.filter(c=>g.plants.some(p=>p.uid===c.uid&&p.health>0));
   for(const p of g.plants.filter(p=>p.health>0)){
    const exposure=catalog.find(d=>d.risk(p,g.ecology));let c=h.cases.find(c=>c.uid===p.uid);
    if(!c&&exposure){c={uid:p.uid,id:exposure.id,since:day,progress:0,detectedDay:0,careUntil:0};h.cases.push(c);}
    if(!c)continue;const d=catalog.find(d=>d.id===c.id),risk=d.risk(p,g.ecology),care=c.careUntil>=day,age=day-c.since;
    c.progress=Math.max(0,Math.min(100,c.progress+(care?-7:risk?8:-5)));
    if(age>=d.incubation&&c.progress>0){c.detectedDay||=day;const resilience=Math.max(0,Math.min(3,p.traits?.resilience||0));p.health=Math.max(0,p.health-(.15+c.progress*.005)*(1-resilience*.1));if(p.health===0){const def=Abyss.PlantData.find(d=>d.id===p.plantId);Abyss.State.log(s,Abyss.HomeData.t(def.name+'枯萎了，种植槽可以清理。',def.en+' withered. The bed can be cleared.'),'warning');h.cases=h.cases.filter(x=>x!==c);}}
    if(c.progress===0&&(!risk||care))h.cases=h.cases.filter(x=>x!==c);
   }
  h.lastDay=day;
 }
 function tick(before,s){const g=s.greenhouse;if(s.mode!=='raising'||!g.unlocked||s.day<=before.day)return;g.plantHealth||=fresh(before.day);for(let d=g.plantHealth.lastDay+1;d<=s.day;d++)day(s,d);}
 function observeShift(s){const h=s.greenhouse.plantHealth;
  for(const c of h?.cases||[])if(s.day>c.since&&!c.detectedDay)c.detectedDay=s.day;
 }
 function prune(s){const h=s.greenhouse.plantHealth;if(h)h.cases=h.cases.filter(c=>s.greenhouse.plants.some(p=>p.uid===c.uid&&p.health>0));}
 function html(s){const en=Abyss.I18n.language()==='en',t=(a,b)=>en?b:a,esc=Abyss.Util.escape,rows=symptoms(s),targets=(s.greenhouse.plantHealth?.cases||[]).filter(c=>c.detectedDay&&c.careUntil<s.day),available=s.mode==='raising'&&Abyss.LabOperations.atLab(s)&&Abyss.LabRooms.canEnter(s,'greenhouse')&&!s.awaySince&&!s.pendingEvent&&!s.dreams.active&&s.ap>=1&&s.climate.labResources.water>=2&&targets.length;
  return '<section class="garden-plant-health"><h3>'+t('植株观察','Plant observations')+'</h3>'+rows.map(r=>{const p=s.greenhouse.plants.find(p=>p.uid===r.uid),d=Abyss.PlantData.find(d=>d.id===p?.plantId),c=s.greenhouse.plantHealth.cases.find(c=>c.uid===r.uid);return '<p>'+esc(d?(en?d.en:d.name):t('种植槽','Plant bed'))+' · '+(r.early?t('早期值班观察','Early duty observation'):t('可见征兆','Visible signs'))+'：'+esc(r.text[en?1:0])+(c.careUntil>=s.day?' · '+t('护理中','Care in progress'):'')+'</p>';}).join('')+(rows.length?'<p>'+t('恢复按日进行；仍需改善土质、水分和环境。','Recovery progresses over days; improve soil, water and environment too.')+'</p><button data-garden-action="plantCare" data-args="{}" '+(available?'':'disabled')+'>'+t('清理病斑 · 1 AP / 2 净水','Clean observed damage · 1 AP / 2 water')+'</button>':'<p>'+t('没有已察觉的病害征兆。','No observed disease signs.')+'</p>')+'</section>';
 }
 function symptoms(s){return (s.greenhouse.plantHealth?.cases||[]).filter(c=>c.detectedDay).map(c=>{const d=catalog.find(d=>d.id===c.id);return {uid:c.uid,id:c.id,since:c.since,early:s.day-c.since<d.incubation,text:s.day-c.since<d.incubation?d.early:d.symptom};});}
 function care(s){if(s.mode!=='raising'||!Abyss.LabOperations.atLab(s)||!Abyss.LabRooms.canEnter(s,'greenhouse')||s.awaySince||s.pendingEvent||s.dreams.active)return false;const h=s.greenhouse.plantHealth,targets=(h?.cases||[]).filter(c=>c.detectedDay&&c.careUntil<s.day);if(!targets.length||s.ap<1||s.climate.labResources.water<2)return false;
  s.ap--;s.climate.labResources.water-=2;for(const c of targets)c.careUntil=s.day+3;return true;
 }
 return {catalog,fresh,read,day,tick,observeShift,symptoms,care,prune,html};
})();
