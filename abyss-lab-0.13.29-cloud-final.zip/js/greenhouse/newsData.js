'use strict';
// Requested 90 news topics. Reports require corresponding state changes or confirmed observations.
Abyss.NewsData=[
  {
    "id": "news_1",
    "number": 1,
    "name": "饮水污染",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_2",
    "number": 2,
    "name": "某区域水源恢复",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_3",
    "number": 3,
    "name": "医院药品短缺",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_4",
    "number": 4,
    "name": "医生/医疗队迁移",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_5",
    "number": 5,
    "name": "检疫站开放或关闭",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_6",
    "number": 6,
    "name": "某聚落出现大量发热病例",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_7",
    "number": 7,
    "name": "宠物/野兽疾病暴发",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_8",
    "number": 8,
    "name": "植物病害",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_9",
    "number": 9,
    "name": "温室种子召回",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_10",
    "number": 10,
    "name": "某种食物批次污染",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_11",
    "number": 11,
    "name": "燃料价格异常",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_12",
    "number": 12,
    "name": "电网断电",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_13",
    "number": 13,
    "name": "桥梁坍塌",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_14",
    "number": 14,
    "name": "道路维修",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_15",
    "number": 15,
    "name": "隧道封闭",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_16",
    "number": 16,
    "name": "地铁区域重新开放",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_17",
    "number": 17,
    "name": "新增检查站",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_18",
    "number": 18,
    "name": "政府配给变化",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_19",
    "number": 19,
    "name": "新的通行许可要求",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_20",
    "number": 20,
    "name": "某区域夜间宵禁",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_21",
    "number": 21,
    "name": "某NPC失踪",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_22",
    "number": 22,
    "name": "某商队领队死亡",
    "category": "CARAVANS",
    "requiresConfirmedState": true
  },
  {
    "id": "news_23",
    "number": 23,
    "name": "某医生失踪",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_24",
    "number": 24,
    "name": "某官员被替换",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_25",
    "number": 25,
    "name": "某土匪头目死亡",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_26",
    "number": 26,
    "name": "新帮派出现",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_27",
    "number": 27,
    "name": "旧帮派分裂",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_28",
    "number": 28,
    "name": "土匪悬赏",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_29",
    "number": 29,
    "name": "赏金猎人活动",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_30",
    "number": 30,
    "name": "某区域怪兽迁徙",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_31",
    "number": 31,
    "name": "大型怪兽目击",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_32",
    "number": 32,
    "name": "变异生物繁殖季",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_33",
    "number": 33,
    "name": "猎物减少",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_34",
    "number": 34,
    "name": "捕食者增加",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_35",
    "number": 35,
    "name": "宠物走失",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_36",
    "number": 36,
    "name": "新救助站开放",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_37",
    "number": 37,
    "name": "难民潮",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_38",
    "number": 38,
    "name": "聚落人口下降",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_39",
    "number": 39,
    "name": "流浪者集中出现",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_40",
    "number": 40,
    "name": "黑市搬迁",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_41",
    "number": 41,
    "name": "黑市被查",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_42",
    "number": 42,
    "name": "假货泛滥",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_43",
    "number": 43,
    "name": "假官方商队",
    "category": "CARAVANS",
    "requiresConfirmedState": true
  },
  {
    "id": "news_44",
    "number": 44,
    "name": "假药事件",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_45",
    "number": 45,
    "name": "稀有种子流入市场",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_46",
    "number": 46,
    "name": "稀有药草发现",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_47",
    "number": 47,
    "name": "传奇变卖物出现",
    "category": "VALUABLES",
    "requiresConfirmedState": true
  },
  {
    "id": "news_48",
    "number": 48,
    "name": "博物馆遗物线索",
    "category": "VALUABLES",
    "requiresConfirmedState": true
  },
  {
    "id": "news_49",
    "number": 49,
    "name": "银行金库重新打开",
    "category": "VALUABLES",
    "requiresConfirmedState": true
  },
  {
    "id": "news_50",
    "number": 50,
    "name": "废弃豪宅被发现",
    "category": "VALUABLES",
    "requiresConfirmedState": true
  },
  {
    "id": "news_51",
    "number": 51,
    "name": "数据中心重新通电",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_52",
    "number": 52,
    "name": "电视台恢复短时广播",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_53",
    "number": 53,
    "name": "新广播频道",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_54",
    "number": 54,
    "name": "异常广播",
    "category": "ANOMALY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_55",
    "number": 55,
    "name": "某地区无线电静默",
    "category": "ANOMALY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_56",
    "number": 56,
    "name": "Grey Tide移动",
    "category": "ANOMALY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_57",
    "number": 57,
    "name": "Grey Tide减弱",
    "category": "ANOMALY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_58",
    "number": 58,
    "name": "酸雨预警",
    "category": "WEATHER",
    "requiresConfirmedState": true
  },
  {
    "id": "news_59",
    "number": 59,
    "name": "雷暴异常",
    "category": "WEATHER",
    "requiresConfirmedState": true
  },
  {
    "id": "news_60",
    "number": 60,
    "name": "沙尘暴路线变化",
    "category": "WEATHER",
    "requiresConfirmedState": true
  },
  {
    "id": "news_61",
    "number": 61,
    "name": "暴雪封路",
    "category": "WEATHER",
    "requiresConfirmedState": true
  },
  {
    "id": "news_62",
    "number": 62,
    "name": "高温预警",
    "category": "WEATHER",
    "requiresConfirmedState": true
  },
  {
    "id": "news_63",
    "number": 63,
    "name": "森林火灾",
    "category": "WEATHER",
    "requiresConfirmedState": true
  },
  {
    "id": "news_64",
    "number": 64,
    "name": "洪水",
    "category": "WEATHER",
    "requiresConfirmedState": true
  },
  {
    "id": "news_65",
    "number": 65,
    "name": "水库干涸",
    "category": "WEATHER",
    "requiresConfirmedState": true
  },
  {
    "id": "news_66",
    "number": 66,
    "name": "河流改道",
    "category": "WEATHER",
    "requiresConfirmedState": true
  },
  {
    "id": "news_67",
    "number": 67,
    "name": "土壤污染",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_68",
    "number": 68,
    "name": "农作物歉收",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_69",
    "number": 69,
    "name": "温室丰收",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_70",
    "number": 70,
    "name": "某聚落粮价下降",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_71",
    "number": 71,
    "name": "某聚落药价上涨",
    "category": "HEALTH",
    "requiresConfirmedState": true
  },
  {
    "id": "news_72",
    "number": 72,
    "name": "木材短缺",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_73",
    "number": 73,
    "name": "电池短缺",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_74",
    "number": 74,
    "name": "清洁用品短缺",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_75",
    "number": 75,
    "name": "电脑零件行情",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_76",
    "number": 76,
    "name": "高档酒行情",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_77",
    "number": 77,
    "name": "烟草行情",
    "category": "TRADE",
    "requiresConfirmedState": true
  },
  {
    "id": "news_78",
    "number": 78,
    "name": "古董行情",
    "category": "VALUABLES",
    "requiresConfirmedState": true
  },
  {
    "id": "news_79",
    "number": 79,
    "name": "官方拍卖",
    "category": "VALUABLES",
    "requiresConfirmedState": true
  },
  {
    "id": "news_80",
    "number": 80,
    "name": "黑市拍卖",
    "category": "VALUABLES",
    "requiresConfirmedState": true
  },
  {
    "id": "news_81",
    "number": 81,
    "name": "车辆失窃",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_82",
    "number": 82,
    "name": "车辆抛锚求援",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_83",
    "number": 83,
    "name": "官方车队延误",
    "category": "CARAVANS",
    "requiresConfirmedState": true
  },
  {
    "id": "news_84",
    "number": 84,
    "name": "官方车队提前抵达",
    "category": "CARAVANS",
    "requiresConfirmedState": true
  },
  {
    "id": "news_85",
    "number": 85,
    "name": "某地出现免费补给点",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_86",
    "number": 86,
    "name": "某地出现诈骗补给点",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_87",
    "number": 87,
    "name": "官方通缉令",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_88",
    "number": 88,
    "name": "官方赦免令",
    "category": "SECURITY",
    "requiresConfirmedState": true
  },
  {
    "id": "news_89",
    "number": 89,
    "name": "聚落选举/权力更替",
    "category": "WORLD",
    "requiresConfirmedState": true
  },
  {
    "id": "news_90",
    "number": 90,
    "name": "纪念日/葬礼公告",
    "category": "WORLD",
    "requiresConfirmedState": true
  }
];
