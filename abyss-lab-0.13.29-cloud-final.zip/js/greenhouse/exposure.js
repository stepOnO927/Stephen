'use strict';
// Only committed gameplay changes can generate exposure. Menus and invalid commands cannot roll.
Abyss.ClinicalExposure=(()=>{
 function context(before,s,c,p){const base={region:Abyss.Climate.here(s),outside:!Abyss.Road.atLab(s)||!!s.wasteland.active,distance:s.road.dayDistance,pollution:s.home.conditions.contamination};
  if(c.type==='experiment'&&s.history.experiment>before.history.experiment)return {...base,experiment:true};
  if(c.type==='feed'&&s.history.feed>before.history.feed){const d=Abyss.Data.foods.find(d=>d.id===c.payload);return {...base,foodPoor:(d?.effects.pollution||0)>=4,food:d?.id==='hunt_gel'?'gel':d?.id==='meat'?'predator':'prey'};}
  if(c.type==='garden:feed'){const b=before.greenhouse.harvest[Number(c.payload?.batch)];return {...base,foodPoor:(b?.contamination||0)>0,food:'prey'};}
  if(c.type==='pet:feed'&&c.payload?.id===p.id)return {...base,food:'prey',foodPoor:before.pets.find(x=>x.id===p.id)?.hunger>90};
  const stressors=[];
  if(before.climate.labResources.power>=10&&s.climate.labResources.power<10)stressors.push(76,87);
  if(c.type==='punish')stressors.push(77,80,86);
  if(c.type==='medical:assess'&&c.payload?.patient===p.id)stressors.push(78);
  if(c.type==='medical:treat'&&c.payload?.patient===p.id)stressors.push(89);
  if(c.type==='medical:quarantine'&&c.payload?.patient===p.id&&p.quarantine)stressors.push(77,86);
  if(c.type==='hunt:resolve')stressors.push(81);
  if(before.pets.some(old=>old.alive&&s.pets.some(x=>x.id===old.id&&!x.alive)))stressors.push(82);
  if(c.type==='exp:start'||c.type==='road:start')stressors.push(79);
  if(before.mutations.length<s.mutations.length)stressors.push(84);
  if(c.type==='rename'&&before.name!==s.name)stressors.push(85);
  if(c.type==='home:move'&&before.home.location!==s.home.location)stressors.push(90);
  if(stressors.length)return {...base,stressors};
  if(c.type==='explore'||c.type?.startsWith('road:')&&s.road.dayDistance>before.road.dayDistance)return base;
  return null;
 }
 function observe(before,s,c){for(const p of s.infirmary.patients){if(p.hostType==='NPC'||!Abyss.Infirmary.living(s,p)||p.lastExposureDay===s.day)continue;const ctx=context(before,s,c,p);if(!ctx)continue;if(p.id!=='b07'&&['feed','garden:feed','experiment','rename'].includes(c.type))continue;if(c.type==='pet:feed'&&c.payload?.id!==p.id)continue;const pool=Abyss.DiseaseData.filter(d=>Abyss.DiseaseRisks.eligible(s,p,d,ctx));if(!pool.length)continue;p.lastExposureDay=s.day;if(Abyss.Util.random(s)<.06)Abyss.Illness.expose(s,p,Abyss.Util.pick(s,pool).diseaseId,c.type);}}
 return {context,observe};
})();
