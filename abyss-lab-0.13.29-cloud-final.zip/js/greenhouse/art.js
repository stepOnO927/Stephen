'use strict';
// Independent SVG illustrations; replace via visual.file with final PNG/WebP art.
Abyss.PlantArt = (() => {
 const esc=x=>Abyss.Util.escape(String(x));
 function render(d,growth=100){
  if(d.visual?.file)return `<img class="garden-art" src="${esc(d.visual.file)}" alt="${esc(d.name)}">`;
  const n=d.number,scale=.35+Math.max(0,Math.min(100,growth))*.0065;
  const shades=['#638958','#78956b','#567c72','#8eaa69','#67846a'],green=shades[n%5],hue=(n*29)%360,fruit=`hsl(${hue} 45% 53%)`,leaf=(x,y,a,s=1)=>`<ellipse cx="${x}" cy="${y}" rx="${16*s}" ry="${7*s}" fill="${green}" stroke="#bfd2a055" transform="rotate(${a} ${x} ${y})"/>`;
  let plant='';
  if(d.category==='tree'){
   plant=`<path d="M116 158 Q${106+n%15} 110 118 56 M116 115 L88 91 M117 99 L145 78" stroke="#887058" stroke-width="9" fill="none"/>`;
   for(let i=0;i<7;i++){const a=i*2.4+n,x=117+Math.cos(a)*(25+i*3),y=74+Math.sin(a)*22;plant+=`<ellipse cx="${x}" cy="${y}" rx="${22+n%9}" ry="${17+i%5}" fill="${green}" stroke="#c3d4a533"/>`;}
   for(let i=0;i<4;i++)plant+=`<circle cx="${88+i*18}" cy="${85+(i%2)*12}" r="5" fill="${fruit}"/>`;
  }else if(d.category==='flower'){
   for(let j=0;j<3;j++){const x=87+j*29,y=67+(j%2)*21,petals=5+n%8;plant+=`<path d="M116 159 Q${x} 114 ${x} ${y}" fill="none" stroke="${green}" stroke-width="3"/>`;for(let i=0;i<petals;i++)plant+=`<ellipse cx="${x}" cy="${y-13}" rx="${5+n%4}" ry="14" fill="${fruit}" transform="rotate(${i*360/petals} ${x} ${y})"/>`;plant+=`<circle cx="${x}" cy="${y}" r="7" fill="#d8c796"/>`;}
   plant+=leaf(103,118,-35)+leaf(133,135,35);
  }else if(/Aloe|Agave|Cactus/.test(d.en)){
   for(let i=0;i<7;i++)plant+=`<path d="M116 157 Q${75+i*13} 112 ${67+i*16} ${53+Math.abs(i-3)*9} Q${94+i*8} 124 122 157Z" fill="${green}" stroke="#c4d4a955"/>`;
  }else{
   const stems=d.category==='herb'?5:3;
   for(let j=0;j<stems;j++){const x=88+j*(56/(stems-1)),top=54+(n+j*7)%24;plant+=`<path d="M117 159 Q${x} 112 ${x} ${top}" stroke="${green}" stroke-width="3" fill="none"/>`;for(let i=0;i<3;i++){const y=top+18+i*24;plant+=leaf(x-9,y,-32,.6+i*.15)+leaf(x+11,y+8,35,.7+i*.1);}if(d.category==='fruit')for(let i=0;i<3;i++)plant+=`<ellipse cx="${x+(i-1)*8}" cy="${top+13+i*8}" rx="${5+n%5}" ry="${6+n%4}" fill="${fruit}" stroke="#e2dfc333"/>`;}
   if(d.category==='vegetable'){
    const tuber=/Potato|Carrot|Turnip|Beet|Onion|Garlic/.test(d.en),color=tuber?/Carrot/.test(d.en)?'#c89158':'#ab9674':fruit;
    plant+=`<ellipse cx="117" cy="${tuber?144:120}" rx="${17+n%14}" ry="${13+n%10}" fill="${color}" stroke="#e5d8a455"/>`;
    for(let i=-1;i<=1;i++)plant+=`<path d="M${117+i*7} ${tuber?133:106} Q${111+i*9} ${tuber?144:120} ${117+i*7} ${tuber?155:134}" fill="none" stroke="#352c2f33"/>`;
   }
  }
  const rare=['EPIC','LEGENDARY','ANOMALOUS'].includes(d.rarity),pot=rare?'#727f7f':'#746858';
  return `<svg class="garden-art" viewBox="0 0 240 210" role="img" aria-label="${esc(d.name)}"><defs><linearGradient id="pot-${n}" x2="1" y2=".8"><stop stop-color="${pot}"/><stop offset="1" stop-color="#293733"/></linearGradient></defs><ellipse cx="120" cy="195" rx="72" ry="8" fill="#0005"/><g transform="translate(${120-120*scale} ${158-158*scale}) scale(${scale})">${plant}</g><path d="M83 153 L91 191 Q120 204 149 191 L157 153Z" fill="url(#pot-${n})" stroke="#b5bca355"/><ellipse cx="120" cy="153" rx="37" ry="9" fill="#574c3e" stroke="#b5bca388"/><path d="M92 167 L96 188" stroke="#d2d7bd55" stroke-width="3"/><rect x="105" y="171" width="32" height="13" rx="2" fill="#d7d7c3"/><text x="121" y="180" text-anchor="middle" fill="#354440" font-size="7">B-${String(n).padStart(3,'0')}</text>${d.rarity==='ANOMALOUS'?'<path d="M60 92 Q86 77 65 65 M171 58 Q197 78 181 99" stroke="#bb929a66" fill="none"/>':''}</svg>`;
 }
 return {render};
})();

// Independent, replaceable equipment/product silhouettes, rather than empty cards.
Abyss.GardenEquipmentArt=(()=>{
 const E=Abyss.Util.escape,wrap=(id,body)=>`<svg class="garden-art" data-garden-model="${E(id)}" viewBox="0 0 240 180" role="img" aria-label="${E(id)}"><defs><linearGradient id="ga-${E(id)}" x2="1" y2="1"><stop stop-color="#aac4b6"/><stop offset=".45" stop-color="#557970"/><stop offset="1" stop-color="#243e42"/></linearGradient></defs><ellipse cx="120" cy="161" rx="76" ry="9" fill="#0005"/>${body}</svg>`;
 const R=(x,y,w,h,fill='#72978c',r=4)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="${fill}" stroke="#c1d4bf66"/>`;
 function product(id){const models={
 calming:`<path d="M63 74h99l-9 69H73Z" fill="#b7b49b"/><ellipse cx="112" cy="75" rx="49" ry="13" fill="#7b674c"/><path d="M163 86q46-8 24 41l-31 5M98 57q-15-18 2-31m23 32q-14-17 1-28" fill="none" stroke="#c5c6aa" stroke-width="5"/>`,
 gel:R(62,79,117,67,'#658f97',13)+`<ellipse cx="120" cy="81" rx="59" ry="12" fill="#b2cec6"/>`+R(68,65,104,18,'#d1cbb5')+R(81,100,77,25,'#cadac9'),
 sleep:`<path d="M65 63l51-16 58 20-6 81-99 6Z" fill="#727688" stroke="#b6bacd"/><path d="M84 66q35 15 68-3M107 80v53" stroke="#d2ccab" fill="none"/><path d="M136 94a15 15 0 1 0 10 22a12 12 0 0 1-10-22" fill="#c8c6a5"/>`,
 cold:R(61,81,119,64,'#a48059',16)+`<path d="M73 90h91m-54-12V62h25v16M85 105q14 25 29 0t30 0" stroke="#e1bf87" fill="none" stroke-width="4"/>`,
 heat:`<path d="M67 73l26-11 74 17-6 69-96-7Z" fill="#679eae" stroke="#b4e0d4"/><path d="m116 86 0 45m-20-34 39 23m-39 0 39-23" stroke="#d4e7df" stroke-width="3"/>`,
 respiratory:R(59,84,121,49,'#c0c6b4',20)+`<path d="M60 91Q20 59 34 123M180 92q38-32 24 31M96 89v37m13-37v37m13-37v37m13-37v37" fill="none" stroke="#78968c" stroke-width="4"/>`,
 comfort:`<path d="M62 69q58-23 116 0l-9 76H72Z" fill="#a38a9d" stroke="#d7bdd3"/><path d="M80 69q40 19 79 0m-40 19v40" stroke="#d9c7b0" fill="none"/><circle cx="121" cy="109" r="12" fill="#c7abb5"/>`,
 recoveryEnvironment:R(81,62,78,86,'#758978',10)+R(91,49,58,18,'#d0c6a1')+`<path d="M101 137q37-25 28-61m-25 28 26 0m-22 15 22 0" fill="none" stroke="#c8d0b3" stroke-width="3"/>`,
 wound:`<path d="M69 88l97-15 12 48-96 19Z" fill="#c3c9b9" stroke="#e3ddc2"/><ellipse cx="79" cy="113" rx="19" ry="28" fill="#a6b9ae"/><ellipse cx="79" cy="113" rx="8" ry="13" fill="#304941"/><path d="m120 89 5 38m-18-15 32-5" stroke="#698e7b" stroke-width="5"/>`,
 pollution:R(87,60,65,88,'#79919a',10)+R(94,47,51,18,'#c5b594')+R(94,102,51,24,'#abbfb7')+`<path d="M107 82h24m-12-12v23" stroke="#c9d5c0" stroke-width="4"/>`};return wrap('product-'+id,models[id]||models.gel);}
 function equipment(id){const shapes={
 soil:`<path d="M49 91l70-32 72 36-68 47Z" fill="#6d5845"/><path d="m49 91 0 36 74 29v-14m68-47v33l-68 28" fill="#3e4840" stroke="#aab697"/><path d="M122 111V68m0 16q-29 3-21-19m21 12q26 7 22-17" stroke="#86b583" fill="none" stroke-width="5"/>`,
 pests:`<path d="M79 66h83v82H79Z" fill="#556b66" stroke="#bacaaf"/><path d="m80 66 21-20h80l-19 20v82l19-20V46" fill="#3d5655" stroke="#8eaaa0"/><circle cx="122" cy="102" r="23" fill="#b3b06e"/><path d="M122 89v26m-12-24 24 19m-24 0 24-19" stroke="#5c6043" stroke-width="3"/>`,
 water:R(70,69,84,78,'#658e9a',12)+`<path d="M73 82l-24 15 11 12 15-9M144 75q54-57 66 18" stroke="#accabc" stroke-width="8" fill="none"/><path d="M114 89q-23 24 0 33q23-9 0-33" fill="#b9dcdb"/>`,
 power:R(64,70,112,80,'#456262')+R(71,77,61,44,'#1c353c')+`<path d="M76 100h11l8-15 11 24 8-11h13m18-41v-8h22v8" stroke="#b7c5a5" stroke-width="3" fill="none"/>`,
 contamination:R(74,93,105,54,'#766f86')+`<path d="M92 90V51m22 39V44m23 46V51" stroke="#a6bfbb" stroke-width="15"/><path d="M88 76v-20m21 20V50m23 28V56" stroke="#b6a1c3" stroke-width="7"/><path d="M162 123q28-40 39-23" stroke="#a4bfb0" fill="none"/>`,
 biodiversity:`<path d="M59 147V64h119v83" fill="none" stroke="#729388" stroke-width="5"/><path d="M59 64l58-34 61 34" fill="#76969044" stroke="#a7c4bb"/><path d="M66 115h104m-88 28V91m27 52V76m29 67V87m23 56V99" stroke="#a9b59a" stroke-width="4"/><ellipse cx="82" cy="92" rx="12" ry="7" fill="#8dae85"/><circle cx="109" cy="75" r="12" fill="#bda4b3"/><ellipse cx="138" cy="90" rx="15" ry="8" fill="#91b487"/>`,
 pollination:`<path d="M65 144h98V81H65Z" fill="#9c865e" stroke="#d4c3a0"/><path d="M59 81l54-30 58 30m-95 17h66m-66 16h66m-66 16h66" stroke="#c8b990" fill="none" stroke-width="5"/><ellipse cx="182" cy="82" rx="17" ry="10" fill="#b9a172"/><ellipse cx="179" cy="67" rx="14" ry="9" fill="#c8e0d666"/><path d="M177 75v17m8-17v17" stroke="#354941" stroke-width="4"/>`};return wrap('equipment-'+id,shapes[id]||shapes.biodiversity);}
 function patient(p){return wrap('patient-'+p.hostType,`<path d="M45 112l124-20 33 35-125 23Z" fill="#a8bbb0" stroke="#d5ddd0"/><path d="m45 112v18l32 33 125-20v-16" fill="#536e69"/><path d="M54 126v30m136-20v23" stroke="#81988c" stroke-width="8"/>${p.hostType==='B07'?'<ellipse cx="111" cy="102" rx="31" ry="24" fill="#83b9a1"/><path d="m86 87 2-20 17 16m19-1 19-14-3 23" fill="#83b9a1"/><circle cx="102" cy="98" r="5" fill="#254b42"/><circle cx="122" cy="98" r="5" fill="#254b42"/>':p.hostType==='PET'?'<ellipse cx="116" cy="107" rx="33" ry="17" fill="#a9977d"/><circle cx="89" cy="96" r="17" fill="#a9977d"/>':'<path d="M90 108q20-27 58-7l23 19-61 8Z" fill="#7793a7"/><circle cx="84" cy="101" r="15" fill="#b8a18b"/>'}${R(168,42,45,35,'#18343b')}<path d="M173 60h7l4-10 5 17 5-7h14M191 78v22" stroke="#a6c9ae" fill="none" stroke-width="2"/>`);}
 function depth(fn){return (...args)=>{let svg=fn(...args),defs='' ;const colors=[...new Set([...svg.matchAll(/fill="(#[0-9a-fA-F]{6})"/g)].map(m=>m[1]))];for(const [n,c]of colors.entries()){const id='material-'+String(args[0]?.hostType||args[0]).replace(/[^a-zA-Z0-9_-]/g,'')+'-'+n;const shade=f=>'#'+[1,3,5].map(i=>Math.max(0,Math.min(255,Math.round(parseInt(c.slice(i,i+2),16)*f))).toString(16).padStart(2,'0')).join('');defs+=`<linearGradient id="${id}" x2="1" y2=".6"><stop stop-color="${shade(1.18)}"/><stop offset=".35" stop-color="${c}"/><stop offset="1" stop-color="${shade(.55)}"/></linearGradient>`;svg=svg.replaceAll(`fill="${c}"`,`fill="url(#${id})"`);}return svg.replace('</defs>',defs+'</defs>');};} return {product:depth(product),equipment:depth(equipment),patient:depth(patient)};
})();
