'use strict';
// Conditions are fictional gameplay records, separate from identity and relationship memories.
Abyss.Illness=(()=>{
 const byId=id=>(Abyss.DiseaseData||[]).find(d=>d.diseaseId===id);
 const clamp=v=>Math.max(0,Math.min(100,v));
 const stages=['MILD','MODERATE','SEVERE','CRITICAL'];
 const statuses=['INCUBATING','STABLE','IMPROVING','NO_CHANGE','WORSENING','RECOVERING','RECOVERED'];
 const count=(v,max)=>Math.max(0,Math.min(max,Math.floor(Number(v)||0)));
 function read(raw){return (Array.isArray(raw)?raw:[]).filter(c=>byId(c?.id)).slice(-12).map(c=>({
  id:c.id,days:count(c.days,999),progress:clamp(Number(c.progress)||0),severity:stages.includes(c.severity)?c.severity:byId(c.id).severity,
  worsening:count(c.worsening,100),status:statuses.includes(c.status)?c.status:'STABLE',origin:String(c.origin||'unknown').slice(0,60),
  afterDays:count(c.afterDays,21),protection:count(c.protection,30),careDays:count(c.careDays,999),missedDays:count(c.missedDays,999)
 }));}
 function expose(s,p,id,origin){
  const d=byId(id),host=p.hostType||(p.id==='jack'?'HUMAN':'B07');p.conditions||=[];
  if(!d||!d.hostTypes.includes(host)||p.conditions.some(c=>c.id===id&&(c.status!=='RECOVERED'||c.protection>0))||p.conditions.filter(c=>c.status!=='RECOVERED').length>=3)return false;
  p.conditions.push({id,days:0,progress:0,severity:d.severity,worsening:0,status:d.incubation?'INCUBATING':'STABLE',origin,afterDays:0,protection:0,careDays:0,missedDays:0});p.conditions=p.conditions.slice(-12);
  if(d.newsReportable){const list=s.infirmary.bulletins||=[],b=list.find(b=>b.day===s.day&&b.diseaseId===id);if(b)b.firstKnownCase++;else list.push({day:s.day,diseaseId:id,originRegion:'Laboratory',firstKnownCase:1,routeSpread:[String(origin)],hostSpecies:[host],expires:s.day+3});s.infirmary.bulletins=list.slice(-8);}return true;
 }
 function careMatches(d,p){
  if(!p.plan)return false;const plants=(p.supportPlants||[]).some(id=>d.plantSupports.includes(id));
  if(d.category==='PSYCHOLOGICAL')return ['calm','sleep'].includes(p.plan)&&p.medicalTrust>=45&&p.stress<60;
  if(d.category==='CONTAMINATION')return p.plan==='pollution'||plants;
  if(['RESPIRATORY','DIGESTIVE','DERMAL','PARASITIC'].includes(d.category))return p.plan==='physical'||plants;
  return ['physical','sleep'].includes(p.plan)||plants;
 }
 function course(s,p,c){
  const d=byId(c.id),b=Abyss.DiseaseBalance.get(d),mental=d.category==='PSYCHOLOGICAL';
  const supported=careMatches(d,p)||(mental&&p.stress<40&&p.sleep>=55&&p.medicalTrust>=50);
  const herb=(p.supportPlants||[]).some(id=>d.plantSupports.includes(id));
  const environment=Abyss.DiseaseBalance.environment(s,p,d);
  const risk=b.worsening*(supported?.22:1)*(environment<1?1.25:1);
  return {d,b,mental,supported,environment,risk,increment:100/b.days*(supported?1:b.natural)*environment*(herb?1.15:1)};
 }
 function tick(s,p,context={}){
  p.conditions||=[];let totalDamage=0;
  for(const c of p.conditions){
   if(c.status==='RECOVERED'){c.afterDays=Math.max(0,c.afterDays-1);c.protection=Math.max(0,(c.protection||0)-1);continue;}
   c.days++;const {d,b,mental,supported,risk,increment}=course(s,p,c);
   if(c.days<=d.incubation){c.status='INCUBATING';continue;}
   c.careDays=(c.careDays||0)+(supported?1:0);c.missedDays=(c.missedDays||0)+(supported?0:1);
   const roll=Abyss.Util.random(s);
   if(roll<risk){
    c.status='WORSENING';c.worsening=(c.worsening||0)+1;
    if(!mental&&c.worsening%4===0)c.severity=stages[Math.min(3,stages.indexOf(c.severity)+1)];
    if(mental)p.stress=clamp(p.stress+(supported?1:2));
    else totalDamage+=Math.min(4,b.damage+(c.severity==='CRITICAL'?1:0));
    c.progress=clamp(c.progress+increment*.25);
   }else {c.progress=clamp(c.progress+increment);c.status=c.progress>=70?'RECOVERING':'IMPROVING';}
   if(c.progress>=100){c.status='RECOVERED';c.afterDays=b.after;c.protection=b.protection;p.history||=[];
    p.history.push(Abyss.HomeData.t('恢复观察：','Recovery follow-up: ')+Abyss.HomeData.t(d.name,d.en));p.history=p.history.slice(-30);}
  }
  if(totalDamage)Abyss.Infirmary.changeHealth(s,p,-Math.min(5,totalDamage));
  if(p.conditions.some(c=>c.status!=='RECOVERED'))return;
  const riskContext={...context,region:Abyss.Climate.here(s),outside:!Abyss.Road.atLab(s)||!!s.wasteland.active,distance:s.road.dayDistance,experiment:context.type==='experiment',stressor:context.type==='hunt:resolve'?81:context.type==='medical:treat'?89:undefined};
  const pool=Abyss.DiseaseData.filter(d=>Abyss.DiseaseRisks.eligible(s,p,d,riskContext));
  if(pool.length&&Abyss.Util.random(s)<.025)expose(s,p,Abyss.Util.pick(s,pool).diseaseId,'environment');
 }
 function contacts(s){
  const ps=s.infirmary.patients;
  for(const source of ps){if(source.quarantine||Abyss.LabVisitors?.admitted(s,source.id)?.quarantined||!Abyss.Infirmary.living(s,source)||source.hostType==='NPC'&&!Abyss.LabOperations?.npcAtLab(s,source.id))continue;
   for(const c of source.conditions||[]){const d=byId(c.id);if(!d.infectious||['RECOVERED','INCUBATING'].includes(c.status))continue;
    const risk=Abyss.DiseaseBalance.get(d).contact*(c.status==='RECOVERING'?.4:1);
    for(const target of ps)if(target!==source&&(target.hostType!=='NPC'||Abyss.LabOperations?.npcAtLab(s,target.id))&&Abyss.Infirmary.living(s,target)&&!target.quarantine&&!Abyss.LabVisitors?.admitted(s,target.id)?.quarantined&&Abyss.Util.random(s)<risk)expose(s,target,c.id,source.id);
   }
  }
 }
 return {read,expose,tick,contacts,careMatches,course};
})();
