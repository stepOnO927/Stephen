'use strict';
Abyss.PlantBreeding = (() => {
 const clamp=v=>Math.max(0,Math.min(3,Math.floor(v)||0));
 function read(raw){return (Array.isArray(raw)?raw:[]).filter(c=>c&&typeof c.id==='string'&&Abyss.PlantData.some(d=>d.id===c.plantId)).slice(0,100).map(c=>({id:c.id.slice(0,40),plantId:c.plantId,name:String(c.name||'').slice(0,32),generation:Math.max(1,Math.min(100,Math.floor(c.generation)||1)),seeds:Math.max(0,Math.min(10000,Math.floor(c.seeds)||0)),traits:{water:clamp(c.traits?.water),yield:clamp(c.traits?.yield),resilience:clamp(c.traits?.resilience)},parents:(Array.isArray(c.parents)?c.parents:[]).slice(0,2).map(x=>String(x).slice(0,40))})).filter((c,i,a)=>a.findIndex(x=>x.id===c.id)===i);}
 function breed(s,p){const g=s.greenhouse,a=g.plants.find(x=>x.uid===Number(p.uid)),b=g.plants.find(x=>x.uid===Number(p.other));
  if(!a||!b||a===b||g.level<3||s.ap<1||g.xp<15||g.cultivars.length>=100||Math.min(a.health,b.health)<70||Math.min(a.growth,b.growth)<50||Abyss.Garden.find(a.plantId).category!==Abyss.Garden.find(b.plantId).category)return {ok:false,message:Abyss.HomeData.t('育种需要LV3、两株同类别健康半熟亲本、1 AP和15研究样本点。','Breeding requires LV3, two healthy half-grown parents of the same category, 1 AP and 15 research points.')};
  s.ap--;g.xp-=15;a.health-=3;b.health-=3;
  const traits={};for(const key of ['water','yield','resilience'])traits[key]=clamp(Math.floor(((a.traits?.[key]||0)+(b.traits?.[key]||0))/2)+(Abyss.Util.random(s)<.25?1:0));
  const id='cultivar_'+g.nextId++,c={id,plantId:a.plantId,name:String(p.name||Abyss.Garden.find(a.plantId).name+' · '+id.split('_')[1]).trim().slice(0,32),generation:Math.min(100,Math.max(a.generation,b.generation)+1),seeds:1,traits,parents:[a.cultivar||a.plantId,b.cultivar||b.plantId]};g.cultivars.push(c);
  return {ok:true,message:Abyss.HomeData.t('品系已记录，可从种子库种植。','Cultivar recorded. Plant it from the seed bank.')};
 }
 return {read,breed};
})();
