'use strict';
Abyss.PlantProcessing = (() => {
 const methods=[
  {id:'dry',name:'干燥',en:'Dry',categories:['herb','flower','fruit'],life:21,power:2,value:1.1},
  {id:'press',name:'压榨',en:'Press',categories:['fruit','vegetable'],life:3,power:3,value:1.2},
  {id:'grind',name:'研磨',en:'Grind',categories:['herb','vegetable'],life:14,power:2,value:1.1},
  {id:'ferment',name:'发酵',en:'Ferment',categories:['fruit','vegetable'],life:21,power:2,value:1.3},
  {id:'extract',name:'提取',en:'Extract',categories:['herb','flower','tree'],life:14,power:4,value:1.4},
  {id:'preserve',name:'保存加工',en:'Preserve',categories:['fruit','vegetable'],life:30,power:3,value:1.15}
 ];
 function spoiled(s,b){return s.day-b.day>(b.shelfLife||7);}
 function command(s,p){const g=s.greenhouse,b=g.harvest[Number(p.batch)],d=b&&Abyss.Garden.find(b.plantId),method=methods.find(m=>m.id===p.method);
  if(!b||!method||b.quantity<1||b.process||b.contamination>25||spoiled(s,b)||!method.categories.includes(d.category)||s.ap<1||s.climate.labResources.power<method.power)return {ok:false,message:Abyss.HomeData.t('加工需要适合的健康原料、行动点和电力。','Processing requires suitable healthy ingredients, AP and power.')};
  s.ap--;s.climate.labResources.power-=method.power;b.quantity--;g.harvest.push({plantId:b.plantId,quantity:1,day:s.day,quality:b.quality,contamination:b.contamination,process:method.id,shelfLife:method.life,sourceDay:b.sourceDay||b.day});g.harvest=g.harvest.filter(b=>b.quantity>0);
  return {ok:true,message:Abyss.HomeData.t('加工完成，保质期和价值已更新。','Processed. Shelf life and value updated.')};
 }
 return {methods,spoiled,command};
})();
