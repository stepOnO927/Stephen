'use strict';
// Body-local tailoring. Global growth/evolution scaling belongs to VisualEvolution.
Abyss.AttachmentRig=(()=>{
 const bodies={normal:[1,1,0],slim:[.86,.94,0],bulky:[1.27,1.12,0],elongated:[1.02,1.06,0],compact:[1.08,.73,0],asymmetrical:[1.21,.97,-7],armored:[1.25,1.05,0],aquatic:[1.16,1,0],amorphous:[1.27,.86,0]};
 function profile(s){return s?.progress?Abyss.Evolution.profile(s):{};}
 function tail(s){const p=profile(s);if(p.tail)return [400+2*p.tail.index,288-5*p.tail.index];return s?.mutations?.some(id=>Abyss.Data.mutations.find(m=>m.id===id)?.layer==='tail')?[412,293]:[327,329];}
 function transform(slot,s){const p=profile(s),[w,h,dx]=bodies[p.body?.variant]||bodies.normal;let x=239,y=266,sx=1,sy=1,tx=0,ty=0;
 if(slot==='body'){x=239;y=350;sx=w*1.4;sy=h*1.12;tx=dx;ty=0;}
 if(slot==='neck'){sx=1.1+(w-1)*.7;tx=dx*.45;ty=-2;}if(slot==='back'){sx=1+(w-1)*.75;sy=1+(h-1)*.5;tx=dx*.5;}
 if(['charm','utility','weapon'].includes(slot)){x=239;y=266;tx=dx;sx=w;sy=h;}
 // Lenses stay aligned with eyes rather than inheriting torso width.
 if(slot==='face'){x=239;y=207;}
 return 'translate('+(x+tx)+' '+(y+ty)+') scale('+sx+' '+sy+') translate('+(-x)+' '+(-y)+')';}
 function fitFace(group,item,s,id){const p=profile(s),v=p.eyes?.variant||'normal';if(!['glasses','goggles','visor'].includes(item.visual.renderer)&&!(['atelier','weather','underground'].includes(item.visual.renderer)&&item.visual.optical))return;let original=group.innerHTML;const staging=document.createElementNS('http://www.w3.org/2000/svg','g');staging.innerHTML=original;group.innerHTML='';const defs=document.createElementNS('http://www.w3.org/2000/svg','defs');group.append(defs);for(const old of staging.querySelectorAll('defs')){while(old.firstChild)defs.append(old.firstChild);old.remove();}original=staging.innerHTML;for(const [index,x]of [199,280].entries()){const [rx,ry]=Abyss.EyeArt.size(v,!!index),sx=Math.max(.72,(rx+8)/30),sy=Math.max(.72,(ry+8)/35),clipId='lens-fit-'+id+'-'+index;defs.insertAdjacentHTML('beforeend','<clipPath id="'+clipId+'"><rect x="'+(index?240:120)+'" y="140" width="120" height="150"/></clipPath>');group.insertAdjacentHTML('beforeend','<g data-lens-fit="'+index+'" transform="translate('+x+' 207) scale('+sx+' '+sy+') translate('+(-x)+' -207)"><g clip-path="url(#'+clipId+')">'+original+'</g></g>');}}
 return {bodies,tail,transform,fitFace};
})();
