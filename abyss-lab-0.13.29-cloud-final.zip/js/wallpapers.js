'use strict';
Abyss.Wallpapers=(()=>{
 const D=Abyss.WallpaperData;let low=false;try{low=localStorage.getItem('abyss-wallpaper-performance-v1')==='low';}catch{}
 function observe(s){if(Abyss.Redeem.entitled(s))return;const m=Abyss.Meta.load();for(const w of D.wallpapers)if(!m.wallpapers.includes(w.id)&&D.unlocked(s,m,w.id)){Abyss.Meta.grantWallpaper(w.id);Abyss.State.log(s,D.t('环境档案解锁：','Environment archive unlocked: ')+w.name,'rare');}}
 function select(id,target){return Abyss.Meta.selectWallpaper(id,target);}
 function quality(value){low=value==='low';try{localStorage.setItem('abyss-wallpaper-performance-v1',low?'low':'full');}catch{}if(typeof document!=='undefined')apply(Abyss.Engine.snapshot());}
 function art(id,s,preview=false){const w=D.wallpapers.find(w=>w.id===id)||D.wallpapers[0];return Abyss.WallpaperArt.render(w,{animated:!low&&s.settings.motion&&(!preview||document.visibilityState!=='hidden')});}
 let rendered='';function apply(s){const holder=document.querySelector('.specimen-scene');if(!holder)return;let layer=holder.querySelector('.wallpaper-layer');if(!layer){layer=document.createElement('div');layer.className='wallpaper-layer';layer.setAttribute('aria-hidden','true');holder.prepend(layer);}const m=Abyss.Meta.load(),key=m.wallpaperLab+':'+low+':'+s.settings.motion;if(rendered!==key){rendered=key;layer.innerHTML=art(m.wallpaperLab,s);holder.dataset.wallpaper=m.wallpaperLab;}document.body.dataset.wallpaperLow=String(low);}
 function menu(s){const id=Abyss.Meta.load().wallpaperMenu;return `<div class="menu-wallpaper" aria-hidden="true">${art(id,s)}</div>`;}
 function bind(){Abyss.Engine.subscribe(apply);document.addEventListener('visibilitychange',()=>{document.body.classList.toggle('wallpaper-paused',document.hidden);});}
 return {observe,select,quality,art,apply,menu,bind,low:()=>low};
})();
