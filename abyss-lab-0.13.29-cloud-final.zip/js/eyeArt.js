
'use strict';
// One renderer for normal and evolved eyes; each eye owns its blink origin.
Abyss.EyeArt=(()=>{
 const sizes={large:[29,33],small:[13,17],wide:[28,17],asymmetrical:[22,27]};
 function size(variant,right=false){return variant==='asymmetrical'&&right?[14,27]:sizes[variant]||[22,27];}
 function eye(x,y,rx,ry,v,s,extra=false){const color=v==='amber'?'#e6b273':v==='glowing'?'#c9f8e2':s.stats.loyalty<30?'#f9b184':'#ceffd1';return `<g class="creature-eye" data-eye="${extra?'extra':x<240?'left':'right'}" style="--eye-x:${x}px;--eye-y:${y}px"><ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="#102834" stroke="#80bca2" stroke-width="2.5"/>${v==='compound'?Array.from({length:6},(_,k)=>`<circle cx="${x-rx*.5+k%3*rx*.5}" cy="${y-ry*.35+Math.floor(k/3)*ry*.7}" r="${Math.min(rx,ry)*.2}" fill="${color}"/>`).join(''):`<ellipse cx="${x}" cy="${y}" rx="${v==='vertical'?rx*.2:rx*.51}" ry="${ry*.64}" fill="${color}"/><ellipse cx="${x}" cy="${y+1}" rx="${rx*.19}" ry="${ry*.36}" fill="#173743"/><circle cx="${x-rx*.25}" cy="${y-ry*.35}" r="${rx*.19}" fill="#fff"/>`}${v==='rings'?`<ellipse cx="${x}" cy="${y}" rx="${rx*.77}" ry="${ry*.8}" fill="none" stroke="#a9cad3"/>`:v==='star'?`<path d="m${x} ${y-ry*.6} 4 10 10 4-10 4-4 10-4-10-10-4 10-4z" fill="#eee3ba"/>`:''}</g>`;}
 function pair(s,c=null){const v=c?.variant||'normal';if(v==='blind')return '<g data-eye-blind><path d="M177 207q22 10 44 0m37 0q22 10 44 0" stroke="#435b64" stroke-width="4" fill="none"/></g>';let out=[199,280].map((x,i)=>eye(x,207,...size(v,!!i),v,s)).join('');if(v==='multiple'||s.mutations.includes('eye'))out+=eye(240,159,16,12,'glowing',s,true);return out;}
 return {pair,size};
})();
