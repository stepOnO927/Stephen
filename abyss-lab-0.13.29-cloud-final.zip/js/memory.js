'use strict';
Abyss.Memory = {
 has:(s,id)=>s.memories.some(m=>m.id===id),
 remember(s,id,detail){const known=s.memories.find(m=>m.id===id);if(known){known.count++;known.lastDay=s.day;return;}s.memories.push({id,firstDay:s.day,lastDay:s.day,count:1,detail});},
 observe(before,s,command){
  const type=command.type;
  if(type==='heal'&&before.stats.health<25)this.remember(s,'saved_life','它记得你在疼痛里伸出的手。');
  if(type==='rest'&&before.stats.hunger+18>=75)this.remember(s,'starved','那个饥饿的夜晚，储藏柜一直没有打开。');
  if(s.history.explore>before.history.explore&&!this.has(s,'first_exploration'))this.remember(s,'first_exploration','第一次离开培养舱，你们一起走进黑暗。');
  if(type==='experiment'&&command.payload==='unstable'&&s.history.experiment>before.history.experiment)this.remember(s,'severe_experiment','刺眼的实验灯，以及之后漫长的沉默。');
  if(!before.form&&s.form)this.remember(s,'first_evolution','它有了自己的模样，而你仍在身边。');
  if(!before.awaySince&&s.awaySince)this.remember(s,'escaped','它曾穿过通风管，试着走向陌生的世界。');
  if(type==='feed'&&command.payload===s.favoriteFood)this.remember(s,'favorite_food','熟悉的月露果味道，让它想起安静的晚餐。');
 },
 context(s,eventId){
  if(eventId==='sick'&&this.has(s,'saved_life'))return '它认得你拿药的动作。这一次，它主动把爪子交给了你。';
  if(eventId==='food'&&this.has(s,'starved'))return '它先数了一遍补给。那场饥饿仍藏在它的记忆里。';
  if(eventId==='gift'&&this.has(s,'first_accessory'))return '它看了看自己的第一件饰品，似乎也想送你一件。';
  if(eventId==='dream'&&this.has(s,'severe_experiment'))return '梦里的实验灯再次亮起。它在睡梦中握紧了爪子。';
  if(eventId==='blackout'&&this.has(s,'escaped'))return '它望了一眼通风口，随后确认你是否还在身边。';
  return '';
 }
};
