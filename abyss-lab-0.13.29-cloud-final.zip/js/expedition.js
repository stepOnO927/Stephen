'use strict';
Abyss.Expedition=(()=>{
 const D=Abyss.ExpeditionData,S=Abyss.ExpeditionState,U=Abyss.Util;
 const ok=message=>({ok:true,message}),bad=message=>({ok:false,message});
 function weighted(s,entries,weight){const sum=entries.reduce((n,e)=>n+weight(e),0);let roll=U.random(s)*sum;return entries.find(e=>(roll-=weight(e))<0)||entries.at(-1);}
 function danger(s,l,environment=10){const p=S.ensure(s).penalty;return Math.round(U.clamp(l.danger+environment+(100-s.stats.health)*.2+s.stats.pollution*.23-(s.stats.strength+s.stats.agility+s.stats.intelligence)*.08-(s.stats.stability-50)*.2+(p&&p.until>s.day?p.amount:0),5,95));}
 function chance(s,c,l,environment){if(!c.stat)return 1;const p=S.ensure(s).penalty;return U.clamp(.65+(s.stats[c.stat]-(p&&p.until>s.day?p.amount:0)-c.threshold)*.008-danger(s,l,environment)*.003,.08,.96);}
 function startExpedition(s,id){const x=S.ensure(s),l=D.locations.find(l=>l.id===id);if(!l)return bad('未知目的地');if(!Abyss.Progression.locationAvailable(s,l))return bad('研究或 BLACK 权限未开放');if(x.active)return bad('已有远征进行中');if(s.pendingEvent||s.endingNotice||s.awaySince)return bad('请先处理实验室事件或找回零号');if(s.ap<l.cost||s.stats.health<25||s.day<l.unlock)return bad(`需要 2 AP、健康 25、第 ${l.unlock} 天`);
  s.ap-=l.cost;s.history.explore++;x.active={day:s.day,location:id,stage:'departure',steps:0,environment:Math.floor(U.random(s)*21),event:null,seen:[],loot:{},notes:[],result:'',forceReturn:false};Abyss.State.log(s,`远征出发：${l.name}。消耗 2 AP。`,'story');return ok('通讯链路已建立');}
 function nextEvent(s){const x=S.ensure(s),a=x.active,l=D.locations.find(l=>l.id===a.location);if(a.forceReturn||a.steps>=l.duration){a.stage='return';return;}
  const pool=D.events.filter(e=>e.location===l.id&&!a.seen.includes(e.id)&&(e.requires||[]).every(f=>x.flags[f])&&Abyss.EventRules.available(s,e));const e=weighted(s,pool,e=>e.weight*(e.room==='装配线'&&x.flags.factory_power_restored?2:1));
  if(!e){a.stage='return';return;}a.event=e.id;a.seen.push(e.id);a.stage='encounter';
  if(e.room&&U.random(s)<.45){const key=l.id+':'+e.room;if(!x.rooms.includes(key)){x.rooms.push(key);a.notes.push('隐蔽区域：'+e.room);}}
 }
 function reward(s,out){const x=S.ensure(s),a=x.active;let found=null;if(out.item){const item=D.loot.find(i=>i.id===out.item),rate=out.certain?1:Math.min(1,Abyss.Rarity.recoveryChance(item.rarity)+(Abyss.Research.has(s,'sealed_samples')&&!item.secret?.12:0));if(U.random(s)<rate){a.loot[out.item]=(a.loot[out.item]||0)+1;found=out.item;}else a.notes.push('目标痕迹已记录，但未能回收完整物件。');}Abyss.EventRules.extra(s,out,a.event,true);if(out.effects)Abyss.State.effects(s,out.effects);if(out.flag)Abyss.WorldState.setWorldFlag(s,out.flag);if(out.doc){Abyss.WorldState.unlockDocument(s,out.doc);a.notes.push('机密档案 '+out.doc+' 已归档');}if(out.mutation){Abyss.Mutations.attempt(s,.2);a.notes.push('检测到突变共振；符合条件的基因可能表达。');}return found;}
 function choose(s,id){const x=S.ensure(s),a=x.active;if(!a||a.stage!=='encounter')return bad('当前没有待决事件');const e=D.events.find(e=>e.id===a.event),c=e.choices.find(c=>c.id===id),l=D.locations.find(l=>l.id===a.location);if(!c)return bad('未知选择');if(!Abyss.Progression.optionAvailable(s,c))return bad('该环境交互需要相应适应器官与研究协议');
  a.steps++;let text;
  if(c.retreat){const ignores=s.stats.loyalty<30&&U.random(s)<.12;if(ignores){Abyss.State.effects(s,{mood:-4,hunger:8});text='它短暂无视召回，在信标牵引下回到撤离路线。';}else text='召回指令已确认。';a.forceReturn=true;}
  else if(s.stats.loyalty<25&&U.random(s)<.06){text='它拒绝继续，停在通讯信标旁。';a.forceReturn=true;Abyss.State.effects(s,{mood:-3});}
  else{const success=U.random(s)<chance(s,c,l,a.environment);const found=reward(s,success?c.success||{}:c.failure||{});const outcome=success?c.success||{}:c.failure||{};text=outcome.text||(success?'行动成功，扫描记录已更新。':'检定失败，行动受到干扰。');if(outcome.items)text+=' 回收：'+Object.entries(outcome.items).map(([id,n])=>D.loot.find(i=>i.id===id).name+' ×'+n).join('、')+'。';
   if(found){const item=D.loot.find(i=>i.id===found);text+=' 发现 '+item.name+' ×1。';}
   if(!success){const hazard=c.failure?.hazard;
    if(hazard==='exhaustion'){Abyss.State.effects(s,{hunger:12,mood:-5});text+=' 疲惫：饥饿 +12。';}
    if(hazard==='contamination'){Abyss.State.effects(s,{pollution:9});text+=' 环境污染 +9。';}
    if(hazard==='lost'){a.forceReturn=true;Abyss.State.effects(s,{hunger:10});text+=' 短暂迷路；救援信标启动，提前返航。';}
    if(hazard==='loot'){const id=Object.keys(a.loot).find(id=>a.loot[id]>0);if(id){a.loot[id]--;text+=' 遗失一件物资。';}}
    if(hazard==='penalty'){x.penalty={until:s.day+1,amount:8};text+=' 疲劳：探索检定属性 −8，次日恢复。';}
    if(c.risky&&danger(s,l,a.environment)>=70&&s.stats.health<45&&U.random(s)<.3){Abyss.State.effects(s,{health:-15});a.forceReturn=true;text+=' 高危深入导致重伤；强制救援。';}
   }
  }
  s.stats.health=Math.max(5,s.stats.health);Abyss.State.effects(s,{hunger:3});if(s.stats.health<25)a.forceReturn=true;
  a.result=text;a.notes.push(e.name+'：'+text);a.stage='consequence';return ok(text);
 }
 function finish(s){const x=S.ensure(s),a=x.active,l=D.locations.find(l=>l.id===a.location);
  if(a.steps>0&&!a.forceReturn){const item=weighted(s,D.tables[l.id].map(id=>D.loot.find(i=>i.id===id)),i=>Abyss.Rarity.weight(i.rarity));a.loot[item.id]=(a.loot[item.id]||0)+1;}
  for(const [id,n]of Object.entries(a.loot))if(n>0)Abyss.Inventory.grantItem(s,id,n,l.name);
  const money=a.location==='city'&&a.steps>0?8+a.steps*4:0;s.money+=money;if(money)a.notes.push('回收资金 ₵ '+money);
  const record={day:a.day,location:a.location,steps:a.steps,condition:a.forceReturn?'提前撤回':s.stats.health<45?'需要治疗':'状态良好',health:s.stats.health,loot:{...a.loot},notes:[...a.notes]};x.records.unshift(record);x.records=x.records.slice(0,60);x.active=null;Abyss.State.log(s,`${l.name}远征结束：${record.condition}，记录已归档。`,'story');return ok('已返回 · 物资入库');
 }
 function command(s,type,payload){const x=S.ensure(s);if(type==='sell')return Abyss.Salvage.sell(s,typeof payload==='string'?{id:payload,quantity:1}:payload);if(type==='start')return startExpedition(s,payload);if(type==='choose')return choose(s,payload);
  if(type==='advance'){if(!x.active)return bad('没有进行中的远征');if(x.active.stage==='encounter')return bad('请先选择行动');if(x.active.stage==='return')return finish(s);nextEvent(s);return ok('远征进度已保存');}
  if(type==='transfer'){if(x.active)return bad('返回实验室后才能移交');const item=D.loot.find(i=>i.id===payload);if(!item?.food||!Abyss.Inventory.consumeItem(s,payload))return bad('食物不足');s.inventory[item.food]=(s.inventory[item.food]||0)+1;return ok('食物已移交喂食库存');}
  return bad('未知远征指令');
 }
 return {startExpedition,command,danger,chance,choose,registerEvent(event){if(!event.id||D.events.some(e=>e.id===event.id))throw Error('重复事件');D.events.push(event);},registerLoot(item,location){if(D.loot.some(i=>i.id===item.id)||!D.tables[location])throw Error('无效物资注册');D.loot.push(item);D.tables[location].push(item.id);}};
})();
