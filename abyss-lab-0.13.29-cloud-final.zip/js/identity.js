'use strict';
// Names are descriptive, cost no AP, and never execute as markup.
Abyss.Identity=(()=>{
 const DEFAULT='零号',suggestions=['苔灯','小墨','月芽','咕噜','雾团','星屑','布丁','回声'];
 function normalize(value){return typeof value==='string'?value.normalize('NFC').trim().replace(/\s+/gu,' '):'';}
 function valid(name){return [...name].length>=1&&[...name].length<=12&&!/[<>\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/u.test(name);}
 function read(value){const n=normalize(value);return valid(n)?n:DEFAULT;}
 function rename(s,value){const n=normalize(value);if(!valid(n))return {ok:false,message:'请输入 1–12 个字符，不能包含尖括号或控制字符。'};if(n===s.name)return {ok:true,message:'它已经叫这个名字了。'};const old=s.name;s.name=n;Abyss.State.log(s,`${old}有了新的名字「${n}」。它抬头听了听你的声音。`,'story');return {ok:true,message:`现在，它叫${n}。`};}
 return {DEFAULT,suggestions,normalize,valid,read,rename};
})();
