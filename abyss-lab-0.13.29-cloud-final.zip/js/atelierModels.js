'use strict';
Abyss.AtelierModels=(()=>{
 const M=Abyss.ArtMaterials,P=M.path,L=M.line,C=M.circle,R=M.rect;
 const bead=(x,y,m)=>C(x,y,8,m.glass)+C(x-2,y-3,2,m.light);
 const page=(x,y,m)=>P(`m${x-12} ${y-14} 24-3 3 30-24 3z`,m.light)+L(`M${x-7} ${y-5}l13-2m-12 8 11-2`,m.dark,1);
 const rose=(m)=>[0,60,120,180,240,300].map(a=>`<g transform="rotate(${a})">${P('M0 0q-23-26-17-31 28-2 17 31',m.light)}${L('M0-3-9-23',m.fill,1)}</g>`).join('')+C(0,0,7,m.metal)+P('M0 7v31m0-11q-18-15-23-7 7 16 23 7',m.fill);
 const models={
 tidal_cap:m=>P('M-43 1q-3-36 42-39 42 1 44 40z',m.fill)+P('M-50 0h100l-16 13h-70z',m.dark)+R(-11,-64,22,39,7,m.dark)+R(-7,-58,14,24,4,m.glass)+L('M0-58v24m-9-27h18m-20 33h22',m.metal,2)+L('M-30-15q30-13 60 0',m.light,3),
 tidal_lens:m=>[-29,29].map(x=>C(x,0,25,m.metal)+C(x,0,19,m.glass)+L(`M${x-9} -10l12-5`,m.light,2)).join('')+P('M-5-8h10v12H-5z',m.dark)+L('M-53-4h-12m118 0h12',m.fill,6)+C(54,5,4,m.light),
 tidal_rope:m=>P('M-55-12q55 29 110 0l-3 15q-51 22-104 0z',m.light)+P('m-8 8-27 22 19 5 11-18 5 38 14-3-13-41z',m.fill)+L('M-33 26l15 7m12 10 15-3',m.light,2)+C(0,11,7,m.metal),
 tidal_coat:m=>P('M-48-43-21-39 0-21l21-18 27-4 20 28-14 28-11-6 3 48-91 0 3-49-10 6-15-27z',m.fill)+P('m-24-37 24 16 24-16-9 29h-30z',m.light)+L('M-19-30 0-18l19-12M-36 41h73',m.dark,3)+R(-35,13,23,18,3,m.dark)+R(12,13,23,18,3,m.dark)+P('M-4-9h8v28l-4 13-4-13z',m.light),
 tidal_bell:m=>P('M-39-69h77v10h-77z',m.metal)+L('M-34-59v122m69-122v122',m.dark,7)+P('M-29 5q-3-55 28-56 34-1 30 56l12 13h-83z',m.metal)+`<ellipse cy="18" rx="41" ry="9" fill="${m.dark}"/>`+C(0,29,7,m.metal)+L('M-21-30v22m-7 47q28 16 56 0',m.light,3)+R(-34,55,70,11,4,m.fill),
 tidal_shell:m=>P('M-28-4q0-45 30-25 26-15 28 22L1 26z',m.metal)+P('M-22-3q3-26 22-14 18-11 23 13L1 17z',m.glass)+[-16,-8,0,8,16].map(x=>L(`M1 17 ${x} -12`,m.light,1)).join('')+C(0,20,4,m.fill),
 tidal_pearl:m=>P('M-8-29h16v13l13 18-4 29q-17 14-33 0l-6-29 14-18z',m.glass)+R(-12,-35,24,10,3,m.metal)+bead(0,12,m)+L('M-13 0v17',m.light,2)+P('m-22 30 22 13 25-13-7 12-18 7-15-6z',m.metal),
 tidal_sextant:m=>P('M-31 31 4-38 33 33q-29 24-64-2','none',`stroke="${m.metal}" stroke-width="5"`)+L('M-21 16q27 19 42 0M4-38 0 32',m.light,2)+C(4,-32,8,m.glass)+R(-8,0,25,10,3,m.dark)+[-22,-12,0,12,22].map(x=>L(`M${x} 33l0 5`,m.dark,1)).join(''),
 tidal_echo:m=>'<g class="hunt-cos-effect">'+[-1,1].flatMap(x=>[0,1,2].map(i=>`<g transform="translate(${x*(95+i*13)} ${-55+i*44})">${bead(0,0,m)}${L('M-12 10q12 9 24 0',m.light,1)}</g>`)).join('')+'</g>',
 tidal_oar:m=>L('M0 60V-8',m.metal,6)+P('M-16-70h30L9-11H-7z',m.fill)+P('M-10-63h18v26h-18z',m.dark)+L('M-2-37v-24h8',m.light,2)+L('M-5 25h10m-10 6h10m-10 6h10',m.dark,2),
 archive_beret:m=>P('M-49-6q-13-42 31-47 22-17 47 0 33 5 28 44z',m.fill)+P('M-43-4q45-12 86 0l-9 12h-74z',m.dark)+L('M-28-24q23-21 50-16',m.light,2)+P('m27-8 5-39 5-5 3 7-7 38z',m.metal)+C(-5,-53,4,m.dark),
 archive_loupe:m=>C(-27,-2,29,m.metal)+C(-27,-2,23,m.glass)+C(-20,3,16,'none',`stroke="${m.fill}" stroke-width="2"`)+L('M2 2H37',m.metal,4)+C(38,2,6,m.glass)+L('M-39-13l11-8',m.light,2)+P('m-5 22 9 3 14 25-8 4z',m.fill),
 archive_key:m=>P('M-55-11q55 25 110 0','none',`stroke="${m.metal}" stroke-width="3"`)+L('M0 3V18',m.metal,2)+C(0,24,9,'none',`stroke="${m.metal}" stroke-width="4"`)+L('M0 33v22h12m-12-7h8',m.metal,4)+page(-29,24,m),
 archive_waistcoat:m=>P('M-47-43-23-38 0-9l22-29 25-5 12 24-9 59-33 10L0 25-17 50-35 40-10-59z',m.dark)+P('m-24-37 17 29-17 13-14-30m62-12L7-8l17 13 13-30',m.fill)+R(-42,16,23,16,2,m.fill)+R(18,16,23,16,2,m.fill)+[0,13,26].map(y=>C(0,y,2.6,m.metal)).join('')+L('M21-18l8 13 10-3m-10 3-3 12M-39 35l18 7',m.light,1)+C(25,-8,3,m.glass),
 archive_library:m=>R(-44,-50,88,111,6,m.dark)+P('m44-50 14 12v99l-14 0z',m.fill)+[-40,-10,20].map(y=>R(-37,y,74,25,2,m.fill)).join('')+[-28,-9,8,26].map((x,i)=>R(x-6,-46,12,43-i%2*8,2,i%2?m.metal:m.fill)+L(`M${x-3} -36h6`,m.light,1)).join('')+page(1,35,m)+L('M-38 4h75',m.metal,4),
 archive_seal:m=>P('M-27-7h53v15h-53z',m.fill)+P('M-10 4 9 8 1 43-8 34-10 8z',m.dark)+P('m0 6 17-4 9 32-13-4z',m.fill)+C(0,8,13,'#a46b71')+C(0,8,9,'none','stroke="#d7b4a0"')+L('M3 2v9q-6 5-7-1','#e3c5b1',2),
 archive_rose:m=>rose(m),
 archive_lamp:m=>P('M-15-19h30v43l8 8h-47l9-8z',m.metal)+R(-10,-13,20,36,4,m.glass)+P('M0 15q-13-12 1-27 13 18-1 27','#d9c39b')+L('M-12-20q0-29 23 0',m.metal,3)+R(-22,29,44,6,3,m.dark),
 archive_stars:m=>'<g class="hunt-cos-effect">'+[-1,1].flatMap(x=>[0,1,2].map(i=>`<g transform="translate(${x*(94+i*15)} ${-59+i*54}) rotate(${x*(12+i*7)})">${page(0,0,m)}${P('M0-6 2-1 8 0 3 4 4 10 0 7-5 10-3 4-7 0-2-1z',m.fill)}</g>`)).join('')+'</g>',
 archive_quill:m=>L('M-5 60 5-8',m.metal,5)+P('M5-8q-33-26-19-55 37-25 39 12L5-8',m.glass)+L('M-6 47 9-57m-5 31-14-5m15-4 13-10m-10-8-14-4',m.light,1.4)+P('M-15 20h12v6h-12m21-65h11v4H6',m.fill)
 };
 function draw(a,m){return models[a.visual.sculpture]?.(m)||null;}
 return {models,draw};
})();
