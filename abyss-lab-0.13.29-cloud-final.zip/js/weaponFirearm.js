'use strict';
// Ammunition and recoil belong to this encounter, not to inventory or player currency.
Abyss.WeaponFirearm=(()=>{
 const id='weapon_road_ak47',capacity=12,reserve=24,t=(zh,en)=>Abyss.HomeData.t(zh,en);
 const supported=w=>w?.id===id;
 function init(s,w,f){if(!supported(w))return;f.weaponAmmo=capacity;f.weaponReserve=reserve;f.weaponRecoil=0;f.weaponBurst=0;f.weaponFirstTarget=(s.hunt.active.encounters||1)===1;}
 function ensure(w,f){if(!supported(w))return;if(!Number.isFinite(f.weaponAmmo))f.weaponAmmo=capacity;if(!Number.isFinite(f.weaponReserve))f.weaponReserve=reserve;}
 function actions(w,f){if(!supported(w)||!f)return [];ensure(w,f);return [{id:'reload',name:t('更换弹匣','Reload magazine'),energy:0,power:0,stat:'intelligence'}];}
 function canReload(f){return f.weaponAmmo<capacity&&f.weaponReserve>0;}
 function canFire(w,f){return !supported(w)||f.weaponAmmo>0;}
 function shot(w,f){if(!supported(w))return true;ensure(w,f);if(!f.weaponAmmo){f.logs.push(t('弹匣已空；先换弹，或撤退。','Magazine empty; reload or retreat.'));return false;}f.weaponAmmo--;f.weaponRecoil=Math.min(5,(f.weaponRecoil||0)+1);return true;}
 function settle(w,f,action){if(!supported(w))return;if(action==='reload'){const n=Math.min(capacity-f.weaponAmmo,f.weaponReserve);f.weaponAmmo+=n;f.weaponReserve-=n;f.weaponRecoil=0;f.weaponBurst=0;f.logs.push(t('更换弹匣，装入 '+n+' 发。','Magazine changed: '+n+' rounds loaded.'));}else if(['guard','counter','shield','shell','resist','heal'].includes(action)){f.weaponRecoil=Math.max(0,(f.weaponRecoil||0)-2);f.weaponBurst=0;}}
 function stats(s,w,f){if(!supported(w)||!f)return {};const r=Abyss.WeaponRare.rank(s,w),recoil=Math.max(0,(f.weaponRecoil||0)-1),o={accuracy:-recoil*(r>=1?.012:.03)};if(r>=2&&f.weaponFirstTarget){o.accuracy+=.04;o.resist=.08;}if(r>=3)o.damage=1+Math.min(5,f.weaponBurst||0)*.018;if(r>=4&&f.weaponAmmo<=3)o.crit=.08;if(r>=5&&f.weaponLineUntil>=f.turn)o.attack=.08;if(r>=6&&f.weaponStandUntil>=f.turn){o.defense=.2;o.resist=(o.resist||0)+.15;}return o;}
 function hit(w,f){if(supported(w))f.weaponBurst=Math.min(5,(f.weaponBurst||0)+1);}
 function miss(w,f){if(supported(w))f.weaponBurst=0;}
 function received(s,w,f,damage){if(!supported(w))return;const r=Abyss.WeaponRare.rank(s,w);if(r>=5&&f.hp>0&&f.hp<=f.maxHp*.3&&(f.weaponLineUntil??-1)<f.turn){f.weaponLineUntil=f.turn+2;f.logs.push('HOLD THE LINE');}if(r>=6&&!f.weaponStandUsed&&damage>=f.maxHp*.2){f.weaponStandUsed=true;f.weaponStandUntil=f.turn+2;f.logs.push('THE BRIDGE STILL STANDS');}}
 Abyss.I18n.register({'后坐影响降低':'Reduced recoil penalty','首次交战稳定性提高':'Improved stability in the first encounter','连续命中逐渐增伤，最多五层':'Consecutive hits increase damage, capped at five stacks','弹匣剩余三发以内暴击提高':'Critical chance increases with three rounds or fewer remaining','实验体低生命时短暂提高攻击':'Brief attack boost when the fighting subject has low health','每场一次受重创后短暂坚守':'Once per fight: brief defensive stand after a severe hit'});
 return {supported,capacity,init,ensure,actions,canReload,canFire,shot,settle,stats,hit,miss,received};
})();
