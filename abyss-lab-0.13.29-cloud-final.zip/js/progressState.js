'use strict';
Abyss.ProgressState=(()=>{
 const fresh=()=>({research:{xp:0,level:1,points:4,technologies:[],seen:[],anomalyVisible:false,clearance:'standard',capRewards:0},evolution:{stage:0,route:null,form:null,scores:{},history:[],pending:null,redirected:false},story:{chapter:0,flags:{},decisions:{},pending:null,history:[]},diet:{},protocols:{}});
 function read(raw,s){const out=fresh(),num=(x,max)=>Number.isInteger(x)&&x>=0&&x<=max,list=(x,ids)=>Array.isArray(x)?[...new Set(x.filter(v=>ids.includes(v)))]:[];
  if(!raw.progress){out.evolution.history=s.mutations.map(id=>({day:s.day,text:'迁移记录：已观察到'+Abyss.Data.mutations.find(m=>m.id===id).name,kind:'legacy'}));out.research.seen=[...s.mutations.map(id=>'mutation:'+id),...s.achievements.map(id=>'achievement:'+id),...Object.keys(raw.exploration?.items||{}).map(id=>'item:'+id),...(raw.exploration?.documents||[]).map(id=>'document:'+id)];return out;}
  const p=raw.progress,r=p.research||{},e=p.evolution||{},st=p.story||{};
  out.research.xp=num(r.xp,10000000)?r.xp:0;out.research.level=Abyss.Research.levelFor(out.research.xp);out.research.points=num(r.points,100000)?r.points:4;out.research.technologies=list(r.technologies,Abyss.Phase3Data.technologies.map(t=>t.id));out.research.seen=Array.isArray(r.seen)?[...new Set(r.seen.filter(x=>typeof x==='string').map(x=>x.slice(0,90)))].slice(0,2000):[];out.research.anomalyVisible=r.anomalyVisible===true;out.research.clearance=r.clearance==='black'&&out.research.technologies.includes('black_protocol')&&out.research.level===20?'black':'standard';out.research.capRewards=num(r.capRewards,50000)?r.capRewards:0;
  out.evolution.stage=num(e.stage,4)?e.stage:0;out.evolution.route=Abyss.Phase3Data.families.some(f=>f.id===e.route)?e.route:null;out.evolution.form=Abyss.Phase3Data.forms.some(f=>f.id===e.form)?e.form:null;out.evolution.redirected=e.redirected===true;
  for(const f of Abyss.Phase3Data.families)out.evolution.scores[f.id]=Number.isFinite(e.scores?.[f.id])?Abyss.Util.clamp(e.scores[f.id],0,10000):0;
  out.evolution.pending=num(e.pending,4)&&e.pending>out.evolution.stage?e.pending:null;
  out.evolution.history=Array.isArray(e.history)?e.history.slice(0,120).filter(h=>h&&num(h.day,s.day)&&typeof h.text==='string').map(h=>({day:h.day,text:h.text.slice(0,400),kind:String(h.kind||'adaptation').slice(0,30)})):[];
  out.story.chapter=num(st.chapter,6)?st.chapter:0;out.story.pending=typeof st.pending==='string'&&Abyss.Phase3Data.chapters.some(c=>c.id===st.pending)?st.pending:null;
  const flagIds=Abyss.Phase3Data.chapters.flatMap(c=>c.choices.flatMap(ch=>Object.keys(ch.flags)));for(const id of flagIds)if(st.flags?.[id]===true)out.story.flags[id]=true;
  for(const c of Abyss.Phase3Data.chapters)if(c.choices.some(ch=>ch.id===st.decisions?.[c.id]))out.story.decisions[c.id]=st.decisions[c.id];
  out.story.history=Array.isArray(st.history)?st.history.slice(0,10).filter(h=>h&&num(h.day,s.day)&&Abyss.Phase3Data.chapters.some(c=>c.id===h.id)).map(h=>({day:h.day,id:h.id,choice:String(h.choice||'').slice(0,50)})):[];
  for(const f of Abyss.Data.foods)if(num(p.diet?.[f.id],100000))out.diet[f.id]=p.diet[f.id];
  for(const id of ['culture','talk','medicine','stabilize','redirect'])if(num(p.protocols?.[id],s.day))out.protocols[id]=p.protocols[id];
  return out;
 }
 return {fresh,read};
})();
