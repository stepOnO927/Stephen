'use strict';
Abyss.Rarity=(()=>{
 const tiers=Abyss.Data.rarities;
 const id=value=>String(value||'common').toLowerCase();
 const find=value=>tiers.find(t=>t.id===id(value))||tiers[0];
 const weight=value=>Abyss.ExpeditionData.rarityWeights[id(value).toUpperCase()]||0;
 const recoveryChance=value=>({common:1,uncommon:.7,rare:.15,epic:.025,legendary:.002,anomalous:.0005}[id(value)]??0);
 return {tiers,id,find,weight,recoveryChance,rank:value=>find(value).rank,label:value=>find(value).name};
})();
