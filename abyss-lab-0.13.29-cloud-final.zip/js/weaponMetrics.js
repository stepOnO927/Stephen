'use strict';
Abyss.WeaponMetrics=(()=>{
 const tiers={SMALL:{size:'SMALL',volume:.012,weight:1.2,length:.4},MEDIUM:{size:'SMALL',volume:.035,weight:3,length:.8},LARGE:{size:'MEDIUM',volume:.08,weight:6,length:1.2},HEAVY:{size:'LARGE',volume:.14,weight:10,length:1.4}};
 for(const w of Abyss.WeaponData.weapons){w.weaponSize=w.category==='heavy'?'HEAVY':w.combatClass==='melee'&&w.range<=1.8?'SMALL':w.combatClass==='ranged'&&w.range>=8?'LARGE':'MEDIUM';w.transport={...tiers[w.weaponSize]};}
 function summary(s,w,x){const view={...s,hunt:{...s.hunt,weapons:{...s.hunt.weapons,[w.id]:{level:x.level,resonanceLevel:x.resonanceLevel,durability:x.condition}}}},p=Abyss.WeaponRare.stats(view,w,{hp:100,maxHp:100,turn:1,distance:1,weaponDawnUsed:true,weaponCeremonyUsed:true,weaponRailUsed:true},{}),time=w.attackTime*p.time+w.attackRecovery,attack=(x.condition<=0?0:w.attack+x.level*1.2)*(1+p.attack)*(p.damage||1);return {range:Number((w.range*p.range).toFixed(2)),time:Number(time.toFixed(3)),dps:Number((attack*(1+Math.max(0,Math.min(.95,.05+(p.crit||0)))*(.6+(p.critDamage||0)))/time).toFixed(2)),size:w.weaponSize,weight:w.transport.weight};}
 function carried(s){return Abyss.WeaponData.weapons.find(w=>w.id===s.hunt.equippedWeapon)?.transport||{volume:0,weight:0};}
 return {summary,carried};
})();
