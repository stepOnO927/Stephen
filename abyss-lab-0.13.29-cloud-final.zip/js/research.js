'use strict';
Abyss.Research=(()=>{
 const threshold=level=>Math.round((level-1)*35+(level-1)**2*4),levelFor=xp=>{let level=1;while(level<20&&xp>=threshold(level+1))level++;return level;};
 const has=(s,id)=>s.progress.research.technologies.includes(id);
 function award(s,key,amount,once=true){const r=s.progress.research;if(once&&r.seen.includes(key))return false;if(once)r.seen.push(key);const before=r.level;r.xp=Math.min(10000000,r.xp+amount);r.level=levelFor(r.xp);r.points+=(r.level-before)*3;
  const cap=Math.max(0,Math.floor((r.xp-threshold(20))/200));if(cap>r.capRewards){r.points+=cap-r.capRewards;r.capRewards=cap;}
  if(r.level>before)Abyss.State.log(s,`研究等级升至 ${r.level}，新增 ${(r.level-before)*3} 研究点。`,'rare');return true;}
 function availability(s,t){const r=s.progress.research;if(has(s,t.id))return {state:'researched',reasons:[]};if(t.hidden&&!r.anomalyVisible)return {state:'hidden',reasons:[]};const reasons=[];
  if(r.level<t.level)reasons.push('研究等级 '+t.level);if(r.points<t.points)reasons.push(t.points+' 研究点');for(const id of t.prerequisites)if(!has(s,id))reasons.push('前置：'+Abyss.Phase3Data.technologies.find(t=>t.id===id).name);
  for(const [id,n]of Object.entries(t.materials))if((s.inventory[id]||0)<n)reasons.push(Abyss.Phase3Data.items.find(i=>i.id===id)?.name+' ×'+n);
  if(t.item&&!(s.inventory[t.item]>0))reasons.push('需要发现特定物件');if(t.storyFlag&&!s.progress.story.flags[t.storyFlag])reasons.push('事故记录权限未确认');if(t.mutationTag&&!Abyss.Evolution.abilities(s).includes(t.mutationTag))reasons.push('尚无相应适应器官');if(t.excludes&&has(s,t.excludes)&&r.level<18)reasons.push('替代协议暂时互斥，等级 18 后可并行');return {state:reasons.length?'locked':'available',reasons};}
 function purchase(s,id){const t=Abyss.Phase3Data.technologies.find(t=>t.id===id);if(!t)return {ok:false,message:'未知研究协议'};const a=availability(s,t);if(a.state!=='available')return {ok:false,message:a.state==='researched'?'研究已完成':a.reasons.join(' / ')||'研究路径未发现'};const r=s.progress.research;r.points-=t.points;for(const [id,n]of Object.entries(t.materials))Abyss.Inventory.consumeItem(s,id,n);r.technologies.push(id);if(id==='black_protocol'){r.clearance='black';Abyss.State.log(s,'BLACK CLEARANCE / 旧设施承认了新的观察者。','rare');}Abyss.State.log(s,'研究完成：'+t.name+'。'+t.unlock,'story');return {ok:true,message:'已解锁 · '+t.name};}
 function observe(before,s,c){
  if(c.type==='experiment'&&s.history.experiment>before.history.experiment)award(s,'repeat:experiment',5,false);
  for(const id of s.mutations)if(!before.mutations.includes(id)){if(award(s,'mutation:'+id,35)){s.progress.research.points++;Abyss.Evolution.record(s,'首次观察：'+Abyss.Data.mutations.find(m=>m.id===id).name,'mutation');}}
  for(const id of s.achievements)if(!before.achievements.includes(id))award(s,'achievement:'+id,20);
  for(const id of Object.keys(s.exploration.items))if(!before.exploration.items[id])award(s,'item:'+id,18);
  for(const id of s.exploration.documents)if(!before.exploration.documents.includes(id)){if(award(s,'document:'+id,30))s.progress.research.points++;}
  if(before.exploration.active&&!s.exploration.active){const l=Abyss.ExpeditionData.locations.find(l=>l.id===before.exploration.active.location);award(s,'repeat:expedition',l.danger>=50?12:5,false);}
  if(s.collection.discoveredSets.length>before.collection.discoveredSets.length)award(s,'behavior:set:'+s.collection.discoveredSets.at(-1),20);
 }
 function identify(s,id){if(!has(s,'material_analysis'))return {ok:false,message:'先研究材料识别'};const item=s.exploration.items[id];if(!item||!(s.inventory[id]>0)||item.identified)return {ok:false,message:'没有可鉴定的物品'};item.identified=true;award(s,'identify:'+id,30);s.progress.research.points++;if(id==='black_glass'||id==='object_redacted'){s.progress.research.anomalyVisible=true;Abyss.State.log(s,'NEW RESEARCH PATH DETECTED / 一组从未登记的研究节点出现了。','rare');}return {ok:true,message:'物品已识别 · 研究经验增加'};}
 return {threshold,levelFor,has,award,availability,purchase,observe,identify};
})();
