
'use strict';
// Unique, replaceable SVG geometry for each of ten slots × six designs.
Abyss.TailoredModels=(()=>{
 const path=(d,fill='var(--art-light)',extra='')=>`<path d="${d}" fill="${fill}" ${extra}/>`,line=(d,w=2,c='var(--art-trim)')=>path(d,'none',`stroke="${c}" stroke-width="${w}"`),circle=(x,y,r,c='var(--art-metal)')=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${c}"/>`,rect=(x,y,w,h,c='var(--art-shade)',r=3)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="${c}"/>`;
 const seam=d=>line(d,1,'var(--art-trim)').replace('/>',' stroke-dasharray="2 3"/>');
 function geometry(a){const i=a.visual.design;let g='';
 if(a.slot==='head')g=[
 path('M154 119q-14-38 36-57 43-20 91 6 35 12 27 50l-13 19H170z')+path('M161 122q80-10 143-7l-8 23-125-1z','var(--art-shade)')+line('M170 99q40-35 92-24')+circle(279,107,7)+line('M279 94v25',2),
 path('M166 126V74q70-34 145 0v52l-27 6-46-18-48 18z')+path('M158 91q-28 43-8 77l34-22V98m117 0v48l34 22q20-34-8-77','var(--art-shade)')+line('M170 80q70-22 130 0',9)+line('M158 115v36m164-36v36',7),
 path('M157 156q-17-77 36-92 78-31 126 40l8 53-35-22-52-9-48 9z')+Array.from({length:7},(_,j)=>path(`m${178+j*19} ${88+Math.abs(3-j)*8} -6-16 11-16 7 18z`,'var(--art-trim)')).join('')+seam('M171 148q66-41 136 0'),
 path('M156 139q-17-70 50-82 87-13 116 58l-18 30z')+line('M163 104q72-37 140 12M167 126q63-23 151-5',12)+path('M310 114l20 87-17 32-10-112','var(--art-shade)')+seam('M312 127l9 66'),
 path('M182 123l15-66 31-28 36 52 35 45z')+`<ellipse cx="239" cy="130" rx="104" ry="15" fill="var(--art-shade)"/>`+line('M187 111q46 19 101 3',7)+[208,230,256,273].map((x,j)=>circle(x,74+j%2*23,3,'var(--art-trim)')).join('')+line('M218 56l15 28 23-3'),
 line('M162 135q76-20 156 0',8,'var(--art-metal)')+[174,302].map((x,j)=>line(`M${x} 126q${j?30:-30}-33 ${j?8:-8}-75m${j?9:-9} 32 ${j?21:-21}-19m${j?-20:20} 10 ${j?-8:8}-23`,5,'var(--art-metal)')).join('')+path('M239 98l14 22-14 15-14-15z','var(--art-trim)')
 ][i];
 if(a.slot==='face'){const pair=(shape)=>[199,280].map(x=>`<g transform="translate(${x} 207)">${shape}</g>`).join('');g=[
 pair(path('M-30-15q28-17 58 0l-6 35q-21 19-46 0z','none','stroke="var(--art-metal)" stroke-width="4"')+path('M-25-11q23-13 47 0l-5 28q-18 16-37 0z','#b4dfe5','opacity=".10"')+line('M-19-10l10-5',2))+line('M229 199h21M169 195l-15-8m154 8 18-8',4,'var(--art-metal)'),
 pair(path('M-31-22q33-2 61 11l-8 29q-22 14-44-3z','none','stroke="var(--art-metal)" stroke-width="4"')+line('M-20-10l11 5'))+line('M230 199h20',3),
 `<circle cx="199" cy="207" r="31" fill="none" stroke="var(--art-metal)" stroke-width="4"/>`+line('M175 229q-31 32-1 57t29-22',2,'var(--art-metal)')+circle(199,242,3)+line('M181 186l8-6',2),
 path('M155 185l24-14 60 19 60-19 26 14-14 48-38 4-33-18-35 18-38-4zM174 192q22-17 48 6l-9 21q-24 8-42-6zM254 198q27-23 48-6l3 21q-18 14-42 6z','var(--art-shade)','fill-rule="evenodd"')+path('M174 192q22-17 48 6l-9 21q-24 8-42-6zM254 198q27-23 48-6l3 21q-18 14-42 6z','#bdd7de','opacity=".08"')+seam('M164 186l15-7 60 19 58-19 20 8'),
 pair(path('M-31-25h62v47q-30 18-62 0z','none','stroke="var(--art-shade)" stroke-width="9"')+path('M-28-22h56v42q-28 17-56 0z','none','stroke="var(--art-metal)" stroke-width="2"')+line('M-19-15h15',2))+line('M229 199h22',5),
 line('M154 181q88-37 172 0',3,'var(--art-metal)')+Array.from({length:12},(_,j)=>path(`M${165+j*14} 186l7 18-7 43-7-43z`,j%2?'var(--art-trim)':'var(--art-light)','opacity=".32"')).join('')
 ][i];}
 if(a.slot==='neck')g=[
 path('M160 262q80 38 160 0l-7 23q-72 25-147 0z')+line('M168 271q75 25 145-1',6)+path('m186 279-13 60 25 13 11-62z','var(--art-shade)')+line('M183 329l17 5',5),
 path('M164 265q76 24 152 0v11q-78 25-150 0z','var(--art-shade)')+path('m238 278-34-17-17 26 49 8 6-8 45 8-6-34z')+path('m239 286-14 48 14-9 12 9 3-48z','var(--art-trim)')+circle(241,281,6),
 line('M170 262q68 65 139 0',3,'var(--art-metal)')+`<ellipse cx="239" cy="309" rx="15" ry="23" fill="var(--art-trim)"/>`+`<ellipse cx="239" cy="309" rx="10" ry="17" fill="#728f68" opacity=".65"/>`+line('M239 320v-19m0 6 5-5',2),
 path('M164 264q72 21 152 0l-2 17q-76 21-148 0z','var(--art-shade)')+rect(221,272,37,17,'var(--art-metal)')+rect(228,276,23,9)+[182,193,282,294].map(x=>circle(x,277,2,'var(--art-trim)')).join(''),
 [0,1,2].map(j=>line(`M${166+j*10} 269q${73-j*10} ${34+j*9} ${147-j*20} 0`,2,'var(--art-metal)')).join('')+[194,239,284].map(x=>path(`m${x} 291 5 8-5 11-5-11z`,'var(--art-trim)')).join(''),
 line('M171 260q-3 47 57 36m81-36q3 47-57 36',8,'var(--art-metal)')+path('m225 287 10 5-7 14-13-9zm31 0-10 5 7 14 13-9z','var(--art-trim)')+line('M173 268q8 25 35 25m97-25q-8 25-35 25',2)
 ][i];
 if(a.slot==='body'){g=[
 path('M170 263l39 10q31 23 63 0l39-10 19 63-23 4-9 22q-61 10-120 0l-9-23-19-5z')+path('m183 266 56 27 55-27-18 40-37-8-34 8z','var(--art-shade)')+line('M190 274l49 24 45-24',3)+line('M239 301v37',3)+seam('M181 346h115'),
 path('M170 263l69 20 66-20 25 83q-84 22-180 0z')+path('m179 267 66 40 48-40-28 76-37 10z','var(--art-shade)')+line('M179 269l65 40 51-40',3)+rect(171,312,140,15,'var(--art-trim)')+line('M239 328l-8 23 14-7',3),
 path('M159 265q80 22 162 0l28 64-26 3-22 26-25-13-36 19-34-19-29 10-18-25-29-2z')+line('M172 286l67 16 68-16',5)+[184,212,240,268,296].map((x,j)=>line(`M${x} 308l${j<2?-12:12} 24`,2)).join('')+seam('M158 327l33 19 47-12 53 12 34-20'),
 path('M181 265h22v44h74v-44h22v84q-56 10-119 0z','var(--art-shade)')+rect(196,283,88,42)+rect(207,292,66,22,'var(--art-shade)')+line('M207 302h63',2)+[193,288].map(x=>rect(x,265,14,9,'var(--art-metal)')).join('')+seam('M186 341h106'),
 path('M166 263l45 10 29 25 29-25 44-10 23 64-23 7-10 20q-67 12-130-1l-8-20-22-7z')+path('m210 273 30 25 29-25-11 39h-39z','var(--art-shade)')+Array.from({length:6},(_,j)=>line(`M${180+j*23} 296l-7 15 7 15-7 15`,1)).join('')+line('M239 301v48',3)+[315,331,345].map(y=>circle(245,y,2,'var(--art-metal)')).join(''),
 path('M175 264l63 22 67-22 28 66-32 22-61-10-61 10-31-24z','var(--art-shade)')+[0,1,2].map(j=>path(`M${174+j*6} ${274+j*22}l65 18 66-18-8 17-58 18-56-18z`,j%2?'var(--art-trim)':'var(--art-light)')).join('')+path('M239 289l18 24-18 27-18-27z','var(--art-metal)')+line('M239 296v36',2)
 ][i];}
 if(a.slot==='back')g=[
 line('M142 235l28 24m-37 49 34 13',7,'var(--art-shade)')+rect(93,213,61,121,'var(--art-shade)',18)+rect(91,221,61,105,'var(--art-light)',15)+[235,310].map(y=>line(`M91 ${y}h61`,9,'var(--art-metal)')).join('')+`<ellipse cx="121" cy="222" rx="27" ry="10" fill="var(--art-trim)"/>`+`<ellipse cx="121" cy="222" rx="16" ry="5" fill="var(--art-shade)"/>`,
 line('M144 200v139m-14-127 42-25',7,'var(--art-metal)')+rect(100,245,71,68,'var(--art-shade)')+path('m104 246 10-16h43l10 16z')+rect(111,255,48,43,'#eccd82')+line('M124 257v36m21-36v36M112 280h45',3,'var(--art-metal)')+line('M122 229q-7-29 19-25t9 25',3),
 [0,1].map(j=>{const sign=j?1:-1,x=j?308:171;return path(`M${x} 248q${sign*119}-119 ${sign*126}-62q${sign*4} 53 ${-sign*105} 68q${sign*94} 41 ${sign*75} 78q${-sign*49} 8 ${-sign*92}-53z`,'#a1c1b4','fill-opacity=".34"')+line(`M${x} 249l${sign*111}-69m${-sign*101} 76 ${sign*77} 51`,2);}).join(''),
 line('M129 160v196',7,'var(--art-metal)')+path('M134 166l-72 132 74-14zm8 0 80 107-78 11z')+seam('M133 184l-58 100 58-12')+path('M137 297l35 37-40 2z','var(--art-shade)')+line('M136 187l79 147',2),
 rect(85,267,87,55,'var(--art-shade)',10)+[99,118,137,157].map(x=>line(`M${x} 273v42`,4)).join('')+Array.from({length:7},(_,j)=>path(`M${105+j*7} 276q${j<3?-38:35}-48 ${j<3?-19:20}-71q12 31-4 50z`,'var(--art-light)')).join('')+line('M109 281q20-61 26-86',3,'var(--art-metal)'),
 `<ellipse cx="239" cy="238" rx="148" ry="119" fill="none" stroke="var(--art-metal)" stroke-width="5"/><ellipse cx="239" cy="238" rx="126" ry="143" fill="none" stroke="var(--art-trim)" stroke-width="2" transform="rotate(32 239 238)"/>`+Array.from({length:12},(_,j)=>{const x=239+Math.cos(j*Math.PI/6)*148,y=238+Math.sin(j*Math.PI/6)*119;return circle(x,y,j%3?3:8);}).join('')+line('M91 238h24m248 0h24M239 119v17',2)
 ][i];
 if(a.slot==='tail')g=[
 line('M-19-7q19-15 38 0',5,'var(--art-metal)')+path('M-12 0h24l12 42-24-9-24 9z')+Array.from({length:7},(_,j)=>line(`M${-15+j*5} 18v27`,1)).join('')+circle(0,2,6),
 `<ellipse rx="23" ry="14" fill="none" stroke="var(--art-metal)" stroke-width="6"/>`+circle(0,14,18,'var(--art-trim)')+circle(0,14,13,'var(--art-shade)')+line('M0 5v9l8 4',2),
 path('M-23 11q-8-41 36-38 2 28-36 38z')+line('M-23 11L7-22m-20 24 14-2m-4-9 10-1',2)+`<ellipse rx="17" ry="9" fill="none" stroke="var(--art-metal)" stroke-width="3"/>`,
 line('M0 4v-41',4,'var(--art-metal)')+path('M2-40l32 11-13 13 12 12L2-7z')+line('M8-30l15 4',3)+`<ellipse cy="4" rx="18" ry="8" fill="none" stroke="var(--art-metal)" stroke-width="5"/>`,
 `<ellipse rx="20" ry="12" fill="none" stroke="var(--art-metal)" stroke-width="5"/>`+path('M-17 3l-29 32 24-4 22-13 22 13 24 4L17 3z','#95c6c3','opacity=".7"')+line('M-12 5l-20 25m44-25 20 25',2),
 line('M-16 0q18 39 49 11',3,'var(--art-metal)')+path('m31 5 5-14 5 14 15 1-12 9 3 15-11-8-12 8 3-15-12-9z','var(--art-trim)')+[0,1,2].map(j=>line(`M${24-j*5} ${17+j*7}l${-35-j*11} ${9+j*5}`,1)).join('')
 ][i];
 if(a.slot==='charm')g=[
 rect(-22,-14,44,34,'var(--art-trim)')+path('M-22-14 0 5 22-14','var(--art-light)')+line('M-22 20 0 4 22 20',1,'var(--art-shade)')+circle(0,4,5,'var(--art-metal)'),
 path('M-21-17l18 12 21-12-3 28-16 17-17-17z','var(--art-trim)')+path('M-18-9-6-2-15 4m28-13-12 7 12 6z','var(--art-light)')+circle(-8,5,2,'var(--art-shade)')+circle(7,5,2,'var(--art-shade)')+line('M-2 9v9',1,'var(--art-shade)'),
 path('M-15-25h30q0 17-15 25 15 8 15 27h-30q0-19 15-27-15-8-15-25z','#b7d7d3','opacity=".55"')+line('M-18-25h36m-36 52h36',5,'var(--art-metal)')+path('M-10 23L0 8l10 15z','var(--art-trim)')+circle(0,-7,3),
 line('M0-19v40m-20-10q20 25 40 0',5,'var(--art-metal)')+`<circle cy="-22" r="6" fill="none" stroke="var(--art-metal)" stroke-width="3"/>`+line('M-10-7h20m-31 16 4 9m38-9-4 9',3),
 rect(-18,-24,36,52,'var(--art-metal)',14)+rect(-12,-15,24,34,'var(--art-shade)',8)+[0,1,2].map(j=>line(`M${-7+j*7} -8v18`,1)).join('')+circle(0,1,6,'var(--art-light)')+line('M17 2h9m0-6v12',3),
 path('M-24 7l24-32L24 7z','var(--art-metal)')+rect(-21,7,42,27)+path('M-15 9L0-9 15 9z','var(--art-shade)')+circle(0,15,8,'var(--art-trim)')+line('M0 9v12m-6-6h12',1,'var(--art-shade)')+line('M-16 30h32',3)
 ][i];

 if(a.slot==='utility')g=[
 rect(121,270,34,65,'var(--art-light)',9)+line('M127 276v49',2)+rect(118,267,40,9,'var(--art-metal)')+line('M140 267q-26-10-14-31',3),
 path('M122 292q-7 44 20 44t19-44z')+path('M122 300q-26-6-9 22m49-21q29-9 15 19', 'none','stroke="var(--art-metal)" stroke-width="4"')+rect(125,286,35,8,'var(--art-metal)')+circle(142,281,5),
 rect(112,286,62,43)+path('M117 291l10-10 39 7-3 38-39 7z','var(--art-shade)')+circle(147,308,17)+circle(147,308,10,'var(--art-shade)')+line('M123 298v22m4-25v29',1),
 path('M122 287h37l7 41h-50z','#a0c7c3','opacity=".5"')+line('M119 286h44m-48 43h50',5,'var(--art-metal)')+line('M130 286q-12-27 12-27t11 27',3)+path('M141 319q-10-17 1-23 9 12 1 23z','var(--art-trim)'),
 path('M116 291l18 44 42-27-13-21z','none','stroke="var(--art-metal)" stroke-width="5"')+line('M118 292l51 15m-34 27 29-45',3)+circle(135,304,8)+line('M144 318l19-7',1),
 rect(109,280,66,57,'var(--art-metal)',8)+rect(115,287,37,32,'var(--art-shade)',4)+[0,1,2,3].map(j=>line(`M119 ${293+j*6}h29`,1)).join('')+circle(163,303,6,'var(--art-trim)')+line('M124 281v-38m3 3h25',2)+rect(118,322,47,9,'var(--art-trim)')
 ][i];
 if(a.slot==='weapon')g=[
 path('M353 207q74 76 0 152','none','stroke="var(--art-light)" stroke-width="7"')+line('M353 207v152',1)+rect(370,279,9,23,'var(--art-metal)'),
 path('M363 235q37 55-5 115l-8-6q27-72 13-109z')+line('M350 342l29 6',5,'var(--art-metal)')+line('M363 346l-4 29',8,'var(--art-shade)')+seam('M362 250q22 60-6 89'),
 path('M369 278l9 65-12 8-7-70z','var(--art-metal)')+line('M353 278h35',6)+rect(363,251,13,26,'var(--art-shade)')+circle(369,249,7),
 rect(335,267,54,14,'var(--art-metal)')+rect(338,267,12,12)+path('M353 280l-9 38 17 3 8-41z','var(--art-shade)')+line('M363 285q21 16 12 24h-14',2,'var(--art-metal)')+circle(390,274,6,'var(--art-shade)'),
 line('M369 245v119',6,'var(--art-metal)')+path('M347 228v24q22 25 44 0v-24m-22-6v48','none','stroke="var(--art-light)" stroke-width="6"')+line('M349 233l-3-11m44 11 3-11',4),
 path('M369 216l7 118-7 17-6-17z','var(--art-trim)')+line('M347 342q22-22 45 0',5,'var(--art-metal)')+line('M369 343v29',8,'var(--art-shade)')+path('m369 211-5 6 5 6 5-6z','var(--art-metal)')
 ][i];
 if(a.slot==='effect'){
 const effects=[
 [0,1,2,3,4].map(j=>`<g transform="translate(${124+j*53} ${350+(j%2)*14}) rotate(${j*23})">${rect(-6,-9,12,18,'var(--art-trim)',1)}${line('M-4-4h8m-8 4h6',1,'var(--art-shade)')}</g>`).join(''),
 [0,1,2,3,4,5,6].map(j=>circle(124+j*35,355+Math.sin(j)*14,3+j%3,'#a9d6d2')).join(''),
 [0,1,2,3,4].map(j=>path(`m${117+j*59} ${336+j%2*29}q-12-23 7-27 18 15-7 27z`,'var(--art-light)')).join(''),
 `<ellipse cx="240" cy="354" rx="158" ry="29" fill="none" stroke="var(--art-metal)" stroke-width="1.5"/>`+[0,1,2,3,4,5,6,7].map(j=>line(`M${97+j*40} 355v${j%2?9:-9}`,1)).join(''),
 line('M100 350q45-70 120-17t170-27m-275 48q85 42 155-15t123-15',3,'var(--art-light)'),
 [0,1,2,3,4,5,6].map(j=>circle(108+j*43,328+Math.sin(j*1.7)*39,3+j%2,'var(--art-trim)')).join('')+line('M108 328l43 39 43-50 43-25 43 55 43 13 43-49',1,'var(--art-light)')
 ];g=`<g class="atelier-ambient atelier-ambient-${i}">${effects[i]}</g>`;
 }
 return `<g data-atelier-design="${a.slot}-${i}">${g}</g>`;}
 return {geometry};
})();
