'use strict';
// Pure configuration. The DOM adapter grounds both sizes on a common floor anchor.
Abyss.SceneComposition=(()=>{
 const fresh=()=>({version:1,chamber:1,creature:1,depth:0});
 function read(raw){const r=raw?.sceneComposition,d=fresh();for(const [k,min,max]of [['chamber',.55,1.15],['creature',.55,1.3],['depth',0,1]])if(Number.isFinite(r?.[k]))d[k]=Abyss.Util.clamp(r[k],min,max);return d;}
 function command(s,p){const d=read({sceneComposition:p});if(!['chamber','creature','depth'].every(k=>Number.isFinite(p?.[k])))return {ok:false,message:'Invalid scene configuration'};s.sceneComposition=d;return {ok:true,message:''};}
 return {fresh,read,command};
})();
