'use strict';
Abyss.WeaponRed=(()=>{
 const supported=w=>w?.id==='weapon_red',rank=(s,w)=>Abyss.WeaponRare.rank(s,w);
 const lines=['反击伤害提高','成功反击让下一次命中更快','反击有概率束缚敌人动作','成功保护实验体时立即获得反击机会','低生命时更容易反击','共同记忆与信任降低反击的不确定性'];
 const en=['Increased counter damage','A successful counter speeds the next hit','Counters may bind enemy movement','Protecting the specimen grants an immediate counter opportunity','Low health improves counter chance','Shared memories and trust make counters more reliable'];const dictionary={};lines.forEach((v,i)=>dictionary[v]=en[i]);Abyss.I18n.register(dictionary);Abyss.WeaponData.weapons.find(supported).anomalousResonance=lines;
 function stats(s,w,f){if(!supported(w))return {};const r=rank(s,w),o={counterDamage:r>=1?1.2:1};if(r>=2&&f?.weaponRedFast)o.time=.8;if(r>=4&&f?.weaponRedReady)o.counter=1;if(r>=5&&f?.hp<f?.maxHp*.3)o.counter=(o.counter||0)+.1;if(r>=6){const memories=Array.isArray(s.memories)?s.memories.length:Object.keys(s.memories||{}).length;const confidence=Math.max(0,Math.min(.08,.02+Math.min(5,memories)*.008+s.stats.loyalty*.0003-s.resentment*.0005));o.counter=(o.counter||0)+confidence;}return o;}
 function received(s,w,f,n){if(supported(w)&&rank(s,w)>=4&&f.guarding&&n>0){f.weaponRedReady=true;f.logs.push('RED THREAD · HOLD');}}
 function counter(s,w,f,e,n){if(!supported(w))return n;const r=rank(s,w);f.weaponRedReady=false;if(r>=2)f.weaponRedFast=true;if(r>=3&&Abyss.Util.random(s)<.3){const slow=f.enemyStatus.find(v=>v.id==='slow');if(slow)slow.turns=Math.max(slow.turns,2);else f.enemyStatus.push({id:'slow',turns:2});f.logs.push('BIND');}f.weaponRedFlash=f.turn;return n;}
 function hit(w,f){if(supported(w))f.weaponRedFast=false;}
 return {supported,stats,received,counter,hit};
})();
