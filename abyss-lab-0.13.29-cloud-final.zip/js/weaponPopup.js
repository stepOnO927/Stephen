'use strict';
// 404 effects stay inside game state and the containment UI.
Abyss.WeaponPopup=(()=>{
 const rank=(s,w)=>Abyss.WeaponRare.rank(s,w),supported=w=>w?.id==='weapon_404';
 const lines=['404触发率提高','触发时有概率打开第二个攻击窗口','暴击率提高且攻击时间缩短','清盾成功后更容易打断目标','敌方命中时小概率反射部分伤害','首次404随机执行两个不同的错误效果'];
 const en=['Increased 404 trigger chance','A chance to open a second attack window','Increased critical chance and shorter attack time','Clearing a shield improves the interruption chance','A small chance to reflect part of incoming damage','The first 404 executes two distinct random error effects'];
 const dictionary={};lines.forEach((v,i)=>dictionary[v]=en[i]);Abyss.I18n.register(dictionary);const w=Abyss.WeaponData.weapons.find(supported);if(w)w.anomalousResonance=lines;
 function stats(s,w,f){if(!supported(w))return {};const r=rank(s,w);return {crit:f?.weapon404Critical?1:r>=3?.06:0,time:r>=3?.9:1};}
 function stun(f){const old=f.enemyStatus.find(v=>v.id==='stun');if(old)old.turns=Math.max(old.turns,2);else f.enemyStatus.push({id:'stun',turns:2});}
 function prepare(s,w,f){if(!supported(w))return;const r=rank(s,w);f.weapon404Critical=false;f.weapon404Repeat=false;f.weapon404Windows=0;
  if(Abyss.Util.random(s)>=(r>=1?.42:.32))return;
  f.popup=true;f.weapon404Windows=1;const cleared=f.enemyShield>0;f.enemyShield=0;if(Abyss.Util.random(s)<(r>=4&&cleared?.7:.3))stun(f);f.logs.push('404 · TARGET NOT FOUND');
  if(r>=2&&Abyss.Util.random(s)<.2){f.weapon404Windows=2;f.weapon404Repeat=true;f.logs.push('SECOND WINDOW');}
  if(r>=6&&!f.weapon404Used){f.weapon404Used=true;const pool=['SHIELD','STUN','CRITICAL','REPEAT','BUFF'];for(let i=0;i<2;i++){const choice=pool.splice(Math.min(pool.length-1,Math.floor(Abyss.Util.random(s)*pool.length)),1)[0];f.logs.push('PAGE NOT FOUND · '+choice);if(choice==='SHIELD')f.enemyShield=0;if(choice==='STUN')stun(f);if(choice==='CRITICAL')f.weapon404Critical=true;if(choice==='REPEAT')f.weapon404Repeat=true;if(choice==='BUFF')f.weapon404MuteUntil=f.turn+3;}}
 }
 function afterHit(s,w,f,n,hurt){if(!supported(w)||!f.weapon404Repeat||n<=0)return;f.weapon404Repeat=false;const copy=Math.min(150,Math.round(n*.45));hurt(f,'enemy',copy);f.logs.push('ERROR WINDOW · '+copy);}
 function incoming(s,w,f,n){if(supported(w)&&n>0&&rank(s,w)>=5&&Abyss.Util.random(s)<.06){const copy=Math.round(n*.25),absorbed=Math.min(f.enemyShield,copy);f.enemyShield-=absorbed;f.enemyHp=Math.max(0,f.enemyHp-copy+absorbed);f.logs.push('REDIRECT · '+copy);return n-copy;}return n;}
 return {supported,stats,prepare,afterHit,incoming};
})();
