'use strict';
Abyss.CombatParty=(()=>{
 const rank=(s,w)=>Abyss.WeaponRare.rank(s,w);
 function start(s,f){f.jackHp=f.jackMax=100;const pet=s.pets?.find(p=>p.id===s.hunt.companionId&&p.active&&p.alive&&!p.escaped&&p.health>=35);f.pet=pet?{id:pet.id,name:pet.name,hp:pet.health,maxHp:100}:null;}
 function danger(s,w,f){if(w?.id!=='weapon_fang'||rank(s,w)<6||f.weaponPackUsed)return;if(f.hp/f.maxHp<.25||f.pet&&f.pet.hp/f.pet.maxHp<.25){f.weaponPackUsed=true;f.weaponPackUntil=f.turn+3;f.logs.push('NONE LEFT BEHIND');}}
 function received(s,w,f,n){danger(s,w,f);if(w?.id==='weapon_fang'&&rank(s,w)>=4&&n>=f.maxHp*.15)f.weaponShareReady=true;}
 function incoming(s,w,f,n){const roll=Abyss.Util.random(s);let target=roll<.12?'jack':roll<.24&&f.pet&&f.pet.hp>0?'pet':'b07';if(f.guarding&&target==='pet'){target='b07';n=Math.round(n*.6);f.weaponPetProtected=true;f.logs.push('COVER · '+f.pet.name);}if(target==='jack'){f.jackHp=Math.max(0,f.jackHp-n);f.logs.push('JACK · '+n);return 0;}if(target==='pet'){f.pet.hp=Math.max(0,f.pet.hp-n);if(w?.id==='weapon_fang'&&rank(s,w)>=4&&n>=15)f.weaponShareReady=true;danger(s,w,f);f.logs.push(f.pet.name+' · '+n);return 0;}return n;}
 function stats(s,w,f){if(w?.id!=='weapon_fang')return {};const r=rank(s,w),o={};if(r>=3)o.attack=.08;if(f?.weaponPackUntil>f?.turn){o.damage=1.12;o.defense=.12;}return o;}
 function hit(s,w,f,n){if(w?.id!=='weapon_fang'||n<=0)return;const r=rank(s,w),low=f.hp/f.maxHp<.3||f.pet&&f.pet.hp/f.pet.maxHp<.3,mult=(r>=1?1.2:1)*(r>=2?1.15:1)*(r>=5&&low?1.2:1)*(f.weaponPackUntil>f.turn?1.2:1);f.hp=Math.min(f.maxHp,f.hp+Math.round(2*mult));if(f.weaponShareReady){f.jackHp=Math.min(f.jackMax,f.jackHp+Math.round(4*mult));f.weaponShareReady=false;f.logs.push('SHARE THE WOUND');}}
 function finish(s,f){if(f?.pet){const p=s.pets.find(p=>p.id===f.pet.id);if(p)p.health=Math.max(12,Math.min(p.health,f.pet.hp));}}
 return {start,incoming,received,stats,hit,finish};
})();
