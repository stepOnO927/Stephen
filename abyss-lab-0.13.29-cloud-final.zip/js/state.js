'use strict';
Abyss.State = (() => {
 const statDefaults = {hunger:28,health:90,mood:72,loyalty:58,strength:10,intelligence:10,agility:10,stability:82,pollution:3};
 const historyDefaults = {feed:0,train:0,care:0,experiment:0,explore:0,neglect:0,punish:0};
 function create(seed = Date.now() >>> 0) {
   const inventory={ration:3,meat:1,fruit:1};
   for(const item of Abyss.ExpeditionData.loot)inventory[item.id]=0;
   return {...Abyss.Phase2State.defaults(seed,1),version:4,homestead:Abyss.HomesteadModel?.fresh(1),happyClub:Abyss.HappyClub?.fresh(),operations:Abyss.LabOperationsState?.fresh(1),roomSystems:Abyss.LabRooms?.fresh(1),greenhouse:Abyss.GardenState?.fresh(1),infirmary:Abyss.Infirmary?.fresh(1),underground:Abyss.UndergroundState.fresh(seed,1),climate:Abyss.ClimateState.fresh(seed,1),road:Abyss.RoadState.fresh(seed),caravan:Abyss.Caravans.fresh(seed),street:Abyss.Street.fresh(seed),story:Abyss.StoryMode.fresh(),pets:[],bedroom:Abyss.Bedroom.fresh(),containmentEvent:null,salvage:Abyss.Salvage.fresh(),sceneComposition:Abyss.SceneComposition.fresh(),redeem:Abyss.Redeem.fresh(),hunt:Abyss.HuntState.fresh(),home:Abyss.Home.fresh(),journey:Abyss.Journey.fresh(),legacy:Abyss.Legacy.fresh(),dreams:Abyss.Dreams.fresh(),continuity:Abyss.Continuity.fresh(seed),social:Abyss.Social.fresh(),wasteland:Abyss.WastelandState.fresh(),color:null,colorRng:(seed^0x7412abcd)>>>0||1,narrative:Abyss.NarrativeState.fresh(),progress:Abyss.ProgressState.fresh(),name:Abyss.Identity.DEFAULT,rng:seed || 1,day:1,age:0,money:100,ap:5,stats:{...statDefaults},history:{...historyDefaults},bias:{gentle:0,feral:0,radiant:0,void:0,armored:0},inventory,exploration:Abyss.ExpeditionState.fresh(),mutations:[],form:null,resentment:0,experimentsToday:0,caredToday:false,fedToday:false,awaySince:null,pendingEvent:null,endingNotice:false,eventDays:{},seenEvents:[],achievements:[],discoveredForms:[],logs:[{day:1,type:'story',text:'舱门开启。一个未知的小生命抬起头，第一次看见了你。'}],settings:{motion:true,sound:false},savedAt:null};
 }
 function log(s,text,type='normal') { s.logs.unshift({day:s.day,text,type}); s.logs=s.logs.slice(0,80); }
 function effects(s,e={}) { for(const [key,value] of Object.entries(e)) if(key in statDefaults) s.stats[key]=Abyss.Util.clamp(s.stats[key]+value); }
 function apply(s,item) {
   if(item.money) s.money=Math.max(0,s.money+item.money);
   effects(s,item.effects);
   for(const [key,n] of Object.entries(item.food||{})) s.inventory[key]=(s.inventory[key]||0)+n;
   for(const [key,n] of Object.entries(item.history||{})) s.history[key]=(s.history[key]||0)+n;
   for(const [key,n] of Object.entries(item.bias||{})) s.bias[key]=(s.bias[key]||0)+n;
 }
 function achieve(s) {
   for(const a of Abyss.Data.achievements) {
     if(a.id.startsWith("climate_")||a.id.startsWith("ud_"))continue;
     const met=a.special==='mutation'?s.mutations.length>0:a.special==='mature'?!!s.form:Abyss.Util.matches(s,a.rules);
     if(met&&!s.achievements.includes(a.id)){s.achievements.push(a.id);log(s,`成就解锁：${a.name}`,'rare');}
   }
 }
 // Strict validation, not a shallow spread of untrusted JSON. Unknown fields are discarded.
 function validate(raw) {
   if(!raw||![1,2,3,4].includes(raw.version)) throw new Error('不支持的存档版本');
   const s=create();s.name=Abyss.Identity.read(raw.name);
   const integer=(n,min,max)=>Number.isInteger(n)&&n>=min&&n<=max;
   for(const [key,min,max] of [['rng',1,4294967295],['day',1,100000],['age',0,99999],['money',0,10000000],['ap',0,5],['resentment',0,100],['experimentsToday',0,5]]){
     if(!integer(raw[key],min,max)) throw new Error(`存档字段无效：${key}`);s[key]=raw[key];
   }
   const birth=Number.isInteger(raw.legacy?.birthDay)&&raw.legacy.birthDay>=1&&raw.legacy.birthDay<=s.day?raw.legacy.birthDay:1;
   if(s.age!==s.day-birth) throw new Error('存档日期无效');
   for(const group of ['stats','history','bias']) for(const key of Object.keys(s[group])) {
     const n=raw[group]?.[key];if(!Number.isFinite(n)||n<0||n>(group==='stats'?100:10000000))throw new Error(`存档属性无效：${key}`);s[group][key]=n;
   }
   s.inventory={};for(const f of Abyss.Data.foods){const n=raw.inventory?.[f.id]??0;if(!integer(n,0,10000000))throw new Error('物品数量无效');s.inventory[f.id]=n;}
   for(const item of Abyss.ExpeditionData.loot){const legacy=raw.exploration?.items?.[item.id]?.quantity;const n=raw.version>=3?(raw.inventory?.[item.id]??legacy??0):(legacy??raw.inventory?.[item.id]??0);if(!integer(n,0,10000000))throw new Error('物品数量无效');s.inventory[item.id]=n;}
   for(const [key,ids] of [['mutations',Abyss.Data.mutations.map(x=>x.id)],['achievements',Abyss.Data.achievements.map(x=>x.id)],['seenEvents',Abyss.Data.events.map(x=>x.id)],['discoveredForms',Abyss.Data.forms.map(x=>x.id)]]) {
     if(!Array.isArray(raw[key]))throw new Error('存档列表无效');s[key]=[...new Set(raw[key].filter(x=>ids.includes(x)))];
   }
   s.form=Abyss.Data.forms.some(f=>f.id===raw.form)?raw.form:null;
   s.pendingEvent=Abyss.Data.events.some(e=>e.id===raw.pendingEvent)?raw.pendingEvent:null;
   s.awaySince=integer(raw.awaySince,1,s.day)?raw.awaySince:null;
   for(const key of ['caredToday','fedToday','endingNotice'])s[key]=raw[key]===true;
   for(const e of Abyss.Data.events)if(integer(raw.eventDays?.[e.id],1,s.day))s.eventDays[e.id]=raw.eventDays[e.id];
   s.settings={motion:raw.settings?.motion!==false,sound:raw.settings?.sound===true};
   s.logs=Array.isArray(raw.logs)?raw.logs.slice(0,80).filter(x=>x&&integer(x.day,1,s.day)&&typeof x.text==='string').map(x=>({day:x.day,text:x.text.slice(0,500),type:['normal','warning','rare','story'].includes(x.type)?x.type:'normal'})):s.logs;
   s.savedAt=typeof raw.savedAt==='string'?raw.savedAt:null;
   Object.assign(s,Abyss.Phase2State.read(raw,s));
   s.exploration=Abyss.ExpeditionState.validate(raw.exploration,s);
   s.progress=Abyss.ProgressState.read(raw,s);
   s.colorRng=integer(raw.colorRng,1,4294967295)?raw.colorRng:(s.rng^0x7412abcd)>>>0||1;s.color=Abyss.ColorData?.colors.some(c=>c.id===raw.color)?raw.color:null;s.narrative=Abyss.NarrativeState.read(raw,s);if(Abyss.Campaign)Abyss.Campaign.read(raw,s);if(Abyss.JackStory)Abyss.JackStory.migrate(raw,s);s.wasteland=Abyss.WastelandState.read(raw,s);s.home=Abyss.Home.read(raw,s);s.journey=Abyss.Journey.read(raw,s);s.legacy=Abyss.Legacy.read(raw,s);s.dreams=Abyss.Dreams.read(raw,s);s.continuity=Abyss.Continuity.read(raw,s);s.social=Abyss.Social.read(raw,s);s.hunt=Abyss.HuntState.read(raw,s);s.redeem=Abyss.Redeem.read(raw);s.pets=Abyss.Pets.read(raw);s.bedroom=Abyss.Bedroom.read(raw);if(Abyss.ContainmentEvents.events.some(e=>e.id===raw.containmentEvent?.id))s.containmentEvent={id:raw.containmentEvent.id,pet:s.pets.some(p=>p.id===raw.containmentEvent.pet)?raw.containmentEvent.pet:null,day:s.day};s.salvage=Abyss.Salvage.read(raw);s.sceneComposition=Abyss.SceneComposition.read(raw);s.caravan=Abyss.Caravans.read(raw,s);s.street=Abyss.Street.read(raw,s);s.story=Abyss.StoryMode.read(raw,s);s.road=Abyss.RoadState.read(raw,s);s.climate=Abyss.ClimateState.read(raw,s);s.underground=Abyss.UndergroundState.read(raw,s);Abyss.StoryRevision?.migrate(raw,s);s.greenhouse=Abyss.GardenState?.read(raw,s);s.infirmary=Abyss.Infirmary?.read(raw,s);s.operations=Abyss.LabOperationsState?.read(raw,s);s.roomSystems=Abyss.LabRooms?.read(raw,s);s.happyClub=Abyss.HappyClub?.read(raw,s);s.homestead=Abyss.HomesteadModel?.read(raw.homestead,s.day);s.version=4;
   return s;
 }
 return {create,log,effects,apply,achieve,validate};
})();

