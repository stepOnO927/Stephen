'use strict';
// Rewrite copied ending prose while retaining every existing decision and ending ID.
(()=>{
 const X=Abyss.JackData,D=Abyss.NarrativeData;
 const endings={
 together_end:`2|再试一次？……接不上了。|Try once more? ...It will not connect.
3|屏幕灭了，风扇仍靠惯性转着。|The screen went dark; the fan spun on its inertia.
4|Jack把响个不停的那只水壶拿下来。|Jack took down the kettle that kept rattling.
7|它只是要听见他的声音。|It only wanted to hear his voice.
8|两张照片压在杯子下面，边角已经沾湿。|Two photographs were trapped under a cup, their corners wet.
9|手链卡在袖口，Jack替它松开。|The bracelet caught on the cuff. Jack freed it.
10|我没有别的电池了。|I have no more batteries.
11|灯管只剩下靠墙的一截亮着。|Only the end of the tube by the wall still glowed.
12|他把椅子拉近，没有坐得更高。|He pulled the chair closer without sitting above it.
13|报警器的电池先用完了。|The alarm battery ran out first.
14|他们分完了杯子里最后一点水。|They shared the last water in the cup.
15|Jack应声的间隔变长。|The intervals between Jack's answers grew longer.
16|它的爪子停在那个缺口杯子旁边。|Its claw rested beside the chipped cup.
17|钥匙在Jack的膝上。他已经握不稳。|The key lay on Jack's knee. He could no longer grip it.
18|它向椅子靠过去，等着一个很短的回答。|It leaned toward the chair, waiting for a short answer.
19|Jack没有再把它挪回玻璃后面。|Jack did not move it behind the glass again.
20|供电记录在凌晨中断。|The power record stopped before dawn.
21|夹子下面还有两人的笔迹。|Both sets of marks remained under the clip.
22|维护单最后一栏没填。|The last maintenance box was empty.
23|碗底的小记号还没有磨掉。|The small mark underneath the bowl had not worn away.
24|屋里终于没有风扇声了。|At last the fan was quiet.`,
 last_creature:`2|接通供氧以后，Jack的手仍搭在断开的线路上。|After oxygen returned, Jack's hand remained on the disconnected line.
3|它靠近椅子，先碰了碰他的袖口。|It approached the chair and touched his cuff first.
4|监测器还在数它的呼吸。|The monitor still counted its breaths.
5|它等到指示灯变绿，也没有听见Jack答应。|The indicator turned green without an answer from Jack.
6|它没有拔掉那条线路。|It left the line connected.
7|供氧管旁边放着一把用错尺寸的扳手。|A wrong-sized wrench lay beside the oxygen pipe.
8|它解开红线，把它重新系在包带上。|It untied the red thread and tied it onto the bag strap.
9|他的杯子还有水。它没倒掉。|There was water in his cup. It left it there.
10|房间变亮的时候，椅子还是那个位置。|When the room brightened, the chair had not moved.
11|它从椅背后绕过去，轻轻扶住椅子。|It went behind the chair and steadied it gently.
12|终端弹出维修提醒，没有人去按确认。|The terminal asked for maintenance. Nobody confirmed it.
13|它在椅子边睡了一次很短的觉。|It slept briefly beside the chair.
14|醒来后，它又等了一会。|After waking, it waited again.
18|架子空出一个碗的位置。|One bowl's place on the rack was empty.
19|另一把钥匙被它放回抽屉里。|It returned the other key to the drawer.
20|走到门外以后，它又回头看了一次椅子。|Outside, it looked back at the chair once more.
21|它没有把那一眼写进供氧记录。|It did not put that look into the oxygen record.
22|后来的手写日期隔了很久。|The next handwritten date was much later.
23|有一行只记着新的水源。|One line recorded only a new water source.
24|没有人续写原来的维护单。|Nobody continued the old maintenance sheet.
25|包里的杯子在走路时碰响。|The cup rattled in the bag as it walked.
26|它把声音压住，继续向前。|It muffled the sound and went on.`,
 betrayal:`2|Jack把维护卡重新贴了一次。|Jack tried the maintenance card again.
3|门后的读卡器只亮了一瞬。|The reader behind the door lit for an instant.
4|他听得见自己的鞋底挪动。|He could hear his soles shifting.
5|把灯留着。|Leave the light on.
6|外面没有答应。|There was no answer outside.
7|Jack翻过维护单，背面还留着旧口令。|Jack turned the sheet over. The old password was on its back.
8|红线掉在隔离缝里，伸手够不到。|The red thread lay in the isolation gap, out of reach.
9|先别关。|Not yet.
10|玻璃反射出他举起的那只手。|The glass reflected his raised hand.
11|外面的影子站得很近，却没有碰开关。|The shadow outside stood close without touching the switch.
12|Jack慢慢把手放下。|Jack slowly lowered his hand.
16|外面的椅子被推回桌下。|The chair outside was pushed under the desk.
17|供氧的灯从绿色变成了黄色。|The oxygen light turned from green to amber.
18|架子上的碗没有被拿走。|The bowl stayed on the rack.
19|备用卡被折断后留在读卡器旁。|The spare card was broken and left by the reader.
20|很久以后，它重新擦了一遍那张椅子。|Much later, it wiped the chair again.
21|没人再坐进去。|Nobody sat in it again.
22|它继续记下灯亮的时间。|It kept recording when the light came on.
23|那些时间之间没有写原因。|No reason appeared between those times.
24|最后一条授权记录来自外侧。|The last authorization record came from outside.
25|名字没有被删掉。|The name had not been deleted.
26|它没有得到一个回答。|It received no answer.`,
 collapse:`2|还得让它先出去。|It still has to get out first.
3|天花板掉下一层很薄的灰。|A thin layer of dust fell from the ceiling.
4|Jack试着撑起身体，手掌滑了一下。|Jack tried to rise; his palm slipped.
7|他听见它向他挪过来的声音。|He heard it moving closer.
8|旧包就在出口旁边。|The old bag was beside the exit.
9|红线挂在包扣上，没有系紧。|The red thread hung loose from the buckle.
10|灯在它那边。|The light is on its side.
11|灯罩落下来，滚到了两人之间。|The shade fell and rolled between them.
12|Jack把包推到另一侧。|Jack pushed the bag across.
17|地面上的风把灰吹回入口。|Wind on the surface blew dust back toward the entrance.
18|它试着拨开落在包上的灰。|It brushed dust off the bag.
19|底下的门再没有响。|The door below made no more sound.
20|它握着包带，等太阳越过那块墙。|It held the strap and waited for the sun to clear the wall.
21|被压住的备用钥匙留在下面。|The trapped spare key stayed below.
22|它把外套折好，放进了包里。|It folded the coat into the bag.
23|走之前，它又检查了一遍入口。|Before leaving it checked the entrance again.
24|后来有人在地图上标记了这处塌方。|Later someone marked the collapse on a map.
25|没有记录能说明它在那里等了多久。|No record said how long it had waited.
26|标记旁边没有写实验编号。|No specimen number appeared beside the mark.
27|它仍记得扳手掉下去的那声响。|It still remembered the falling wrench.
28|新一天的路从废墟外面开始。|The next day's road began outside the ruin.`};
 for(const [key,raw]of Object.entries(endings)){const n=D.nodes.find(n=>n.id==='p6_ending_'+key);for(const row of raw.split('\n')){const [i,zh,en]=row.split('|'),b=n.lines[Number(i)];b.text=X.tr(zh,en);if(key==='last_creature'&&b.speaker==='player'){b.speaker='narrator';b.voice='narration';}}}
 const observer=D.nodes.find(n=>n.id==='p6_ending_observer');X.replace(observer.id,`N|它把Jack的杯子移到了玻璃里面。|It moved Jack's cup behind the glass.
J|你想让我坐多久？|How long do you want me to sit?
N|它看了看记录，没有给一个时间。|It checked the record without giving a time.
B|以前你也不说。|You did not say before either.
N|Jack听见开关咔哒一声，仍看着它的手。|Jack heard the switch click and kept looking at its hand.
J|……行。我先坐着。|...Fine. I will sit for now.
N|它把钥匙放在桌面，没有放到谁都能拿到的位置。|It laid the key on the table, out of easy reach.
N|坐在椅子里的人换了。水仍会按时送来。|The person in the chair had changed. Water would still arrive on time.`,{group:'ending',choices:observer.choices,narrativeLayer:'CORE STORY',emotionalIntensity:4});
 const betrayal=D.nodes.find(n=>n.id==='p6_ending_betrayal');betrayal.hostLines=X.lines(`N|它先把Jack的手拉到身边，像很多次换药时那样。|It first drew Jack's hand close, as during many changes of dressing.
J|你想说什么？|What do you want to say?
B|你知道。|You know.
N|Jack停了一下。他知道的不是它正在等的那个答案。|Jack paused. What he knew was not the answer it awaited.
N|它说出了一个旧名字。Jack没有应声。|It spoke an old name. Jack did not answer.
J|我不是那个人。|I am not that person.
N|它把额头靠近他的手。那一下太熟悉，Jack没有马上躲开。|It brought its forehead to his hand. The gesture was familiar enough that Jack did not pull away immediately.
N|随后，屋里只剩下一道呼吸声。|Afterwards, only one breath remained in the room.
N|它仍扶着他的手，等那个名字被回答。|It still held his hand, waiting for the name to be answered.
B|……Jack？|...Jack?
N|没有东西因此复原。|Nothing had been restored.
N|它把已经冷掉的水换了一次，没有人喝。|It replaced the cold water once. Nobody drank it.
N|记录上那一行旧名字，被写了又划掉。|The old name in the record was written and crossed out.
N|Jack的杯子留在椅子旁边。|Jack's cup stayed beside the chair.`);
})();
