'use strict';
// Authored bilingual character scenes; they never change sandbox resources.
Abyss.StoryLife=(()=>{
 const raw=`1|soup|失败的汤|Failed soup
N|锅底冒出一圈黑泡。Jack把火关了。|Black bubbles rose from the pot. Jack turned off the heat.
J|……这锅不能吃。|...We cannot eat this batch.
B|咕。|Guh.
N|它把空碗推远了。Jack另拆了一包饼干。|It pushed the empty bowl away. Jack opened some crackers.

1|heater|暖气|The heater
N|暖气只有左边两节是热的。|Only two sections of the heater were warm.
J|挪这边。别贴着管子。|Move over here. Stay off the pipe.
B|……|...
N|Jack在地上铺了折起来的旧毛巾。它先摸了摸。|Jack folded an old towel onto the floor. It touched it first.

2|cup|缺口杯子|The chipped cup
N|两个杯子里，只有一个没有缺口。|Only one of the two cups was unchipped.
J|行。好的给你。|Fine. You get the good one.
B|嗯。|Mm.
N|它把另一个杯子推回Jack手边，没有碰他的手。|It pushed the other cup back to Jack without touching his hand.

2|laundry|洗衣日|Laundry day
N|一只袖子滴下的水重新浸湿了Jack的鞋。|Water from a sleeve soaked Jack's shoe again.
J|夹子。红的那个。|The peg. The red one.
B|……？|...?
N|它把所有夹子都搬了过来。Jack找了两分钟才拿到红色的。|It brought every peg. Jack took two minutes to find the red one.

3|music|旧收音机|The old radio
N|调频旋钮很松。歌声夹在两道噪声之间。|The tuning knob was loose. A song sat between two bands of static.
J|不是有人在里面。是录下来的。|There is nobody inside. It is a recording.
B|再。|Again.
N|Jack记住了旋钮的位置，在旁边画了一个很小的点。|Jack marked the knob's position with a tiny dot.

3|cards|牌背|Card backs
N|Jack摊开五张牌。它先把牌全翻了过来。|Jack laid down five cards. It turned them all over first.
J|还不能看。背面先朝上。|Not yet. Backs face up first.
B|藏？|Hide?
N|Jack把自己的牌也扣下了。它这才放开爪尖。|Jack turned his own cards down. Only then did it lift its claw.

4|rain|接雨的桶|The rain bucket
N|天花板漏水。第一个桶太矮，水一直溅到外面。|The ceiling leaked. The first bucket was too shallow.
J|大的在柜子后面。|The big one is behind the cabinet.
B|这里，也下雨。|Rain here too.
N|换了桶以后，两个人都没有立刻走。|After changing buckets, neither left immediately.

4|roadsign|路牌|The road sign
N|旧路牌少了一半字母。Jack蹲着把剩下的念完。|Half the letters were missing. Jack crouched and read the rest.
J|不是所有空着的地方都能猜出来。|We cannot guess every missing bit.
B|那留空。|Leave it blank.
N|它在纸上画了一个空框。|It drew an empty box on the paper.

5|car|卡住的螺丝|The stuck bolt
N|扳手滑了两次。Jack把另一只手缩了回去。|The wrench slipped twice. Jack drew his other hand back.
J|等一下。这个得换角度。|Wait. This needs a different angle.
B|你，也不会？|You cannot do it either?
N|Jack点头。它把灯举得更近了一点。|Jack nodded. It held the lamp closer.

5|tools|少一把钳子|One missing plier
N|工具盘里空了一个位置。钳子在它的垫子下面。|There was a gap in the tray. The pliers were under its mat.
J|用完放回这里。不是另一边。|Put it back here afterwards. Not over there.
B|这里。|Here.
N|它用爪尖绕着那个位置画了一圈。|It traced a circle around the empty place.

6|shirt|晾干的衣服|A dry shirt
N|Jack拿来两件衣服。它把灰色的留在面前。|Jack brought two shirts. It kept the grey one in front of it.
J|这件干了。另一件还有点潮。|This one is dry. The other is still damp.
B|灰的。|Grey.
N|Jack把另一件重新挂了回去。|Jack hung the other one back up.

6|tv|坏电视|The broken television
N|屏幕里只有一条白线。Jack敲了一下外壳。|There was one white line on the screen. Jack tapped the case.
J|我知道。敲它也没用。|I know. Tapping it will not help.
B|那别敲。|Then stop tapping.
N|Jack收回了手。两个人继续看那条白线。|Jack withdrew his hand. They kept looking at the line.

7|water|半夜的水|Water at night
N|杯子碰到桌沿，Jack被那一声惊醒。|A cup hit the table edge and woke Jack.
J|灯在你右边。慢点。|The light is to your right. Slowly.
B|我知道。|I know.
N|它把杯子扶稳，没有等Jack走过来。|It steadied the cup without waiting for Jack.

7|room|重新摆放|Rearranging
N|它把垫子拖到远离出风口的位置。|It dragged its mat away from the vent.
J|柜子挡住了。我挪柜子。|The cabinet blocks it. I will move that.
B|我放这里。|I am putting this here.
N|Jack先把杯子拿下来，再推柜子。|Jack took the cups down before moving the cabinet.

8|cold|Jack感冒了|Jack has a cold
N|Jack擤鼻子的纸堆在袋子里。袋口没扎好。|Jack's used tissues piled in an untied bag.
J|别碰。传给你怎么办。|Do not touch. What if you catch it?
B|我把袋子拿远。|I will move the bag away.
N|Jack递给它一根长柄夹子。|Jack handed it a long-handled grabber.

8|bread|藏起来的面包|Hidden bread
N|半块面包从垫子里掉了出来，已经硬了。|Half a loaf fell from the mat. It was already hard.
J|下次包起来。会干。|Wrap it next time. It dries out.
B|我留到晚上。|I saved it for tonight.
N|Jack拿来一只干净的盒子，没有把面包拿走。|Jack brought a clean box and left the bread there.

9|blackout|手电筒|The flashlight
N|停电后，手电筒只照到一双鞋和半张桌子。|After the blackout, the flashlight lit two shoes and half a table.
J|电池还有。先别晃它。|There is some battery left. Stop shaking it.
B|我没有晃。是你。|I am not shaking it. You are.
N|Jack换了一只手拿。|Jack switched hands.

9|game|输了也不重来|No restart after losing
N|最后一张牌落在桌上。Jack数错了点数。|The last card landed. Jack had counted wrong.
J|算你赢。不是让你。|You win. I am not letting you.
B|我知道你输了。|I know you lost.
N|它把牌叠好，最上面那张朝着Jack。|It stacked the cards with the top card facing Jack.

10|video|旧录像|An old tape
N|录像里有人把蛋糕掉到了地上。声音比画面慢一拍。|Someone dropped a cake in the recording. Sound lagged behind the picture.
J|这个人是我。别笑。|That is me. Do not laugh.
B|先别关。我想看完。|Do not stop it yet. I want to finish.
N|Jack把手从停止键上挪开。|Jack moved his hand off the stop button.

10|kettle|忘记的水壶|The forgotten kettle
N|水壶烧干了。底下的圆印又多了一层。|The kettle boiled dry. The ring underneath gained another layer.
J|又忘了。把开关拔掉。|Forgot again. Unplug it.
B|你等下要再买一个？|Will you buy another later?
N|Jack看看旧壶，开始找螺丝刀。|Jack looked at the old kettle and found a screwdriver.

11|snow|第一块雪|The first snow
N|窗外落下一小块雪，粘在玻璃上。|A little snow stuck to the outside of the glass.
J|等着。我拿个碟子。|Wait. I will get a plate.
B|手里很快就没了。|It disappears quickly in a hand.
N|碟子拿来时，那块雪已经化了。|By the time the plate arrived, the snow had melted.

11|petbed|错了床位|The wrong bed
N|小住户睡在Jack的外套上。他站了好一会。|A small inhabitant slept on Jack's coat. He stood for a while.
J|算了。今天穿另一件。|Fine. I will wear the other one today.
B|它选了你的。|It chose yours.
N|他把袖子从爪子底下轻轻抽出来。|He gently pulled a sleeve from under a paw.

12|breakfast|早餐值班|Breakfast duty
N|它把三个碗排成一条线，Jack只找到两把勺子。|It lined up three bowls. Jack found only two spoons.
J|第三个用这个。别放热锅里。|Use this for the third. Keep it out of the hot pan.
B|这个太长。|This is too long.
N|Jack拿了一把短柄的。|Jack found one with a shorter handle.

13|window|擦窗|Cleaning the window
N|擦干净一边，另一边仍然灰蒙蒙的。|One side was clean. The other was still grey.
J|外面也得擦。今天够不到。|The outside needs cleaning too. Cannot reach it today.
B|先看这一边。|Let us look through this side first.
N|两个人挪到了干净的那块玻璃前。|They moved to the clean part of the pane.

14|boots|鞋里的石子|A stone in a boot
N|Jack把鞋脱下来，倒出一颗很小的石子。|Jack took off his boot and tipped out a tiny stone.
J|就这玩意。疼一路。|This little thing. Hurt all the way.
B|你刚才不肯停。|You would not stop earlier.
N|Jack坐下来，把另一只鞋也检查了。|Jack sat down and checked the other boot too.

15|blanket|太短的毯子|A short blanket
N|毯子盖住肩膀，就露出脚。Jack把旧外套接在末端。|The blanket covered shoulders or feet. Jack added a coat at the end.
J|明天缝一块。今晚先这样。|I will sew on a piece tomorrow. This will do tonight.
B|针别放床上。|Do not leave the needle on the bed.
N|Jack把针放回了盒子，关上盖子。|Jack put the needle back and closed the box.

16|battery|两节电池|Two batteries
N|电池滚到桌下。Jack趴下来，只拿到一节。|Batteries rolled under the table. Jack reached one.
J|另一节在你那边。|The other is on your side.
B|等一下。我够不到。|Wait. I cannot reach it.
N|Jack找来扫帚，两个人从两头慢慢把它推出来。|Jack found a broom. They pushed it out from opposite ends.

17|hair|剪线头|Trimming a loose thread
N|袖口拖着一根很长的线。Jack把剪刀递过来。|A long thread hung from the cuff. Jack offered scissors.
J|别拉。拉了会全散。|Do not pull. It will unravel.
B|我想留短一点。|I want to leave a short piece.
N|它剪完以后，把剪刀放回同一个位置。|After cutting, it returned the scissors to the same place.

18|packing|少放一点|Pack less
N|包扣不上。Jack拿出了一件备用外套。|The bag would not close. Jack removed a spare coat.
J|够了。真冷再想办法。|Enough. We will deal with real cold later.
B|你总怕少一样。|You always fear leaving something out.
N|Jack没有把那件外套放回去。|Jack left the coat out.

19|dish|最后一个碗|The last bowl
N|水槽里剩下一个碗。谁都说不是自己用的。|One bowl remained in the sink. Both denied using it.
J|行。我洗。下次轮你。|Fine. I will wash it. Your turn next time.
B|下次你记得说。|Remember to tell me next time.
N|Jack把碗放到架子上。它把歪掉的毛巾摆正。|Jack put the bowl on the rack. It straightened the towel.`;
 const scenes=raw.split(/\n\n/).map(block=>{const rows=block.split('\n'),[chapter,key,title,enTitle]=rows.shift().split('|');const id='life_'+key,node=Abyss.JackData.replace(id,rows.join('\n'),{group:'character',priority:130,once:true,choices:[],title:Abyss.JackData.tr(title,enTitle),requirements:{},emotionalIntensity:Number(chapter)<9?1:0,narrativeLayer:'CHARACTER SCENES'});node.lifeChapter=Number(chapter);if(key==='petbed'){node.lines[0].variants=[{requirements:{'pets.length':{max:0}},text:Abyss.JackData.tr('它把Jack的外套垫在了头下。Jack站了好一会。','It had rested its head on Jack’s coat. Jack stood for a while.')}];node.lines[2].variants=[{requirements:{'pets.length':{max:0}},text:Abyss.JackData.tr('我还没起来。','I have not got up yet.')}];}for(const b of node.lines)b.minLanguage=0;return {id,chapter:Number(chapter)};});
 function schedule(s,chapter){if(s.campaign.creatureAlive===false)return;for(const item of scenes.filter(x=>x.chapter===chapter&&!s.narrative.seen[x.id]))Abyss.Narrative.enqueue(s,item.id);}
 return {scenes,schedule};
})();
