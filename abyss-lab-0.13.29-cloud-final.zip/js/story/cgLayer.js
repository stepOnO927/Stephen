'use strict';
// Presentation only: two image layers preserve the old frame during a true crossfade.
Abyss.StoryCGLayer=(()=>{
 let root,image,previous,clearTimer;
 function bind(el){root=el;image=root.querySelector('#story-cg');previous=root.querySelector('#story-cg-previous');}
 function render(s,frame){
  const art=Abyss.StoryCG.assets[frame.cg];root.dataset.cg=frame.cg||'';root.dataset.cgMotion=String(s.settings.motion);
  if(!art){clearTimeout(clearTimer);image.hidden=previous.hidden=true;image.removeAttribute('src');previous.removeAttribute('src');image.dataset.cg='';return;}
  if(image.dataset.cg!==art.id){
   clearTimeout(clearTimer);const cross=!image.hidden&&image.dataset.cg&&art.transition==='crossfade';
   previous.hidden=!cross;
   if(cross){previous.src=image.src;previous.style.objectPosition=image.style.objectPosition;previous.style.transformOrigin=image.style.transformOrigin;previous.style.transform=getComputedStyle(image).transform;previous.className='';}
   image.className='';image.src=art.src;image.dataset.cg=art.id;image.style.objectPosition=art.focusX+'% '+art.focusY+'%';image.hidden=false;
   const motion=art.motion||{};image.style.transformOrigin=(motion.originX??50)+'% '+(motion.originY??50)+'%';image.style.setProperty('--cg-scale',motion.scale||1);image.style.setProperty('--cg-x',(motion.x||0)+'px');image.style.setProperty('--cg-y',(motion.y||0)+'px');image.style.setProperty('--cg-motion-time',(motion.duration||8000)+'ms');
   const duration=s.settings.motion?art.duration:0;image.style.setProperty('--cg-fade-time',duration+'ms');previous.style.setProperty('--cg-fade-time',duration+'ms');
   root.dataset.cgMotion=String(s.settings.motion);void image.offsetWidth;
   image.className='vn-cg-enter';if(cross){void previous.offsetWidth;previous.className='vn-cg-exit';clearTimer=setTimeout(()=>{previous.hidden=true;previous.removeAttribute('src');},duration);}
   Abyss.StoryBook.unlock(art.id);
  }
 }
 return {bind,render};
})();
