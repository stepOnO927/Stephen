'use strict';
(()=>{
 const X=Abyss.JackData,P=Abyss.Phase6Data;
 const ending={id:'preemptive_silence',name:X.tr('预先的沉默','PREEMPTIVE SILENCE'),text:X.tr('桌上没有写下危险被证明的那一天。','No date on the desk proves the danger would have happened.'),item:null,skin:'ashen',hidden:true,playerDeath:false,creatureDeath:true};P.endings.push(ending);X.expandedEndings.push(ending.id);
 X.replace('p6_ending_preemptive_silence',`N|Jack看完了记录，又把最后一页翻回去。|Jack read the record, then turned back to the last page.
N|那一页没有新证据。|There was no new evidence on that page.
J|也许我看对了。|Maybe I saw it correctly.
N|它停在离他很近的地方，没有替他证明这句话。|It stopped close to him without proving that sentence for him.
N|Jack没有再延后那个决定。|Jack did not postpone the decision again.
N|后来，培养舱里没有了呼吸声。|Later, there was no breath in the chamber.
N|他把原来的碗留下，没有把它写成预防成功的证据。|He left the old bowl without calling it evidence of successful prevention.
J|……也许。|...Maybe.
N|走廊里有人开了灯。他没有过去。|Someone turned on a corridor light. He did not go there.
N|记录最后一栏仍然是空的。|The last box in the record stayed empty.`,{group:'ending',title:ending.name,choices:[X.C('memorial','保留尚未得到的答案','Keep the answer that never came',{jackEndComplete:true,campaignFlag:'memorial'})],narrativeLayer:'CORE STORY',emotionalIntensity:4});
 const achievement={id:'narrative_saw_it',name:'I SAW IT COMING',desc:X.tr('你是对的。大概。','You were right. Probably.'),category:'STORY',rules:{'campaign.ending':'preemptive_silence'},secret:true};P.achievements.push(achievement);Abyss.Data.achievements.push(achievement);
 Abyss.StoryRoutes.rules.unshift({decision:'continue',ending:'betrayal',priority:110,when:(s,v,f)=>f.HOST_TRIGGER&&v.HOST_ROUTE_INSTABILITY>=15&&v.FALSE_ENEMY_PROJECTION>=16});
})();
