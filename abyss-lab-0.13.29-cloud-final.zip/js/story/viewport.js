'use strict';
// Safari can expose prefixed fullscreen methods or no fullscreen at all.
// Use the document so sibling native dialogs remain part of the fullscreen tree.
Abyss.StoryViewport=(()=>{
 let root,notify,pageFull=false,pending=false;
 const current=()=>document.fullscreenElement||document.webkitFullscreenElement;
 function sync(){if(!root)return;const v=window.visualViewport;root.style.setProperty('--story-height',(v?.height||innerHeight)+'px');root.style.setProperty('--story-width',(v?.width||innerWidth)+'px');root.style.setProperty('--story-top',(v?.offsetTop||0)+'px');root.style.setProperty('--story-left',(v?.offsetLeft||0)+'px');root.dataset.fullscreen=current()?'native':pageFull?'page':'window';document.querySelectorAll('[data-vn="fullscreen"]').forEach(b=>{b.setAttribute('aria-pressed',String(!!current()||pageFull));b.setAttribute('aria-label',Abyss.I18n.language()==='en'?'Toggle fullscreen':'切换全屏');});}
 function fallback(){pending=false;pageFull=true;sync();notify(Abyss.I18n.language()==='en'?'The story fills the available screen. Safari may keep its browser bar; Add to Home Screen for standalone display.':'已铺满可用屏幕。Safari可能保留地址栏；从“添加到主屏幕”启动可使用独立显示。');}
 async function toggle(){
  if(pending)return;
  if(current()){try{const exit=document.fullscreenElement?document.exitFullscreen:(document.webkitExitFullscreen||document.exitFullscreen);if(exit)await Promise.resolve(exit.call(document));}catch{}pageFull=false;sync();return;}
  if(pageFull){pageFull=false;sync();return;}
  const target=document.documentElement,request=document.fullscreenEnabled!==false&&target.requestFullscreen?target.requestFullscreen:(target.webkitRequestFullscreen||target.requestFullscreen);
  if(!request||document.fullscreenEnabled===false&&!target.webkitRequestFullscreen){fallback();return;}
  pending=true;try{await Promise.resolve(request.call(target));if(current()){pending=false;sync();}else setTimeout(()=>{if(current()){pending=false;sync();}else if(pending)fallback();},500);}catch{fallback();}
 }
 function bind(el,feedback){root=el;notify=feedback;for(const name of ['resize','orientationchange'])window.addEventListener(name,sync);window.visualViewport?.addEventListener('resize',sync);window.visualViewport?.addEventListener('scroll',sync);for(const name of ['fullscreenchange','webkitfullscreenchange'])document.addEventListener(name,()=>{pending=false;pageFull=false;sync();});document.addEventListener('abyss:language',sync);sync();}
 return {bind,toggle,sync};
})();
