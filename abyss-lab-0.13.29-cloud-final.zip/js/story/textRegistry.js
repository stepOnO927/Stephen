'use strict';
Abyss.StoryTexts=(()=>{
 const entries={},register=(id,zh,en,layer)=>entries[id]={id,zh,en:en||Abyss.JackData.english[zh]||Abyss.EnglishCatalog?.[zh]||Abyss.HomeData.english[zh]||zh,layer};
 // Solo investigation retains the subject of each scene without speaking for the absent creature.
 for(const node of Abyss.NarrativeData.nodes)if(node.soloLines?.length===2&&node.soloLines[0].text==='Jack 独自读完这份记录。旁边的椅子没有回答。'){
 const title=node.title||node.id,meta=Abyss.StoryChapters.chapters.find(c=>c.id===(node.chapter||node.chapterMetadata));
 node.soloLines[0].text=Abyss.JackData.tr('Jack把“'+title+'”的记录移到灯下。桌边只剩他自己的脚步声。','Jack moved the record “'+(Abyss.JackData.english[title]||Abyss.EnglishCatalog?.[title]||title)+'” under the lamp. Only his footsteps remained by the desk.');
 node.soloLines[1].text=Abyss.JackData.tr(meta?'这份记录留下的问题是：'+meta.newInformation+'。Jack没有再把空椅子写成见证者。':'他在“'+title+'”下面留下空白，没有替不在这里的它补一句回答。',meta?'This record raises a question in '+(Abyss.JackData.english[title]||Abyss.EnglishCatalog?.[title]||title)+'. Jack did not list the empty chair as a witness.':'He left a blank below “'+(Abyss.JackData.english[title]||Abyss.EnglishCatalog?.[title]||title)+'” rather than invent an answer from the absent creature.');
 }
 for(const node of Abyss.NarrativeData.nodes){node.narrativeLayer||=['project','project_response','ending','secret','major'].includes(node.group)?'CORE STORY':['character','jack_daily','care','relationship'].includes(node.group)?'CHARACTER SCENES':'AMBIENT WORLD';const prefix=node.narrativeLayer==='CORE STORY'?'STORY':node.narrativeLayer==='CHARACTER SCENES'?'CHAR':'AMBIENT';for(const [collection,beats]of Object.entries({lines:node.lines||[],soloLines:node.soloLines||[],hostLines:node.hostLines||[]}))for(const [i,b]of beats.entries()){const id=b.approvedTextId||prefix+'_'+node.id.toUpperCase()+(collection==='lines'?'_':'_'+collection.toUpperCase()+'_')+String(i).padStart(3,'0'),text=b.text;register(id,text,Abyss.JackData.english[text],node.narrativeLayer);b.textId=id;Object.defineProperty(b,'text',{get:()=>entries[id].zh,set:v=>{entries[id].zh=v;},enumerable:true,configurable:true});}for(const [i,b]of (node.lines||[]).entries()){
 for(const [key,value]of Object.entries(b.language||{})){const id=prefix+'_'+node.id.toUpperCase()+'_'+String(i).padStart(3,'0')+'_LANG_'+key.toUpperCase();register(id,value,null,node.narrativeLayer);}
 for(const [v,variant]of (b.variants||[]).entries()){const id=prefix+'_'+node.id.toUpperCase()+'_'+String(i).padStart(3,'0')+'_VAR_'+v;register(id,variant.text,null,node.narrativeLayer);variant.textId=id;}
 }
 for(const choice of node.choices||[]){choice.textId=prefix+'_'+node.id.toUpperCase()+'_CHOICE_'+choice.id.toUpperCase();register(choice.textId,choice.label,null,node.narrativeLayer);}
 node.textId=prefix+'_'+node.id.toUpperCase()+'_ROOT';register(node.textId,node.text,Abyss.JackData.english[node.text],node.narrativeLayer);}
 Abyss.I18n.register(Abyss.JackData.english);Abyss.JackData.beatIds=Abyss.NarrativeData.nodes.filter(n=>n.jackScene).flatMap(n=>n.lines.map((b,i)=>n.id+':'+i));const raw=id=>entries[id]?.zh||'',get=(id,lang=Abyss.I18n.language())=>lang==='en'?entries[id]?.en||raw(id):raw(id);
 return {entries,raw,get,register};
})();
