'use strict';
// Slot-local tailoring. Theme determines construction, not merely a different color.
Abyss.Couture=(()=>{
 const M=Abyss.ArtMaterials,P=M.path,L=M.line,C=M.circle,R=M.rect;
 const seam=(d,m)=>P(d,'none',`stroke="${m.light}" stroke-width="1" stroke-dasharray="2 3" opacity=".7"`);
 const jewel=(x,y,m)=>P(`m${x} ${y-9} 7 9-7 10-7-10z`,m.glass)+L(`M${x} ${y-9}v19m-7-10h14`,m.light,.8);
 const buckle=(x,y,m)=>R(x-9,y-7,18,14,3,m.metal)+R(x-5,y-3,10,6,1,m.dark)+L(`M${x-5} ${y}h11`,m.light,1);
 const chain=(x,y,count,m)=>Array.from({length:count},(_,i)=>`<ellipse cx="${x+i*9}" cy="${y+Math.sin(i/(count-1)*Math.PI)*9}" rx="6" ry="3.5" fill="none" stroke="${m.metal}" stroke-width="2"/>`).join('');
 const body=(i,m)=>[
 P('M-49-43-20-35-9-10 2-32 38-46 62-19 58 43 13 50 0 24-14 50-62 38-61-21z',m.fill)+P('m-42-31 11 74 11-3-9-72zm67-2-5 78 12-2 5-82z',m.light)+L('M-59 14h116',m.light,8)+R(-50,-8,22,16,2,m.dark)+R(25,20,22,16,2,m.dark),
 P('m-49-47-22 24-5 43 23 6 8 25 94-1 4-28 23-6-11-43-34-22-39 22z',m.fill)+P('m-42-40 28 6 14 23 14-23 29-6-24 35H-20z',m.dark)+R(-37,-4,26,20,3,m.dark)+R(14,-4,25,21,3,m.dark)+seam('M-40 32h80M0-10v49',m)+R(23,25,26,14,2,'#9b8870')+M.rivets([[0,0],[0,15],[0,31]],m),
 P('m-49-49 32 11 17 29 18-29 34-11 20 32-11 33-16-5-3 46-39 5-3-53-3 53-40-5-5-46-18 6-11-35z',m.fill)+L('M-17-38 0-9 18-38M0-9v62',m.light,6)+Array.from({length:7},(_,j)=>seam(`M${-41+j*13} -2q-5 10 0 18t0 22`,m)).join('')+R(-38,20,22,23,4,m.dark)+R(17,20,22,23,4,m.dark),
 P('m-44-45 25 6 19 18 19-18 25-6 23 25-13 24-10-4 7 58-49 0-2-50-2 50h-50l8-58-13 5-12-24z',m.light)+P('m-21-38 21 17-16 14-17-26m54-5L0-21 16-7l17-26',m.fill)+L('M0-18v72',m.dark,2)+R(-36,14,24,20,2,m.fill)+R(19,-11,20,15,2,m.fill)+L('M24-8v9m5-9v9',m.dark,2)+M.rivets([[5,2],[5,19],[5,37]],m),
 P('m-51-47 29 6 22 22 27-22 25-2 16 32-10 34-19-3 8 28-41 10-12-21-11 21-44-7 6-31-18 3-10-30z',m.dark)+P('m-22-40 22 21-21 17-18-27m66-11L0-19 18 3l24-35',m.fill)+L('M0-16-12 52',m.metal,3)+R(-45,13,23,17,2,m.fill)+R(20,12,25,19,1,'#baad8c')+M.rivets([[-49,-30],[-42,-22],[42,-27],[47,-17]],m)+chain(13,36,5,m),
 P('M-35-41q35-24 70 0l-8 31 31 56q-61 23-116 0l31-56z',m.fill)+L('M-30-36q30-17 60 0M-46 47q47 12 91 0',m.metal,3)+R(-26,4,52,27,5,m.dark)+seam('M-23 8h46v19h-46z',m)+buckle(0,-27,m),
 P('M-51-43 0-22 51-43 72 40 40 28 26 54 0 37-27 55-42 29-74 41z',m.dark)+Array.from({length:12},(_,j)=>`<g transform="translate(${-46+j%4*29} ${-25+Math.floor(j/4)*27}) rotate(${j%2?9:-7})">${P('M-13-12h25v23l-6 6h-19z',['#e8d9aa','#9fbab3','#caa3a2'][j%3])}${L('M-8-5h15m-15 6h10',m.dark,1)}</g>`).join(''),
 P('m-47-41 27 3 20 18 20-18 27-3 17 24-14 26-11-2 17 49-32-12-24 23-26-23-31 12 19-51-12 3-17-25z',m.dark)+P('m-20-38 20 18 20-18-6 37H-13z',m.light)+P('m-33-34 13-4 5 37-16-7m64-26-13-4-5 37 17-7',m.fill)+L('M0-1v35',m.metal,2)+M.rivets([[0,8],[0,20]],m)+chain(15,3,4,m),
 P('M-30-41q30-14 60 0L43 7 58 43q-58 18-116 0l14-36z',m.fill)+L('M-23-40-16-7m39-33L16-7',m.dark,6)+R(-33,3,65,28,4,m.dark)+L('M-11 4v27m22-27v27',m.light,1)+seam('M-48 42q49 13 96 0',m)+P('m10 5 2-24 10-4 4 29z',m.metal)+P('m-26 4 5-22 6 4-5 18z','#99b585'),
 P('m-46-43 26 8 20 19 22-19 27-8 18 34-15 22-14-5 10 42-32-6-16 13-25-17-32 12 6-44-17 4-7-35z',m.dark)+P('m-20-35 20 19 23-19-11 38-27-1z',m.fill)+P('m13 3 29 5-9 28-25-10z','#0a121d')+P('m13 3 29 5-9 28-6-9 7-15-21-1z',m.metal)+L('M-45 32h24m-8 5h16M20-33l12 12',m.light)+C(26,17,7,m.glass)
 ][i];
 const back=(i,m)=>[
 L('M-23-55v116m47-116v116',m.metal,6)+P('M-45-63h88v33h-88z',m.fill)+P('m-37-57 73 0v21h-73z',m.dark)+P('m-29-51 43 0-9-5 21 11-21 10 9-6h-43z',m.light)+P('m-40-18 60-13 21 24-60 14z',m.metal)+L('M-26-13l43-8',m.dark,3)+R(-31,30,59,22,4,m.dark),
 P('M-42-23h83l-9 83h-65z',m.dark)+Array.from({length:5},(_,j)=>R(-33+j*14,-44-j%2*12,11,89,5,m.metal)+L(`M${-28+j*14} -30v54`,m.light,1)).join('')+L('M-40 10h79m-76 30h73',m.fill,9)+seam('M-35 53h65',m),
 R(-40,-51,80,111,18,m.fill)+P('M-40-36q40-28 80 0v28q-40 23-80 0z',m.dark)+L('M-17-53v-11h34v11',m.metal,5)+R(-29,11,58,36,8,m.light)+R(-18,15,36,27,4,m.fill)+buckle(-23,-10,m)+buckle(23,-10,m)+seam('M-29 49h57',m),
 P('M-42-55h73v111h-73z',m.dark)+P('m31-55 18 14V69L31 56z',m.fill)+[-44,-10,24].map(y=>R(-35,y,60,29,3,m.fill)+R(-14,y+9,21,5,2,m.metal)+R(-30,y+6,10,15,1,m.light)).join(''),
 P('m-28-28 56-31v84l-56-23z',m.metal)+P('m-28-28-18 7v25l18 9z',m.dark)+`<ellipse cx="28" cy="-17" rx="19" ry="42" fill="${m.dark}"/><ellipse cx="28" cy="-17" rx="12" ry="29" fill="${m.fill}"/>`+L('M-10 18v31h26V27',m.metal,5)+R(-31,43,60,14,4,m.fill),
 R(-30,-51,60,109,8,m.dark)+P('m-30-51 17-10h52l-9 10z',m.metal)+R(-23,-44,20,94,9,m.fill)+R(4,-44,20,94,9,m.metal)+L('M-38 38V-23h17M30 37h17v-69H12',m.metal,7)+C(0,3,26,m.metal)+C(0,3,18,m.dark)+L('M0-15v36M-18 3h36',m.fill,6)+C(0,3,6,m.metal),
 P('M-42-45h18v-13h18v13H11v-13h17v13h16V55h-86z',m.fill)+P('m44-45 16 13v77L44 55z',m.dark)+P('M-28 55V20q15-27 31 0v35z',m.dark)+R(13,-20,15,22,2,m.light)+L('M-38-5h39m-28 7h65M-30 41h-8m48 0h25',m.light)+seam('M-39 51h24',m),
 P('M0 56-59-30q58-62 118 0z',m.fill)+Array.from({length:9},(_,j)=>L(`M0 56 ${-56+j*14} ${-32-Math.sin(j/8*Math.PI)*20}`,m.metal,1.7)).join('')+P('M-52-20q53-52 104 0l-10 15q-42-39-84 0z',m.light)+C(0,53,5,m.metal),
 P('m-39 8 79 0-13 50h-54z',m.fill)+P('M-42 0h86v13h-86z',m.metal)+P('M-31 1q-8-20 22-34-2-38 20-43 29 14 4 46 31-8 27 8z','#6d947b')+L('M0 2v-56M0-14l-18-17m18 7 22-13',m.light,2)+L('M-24 25l4 22m16-23v25m18-25-4 24',m.dark,2),
 P('M-48-49h79v80h-79z',m.dark)+P('m31-49 26 17v75L31 31z',m.fill)+P('m-48-49 21-14h69l-11 14z',m.metal)+R(-41,-42,64,56,9,m.glass)+L('M-35-32h49m-49 7h49m-49 7h49m-49 7h49m-49 7h49','#97b8ab44',1)+P('m-24-20 12-8 8 8-8 9z',m.light)+R(-36,22,44,5,2,m.metal)+C(20,25,4,m.metal)+L('M-9 44v13h34',m.metal,4)
 ][i];
 const weapon=(i,m)=>[
 L('M0-67v124',m.dark,7)+P('M-27-67h53v24h-53z',m.fill)+P('m-18-58 24 0-7-5 16 9-16 8 7-5h-24z',m.light)+R(-5,14,10,29,2,m.metal),
 P('m0-62 15-9-5 87-9 10-9-9z',m.metal)+L('M5-52 2 14',m.light,1)+P('M-20 17h40l-3 8H-17z',m.fill)+R(-5,26,10,30,2,m.dark)+seam('M-4 30h8m-8 6h8m-8 6h8m-8 6h8',m),
 L('M0 57V-28',m.fill,9)+L('M0-28-23-59m23 31 25-32',m.metal,7)+P('m-23-59-10 4 10-19 5 19zm48-1-10 1 16-14-1 20z',m.metal),
 R(-6,-51,12,105,3,m.fill)+P('m-6-51 6-21 6 21z',m.metal)+R(-9,-34,18,29,3,m.glass)+L('M-3-29v18',m.light,1)+L('M-6 26h12m-12 5h12m-12 5h12',m.dark,2),
 P('M-6 50-13-21 8-65 17-48 7-20 6 50z',m.dark)+L('M-8-19 10-58m-20 51 23-36',m.metal,3)+L('M-4-12 7-41M-3-3 12-26',m.light,1)+R(-7,22,14,28,3,m.fill),
 L('M0 56V-30',m.fill,8)+P('M-30-69h60l-4 39-26 19-26-19z',m.metal)+P('M-21-63h42l-4 29-17 13-17-13z',m.dark)+L('M0-58v30',m.light,2)+L('M-10 45v-9h20v9',m.metal,5),
 R(-5,-27,10,83,4,m.fill)+R(-41,-55,82,36,15,m.fill)+P('M-26-55h10v36h-10zm38 0h10v36H12z',m.light)+L('M-34-44h15m9 0h19',m.light,2),
 L('M0 56V-42',m.dark,7)+C(0,-49,13,m.metal)+C(0,-49,7,m.glass)+L('M-5-29H5M-5 34H5',m.metal,6)+chain(3,-37,4,m),
 L('M0 55V-47',m.fill,8)+P('m-3-51 39-9 4 15-36 7-12 29-12-5z',m.metal)+L('M13-49l19-4',m.light,2)+seam('M-4 24h8m-8 6h8m-8 6h8',m),
 P('M-16-41q-5-37 26-30 34 14 2 44v16H-3v-23q30-24 6-28-12-1-12 20z',m.metal)+P('M-4-4H9v10H-4z',m.glass)+L('M3 14V53',m.dark,8)+R(-5,39,16,10,2,m.fill)
 ][i];
 const tail=(i,m)=>[
 P('m-25-9 15-16h26l12 17-5 21h-45z',m.metal)+P('m-14-10 9-10h17l10 12-8 10H-9z',m.dark)+M.rivets([[-18,4],[20,4]],m),
 ` <ellipse rx="25" ry="15" fill="${m.metal}"/><ellipse cy="-3" rx="17" ry="8" fill="${m.dark}"/>`+P('m-5 12 20 0 4 25-25-1z',m.fill)+L('M0 20h11m-11 5h11',m.light),
 P('M-26-19h40v26q36 4 24 24-11 11-40-3l-18-8z',m.fill)+L('M-23-13H12',m.light,8)+seam('M-22 2h35m-33 7h35m-24 9h32',m)+P('M25 12q23 5 10 16-13 2-18-6z',m.light),
 P('M-24-14h43v20h-43z',m.dark)+P('m-5 4 29 8-9 28-28-8z',m.light)+L('M-2 12l16 4m-18 4 6 1m-7 6 15 4',m.dark,2),
 P('m-26-13 9-10 8 11 11-12 9 11 13-6 4 13-9 20-37-3z',m.metal)+P('M-16-4h29v12h-29z',m.dark)+C(-3,5,4,m.glass),
 chain(-27,-9,7,m)+chain(-23,3,6,m)+C(0,13,9,m.metal)+C(0,13,5,m.dark),
 ` <ellipse rx="29" ry="18" fill="${m.fill}"/><ellipse cy="-2" rx="14" ry="8" fill="${m.dark}"/>`+Array.from({length:8},(_,j)=>C(Math.cos(j*.785)*23,Math.sin(j*.785)*12,2.4,m.dark)).join(''),
 Array.from({length:7},(_,j)=>`<g transform="rotate(${j*51})">${P('M0 0q-31-22-24-30Q4-30 0 0',m.fill)}${L('M0 0-17-23',m.light)}</g>`).join('')+P('m-4 7-16 36 13-5 8 6 7-37z',m.dark)+jewel(0,0,m),
 P('M-27-7q52-20 48 4t-43 12q-20-5 6-21','none',`stroke="${m.fill}" stroke-width="5"`)+[-18,5,20].map((x,j)=>P(`M${x} 1q-10-28 6-26q19 8-6 26`,j%2?m.light:m.base)).join(''),
 P('M-25-8q14-34 28-14l18 2-8 19 20 9-23 10-25-11-12 14 5-21z',m.dark)+L('M-26-8l18-9m19 27 20 1',m.light,2)+P('M-16-8h12v6h-12m18 20h13v5H2',m.fill)
 ][i];
 function neck(i,m){const band=P('M-57-12q57 27 114 0l-3 13q-52 25-108 0z',m.fill);return [band+P('m-36 2 19 7-8 47-22-4z',m.fill)+L('M-48 39l22 5',m.light,7),chain(-48,-9,12,m)+P('m-16 17 20-4 4 31-21 4z',m.metal)+P('m5 22 18-1 1 32-18 1z',m.fill)+L('M-10 24l10-2m-9 9 10-2',m.dark),band+P('M7 9h25l12 42H8z',m.fill)+L('M-54-4q55 20 108 0M13 12l13 38m-16-20h30',m.light,4)+seam('M10 47h31',m),band+R(-19,14,38,34,4,m.light)+R(-14,20,28,12,2,m.dark)+L('M-13 38h23',m.dark,2),chain(-49,-8,12,m)+P('M-4 10q-22 31-7 40 24 9 23-14L6 18q-7-12-10 1v19','none',`stroke="${m.metal}" stroke-width="3"`),chain(-44,-7,11,m)+P('m0 15 19 10v20L0 56-19 45V25z',m.metal)+C(0,36,10,m.dark),band+L('M0 12V43M-10 10v14h20V10',m.metal,4)+C(0,46,3,m.light),band+P('M0 13q-41-31-39-5t39 5q41-31 39-5T0 13',m.fill)+L('M-29 3-7 12-27 17m56-14L7 12l20 5',m.light,2)+R(-6,3,12,20,4,m.metal),chain(-45,-10,11,m)+[-32,-16,0,16,32].map((x,j)=>`<ellipse cx="${x}" cy="${20-Math.abs(x)*.25}" rx="5" ry="${10+j%2*3}" fill="${j%2?m.fill:m.metal}"/>`).join(''),P('M-50-9q15 36 49 8t50-1q-14 32-48 9t-50 2','none',`stroke="${m.metal}" stroke-width="8"`)+L('M-8 5q15-16 23-6',m.light,2)][i];}
 function detail(a,m){const i=a.visual.variant,r=['common','uncommon','rare','epic','legendary','anomalous'].indexOf(a.rarity);if(a.slot==='effect')return '';const small=['charm','utility','tail','weapon'].includes(a.slot),y=a.slot==='head'?-12:a.slot==='face'?17:small?18:30;return (r>=2?M.rivets([[small?-13:-29,y],[small?13:29,y]],m):'')+(r>=3&&['head','body','back'].includes(a.slot)?seam(`M-26 ${y-6}q26 10 52 0`,m):'')+(r===4&&['head','body','back'].includes(a.slot)?jewel(0,y,m):'');}
 function head(i,m,fallback,a){if(i===4)return P('M-44 1q44-17 88 0l-4 12h-80z',m.dark)+[-29,0,29].map((x,j)=>`<g transform="translate(${x} ${j===1?-49:-28})">${Array.from({length:9},(_,k)=>`<g transform="rotate(${k*40})">${R(-3,-26,6,12,1,m.metal)}</g>`).join('')}${C(0,0,20,m.metal)}${C(0,0,12,m.dark)}${C(0,0,5,m.fill)}${L('M0-11v22M-11 0h22',m.fill,3)}</g>`).join('')+L('M-29-9V0M0-28V0M29-9V0',m.metal,5);if(i===3)return P('M-47 1h94v11h-94z',m.dark)+[-35,-18,0,18,35].map((x,j)=>{const h=[39,52,71,48,33][j];return P(`M${x-5} 1v-${h}l10-4V1z`,m.metal)+Array.from({length:Math.floor(h/8)},(_,k)=>L(`M${x-4} ${-5-k*8}h${k%2?3:6}`,m.dark,1)).join('');}).join('');if(i===5)return P('M-44-10h88v21h-88z',m.dark)+C(0,-26,27,m.metal)+C(0,-26,21,m.light)+Array.from({length:9},(_,j)=>`<g transform="rotate(${j*30-120} 0 -26)">${L('M0-45v5',m.dark,1)}</g>`).join('')+L('M0-26 12-35',m.dark,2)+C(0,-26,3,m.fill)+M.rivets([[-35,0],[35,0]],m);if(i===7)return P('M-43 1q43-16 86 0l-6 11h-74z',m.metal)+[-28,0,28].map((x,j)=>P(`M${x-14} 0q0-${j===1?45:29} 14-${j===1?50:34}q14 10 14 ${j===1?50:34}z`,m.metal)+P(`M${x-8} -4q0-18 8-${j===1?37:23}q8 9 8 ${j===1?37:23}z`,m.dark)+jewel(x,j===1?-17:-8,m)).join('');return fallback(a);}
 function face(i,m){return [
 P('M-46-31h88l10 29-12 34-36 8-41-14-13-28z',m.metal)+R(-33,-19,66,28,5,m.dark)+R(-27,-14,54,17,2,m.glass)+L('M-20-9h20',m.light,2)+L('M-24 19h47m-39 6h28',m.dark,2)+M.rivets([[-40,-9],[42,-9]],m),
 R(-51,-24,102,44,8,m.dark)+R(-38,-17,27,30,3,m.fill)+R(11,-17,27,30,3,m.fill)+C(-25,-2,9,m.glass)+C(25,-2,9,m.glass)+P('M-10-14H10v9H-10z',m.metal)+R(15,-37,26,15,2,m.metal)+L('M20-34h12',m.dark,3),
 P('M0 3q-14-29-33-7-17 5-25-14 1 43 38 33L0 6q28 25 50 3 12-15 9-27-12 27-29 8Q16-23 0 3',m.dark)+L('M-43 6q14 10 29-1m27 1q16 11 33-1','#947968',1.5),
 [-31,31].map((x,j)=>R(x-26,-25,52,47,7,m.metal)+R(x-21,-20,42,37,4,m.glass)+P(`m${x-24} -20 31-13 22 17-34 18z`,m.glass)+L(`M${x-14} -12l21-6`,m.light,1.5)).join('')+L('M-5-2H5',m.metal,4),
 P('M-56-18-12-28-5 16-47 27zm68-10 44 10-9 45-42-11z',m.dark)+P('m-48-12 29-7 6 29-28 8zm67-7 29 7-7 30-28-8z',m.glass)+L('M-8-7H8',m.metal,4)+M.rivets([[-51,-14],[-43,21],[50,-14],[43,21]],m),
 [-31,31].map(x=>C(x,0,25,m.metal)+C(x,0,18,m.dark)+C(x,0,13,m.glass)+L(`M${x-10} -6l9-6`,m.light,2)).join('')+L('M-7-3H7',m.dark,7)+L('M-57-2h-9m123 0h10',m.fill,8),
 C(-31,0,23,m.metal)+C(-31,0,19,m.glass)+C(31,0,23,m.metal)+C(31,0,19,m.glass)+L('M-8-4H8',m.metal,3)+P('M0-9-13 21l23-5z',m.light)+P('M0-9 10 25 2 16z',m.fill),
 C(-27,-2,28,m.metal)+C(-27,-2,23,m.glass)+L('M-42-13l13-8',m.light,2)+P('M0 7q34 18 40 47','none',`stroke="${m.metal}" stroke-width="2"`)+C(41,56,4,m.metal),
 P('M0 4q-18-43-60-15 13 50 60 15Q22-37 61-8 44 32 0 4',m.fill)+L('M-48-8-1 5l47-10M-35-14l10 17m4-16 9 17M31-12 23 4m19-14-9 10',m.light,1.2)+C(0,5,4,m.metal),
 P('M-46-30q48-16 93 3l-6 39-40 24-41-26z',m.glass)+P('M-46-30q28 16 28 40l19 26-41-26z',m.fill)+L('M17-22q15 14 7 29M-5-29l-3 15',m.light,2)
 ][i];}
 function effect(i,m){const glyph=[
 P('M-7-9q12-5 13 7l-5 16-11-5z',m.fill)+C(4,-14,3,m.light),
 P('M-12-16h24v29l-6 5h-18z',m.light)+L('M-7-8H7m-14 6H4m-11 6H6',m.dark),
 C(0,0,16,m.glass)+L('M-10-5q1-7 8-8',m.light,2)+C(11,16,5,m.glass),
 L('M-10 10 10-12m-23 23 4-10',m.metal,4)+P('m9-15 6 6 4-10z',m.light),
 L('M0-14v26q-15 8-15-1t15-5m0-20 15 7',m.metal,4),
 P('M-14 20q-12-12 2-23t-4-24m19 45q-12-12 2-23','none',`stroke="${m.light}" stroke-width="3" opacity=".65"`),
 P('m0-18 5 12 15 1-11 9 3 14-12-7-12 7 3-14-11-9 15-1z',m.glass),
 P('M0 16q-32-22-14-36Q16-30 0 16',m.fill)+L('M-9-14 0 10',m.light),
 P('M-15 10q-3-34 34-32 5 26-34 32',m.fill)+L('M-15 10 12-15m-13 13 0-9',m.light),
 R(-15,-15,14,14,0,m.fill)+R(2,1,14,14,0,m.light)+R(-18,4,8,8,0,m.dark)
 ][i];return '<g class="hunt-cos-effect">'+Array.from({length:6},(_,j)=>`<g transform="translate(${(j%2?-1:1)*(94+j%3*15)} ${-66+Math.floor(j/2)*58}) rotate(${j*21-35}) scale(${.65+j%3*.15})">${glyph}</g>`).join('')+'</g>';}
 function geometry(a,m,fallback){if(a.visual.sculpture)return Abyss.AtelierModels.draw(a,m);const i=a.visual.variant;const custom=({body,back,weapon,tail,neck,face,effect})[a.slot];let g=custom?custom(i,m):a.slot==='head'?head(i,m,fallback,a):fallback(a);if(a.slot==='head'&&i===9)g=P('M-44-10q44-24 88 0l-8 24h-73z',m.dark)+C(0,-40,31,m.metal)+C(0,-40,24,m.dark)+L('M0-61v21l-14 9',m.light,3)+[0,60,120,180,240,300].map(v=>`<g transform="rotate(${v} 0 -40)">${L('M0-67v5',m.light,2)}</g>`).join('')+P('m-34-25-12-15 4 32 12-7m61-9 18-20-2 30-11 3',m.fill);return g+detail(a,m);}
 function material(a,m,g){return `${m.defs}<g color="${m.base}" fill="${m.fill}" stroke="${m.dark}" stroke-width="1.35" stroke-linejoin="round" stroke-linecap="round"><g transform="translate(2.5 3)" style="filter:brightness(.2)" opacity=".55">${g}</g>${g}</g>`;}
 function premium(a){const m=M.make(a.rarity==='anomalous'?'anomaly':a.id==='experimental_armor'?'industrial':'formal');let g;switch(a.id){
 case 'containment_helmet':g=P('M153 139q-8-63 46-80 47-16 87 6 46 29 40 75l-28-14q-57-26-115 0z',m.metal)+P('M173 119q13-47 62-48l-10 52z',m.fill)+P('M253 69q53 4 61 54l-56-8z',m.dark)+P('M173 126q65-18 133 0l-5 37q-55-9-124 0z',m.glass)+L('M180 135q58-15 114-1',m.light,2)+R(222,99,34,20,5,m.dark)+C(240,109,6,m.glass)+M.rivets([[162,123],[317,122],[198,80],[282,81]],m);break;
 case 'cyber_visor':g=P('M153 181q87-25 174 0l-10 50-39 2-16-10-100 8z',m.dark)+P('M165 185q75-19 146 0l-5 32-137 4z',m.glass)+L('M174 194l39-8m34 13h34m-21 8h35','#a9dadb',2)+R(148,192,18,25,5,m.metal)+C(157,203,4,m.glass)+P('M322 204h11v30h-11',m.metal);break;
 case 'oracle_lens':g=P('M154 202q30-39 74-7l13-12 14 13q44-33 72 7l-22 31-52-17-14 18-14-18-48 20z',m.metal)+C(199,205,24,m.dark)+C(280,205,24,m.dark)+[199,280].map(x=>C(x,205,19,m.glass)+C(x,205,10,'none',`stroke="${m.light}"`)+L(`M${x-22} 205h8m14 0h22M${x} 183v8m0 28v8`,m.light,1)).join('')+jewel(239,196,m)+chain(302,229,4,m)+P('M324 240v45',m.metal);break;
 case 'memory_chain':g=chain(178,256,15,m)+[196,220,247,273,298].map((x,i)=>L(`M${x} ${273+i%2*4}v${10+i%3*4}`,m.metal,2)+R(x-6,284+i%2*4,12,17+i%3*3,3,i%2?m.glass:m.metal)+C(x,290+i%2*4,2,m.light)).join('');break;
 case 'experimental_armor':g=P('m173 263 34 3 32 16 32-17 36 1 24 48-19 24-30-8-20 25-40-2-24-25-28 10-22-26z',m.dark)+P('m187 275 50 18 51-18-8 44-42 19-41-19z',m.metal)+P('m164 273 26-3 8 31-40 8zm125-4 24 4 16 36-40-8z',m.fill)+L('M239 294v38m-32-29 32 14 33-15',m.dark,3)+jewel(239,308,m)+M.rivets([[175,286],[307,286],[207,325],[271,325]],m);break;
 case 'guardian_mantle':g=P('M168 253q72 35 144 0l37 85-32-7-10 28-39-9-27 15-29-16-37 10-11-27-31 7z',m.dark)+P('M180 263q59 34 119 0l28 71q-85 29-172 0z',m.fill)+P('m185 268 54 22 56-22-19 46-37 23-38-24z',m.metal)+P('m207 277 32 13 33-13-14 31-19 16-19-17z',m.dark)+seam('M157 333q80 26 168 0',m)+[174,194,219,241,266,290,310].map((x,i)=>L(`M${x} ${340+Math.sin(i/6*Math.PI)*7}l0 10`,m.metal,2)).join('')+jewel(239,300,m);break;
 case 'mechanical_apparatus':g=[146,131].map((r,i)=>`<ellipse cx="240" cy="229" rx="${r}" ry="${r*.88}" fill="none" stroke="${i?m.fill:m.metal}" stroke-width="${i?3:9}" transform="rotate(${i?-17:17} 240 229)"/>`).join('')+Array.from({length:8},(_,i)=>{const x=240+Math.cos(i*Math.PI/4)*142,y=229+Math.sin(i*Math.PI/4)*124;return C(x,y,12,m.dark)+C(x,y,7,m.glass)+L(`M${x-3} ${y}h6`,m.light);}).join('')+L('M106 192 91 162m269 124 29 24',m.metal,7);break;
 case 'phosphor_tail':g=`<ellipse rx="23" ry="14" fill="${m.dark}"/><ellipse cy="-3" rx="23" ry="14" fill="none" stroke="${m.metal}" stroke-width="6"/>`+[-18,0,18].map((x,i)=>P(`M${x-4} 0l8-2 3 ${20+i%2*8}-7 10-7-9z`,m.glass)+L(`M${x} 5v13`,'#a5d7c9',2)).join('');break;
 case 'prism_charm':g=P('M0-32 23-8 16 25 0 37-20 17-23-8z',m.metal)+P('M0-27 17-7 0 27-17-7z',m.glass)+L('M0-27v54M-17-7H17',m.light)+P('m-28 5 8 10-8 12-7-12zm55-29 6 9-6 10-6-10z',m.fill);break;
 case 'broken_halo':g=`<ellipse cx="239" cy="63" rx="99" ry="28" fill="none" stroke="${m.dark}" stroke-width="13" stroke-dasharray="177 23 135 24 130 24"/><ellipse cx="239" cy="59" rx="99" ry="28" fill="none" stroke="${m.metal}" stroke-width="8" stroke-dasharray="177 23 135 24 130 24"/><ellipse cx="239" cy="59" rx="85" ry="19" fill="none" stroke="${m.light}" stroke-width="1" stroke-dasharray="31 12"/>`+P('m157 79-14 26 22-14m142-47 21-12-9 23',m.fill)+[174,204,275,301].map((x,i)=>L(`M${x} ${78-i%2*7}v${13+i%2*12}`,m.metal,1)+jewel(x,99+i%2*7,m)).join('');break;
 case 'night_compass':g=C(0,0,29,m.metal)+C(0,0,23,m.dark)+C(0,0,17,m.glass)+Array.from({length:12},(_,i)=>`<g transform="rotate(${i*30})">${L('M0-25v4',m.light,1)}</g>`).join('')+P('M0-21 6-1 0 19-6 1z',m.light)+P('M0-21 6-1 0 0z',m.fill)+C(0,0,3,m.metal)+P('M-8-29v-9h16v9',m.metal)+chain(23,6,4,m);break;
 case 'absent_crown':g=P('m166 133-7-45 33 17 14-52 28 40 22-53 17 50 37-25-9 48z',m.dark)+P('m166 133 4-30 22 2 14-52 8 67 20-27 22-53-5 79 22-29 37-25-9 48z',m.glass)+L('M170 127l21-6m20-59 2 43m48-54-6 28m22 29 22-26',m.light,2)+P('M204 119h24v8h-24m65 10h17v5h-17',m.fill)+`<ellipse cx="241" cy="121" rx="19" ry="7" fill="#060e18"/>`;break;
 case 'echo_thread':g=P('M-20 4q62-74 37-67t-13 70q-31 67 12 45 22-12 7-31','none',`stroke="${m.metal}" stroke-width="3"`)+P('M-14 10q62-74 37-67t-13 70q-31 67 12 45','none',`stroke="${m.light}" stroke-opacity=".35" stroke-width="1" stroke-dasharray="8 11"`)+P('m16-40 13-10 10 11-14 14z',m.glass)+L('M-9 0h17m-10 7h16',m.light);break;
 default:return null;
 }return material(a,m,g);}
 return {geometry,material,premium};
})();
