'use strict';
// Transaction boundary: failed commands never mutate live state. UI receives copies.
Abyss.Engine = (() => {
 let state=null;const listeners=new Set();
 const snapshot=()=>Abyss.Util.clone(state);
 const notify=()=>listeners.forEach(fn=>fn(snapshot()));
 function init(loaded){Abyss.HappyClub?.reset();state=loaded?Abyss.State.validate(loaded):Abyss.State.create();const slot=Abyss.Save.active();if(slot)state.mode=slot.mode;Abyss.Climate.init(state);Abyss.Underground.init(state);Abyss.Weapons2.init(state);Abyss.Accessories.reconcile(state);Abyss.Redeem.completeCollection(state);Abyss.Weapons2.capture(state);Abyss.Campaign?.prepare(state);Abyss.Narrative.sync(state);Abyss.StoryDay.sync(state);if(state.mode==='raising')Abyss.Caravans.sync(state);if(Abyss.Save.active()){Abyss.Meta?.observe(state);Abyss.Wallpapers.observe(state);}notify();return snapshot();}
 function dispatch(command){
   if(!state)return {ok:false,message:'游戏尚未初始化。'};
   const next=snapshot();let r;
   if(!Abyss.StoryMode.allowed(next,command.type))return {ok:false,message:Abyss.HomeData.t('主线通过剧情选择和调查推进；养成操作在养成模式中使用。','Story advances through choices and investigation. Sandbox actions belong to Raising Mode.')};if(command.type.startsWith('happy:'))r=Abyss.HappyClub.command(next,command.type.slice(6),command.payload);else if(next.happyClub?.active&&!['settings','rename'].includes(command.type))r={ok:false,message:Abyss.HomeData.t('先完成或结束快乐俱乐部挑战。','Finish or leave the Happy Club round first.')};else if(command.type.startsWith('story:'))r=Abyss.StoryMode.command(next,command.type.slice(6),command.payload);else if(command.type.startsWith('road:'))r=Abyss.Road.command(next,command.type.slice(5),command.payload);else if(!Abyss.Road.atLab(next)&&!['settings','rename','redeem','accessory:ack','climate:site'].includes(command.type)&&!(next.road.mode==='site'&&(command.type.startsWith('underground:')||command.type.startsWith('medical:')||command.type==='caravan:livestock')))r={ok:false,message:Abyss.HomeData.t('先从灰烬之路返回实验室。','Return from Road of Ash first.')};else if(command.type==='redeem')r=Abyss.Redeem.command(next,command.payload);else if(!Abyss.StoryDay.allowed(next,command.type))r={ok:false,message:Abyss.StoryDay.message()};else if(next.narrative?.jack?.pendingEnding&&!command.type.startsWith('nv:')&&!['settings','rename'].includes(command.type))r={ok:false,message:'请先读完这段告别，或查看共同记忆'};else if(command.type.startsWith('nv:'))r=Abyss.Narrative.command(next,command.type.slice(3),command.payload);
   else if(next.dreams.active&&!command.type.startsWith('dream:')&&!['settings','rename'].includes(command.type))r={ok:false,message:Abyss.HomeData.t('先从梦中醒来。','Wake from the dream first.')};
   else if(command.type.startsWith('dream:'))r=Abyss.Dreams.command(next,command.type.slice(6),command.payload);
   else if(next.hunt.active&&!command.type.startsWith('hunt:')&&!['settings','rename'].includes(command.type))r={ok:false,message:Abyss.HomeData.t('先完成狩猎或免费撤回。','Finish the hunt or retreat free.')};
   else if(next.journey.active&&!command.type.startsWith('journey:')&&!['rest','event','settings','rename'].includes(command.type))r={ok:false,message:Abyss.HomeData.t('先完成旅程或返回。','Finish the journey or return first.')};
   else if(command.type.startsWith('journey:'))r=Abyss.Journey.command(next,command.type.slice(8),command.payload);
   else if(command.type.startsWith('underground:'))r=Abyss.Underground.command(next,command.type.slice(12),command.payload);
   else if(command.type.startsWith('caravan:')||command.type.startsWith('street:')){if(next.exploration.active||next.pendingEvent||next.awaySince)r={ok:false,message:'Finish the active journey or event first.'};else r=command.type.startsWith('caravan:')?Abyss.Caravans.command(next,command.type.slice(8),command.payload):Abyss.Street.command(next,command.type.slice(7),command.payload);}
   else if(next.wasteland.active&&!command.type.startsWith('waste:')&&!command.type.startsWith('medical:')&&!['settings','rename'].includes(command.type))r={ok:false,message:'先从聚落返回实验室。'};
   else if(command.type.startsWith('waste:'))r=Abyss.Wasteland.command(next,command.type.slice(6),command.payload);
   else if(command.type.startsWith('exp:'))r=Abyss.Expedition.command(next,command.type.slice(4),command.payload);
   else if(next.exploration?.active&&!['settings','ackEnding','rename'].includes(command.type))r={ok:false,message:'请先在探索终端完成远征或撤回。'};
   else if(command.type.startsWith('room:'))r=Abyss.LabRooms.command(next,command.type.slice(5),command.payload);
   else if(command.type.startsWith('ops:'))r=Abyss.LabOperations.command(next,command.type.slice(4),command.payload);
   else if(command.type.startsWith('home:'))r=Abyss.Home.command(next,command.type.slice(5),command.payload);
   else if(command.type.startsWith('legacy:'))r=Abyss.Legacy.command(next,command.type.slice(7),command.payload);
   else if(command.type.startsWith('social:'))r=Abyss.Social.command(next,command.type.slice(7),command.payload);
   else if(command.type.startsWith('continuity:'))r=Abyss.Continuity.command(next,command.type.slice(11),command.payload);
   else if(next.mode==='raising'&&!next.legacy.active&&!['settings','rename','ackEnding'].includes(command.type))r={ok:false,message:Abyss.HomeData.t('这段生命已封存，请从生命档案迎接下一个个体。','This life is archived. Welcome the next individual from the Legacy Archive.')};
   else if(command.type==='news:choose')r=Abyss.NewsChains.command(next,command.payload);
   else if(command.type.startsWith('farm:'))r=Abyss.Homestead.command(next,command.type.slice(5),command.payload);
   else if(command.type.startsWith('garden:'))r=Abyss.Garden.command(next,command.type.slice(7),command.payload);
   else if(command.type.startsWith('medical:'))r=Abyss.Infirmary.command(next,command.type.slice(8),command.payload);
   else if(command.type.startsWith('climate:'))r=Abyss.Climate.command(next,command.type.slice(8),command.payload);
   else if(command.type==='experiment'&&next.climate.labResources.power<10)r={ok:false,message:Abyss.ClimateData.t('断电时实验设备无法运行，先恢复电力。','Experiments cannot run during a blackout. Restore power first.')};
   else if(command.type.startsWith('weapon2:'))r=Abyss.Weapons2.command(next,command.type.slice(8),command.payload);else if(command.type.startsWith('hunt:'))r=Abyss.Hunt.command(next,command.type.slice(5),command.payload);
   else if(command.type.startsWith('progress:'))r=Abyss.Progression.command(next,command.type.slice(9),command.payload);
   else if(command.type.startsWith('color:'))r=Abyss.Colors.command(next,command.type.slice(6),command.payload);
   else if(command.type.startsWith('pet:'))r=Abyss.Pets.command(next,command.type.slice(4),command.payload);
   else if(command.type.startsWith('bedroom:'))r=Abyss.Bedroom.command(next,command.type.slice(8),command.payload);
   else if(command.type==='life:event')r=Abyss.ContainmentEvents.command(next,command.payload);
   else if(command.type==='scene:change')r=Abyss.SceneComposition.command(next,command.payload);
   else if(command.type==='cosmetic:skin'){if(Abyss.Meta.skinUnlocked(command.payload)){next.skin=command.payload;r={ok:true,message:'皮肤已更换'};}else r={ok:false,message:'尚未发现此皮肤'};}
   else if(command.type==='cosmetic:anomaly'){if(Abyss.Meta.hasItem(command.payload)){next.campaign.anomaly=command.payload;Abyss.Narrative.enqueue(next,'anomaly_'+command.payload);r={ok:true,message:'异常物件已带入交流'};}else r={ok:false,message:'尚未发现此物件'};}
   else if(next.mode==='story'&&next.campaign?.ending&&!['settings','rename','ackEnding'].includes(command.type))r={ok:false,message:'本轮故事已经结束，请读取其他记录或开始新周目。'};
   else if(next.mode==='story'&&next.campaign?.creatureAlive===false&&['feed','train','companion','experiment','heal','reward','punish'].includes(command.type))r={ok:false,message:'这个个体已经离世。你可以独自继续调查与研究。'};
   else if(command.type==='rename')r=Abyss.Identity.rename(next,command.payload);
   else if(command.type.startsWith('accessory:')||command.type.startsWith('outfit:'))r=Abyss.Accessories.command(next,command.type,command.payload);
   else if(command.type==='event')r=Abyss.Events.resolve(next,command.payload);
   else if(command.type==='settings'){
     next.settings={motion:command.payload.motion===true,sound:command.payload.sound===true};r={ok:true,message:'设置已保存'};
   }else if(command.type==='ackEnding'){next.endingNotice=false;r={ok:true,message:''};}
   else r=Abyss.Actions.run(next,command.type,command.payload);
   if(!r.ok)return r;Abyss.Weapons2.capture(next);
   if(r.transient){state=next;return {...r,saved:undefined};}

   Abyss.Redeem.completeCollection(next);Abyss.Redeem.cap(next);
   const observed=r.observed||(command.type==='exp:start'?{...command,type:'explore'}:command);
   if(next.mode==='raising')Abyss.ClinicalEffects?.afterAction(state,next,observed);const gameplay=observed.type==='event'||observed.type in Abyss.Actions.costs||observed.type==='exp:start';
   if(gameplay){Abyss.Memory.observe(state,next,observed);Abyss.Personality.observe(state,next,observed);}
   if(next.mode==='raising'){if(state.legacy.birthDay!==next.legacy.birthDay){next.climate.preferences={like:Abyss.ClimateData.weather[next.rng%12].id,dislike:Abyss.ClimateData.weather[(next.rng+5)%12].id};next.climate.weatherMemories=[];}Abyss.LabOperations?.beginDay(state,next);Abyss.Climate.tick(state,next);Abyss.Garden?.observe(state,next,observed);Abyss.HomesteadDaily?.observe(state,next);Abyss.Infirmary?.observe(state,next,observed);Abyss.Caravans.observe(state,next,observed);Abyss.HomesteadAuction?.observe(state,next);Abyss.HomesteadMarket?.observe(state,next);Abyss.HomesteadRescue?.observe(state,next);Abyss.HomesteadEvents?.observe(state,next);Abyss.Street.observe(state,next,observed);Abyss.Underground.observe(state,next,observed);Abyss.Bedroom.observe(state,next,observed);Abyss.Pets.observe(state,next,observed);if(next.infirmary)Abyss.Infirmary?.sync(next.infirmary,next);Abyss.ContainmentEvents.observe(state,next,observed);Abyss.Salvage.observe(state,next,observed);Abyss.State.achieve(next);
   if(gameplay)Abyss.Accessories.after(state,next,observed);
   Abyss.Hunt.observe(state,next,observed);Abyss.Progression.observe(state,next,observed);Abyss.Narrative.observe(state,next,observed);
   for(const a of Abyss.ExpansionRewards)if(a.test(next)&&!next.achievements.includes(a.id))next.achievements.push(a.id);Abyss.Home.observe(state,next,observed);Abyss.Journey.observe(state,next,observed);Abyss.Legacy.observe(state,next,observed);Abyss.Dreams.observe(state,next,observed);Abyss.Social.observe(state,next,observed);Abyss.Continuity.observe(state,next,observed);Abyss.Wasteland.observe(state,next,observed);Abyss.WastelandNews?.observe(state,next,observed);Abyss.NewsChains?.observe(state,next,observed);Abyss.Wasteland.achievements(next);Abyss.Colors?.observe(state,next,observed);}else {Abyss.Narrative.sync(next);Abyss.Continuity.observe(state,next,observed);}Abyss.LabOperations?.finish(state,next,observed);Abyss.Meta?.observe(next);Abyss.Wallpapers.observe(next);Abyss.StoryDay.sync(next);const persist=Abyss.StorySaves?.shouldAuto(state,next,command)??true;state=next;
   const saved=persist?Abyss.Save.write(state):undefined;if(persist&&state.mode==='story'&&Abyss.Save.active())try{Abyss.StorySaves?.save('auto',state);}catch{}notify();return {...r,saved};
 }
 function replace(next){Abyss.HappyClub?.reset();state=Abyss.State.validate(next);Abyss.Climate.init(state);Abyss.Underground.init(state);Abyss.Weapons2.init(state);const active=Abyss.Save.active();if(active)state.mode=active.mode;Abyss.Accessories.reconcile(state);Abyss.Redeem.completeCollection(state);Abyss.Weapons2.capture(state);Abyss.Campaign?.prepare(state);Abyss.Narrative.sync(state);Abyss.StoryDay.sync(state);if(state.mode==='raising')Abyss.Caravans.sync(state);Abyss.Meta?.observe(state);Abyss.Wallpapers.observe(state);Abyss.Save.write(state);notify();}
 return {init,dispatch,replace,snapshot,subscribe(fn){listeners.add(fn);return ()=>listeners.delete(fn);}};
})();


