'use strict';
// Independent SVG layers. Replace a renderer with an <image href="assets/..."> later.
Abyss.Renderer = (() => {
 const layers={
  glow:()=>'<ellipse cx="239" cy="245" rx="127" ry="136" fill="#abf5a6" opacity=".12" filter="url(#glowing)"/><g fill="#bafac1"><circle cx="113" cy="207" r="3"/><circle cx="352" cy="160" r="3"/><circle cx="139" cy="128" r="2"/><circle cx="346" cy="288" r="4"/></g>',
  wings:()=>'<path d="M169 225 Q75 97 48 162 Q60 214 94 241 Q117 243 145 275 M311 225 Q405 97 432 162 Q420 214 386 241 Q363 243 335 275" fill="#779ab9" fill-opacity=".35" stroke="#96c7d1" stroke-width="2"/><path d="M155 238 L62 166 M325 238 L418 166" stroke="#84bebc" opacity=".5"/>',
  tail:()=>'<path d="M303 318 Q410 364 403 274 Q398 244 376 266 Q419 223 432 265 Q455 369 321 354" fill="#418d7f" stroke="#7ec1a5" stroke-width="2"/>',
  tentacles:()=>'<g fill="none" stroke="#819cc0" stroke-width="13" stroke-linecap="round"><path d="M154 294 Q76 278 103 332 Q115 365 76 348"/><path d="M324 294 Q402 278 379 332 Q365 368 404 347"/></g><g fill="none" stroke="#aad1d4" stroke-width="2"><path d="M154 291 Q78 278 103 330"/><path d="M324 291 Q402 278 379 330"/></g>',
  shell:()=>'<g fill="#316067" stroke="#6aaba6" stroke-width="2"><path d="M182 282 L211 262 L240 279 L235 313 L202 319 Z"/><path d="M240 279 L270 262 L299 282 L278 319 L245 314 Z"/><path d="M203 322 L238 317 L277 323 L260 346 L221 348 Z"/></g>',
  horns:()=>'<path d="M171 153 Q136 116 157 77 Q161 113 191 136 M290 136 Q321 113 322 77 Q349 116 310 156" fill="url(#horn-fill)" stroke="#b4cdb4" stroke-width="2"/>',
  organs:()=>'<g fill="#a7edb0" opacity=".75"><path d="M193 271 L203 266 L209 279 L200 285 Z"/><path d="M275 283 L287 278 L293 290 L281 298 Z"/><circle cx="238" cy="327" r="5"/></g>',
  eyes:s=>Abyss.EyeArt.pair(s)

 };

 let rigSequence=0;
 const order=['glow','wings','accessory-back','body','shell','accessory-body','tail','accessory-tail','limbs','accessory-neck','horns','eyes','accessory-head','accessory-face','accessory-charm','accessory-utility','accessory-weapon','tentacles','organs','accessory-effect'];
 function prepare(root){
  const creature=root.querySelector('[data-creature]')||root.querySelector('#creature');
  creature.setAttribute('data-creature','');
  const gradient=root.querySelector('[data-body-fill]')||root.querySelector('#body-fill');
  gradient?.setAttribute('data-body-fill','');
  const body=creature.querySelector('[data-layer="body"]');
  if(!creature.querySelector('[data-layer="limbs"]')){
   const limbs=document.createElementNS('http://www.w3.org/2000/svg','g');limbs.dataset.layer='limbs';
   const legs=body.querySelector('path'),arms=[...body.querySelectorAll('path')].find(p=>p.getAttribute('d').startsWith('M159 235'));
   if(legs){legs.setAttribute('d','M164 319 Q128 308 130 338 Q135 362 179 345 Z M300 319 Q338 309 350 332 Q360 359 302 346 Z');limbs.appendChild(legs);}if(arms)limbs.appendChild(arms);creature.appendChild(limbs);
  }
  for(const slot of Object.keys(Abyss.Data.slots))if(!creature.querySelector('[data-accessory-slot="'+slot+'"]')){
   const group=document.createElementNS('http://www.w3.org/2000/svg','g');group.dataset.layer='accessory-'+slot;group.dataset.accessorySlot=slot;creature.appendChild(group);
  }
  for(const layer of order){const el=creature.querySelector('[data-layer="'+layer+'"]');if(el)creature.appendChild(el);}
 }
 function render(s,root=document.getElementById('monster')){
   if(!root)return;prepare(root);
   const expressed=new Set(s.mutations.map(id=>Abyss.Data.mutations.find(m=>m.id===id)?.layer));
   for(const [name,draw] of Object.entries(layers)){const el=root.querySelector('[data-layer="'+name+'"]');if(el)el.innerHTML=name==='eyes'||expressed.has(name)?(root.id==='wardrobe-creature'?draw(s).replace(/url\(#/g,'url(#wardrobe-svg-'):draw(s)):'';}
   const creature=root.querySelector('[data-creature]');creature.style.opacity=s.awaySince?'.08':'1';
   root.style.scale=String(s.age<6?.84:s.age<13?.93:1);
   const form=Abyss.Data.forms.find(f=>f.id===s.form);
   root.querySelector('[data-body-fill] stop').setAttribute('stop-color',Abyss.Phase6Data?.skins.find(k=>k.id===s.skin)?.color||form?.color||'#99edc2');
   Abyss.VisualEvolution.render(s,root);
   const rigId=root.dataset.rigId||=String(++rigSequence);let clip=root.querySelector('[data-garment-clip]');if(!clip){clip=document.createElementNS('http://www.w3.org/2000/svg','clipPath');clip.dataset.garmentClip='';clip.setAttribute('clipPathUnits','userSpaceOnUse');root.querySelector('defs').append(clip);}clip.id='garment-fit-'+rigId;clip.innerHTML='<path d="'+root.querySelector('[data-layer="body"]>path').getAttribute('d')+'"/>';
   for(const slot of Object.keys(Abyss.Data.slots)){
    const id=s.collection.equipped[slot],item=Abyss.Accessories.find(id),group=root.querySelector('[data-accessory-slot="'+slot+'"]');
    const art=item?Abyss.AccessoryArt.markup(item,s):'';group.innerHTML=slot==='body'?'<g transform="'+Abyss.AttachmentRig.transform(slot,s)+'">'+art+'</g>':art;group.dataset.item=id||'';group.setAttribute('transform',slot==='body'?'':Abyss.AttachmentRig.transform(slot,s));if(slot==='body')group.setAttribute('clip-path','url(#'+clip.id+')');if(slot==='face'&&item)Abyss.AttachmentRig.fitFace(group,item,s,rigId);
   }
   Abyss.SkinArt?.render(s,root);Abyss.Colors?.render(s,root);
   let anomaly=root.querySelector('[data-anomaly-layer]');if(!anomaly){anomaly=document.createElementNS('http://www.w3.org/2000/svg','g');anomaly.setAttribute('data-anomaly-layer','');root.querySelector('[data-creature]').appendChild(anomaly);}const token=s.campaign?.anomaly;anomaly.innerHTML=!token?'':token==='red_thread'?'<path d="M184 270 Q220 298 304 279" fill="none" stroke="#b16e79" stroke-width="3"/><path d="M264 286q12 25 22 7" fill="none" stroke="#b16e79" stroke-width="2"/>':token==='salt_shell'?'<path d="M264 285q-11-17 1-20q17-1 18 13l-13 13z" fill="#c9bda5" stroke="#f0dfbc"/><path d="M266 268l4 19m6-17l-6 17" stroke="#948c84"/>':'<path d="M260 273l12-12 13 14-13 16z" fill="#9088a9" stroke="#bbc7ce"/><circle cx="272" cy="275" r="3" fill="#ccd7d2"/>';
   root.dataset.idle=Abyss.Personality.idle(s);
   root.dataset.outfit=Abyss.Accessories.activeSets(s).map(set=>set.effect).join(' ');
   if(root.id==='monster')document.querySelector('.chamber').dataset.outfit=root.dataset.outfit;
 }
 function clone(s){
   const source=document.getElementById('monster');prepare(source);
   const root=source.cloneNode(true);root.id='wardrobe-creature';delete root.dataset.rigId;
   // A preview owns its SVG definitions; duplicate IDs never refer to the main scene.
   const ids=new Map();root.querySelectorAll('[id]').forEach(el=>{const id=el.id;ids.set(id,'wardrobe-svg-'+id);el.id='wardrobe-svg-'+id;});
   root.querySelectorAll('*').forEach(el=>{for(const attr of [...el.attributes]){let value=attr.value;for(const [old,id] of ids)value=value.split('url(#'+old+')').join('url(#'+id+')');if(value!==attr.value)el.setAttribute(attr.name,value);}});
   render(s,root);root.setAttribute('viewBox','0 0 510 430');root.style.scale='1';return root;
 }
 return {render,layers,order,clone};
})();


