 'use strict';
// Weapon identity rules mutate only the isolated fight, never browser or storage state.
Abyss.WeaponCombat=(()=>{
 const traits=['entangle','split','hunter','breach','pin','wet','escort','stun','heavybolt','steady','closeburst','charge','shock','magnetic','chain','debt','frost','authorized','authority','repeat'];
 Abyss.WeaponData.weapons.filter(w=>w.underground).forEach((w,i)=>{w.trait=traits[i];if(i!==8)w.bonus={};});
 function onHit(s,w,f,e,damage,critical){if(!w)return damage;if(Abyss.WeaponEpic.designs[w.id]||Abyss.WeaponLegendary.designs[w.id])return damage;const r=s.hunt.weapons[w.id]?.resonanceLevel||0,random=()=>Abyss.Util.random(s),status=id=>{if(!f.enemyStatus.some(x=>x.id===id&&x.turns>0))f.enemyStatus.push({id,turns:3});},mechanical=['machine','security','robot'].includes(e.category)||/drone|turret|robot|watchdog/.test(e.id);switch(w.trait){
 case 'entangle':if(random()<.25+r*.015)status('slow');break;
 case 'split':if(random()<.22+r*.02)status('break');break;
 case 'hunter':if(f.enemyHp<f.enemyMax*.65&&random()<.15+r*.015)damage*=1.4;break;
 case 'breach':f.enemyShield=Math.max(0,f.enemyShield-4-r);break;
 case 'pin':if(random()<.2+r*.02)status('slow');break;
 case 'wet':if(Abyss.HuntData.zones.find(z=>z.id===s.hunt.active.zone)?.environment==='flood')damage*=1.12+r*.015;break;
 case 'escort':if(f.hp<f.maxHp*.5)damage*=1.12+r*.02;break;
 case 'heavybolt':damage*=1.1+r*.01;break;
 case 'steady':damage*=1+Math.min(.18,f.turn*.025)+r*.005;break;
 case 'closeburst':damage*=1+Math.max(0,(5-(f.distance??2.5))*.055);break;
 case 'charge':damage*=1+Math.min(.18,w.attackTime*.1);break;
 case 'shock':if(f.enemyShield>0){f.enemyShield=Math.max(0,f.enemyShield-5-r);if(random()<.18+r*.02)status('stun');}break;
 case 'magnetic':if(mechanical)damage*=1.18+r*.025;break;
 case 'chain':if(random()<.12+r*.025){status('stun');damage*=1.12;f.logs.push('ARC · '+Abyss.HomeData.t('电弧干扰目标线路。','An arc disrupts the target circuit.'));}break;
 case 'debt':f.weaponDebt=Math.min(5,(f.weaponDebt||0)+(r>=2?2:1));if(f.weaponDebt>=5){damage*=r>=6?1.7:1.35;f.weaponDebt=0;}break;
 case 'frost':if((f.distance??2.5)>=8)damage*=1.15+r*.02;if(r>=4)status('slow');break;
 case 'authorized':if(e.elite||e.boss)damage*=1.15+r*.025;break;
 case 'authority':if(f.turn===1&&f.hp>=f.maxHp*.95){damage*=1.2+r*.025;f.shield=Math.min(100,f.shield+5+r);}break;
 }return Math.max(0,Math.round(damage));}
 return {onHit};
})();
