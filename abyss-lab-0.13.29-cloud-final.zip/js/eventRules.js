'use strict';
// Shared, declarative eligibility and non-stat outcomes for laboratory and field events.
Abyss.EventRules=(()=>{
 function available(s,e){const d=e.discovery||{},v=s.progress?.evolution;return (!e.farmRescue||Abyss.HomesteadRescue?.available(s,e.id))&&Abyss.Util.matches(s,e.rules)&&(!d.stage||(v?.stage||0)>=d.stage)&&(!d.route||v?.route===d.route)&&(!d.technology||Abyss.Research.has(s,d.technology));}
 function extra(s,out,source,field=false){if(field&&out.farmRescue)Abyss.HomesteadRescue.recover(s,out.farmRescue);const a=field?s.exploration.active:null;for(const [id,n]of Object.entries(out.items||{})){if(a)a.loot[id]=(a.loot[id]||0)+n;else Abyss.Inventory.grantItem(s,id,n,source);}
 if(out.resentment)s.resentment=Abyss.Util.clamp(s.resentment+out.resentment);if(out.research)Abyss.Research.award(s,'event:'+source,out.research);if(out.evolutionMemory)Abyss.Evolution.record(s,out.evolutionMemory,'discovery');
 if(a){if(out.money)s.money=Math.max(0,s.money+out.money);for(const [id,n]of Object.entries(out.bias||{}))s.bias[id]=(s.bias[id]||0)+n;if(out.loseLoot)for(const id of Object.keys(a.loot))a.loot[id]=Math.floor(a.loot[id]/2);if(out.forceReturn)a.forceReturn=true;}
 }
 return {available,extra};
})();
