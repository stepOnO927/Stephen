'use strict';
// Bespoke high-tier containment housings, around independently replaceable vial layers.
Abyss.SerumSculptures=(()=>{
 const M=Abyss.ArtMaterials,P=M.path,L=M.line,C=M.circle,R=M.rect;
 function housing(d){const m=M.make(d.rarity==='anomalous'?'anomaly':d.rarity==='legendary'?'formal':'industrial'),id=d.id;const cases={
 serum_void:()=>P('M43 37 61 18 105 22 127 44 117 145 39 145z',m.dark)+P('m43 37 18-19 5 17-14 95H40m65-108 22 22-10 101-10-14 10-90z',m.metal)+L('M44 147h74',m.light,2),
 serum_dawn:()=>Array.from({length:7},(_,i)=>`<g transform="rotate(${i*25-75} 80 80)">${P('m77 15 3-13 4 13-1 25h-5z',m.metal)}</g>`).join('')+P('M35 133q45 25 91 0l-5 20H39z',m.metal),
 serum_oracle:()=>P('M26 85q55-79 109 0-55 79-109 0','none',`stroke="${m.metal}" stroke-width="5"`)+L('M80 21v17m0 94v18',m.light,2)+[41,120].map(x=>C(x,85,5,m.glass)).join(''),
 serum_sea:()=>P('M35 137q-27-30-9-61-6 30 21 33m66 27q28-35 18-76 0 37-19 43',m.fill)+P('M28 142q53-19 104 0l-8 14H38z',m.metal)+L('M37 146q43-12 83 0',m.light,2),
 serum_witness:()=>R(30,24,18,122,4,m.metal)+R(115,35,13,111,3,m.fill)+L('M38 32h84M38 142h84',m.metal,5)+C(121,75,12,m.dark)+C(121,75,7,m.glass)+P('m30 140 95 0 7 15H25z',m.dark),
 serum_zero:()=>C(80,89,57,'none',`stroke="${m.metal}" stroke-width="5"`)+C(80,89,64,'none',`stroke="${m.light}" stroke-width="1" stroke-dasharray="11 17"`)+R(49,147,65,8,2,m.dark),
 serum_absence:()=>P('M29 40h22v8H37v30h-8zm83-2h18v36h-8V46h-10zM29 113h8v30h14v8H29zm83 30h10v-27h8v35h-18z',m.metal)+R(24,92,20,5,0,m.fill)+R(119,87,17,7,0,m.light),
 serum_orbit:()=>`<ellipse cx="80" cy="87" rx="68" ry="23" transform="rotate(-29 80 87)" fill="none" stroke="${m.metal}" stroke-width="4"/><ellipse cx="80" cy="87" rx="27" ry="62" transform="rotate(-29 80 87)" fill="none" stroke="${m.fill}" stroke-width="2"/>`+C(26,111,8,m.glass)+C(111,33,5,m.metal),
 serum_choice:()=>P('M30 36 57 20v124l-27 10zm73-16 28 16v118l-28-10z',m.dark)+L('M40 42v98m79-98v98',m.metal,4)+C(48,88,3,m.light)+C(112,88,3,m.light),
 serum_wind:()=>P('M25 117q-17-80 78-98-49 24-51 61m82-31q33 75-73 99 55-29 55-59','none',`stroke="${m.metal}" stroke-width="3"`)+P('m102 19-14-2 10 13m-37 118 15 1-10-12',m.fill),
 serum_bet_uncommon:()=>[0,1,2].map(i=>`<ellipse cx="${37+i*7}" cy="${144-i*5}" rx="21" ry="6" fill="${m.metal}"/>`).join('')+C(124,122,17,m.metal)+C(124,122,11,m.dark),
 serum_bet_rare:()=>P('m24 93 30-8 13 58-29 9zm80-9 28 11-18 58-25-11z',m.light)+P('m34 109 5-9 8 8-4 12zm76 6 9-6 5 9-9 8z',m.dark),
 serum_bet_epic:()=>C(80,90,61,'none',`stroke="${m.metal}" stroke-width="7"`)+L('M32 54l-8-10m104 10 8-10M80 26v12m0 104v12',m.light,2)+R(110,95,25,9,0,m.dark),
 serum_bet_legendary:()=>P('M28 63q0-36 22-41h62q22 6 22 41v86H28z',m.dark)+P('M36 52h16v45H36zm73 0h16v45h-16z',m.glass)+R(35,117,18,11,3,m.metal)+R(108,117,18,11,3,m.metal)+L('M40 144h79',m.metal,5),
 serum_bet_anomalous:()=>P('M25 36 49 19 48 46 31 66zm90-17 22 13-1 36-22-21zM21 121l25-8 8 40-21-6zm92-9 25 12-13 23-16 5z',m.metal)+L('M21 87h21m78 9h21',m.light,3)
 };const g=cases[id]?.();return g?m.defs+`<g stroke="${m.dark}" stroke-width="1" stroke-linejoin="round">${g}</g>`:'';}
 return {housing};
})();
