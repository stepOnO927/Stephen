'use strict';
Abyss.LabOperationsData=(()=>{
 const equipment=[
 ['generator','发电机','Generator','power','wire',.32,'generator'],
 ['filter','净水滤芯','Water filter','water','filter',.4,'filter'],
 ['pump','供水泵','Water pump','water','pipe',.3,null],
 ['heater','暖气','Heater','engineering','seal',.28,'heater'],
 ['cooling','冷却器','Cooling','engineering','seal',.28,'cooler'],
 ['airFilter','空气过滤器','Air filter','engineering','filter',.35,null],
 ['growLight','培养灯','Grow light','greenhouse','wire',.3,null],
 ['hydroponics','水培管路','Hydroponics','greenhouse','pipe',.32,null],
 ['scanner','医疗扫描仪','Medical scanner','medical','battery',.25,null],
 ['camera','安防摄像机','Security camera','observation','wire',.2,null],
 ['lock','走廊门锁','Passage lock','containment','tool',.22,null],
 ['radio','无线电机组','Radio rack','radio','battery',.23,null],
 ['server','档案服务器','Archive server','archive','tool',.18,null]
 ].map(([id,name,en,room,part,wear,climate])=>({id,name,en,room,part,wear,climate}));
 const duties=[
 ['greenhouse','温室','Greenhouse','greenhouse'],['infirmary','医务','Infirmary','medical'],
 ['security','门岗','Security','observation'],['maintenance','维护','Maintenance','engineering'],
 ['kitchen','厨房','Kitchen','kitchen'],['cleaning','清洁','Cleaning','living'],['radio','通讯','Radio','radio']
 ].map(([id,name,en,room])=>({id,name,en,room}));
 const parts=[['wire','电线','Wire'],['filter','滤芯','Filter'],['seal','密封圈','Seal'],['battery','电池','Battery'],['pipe','水管','Pipe'],['tool','工具零件','Tool parts'],['scrap','废料','Scrap']].map(([id,name,en])=>({id,name,en}));
 const priorities=['LOW','NORMAL','HIGH','CRITICAL'];
 const chains=[
 {id:'waterLeak',source:'pump',room:'water',after:3,step:'damp',later:6,end:'mold'},
 {id:'airClog',source:'airFilter',room:'engineering',after:3,step:'dust',later:6,end:'poorAir'},
 {id:'powerDrop',source:'generator',room:'power',after:2,step:'flicker',later:5,end:'growLight'},
 {id:'doorFault',source:'lock',room:'containment',after:2,step:'latch',later:4,end:'security'}
 ];
 return {equipment,duties,parts,priorities,chains};
})();
