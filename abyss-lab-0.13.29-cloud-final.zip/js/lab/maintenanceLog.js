'use strict';
Abyss.LabMaintenanceLog=(()=>{
 const fresh=()=>({nextId:1,entries:[]}),D=()=>Abyss.LabOperationsData;
 const clean=v=>typeof v==='string'?v.replace(/\r\n?/g,'\n').trim():'';
 const validText=v=>v.length>0&&v.length<=240&&!/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(v);
 function read(raw,s){const out=fresh();if(!raw||typeof raw!=='object')return out;
  const seen=new Set();for(const r of (Array.isArray(raw.entries)?raw.entries:[]).slice(-30)){
   const text=clean(r?.text),device=D().equipment.find(d=>d.id===r?.equipment);
   if(!r||!Number.isInteger(r.id)||r.id<1||r.id>=1000000000||seen.has(r.id)||!Number.isInteger(r.day)||r.day<1||r.day>s.day||!Abyss.HomeData.rooms.some(d=>d.id===r.room)||!validText(text)||!(r.equipment===null||device&&device.room===r.room&&Number.isFinite(r.condition)&&r.condition>=0&&r.condition<=100))continue;
   seen.add(r.id);out.entries.push({id:r.id,day:r.day,room:r.room,equipment:r.equipment,condition:device?r.condition:null,text,...(device&&Number.isInteger(r.recalledDay)&&r.recalledDay>=r.day&&r.recalledDay<=s.day?{recalledDay:r.recalledDay}:{})});
  }
  out.nextId=Math.max(1,...out.entries.map(e=>e.id+1));if(Number.isInteger(raw.nextId)&&raw.nextId>=out.nextId&&raw.nextId<1000000000)out.nextId=raw.nextId;return out;
 }
 function write(s,p){const t=Abyss.HomeData.t,fail=()=>({ok:false,message:t('填写1–240字的记录，并选择可用房间或设备。','Write 1–240 characters and select an available room or device.')}),text=clean(p.text),device=p.equipment?D().equipment.find(d=>d.id===p.equipment):null,room=device?.room||p.room;
  if(s.mode!=='raising'||!Abyss.LabOperations.atLab(s)||s.awaySince||s.pendingEvent||s.dreams.active||!validText(text)||p.equipment&&!device||!Abyss.LabRooms.canEnter(s,room)||device&&!Abyss.LabOperations.active(s,device)||s.operations.maintenanceLog.nextId>=1000000000)return fail();
  const log=s.operations.maintenanceLog;log.entries.push({id:log.nextId++,day:s.day,room,equipment:device?.id||null,condition:device?s.operations.equipment[device.id].condition:null,text});log.entries=log.entries.slice(-30);return {ok:true,message:t('维护记录已保存。','Maintenance note saved.')};
 }
 function recall(s,equipment){const d=D().equipment.find(d=>d.id===equipment),entry=s.operations.maintenanceLog.entries.slice().reverse().find(e=>e.equipment===equipment&&e.condition>=20&&!e.recalledDay&&e.day<s.day);if(!d||!entry)return;entry.recalledDay=s.day;Abyss.LabOperations.note(s,d.room,'Jack翻回D'+entry.day+'的维护记录。'+d.name+'的旧观察还在那一页。','Jack turns back to the maintenance note from D'+entry.day+'. The earlier observation about '+d.en+' is still on that page.','journalCallback');}
 function html(s){const t=(zh,en)=>Abyss.I18n.language()==='en'?en:zh,esc=Abyss.Util.escape,enabled=Abyss.LabOperations.atLab(s)&&!s.awaySince&&!s.pendingEvent&&!s.dreams.active;
  return '<section class="ops-written-log"><h3>'+t('Jack的维护记录','Jack’s maintenance notes')+'</h3><p>'+t('保留最近30条，每条最多240字。原文保留，不自动翻译。','Keep the latest 30 notes, up to 240 characters each. Your text stays as written.')+'</p><label>'+t('记录位置','Room')+'<select id="ops-log-room">'+Abyss.HomeData.rooms.filter(d=>Abyss.LabRooms.canEnter(s,d.id)).map(d=>'<option value="'+esc(d.id)+'">'+esc(Abyss.I18n.text(d.name))+'</option>').join('')+'</select></label><label>'+t('关联设备（可选，自动使用设备所在房间）','Related device (optional; uses the device’s room)')+'<select id="ops-log-equipment"><option value="">—</option>'+D().equipment.filter(d=>Abyss.LabOperations.active(s,d)&&Abyss.LabRooms.canEnter(s,d.room)).map(d=>'<option value="'+esc(d.id)+'">'+esc(t(d.name,d.en))+'</option>').join('')+'</select></label><label>'+t('维护记录','Maintenance note')+'<textarea id="ops-log-text" rows="4" maxlength="240" placeholder="'+esc(t('水泵的声音还是不对。','The pump still sounds wrong.'))+'" '+(!enabled?'disabled':'')+'></textarea></label><button data-ops="writeLog" '+(!enabled?'disabled':'')+'>'+t('保存记录','Save note')+'</button>'+s.operations.maintenanceLog.entries.slice().reverse().map(e=>'<article class="ops-written-entry"><small>D'+e.day+' · '+esc(Abyss.I18n.text(Abyss.HomeData.rooms.find(d=>d.id===e.room)?.name||e.room))+(e.recalledDay?' · D'+e.recalledDay+' '+t('再次翻阅','revisited'):'')+'</small><p>'+esc(e.text)+'</p></article>').join('')+'</section>';
 }
 return {fresh,read,write,recall,html};
})();
