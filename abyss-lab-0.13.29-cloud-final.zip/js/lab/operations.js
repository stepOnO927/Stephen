'use strict';
// One daily coordinator. Existing Climate/Garden/Infirmary retain their own resource and progression logic.
Abyss.LabOperations=(()=>{
 const D=Abyss.LabOperationsData,U=Abyss.Util,t=Abyss.HomeData.t;
 const clamp=(v,min=0,max=100)=>Math.max(min,Math.min(max,v));
 function random(s){const o=s.operations;o.rng=(Math.imul(o.rng??(s.rng^0x4c4142),1664525)+1013904223)>>>0;return o.rng/4294967296;}
 const result=(ok,zh,en)=>({ok,message:t(zh,en)});
 const level=o=>Math.min(20,1+Math.floor(Math.sqrt(o.xp/12)));
 function active(s,d){if(d.climate)return !!s.climate.equipment[d.climate];return s.home.rooms[d.room]?.level>0||d.room==='greenhouse'&&s.greenhouse.unlocked||d.room==='medical'&&s.infirmary.level>0;}
 function note(s,room,zh,en,kind='maintenance'){
  const o=s.operations,entry={day:s.day,room,zh,en,kind};o.notes.push(entry);o.notes=o.notes.slice(-100);
  const report=o.reports.find(p=>p.day===s.day);if(report){report.evening.push({zh,en,kind});report.evening=report.evening.slice(-40);}
 }
 function actors(s){
  const o=s.operations,rows=[{id:'jack',name:'Jack',kind:'jack',duties:D.duties.map(d=>d.id)}];
  if(s.legacy.active&&s.campaign?.creatureAlive!==false&&s.narrative.languageStage>=1)rows.push({id:'b07',name:s.name,kind:'b07',duties:['greenhouse','infirmary','security','cleaning']});
  for(const pet of s.pets.filter(p=>p.alive&&!p.escaped)){
   const roles=({cat:['greenhouse','security'],mouse:['infirmary'],moth:['greenhouse'],bird:['security'],hound:['security','infirmary'],drone:['maintenance','cleaning'],beetle:['greenhouse']})[pet.species];
   if(roles)rows.push({id:pet.id,name:pet.name,kind:'pet',duties:roles});
  }
  for(const id of o.residents){const n=Abyss.StreetData.people.find(n=>n.id===id);if(n&&s.street.people[id]?.alive!==false&&s.underground.npcAlive[id]!==false)rows.push({id,name:n.name,kind:'npc',duties:D.duties.map(d=>d.id)});}
  return rows;
 }
 function personnel(s,id){return s.operations.people[id]||=({fatigue:0,morale:70,streak:0,reliability:id==='jack'?90:70});}
 function patient(s,id){return s.infirmary.patients.find(p=>p.id===id);}
 const atLab=s=>Abyss.Road.atLab(s)&&!s.wasteland.active&&!s.exploration?.active;
 function available(s,id,duty){const a=actors(s).find(a=>a.id===id),d=D.duties.find(d=>d.id===duty);const away=a&&(a.kind==='jack'||a.kind==='b07'||a.kind==='pet'&&s.pets.find(p=>p.id===a.id)?.active)&&!atLab(s);return !away&&!(a?.kind==='b07'&&s.awaySince)&&!!a&&!!d&&Abyss.LabRooms.canEnter(s,d.room)&&a.duties.includes(duty)&&!patient(s,id)?.quarantine&&!(patient(s,id)?.conditions||[]).some(c=>c.status!=='RECOVERED'&&['SEVERE','CRITICAL'].includes(c.severity));}
 function conditionName(v){return v<=0?'BROKEN':v<20?'FAILING':v<45?'POOR':v<70?'WORN':'GOOD';}
 function powered(s,room){const power=s.climate.labResources.power;if(power<10)return false;if(power>=25)return true;return room==='containment'||room===({medical:'medical',greenhouse:'greenhouse',security:'observation',living:'living'})[s.operations.policy];}
 function online(s,id){const d=D.equipment.find(e=>e.id===id);return !!d&&active(s,d)&&s.operations.equipment[id].condition>=20&&powered(s,d.room);}
 function radioReady(s){return s.mode==='raising'&&s.operations.lastRadioDay===s.day&&Abyss.LabRooms.canEnter(s,'radio')&&online(s,'radio');}
 function securityReady(s){return s.mode==='raising'&&s.operations.lastSecurityDay===s.day&&Abyss.LabRooms.canEnter(s,'observation')&&online(s,'camera')&&s.operations.equipment.lock.condition>=20;}
 function radioBriefing(s){if(!radioReady(s))return [];return Abyss.CaravanData.caravans.flatMap(d=>{const r=s.caravan.routes[d.id];if(!r?.alive||r.hidden)return [];const loc=Abyss.Caravans.location(s,d);if(!loc.present&&loc.eta>1)return [];return [{id:d.id,name:d.name,place:loc.place,present:loc.present,eta:loc.eta,attacks:r.attacks}];}).slice(0,6);}
 const residentCapacity=s=>Abyss.LabRooms.canEnter(s,'quarters')?Math.min(8,Math.max(1,s.home.rooms.quarters.level)*2):0;
 function resident(s,id){return s.mode==='raising'&&!!s.operations?.residents.includes(id);}
 const npcAtLab=(s,id)=>resident(s,id)||!!Abyss.LabVisitors?.admitted(s,id);
 function cost(s,id){const d=D.equipment.find(d=>d.id===id),e=s.operations.equipment[id];if(!d||!e)return null;const skill=level(s.operations);return {credits:Math.ceil((Math.ceil((100-e.condition)/5)+8)*(1-Math.min(.15,(skill-1)*.008))),parts:e.condition<20&&skill<14?2:1,scrap:e.condition<20?Math.max(1,3-Math.floor(skill/8)):1,ap:1};}
 function repairLearning(s,room){const o=s.operations,p=o.repairLearning;if(p.lastDay===s.day||!s.legacy.active||s.campaign?.creatureAlive===false||s.awaySince||s.narrative.languageStage<1||s.stats.loyalty<65||s.stats.mood<40||s.resentment>25||s.personality.curious<30)return;
  p.lastDay=s.day;p.observations++;const tool=['wrench10','pliers','filterKey'][(p.observations-1)%3],place=['trayLeft','trayRight','lowerShelf'][(p.observations-1)%3];p.toolLocations[tool]=place;
  const wrong=s.stats.intelligence<30&&random(s)<.2;if(wrong){p.mistakes++;note(s,room,'它把一截胶带递给松开的管接头。Jack把胶带放回去，拿了管钳。','It offers tape for the loose pipe joint. Jack puts the tape back and takes the pipe wrench.','routine');}
  else {p.helped++;note(s,room,p.observations===1?'它先看Jack的手，又看工具盘。下一件工具被推到了盘边。':'Jack伸手时，工具已经在盘边。它指了一下原来的位置。',p.observations===1?'It watches Jack’s hands, then the tray. The next tool is pushed to the edge.':'When Jack reaches, the tool is at the tray’s edge. It points to the old position.','routine');}
 }
 function command(s,type,p={}){
  const o=s.operations,d=D.equipment.find(d=>d.id===p.equipment),e=d&&o.equipment[d.id];
  if(s.mode!=='raising'||!atLab(s)||s.pendingEvent||s.dreams.active||s.awaySince)return result(false,'先返回实验室并结束当前事件。','Return to the lab and resolve the active event first.');
  if(type==='writeLog')return Abyss.LabMaintenanceLog.write(s,p);
  if(type==='kitchenPolicy')return Abyss.LabMeals.policy(s,p);
  if(type==='incident')return Abyss.LabRoomIncidents.command(s,p);
  if(type==='visitor')return Abyss.LabVisitors.command(s,p);
  if(type==='supplyOrder'||type==='receiveDelivery')return Abyss.LabTrade.command(s,type==='supplyOrder'?'order':'receive',p);
  if(type==='presentReport'){let report=o.reports.find(r=>r.day===s.day);if(report?.presented||report?.read)return result(false,'今天的晨报已展示。','Today’s briefing was already shown.');if(!report){report={day:s.day,read:false,presented:false,archived:false,snapshot:summary(s),evening:[]};o.reports.push(report);o.reports=o.reports.slice(-60);}report.snapshot=summary(s);report.presented=true;return result(true,'','');}
  if(type==='markReport'){let report=o.reports.find(r=>r.day===Number(p.day));if(!report&&Number(p.day)===s.day){report={day:s.day,read:false,presented:false,archived:false,snapshot:summary(s),evening:[]};o.reports.push(report);}if(!report)return result(false,'没有这一天的报告。','No report for that day.');report.presented=true;report.read=true;report.archived=p.archive===true;return result(true,'报告已归档。','Report filed.');}
  if(type==='readReturn'){if(o.returnReport)o.returnReport.read=true;return result(true,'返家记录已保存。','Return report saved.');}
  if(type==='priority'){if(!e||!D.priorities.includes(p.priority))return result(false,'未知设备或优先级。','Unknown equipment or priority.');e.priority=p.priority;return result(true,'维修优先级已保存。','Maintenance priority saved.');}
  if(type==='powerPolicy'){if(!['medical','greenhouse','security','living'].includes(p.policy))return result(false,'未知供电优先项。','Unknown power priority.');o.policy=p.policy;return result(true,'应急供电顺序已保存。','Emergency power priority saved.');}
  if(type==='assign'){const duty=D.duties.find(d=>d.id===p.duty);if(!duty)return result(false,'未知值班岗位。','Unknown duty.');if(!p.actor){delete o.roster[duty.id];return result(true,'该岗位留空休息。','Duty cleared for rest.');}
   if(!available(s,p.actor,duty.id)||Object.entries(o.roster).some(([key,id])=>key!==duty.id&&id===p.actor))return result(false,'角色不适合这个岗位、需要治疗，或已在另一岗位值班。','Actor is unsuitable, needs treatment, or already holds another duty.');o.roster[duty.id]=p.actor;return result(true,'排班已保存。','Roster saved.');}
  if(type==='autoRoster'){o.roster={};for(const duty of [...D.duties].sort((a,b)=>(a.id==='maintenance'?-1:b.id==='maintenance'?1:0))){const candidates=actors(s).filter(a=>available(s,a.id,duty.id)&&!Object.values(o.roster).includes(a.id)&&personnel(s,a.id).fatigue<70).sort((a,b)=>skill(s,b,duty.id)-skill(s,a,duty.id));if(candidates.length)o.roster[duty.id]=candidates[0].id;}return result(true,'根据技能安排了一人一岗；偏好仍需你检查。','Assigned one duty per actor by skill; review their preferences.');}
  if(type==='invite'){if(Abyss.LabVisitors?.admitted(s,p.actor)?.care==='INPATIENT')return result(false,'先完成留院照护和出院手续。','Complete inpatient care and discharge first.');const n=Abyss.StreetData.people.find(n=>n.id===p.actor),r=n&&s.street.people[n.id];if(!Abyss.LabRooms.canEnter(s,'quarters')||!n||!r?.visits||r.alive===false||s.underground.npcAlive[n.id]===false||r.trust<50||o.residents.length>=residentCapacity(s)||o.residents.includes(n.id))return result(false,'需要已认识、愿意入住的人和空床位。','Requires an acquainted, willing resident and a free bed.');o.residents.push(n.id);note(s,'living',n.name+'确认了临时住处。',n.name+' accepts temporary quarters.','visitor');return result(true,'入住登记已保存。','Resident registered.');}
  if(type==='release'){if(!o.residents.includes(p.actor))return result(false,'此人没有入住。','This person is not a resident.');o.residents=o.residents.filter(id=>id!==p.actor);for(const k of Object.keys(o.roster))if(o.roster[k]===p.actor)delete o.roster[k];return result(true,'结束入住；关系与人物记录保留。','Residency ended; relationships and records remain.');}
  if(type==='parts'){if(!D.parts.some(d=>d.id===p.part)||s.hunt.materials<2||s.ap<1)return result(false,'制造维修件需要1行动点和2份废料。','Fabricating a part requires 1 AP and 2 scrap.');s.ap--;s.hunt.materials-=2;o.parts[p.part]+=s.roomSystems.rooms.workshop.specialization==='fabrication'?2:1;return result(true,'维修件已入库。','Maintenance part stored.');}
  if(type==='automation'){if(!['autoCleaning','autoMaintenance'].includes(p.kind)||o[p.kind]||s.money<180||s.hunt.materials<6||level(o)<3)return result(false,'自动设备需要维修等级3、180资金和6废料。','Automation requires maintenance level 3, 180 credits and 6 scrap.');s.money-=180;s.hunt.materials-=6;o[p.kind]=true;return result(true,'自动设备已安装；大故障仍需手动修理。','Automation installed; major failures still require manual repairs.');}
  if(type==='clean'){if(s.ap<1||s.climate.labResources.water<2)return result(false,'清理需要1行动点和2水。','Cleaning requires 1 AP and 2 water.');s.ap--;s.climate.labResources.water-=2;o.cleanliness=clamp(o.cleanliness+22);note(s,'living','Jack清理了积灰，没有把每个房间重新擦一遍。','Jack clears accumulated dust without scrubbing every room.','maintenance');return result(true,'积灰已清理。','Accumulated dust cleared.');}
  if(type==='repair'){const c=cost(s,p.equipment);if(!e||!active(s,d)||s.home.rooms[d.room].sealed||s.home.rooms[d.room].lost||e.condition>=96||s.ap<c.ap||s.money<c.credits||s.hunt.materials<c.scrap||o.parts[d.part]<c.parts)return result(false,'检查设备、行动点、资金、废料和专用维修件。','Check equipment, AP, credits, scrap and the matching repair parts.');
   const major=e.condition<40;s.ap-=c.ap;s.money-=c.credits;s.hunt.materials-=c.scrap;o.parts[d.part]-=c.parts;e.condition=clamp(e.condition+40+level(o));e.wear=0;e.lastMaintenanceDay=s.day;e.warned=0;o.xp+=major?10:6;
   for(const chain of o.chains)if(D.chains.find(d=>d.id===chain.id)?.source===d.id)chain.resolved=true;
   if(d.climate&&Object.hasOwn(s.climate.maintenance,d.id))s.climate.maintenance[d.id]=e.condition;
   note(s,d.room,d.name+'已修理，旧磨损记录仍保留。',d.en+' repaired; the wear record is retained.');repairLearning(s,d.room);o.firsts.repair||=s.day;if(major)Abyss.LabOperationalMemories.record(s,'majorRepair',{room:d.room,equipment:d.id});return result(true,'维修完成。','Repair completed.');}
  return result(false,'未知运营操作。','Unknown lab operation.');
 }
 function skill(s,a,duty){if(a.kind==='jack')return duty==='maintenance'?85+level(s.operations)/2:duty==='security'?78:['kitchen','infirmary','greenhouse'].includes(duty)?42:65;
  if(a.kind==='b07')return Math.min(85,40+s.stats.intelligence/3)+(duty==='greenhouse'?(s.personality.curious||0)/10:0);
  if(a.kind==='pet')return 55;const n=Abyss.StreetData.people.find(n=>n.id===a.id);return /doctor|medic|nurse/.test(n?.role||'')&&duty==='infirmary'?88:/engineer|mechanic/.test(n?.role||'')&&duty==='maintenance'?88:65;}
 function preference(s,a,duty){if(a.kind==='jack')return duty==='maintenance'?1:duty==='cleaning'?-.3:0;if(a.kind==='b07')return duty==='greenhouse'?(s.personality.curious||0)/100:duty==='infirmary'?(s.personality.affectionate||0)/100:duty==='security'?(s.personality.timid||0)/-100:0;if(a.kind==='pet')return a.duties[0]===duty?.7:0;const n=Abyss.StreetData.people.find(n=>n.id===a.id);return /doctor|medic|nurse/.test(n?.role||'')?(duty==='infirmary'?1:duty==='security'?-.5:0):/engineer|mechanic/.test(n?.role||'')?(duty==='maintenance'?1:0):/guard|veteran|government|soldier/.test(n?.role||'')?(duty==='security'?1:0):/cook|farmer/.test(n?.role||'')?(duty==='kitchen'||duty==='greenhouse'?1:0):0;}
 function dutyDay(s){
  const o=s.operations,worked=new Set(),completed=new Set();o.locations={};
  const reserved=new Set(Object.values(o.roster));
  for(const [id,scheduled] of Object.entries(o.roster)){
   const duty=D.duties.find(d=>d.id===id);let actor=scheduled,a=actors(s).find(a=>a.id===actor);if(!duty||worked.has(actor))continue;
   if(!a||!available(s,actor,id)||personnel(s,actor).fatigue>85){
    if(a)note(s,duty.room,a.name+'今天休班。',a.name+' takes the day off.','duty');
    // Cover only this shift. Never steal another rostered actor or overwrite the saved roster.
    const relief=actors(s).filter(x=>!reserved.has(x.id)&&!worked.has(x.id)&&available(s,x.id,id)&&personnel(s,x.id).fatigue<70)
     .sort((x,y)=>skill(s,y,id)-skill(s,x,id)||x.id.localeCompare(y.id))[0];
    if(!relief){note(s,duty.room,'没有合适的替班人员，这班留空。','No suitable relief is available; the shift stays vacant.','duty');continue;}
    actor=relief.id;a=relief;note(s,duty.room,a.name+'临时接了这一班；原排班保留。',a.name+' covers this shift; the regular roster is retained.','relief');
   }
   if(Abyss.LabRoutineTransitions.electrical.has(id)&&!powered(s,duty.room)){note(s,duty.room,'供电不足，这班暂时停下。','Insufficient power pauses this shift.','duty');continue;}
   const p=personnel(s,actor),med=patient(s,actor);
   worked.add(actor);p.streak++;p.morale=clamp(p.morale+preference(s,a,id)*.8-(p.streak>4?.7:0));p.fatigue=clamp(p.fatigue+5+(p.streak>4?3:0));o.locations[actor]=duty.room;
   const refuse=a.kind==='b07'&&(s.resentment>55||s.stats.mood<25)&&random(s)<.35;
   if(refuse){note(s,duty.room,'它没有接过工具。Jack把这班留空。','It does not take the tools. Jack leaves the shift empty.','duty');continue;}
   const efficiency=Math.min(.95,skill(s,a,id)/100*(1-p.fatigue/150)*(.8+p.morale/250)*(.8+p.reliability/350)),success=random(s)<efficiency;
   if(!success){p.reliability=clamp(p.reliability-.15);note(s,duty.room,a.name+'这一班没有完成全部工作。',a.name+' does not finish everything on this shift.','duty');if(med)med.stress=clamp(med.stress+1);continue;}
   p.reliability=clamp(p.reliability+.25);
   if(id==='greenhouse')for(const plant of s.greenhouse.plants)plant.health=clamp(plant.health+.8);
   if(id==='infirmary')for(const p of s.infirmary.patients.filter(p=>Abyss.Infirmary.living(s,p)&&(p.hostType==='NPC'?npcAtLab(s,p.id):atLab(s)&&(p.id==='jack'||p.id==='b07'||!s.pets.find(x=>x.id===p.id)?.active))))p.medicalTrust=clamp(p.medicalTrust+.3);
   if(id==='security'){s.home.conditions.security=clamp(s.home.conditions.security+.5);if(online(s,'camera')&&o.equipment.lock.condition>=20){o.lastSecurityDay=s.day;const next=Abyss.Home.upcoming?.(s,s.day+1);if(next?.type==='attack')note(s,'observation','门岗发现培养舱外侧有人试过门锁，明天需要检查入口。','Gate duty finds signs of a lock test outside containment; check the entrance tomorrow.','security');}}
   if(id==='maintenance'){const candidate=D.equipment.filter(d=>active(s,d)&&o.equipment[d.id].condition>45&&o.equipment[d.id].condition<95).sort((a,b)=>D.priorities.indexOf(o.equipment[b.id].priority)-D.priorities.indexOf(o.equipment[a.id].priority)||o.equipment[a.id].condition-o.equipment[b.id].condition)[0];if(candidate){const equipment=o.equipment[candidate.id];equipment.condition=clamp(equipment.condition+.5);if(candidate.climate&&Object.hasOwn(s.climate.maintenance,candidate.id))s.climate.maintenance[candidate.id]=equipment.condition;}}
   if(id==='cleaning')o.cleanliness=clamp(o.cleanliness+1.1);
   if(id==='kitchen'){o.kitchenCare=.8;}
   if(id==='radio'){if(!online(s,'radio')){note(s,duty.room,'接收机没有启动；值班员留下检修记录。','The receiver stays off; the operator records a service request.','duty');continue;}o.firsts.radioDuty||=s.day;o.lastRadioDay=s.day;}
   let routine=o.routines.find(r=>r.subject===actor&&r.action===id);if(!routine){routine={routineId:actor+':'+id,subject:actor,action:id,timePreference:id==='radio'?'morning':'evening',location:duty.room,frequency:0,strength:0,interrupted:false};o.routines.push(routine);}
   routine.frequency++;routine.strength=clamp(routine.strength+3);completed.add(actor+':'+id);Abyss.LabDutyObservations.successful(s,id);
  }
  for(const [id,p]of Object.entries(o.people))if(!worked.has(id)){p.fatigue=clamp(p.fatigue-10);p.streak=0;p.morale=clamp(p.morale+.6);}
  Abyss.LabRoutineTransitions.finish(s,completed);
  o.routines=o.routines.slice(-40);
 }
 function faults(s){const o=s.operations;
  for(const d of D.equipment){if(!active(s,d))continue;const e=o.equipment[d.id],wear=d.wear*(s.climate.labResources.power<10?.6:1);e.wear+=wear;e.condition=clamp(e.condition-wear);if(d.climate&&Object.hasOwn(s.climate.maintenance,d.id)){e.condition=Math.min(e.condition,s.climate.maintenance[d.id]);s.climate.maintenance[d.id]=e.condition;}
   if(o.autoMaintenance&&e.condition>45&&o.parts[d.part]>0&&e.condition<70){o.parts[d.part]--;e.condition=clamp(e.condition+12);if(d.climate&&Object.hasOwn(s.climate.maintenance,d.id))s.climate.maintenance[d.id]=e.condition;note(s,d.room,'自动检修更换了'+d.name+'的小零件。','Automatic service replaces a small part in '+d.en+'.');}
   if(e.condition<45&&e.warned<1){e.warned=1;note(s,d.room,d.name+'运行声音变了；建议检修。',d.en+' sounds different; service is recommended.');}
   if(e.condition<20&&e.warned<2){e.warned=2;note(s,d.room,d.name+'接近停机。',d.en+' is close to failure.','critical');Abyss.LabMaintenanceLog.recall(s,d.id);}
  }
  for(const d of D.chains){const e=o.equipment[d.source],definition=D.equipment.find(x=>x.id===d.source);if(!active(s,definition))continue;
   let chain=o.chains.find(c=>c.id===d.id&&!c.resolved);if(e.condition<20&&!chain){chain={id:d.id,start:s.day,stage:0,resolved:false};o.chains.push(chain);note(s,d.room,'连续故障需要检查源设备。','A developing fault needs its source equipment checked.');}
   if(!chain)continue;if(e.condition>=45){chain.resolved=true;continue;}
   const age=s.day-chain.start;if(age>=d.later)chain.stage=2;else if(age>=d.after)chain.stage=1;
   if(chain.stage){if(d.id==='waterLeak'){s.home.conditions.air=clamp(s.home.conditions.air-(chain.stage===2?1.4:.3));s.home.conditions.structure=clamp(s.home.conditions.structure-.2);}
    if(d.id==='airClog')s.home.conditions.air=clamp(s.home.conditions.air-(chain.stage===2?1:.3));
    if(d.id==='powerDrop'){s.climate.labResources.power=clamp(s.climate.labResources.power-1);if(chain.stage===2)for(const p of s.greenhouse.plants)p.growth=Math.max(0,p.growth-.5);}
    if(d.id==='doorFault')s.home.conditions.security=clamp(s.home.conditions.security-.8);
   }
  }o.chains=o.chains.filter(c=>!c.resolved||s.day-c.start<14).slice(-8);
 }
 function beginDay(before,s){if(s.mode!=='raising'||s.day<=before.day||s.operations.lastDay>=s.day)return;
  const o=s.operations,end=s.day,extra=o.residents.filter(id=>actors(s).some(a=>a.id===id)).length;
  try{for(let day=o.lastDay+1;day<=end;day++){s.day=day;o.cleanliness=clamp(o.cleanliness-.18-(extra+s.pets.filter(p=>p.alive&&!p.escaped).length)*.04+(o.autoCleaning?.35:0));o.kitchenCare=0;faults(s);dutyDay(s);Abyss.LabEvents?.tick(s);Abyss.LabRoomIncidents?.tick(s);Abyss.LabVisitors?.tick(s);Abyss.LabTrade?.tick(s);
   Abyss.LabMeals.tick(s);
   if(active(s,D.equipment.find(d=>d.id==='airFilter'))&&powered(s,'engineering'))s.home.conditions.air=clamp(s.home.conditions.air+(online(s,'airFilter')?.45*s.operations.equipment.airFilter.condition/100:-.25));
  }}finally{s.day=end;}
  if(o.cleanliness<25){s.home.conditions.air=clamp(s.home.conditions.air-.4);s.greenhouse.ecology.pests=clamp(s.greenhouse.ecology.pests+.3);}
  const furnished=Object.values(s.home.rooms).reduce((n,r)=>n+r.objects.length,0);o.comfort=clamp((o.cleanliness+s.home.conditions.temperature+s.home.conditions.air)/3+Math.min(15,furnished*.6)+(o.kitchenCare||0));
  o.lastDay=s.day;
 }
 function summary(s){const o=s.operations,r=s.climate.labResources,living=actors(s).length,weather=Abyss.Climate.conditions(s,'central',false);
  const equipment=D.equipment.filter(d=>active(s,d)).map(d=>({id:d.id,name:d.name,en:d.en,room:d.room,condition:+o.equipment[d.id].condition.toFixed(1),status:conditionName(o.equipment[d.id].condition)}));
  const eq=s.climate.equipment,placed=s.bedroom.placed.map(x=>x.id),hot=weather.temperature>32;
  // Use the player's instrument forecast, never the hidden simulation weatherPlan.
  const forecast=s.climate.weatherForecast.central?.find(x=>x.day===s.day+1),device=Abyss.ClimateData.devices.find(d=>d.id===s.climate.device);
  const tasks=equipment.filter(e=>e.condition<45).map(e=>({room:e.room,equipment:e.id,priority:e.condition<20?'CRITICAL':'HIGH',kind:'repair'}));
  if(atLab(s)&&!s.awaySince){
   const cases=s.infirmary.patients.filter(p=>Abyss.Infirmary.living(s,p)&&Abyss.Infirmary.basePatient(s,p)&&p.conditions.some(c=>c.status!=='RECOVERED'));
   if(cases.length)tasks.push({room:'medical',equipment:'',priority:cases.some(p=>p.conditions.some(c=>c.status!=='RECOVERED'&&['SEVERE','CRITICAL'].includes(c.severity)))?'CRITICAL':'HIGH',kind:'medical',count:cases.length});
   const ready=s.greenhouse.plants.filter(p=>p.growth>=100&&p.health>0).length,dry=s.greenhouse.plants.filter(p=>p.health>0&&p.water<25).length;
   if(dry)tasks.push({room:'greenhouse',equipment:'',priority:'HIGH',kind:'water',count:dry});
   if(ready)tasks.push({room:'greenhouse',equipment:'',priority:'NORMAL',kind:'harvest',count:ready});
   const waiting=Abyss.LabVisitors?.current(s).filter(v=>['WAITING','VERIFIED'].includes(v.status)).length||0;
   if(waiting)tasks.push({room:'observation',equipment:'',priority:'NORMAL',kind:'visitors',count:waiting});
   const deliveries=Abyss.LabTrade?.pending(s).filter(x=>x.dueDay<=s.day).length||0;
   if(deliveries)tasks.push({room:'storage',equipment:'',priority:'NORMAL',kind:'delivery',count:deliveries});
  }
  tasks.sort((a,b)=>['CRITICAL','HIGH','NORMAL'].indexOf(a.priority)-['CRITICAL','HIGH','NORMAL'].indexOf(b.priority));
  const clinicalWater=s.infirmary.patients.filter(p=>Abyss.Infirmary.living(s,p)&&(p.hostType!=='NPC'||npcAtLab(s,p.id))).reduce((n,p)=>n+Abyss.ClinicalEffects.aggregate(p).water,0);
  const rates={food:.4+(hot&&!eq.fridge?.6:0)+(o.residents.length+(Abyss.LabVisitors?.inpatients(s).length||0))*.3,water:Math.max(0,.5+(hot?.65:0)+(o.residents.length+(Abyss.LabVisitors?.inpatients(s).length||0))*.35+clinicalWater-(eq.filter&&s.climate.maintenance.filter>20?.45*(active(s,D.equipment.find(d=>d.id==='pump'))?Math.min(1,o.equipment.pump.condition/80):1):0)-(eq.rain&&['rain','heavy_rain'].includes(weather.id)?1.4:0)-(eq.tank?.15:0)-(placed.includes('climate_furniture_tank')?.12:0)),fuel:(eq.generator?.35:0)+(s.climate.currentSeason==='winter'&&eq.heater?.4:0),medicine:.05};
  return {base:{power:r.power<10?'BLACKOUT':r.power<25?'CRITICAL':r.power<45?'LOW':r.power<65?'UNSTABLE':'STABLE',air:s.home.conditions.air,temperature:s.home.conditions.temperature,structure:s.home.conditions.structure,cleanliness:o.cleanliness,contamination:s.home.conditions.contamination,security:s.home.conditions.security,comfort:o.comfort,home:furnishedStage(s)},
   resources:Object.fromEntries(Object.keys(r).map(k=>[k,{amount:+r[k].toFixed(1),days:rates[k]?Math.floor(r[k]/rates[k]):null}])),
   greenhouse:{ready:s.greenhouse.plants.filter(p=>p.growth>=100&&p.health>0).length,stressed:s.greenhouse.plants.filter(p=>p.health<45).length,water:s.greenhouse.plants.filter(p=>p.water<25).length},
   infirmary:s.infirmary.patients.filter(p=>Abyss.Infirmary.living(s,p)&&(p.hostType!=='NPC'||npcAtLab(s,p.id))&&p.conditions.some(c=>c.status!=='RECOVERED')).map(p=>({id:p.id,quarantine:p.quarantine,conditions:p.conditions.filter(c=>c.status!=='RECOVERED').map(c=>({id:c.id,status:c.status,severity:c.severity}))})),
   tradeReceipts:(s.operations.trade?.receipts||[]).filter(x=>x.day===s.day).slice(-12),doorVisits:Abyss.LabVisitors?.current(s).map(v=>({id:v.id,name:Abyss.LabVisitors.name(v),status:v.status,quarantined:v.quarantined,care:v.care==='INPATIENT'?'INPATIENT':'NONE'}))||[],security:{doors:s.home.rooms.containment.sealed?'SEALED':o.equipment.lock.condition<20?'FAILING':'CHECKED',camera:conditionName(o.equipment.camera.condition)},
   visitors:Abyss.CaravanData.caravans.filter(d=>s.caravan.routes[d.id]?.visit>0||radioBriefing(s).some(v=>v.id===d.id)).map(d=>({id:d.id,name:d.name,place:Abyss.Caravans.location(s,d).place,present:Abyss.Caravans.location(s,d).present,eta:Abyss.Caravans.location(s,d).eta,radioConfirmed:radioBriefing(s).some(v=>v.id===d.id)})).slice(0,6),news:s.infirmary.newsChains.records.filter(n=>!['CLOSED','EXPIRED'].includes(n.status)).slice(0,3).map(n=>({number:n.number,status:n.status})),
   weather:{id:weather.id,temperature:weather.temperature,...(forecast?{forecast:{day:forecast.day,id:forecast.id,device:device.id,accuracy:device.accuracy}}:{})},maintenance:equipment,b07:{location:atLab(s)&&!s.awaySince?(Abyss.LabRoomData.rooms.find(r=>Abyss.LabRooms.characters(s,r.id).some(a=>a.id==='b07'))?.id||s.home.location):'away',observed:s.campaign?.creatureAlive===false||!s.legacy.active?'ARCHIVED':!atLab(s)||s.awaySince?'AWAY':s.stats.hunger>75?'MEAL MISSED':s.infirmary.patients.find(p=>p.id==='b07')?.sleep<35?'RESTLESS':'ATE NORMALLY'},
   pets:s.pets.filter(p=>p.alive&&!p.escaped).map(p=>({id:p.id,name:p.name,health:p.health,stress:p.stress})),tasks:tasks.slice(0,20),personnel:living};
 }
 function furnishedStage(s){const objects=Object.values(s.home.rooms).reduce((n,r)=>n+r.objects.length,0),o=s.operations;return objects>=8&&o.routines.some(r=>r.strength>=50)&&o.comfort>65?'HOME':objects>=4?'LIVED-IN':s.day-o.startDay>=7?'SHELTER':'FACILITY';}
 function finish(before,s,c){if(s.mode!=='raising')return;const o=s.operations;
  Abyss.LabVisitors?.tick(s);Abyss.LabTrade?.tick(s);
  for(const d of D.equipment)if(d.climate&&Object.hasOwn(s.climate.maintenance,d.id)&&c.type!=='climate:repair'){const value=Math.min(o.equipment[d.id].condition,s.climate.maintenance[d.id]);o.equipment[d.id].condition=value;s.climate.maintenance[d.id]=value;}
  if(c.type==='climate:repair'){const d=D.equipment.find(d=>d.id===c.payload?.id);if(d&&Object.hasOwn(s.climate.maintenance,d.id)){const e=o.equipment[d.id];e.condition=s.climate.maintenance[d.id];e.wear=0;e.warned=0;e.lastMaintenanceDay=s.day;for(const chain of o.chains)if(D.chains.find(d=>d.id===chain.id)?.source===d.id)chain.resolved=true;}}
  if(atLab(before)&&!atLab(s)&&!o.away)o.away={day:before.day,resources:{...before.climate.labResources}};
  if(o.away&&atLab(s)){o.returnReport={day:s.day,days:s.day-o.away.day,read:false,resources:Object.fromEntries(Object.keys(o.away.resources).map(k=>[k,+(s.climate.labResources[k]-o.away.resources[k]).toFixed(1)])),notes:o.notes.filter(n=>n.day>=o.away.day).slice(-20),snapshot:summary(s)};note(s,'engineering','Jack回来检查了离开期间的记录。','Jack returns and checks the records kept while he was away.','return');o.away=null;}
  Abyss.LabPersonalRoutines.finish(before,s,c);Abyss.LabDutyObservations.finish(before,s);Abyss.LabOperationalMemories.finish(before,s,c);Abyss.LabNightReport.capture(before,s);
  if(!o.reports.some(r=>r.day===s.day))o.reports.push({day:s.day,read:false,presented:false,archived:false,snapshot:summary(s),evening:o.notes.filter(n=>n.day===s.day).map(n=>({zh:n.zh,en:n.en,kind:n.kind}))});
  o.reports=o.reports.slice(-60);
  if(c.type==='garden:harvest')o.firsts.harvest||=s.day;if(c.type==='medical:treat')o.firsts.patient||=s.day;if(s.climate.labResources.power<10)o.firsts.blackout||=s.day;
 }
 function alerts(s){if(s.mode!=='raising'||!atLab(s))return [];const rows=[];
  if(s.climate.labResources.power<10)rows.push({id:'POWER_FAILURE',room:'power'});
  if(s.infirmary.patients.some(p=>Abyss.Infirmary.living(s,p)&&Abyss.Infirmary.basePatient(s,p)&&!(p.id==='b07'&&s.awaySince)&&(Abyss.Infirmary.health(s,p)<20||p.conditions.some(c=>c.status!=='RECOVERED'&&c.severity==='CRITICAL'))))rows.push({id:'PATIENT_CRITICAL',room:'medical'});
  if(s.home.crisis?.type==='attack'||Abyss.LabVisitors?.current(s).some(v=>v.person==='impostor43'&&v.status==='ADMITTED'))rows.push({id:'INTRUDER',room:'observation'});
  if(s.home.crisis?.type==='fire')rows.push({id:'FIRE',room:s.home.crisis.room});
  if(s.home.crisis?.type==='leak'||s.home.conditions.contamination>=75)rows.push({id:'CONTAMINATION_LEAK',room:s.home.crisis?.type==='leak'?s.home.crisis.room:'engineering'});
  return rows;
 }
 return {active,actors,available,personnel,conditionName,cost,command,skill,beginDay,finish,summary,level,note,furnishedStage,powered,online,radioReady,radioBriefing,securityReady,random,resident,npcAtLab,preference,atLab,residentCapacity,alerts};
})();


