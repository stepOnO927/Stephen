'use strict';
// Small independent floor props. No inventory or room-state mutation.
Abyss.LabRoomDecorArt=(()=>{
 const shapes={
 lamp:'<path d="M-20-3l18-7 20 7-18 7z" fill="#6e7772"/><path d="M0-5v-44" stroke="#85908a" stroke-width="4"/><path d="M-18-40l7-20h20l10 20z" fill="#bcb393"/><ellipse cy="-40" rx="19" ry="5" fill="#d3c7a0"/>',
 plant:'<path d="M-16-22h32l-5 23h-23z" fill="#8e7461"/><ellipse cy="-22" rx="16" ry="5" fill="#494a36"/><path d="M0-21v-27m0 11q-24-22-20-8q1 15 20 10m0-15q22-20 20-5q-1 11-20 15" stroke="#77927b" fill="#4f7460" stroke-width="2"/>',
 radio:'<path d="M-26-5v-32l13-7h41v31L17-5z" fill="#786a52"/><path d="M-26-37h43v32h-43z" fill="#8a7e66"/><path d="M17-37l11-7v31L17-5z" fill="#4c493c"/><path d="M-20-29h27v8h-27z" fill="#1f3a3e"/><path d="M-18-17h13m-13 4h13m-13 4h13" stroke="#433f36"/><circle cx="9" cy="-12" r="5" fill="#bdac88"/><path d="M22-43l-6-28" stroke="#9aaba6" stroke-width="2"/>',
 toy:'<path d="M-26-9l9-14h29l16 14v8h-54z" fill="#927c69"/><path d="M-9-23v-9h16l10 9z" fill="#607e85"/><path d="M-7-29h9v6h-9z" fill="#b3ccca"/><circle cx="-16" cy="-2" r="7" fill="#172b32"/><circle cx="16" cy="-2" r="7" fill="#172b32"/><path d="M-18-12h25" stroke="#ccab78" stroke-width="2"/>',
 book:'<path d="M-26-13l35-8 19 11-35 9z" fill="#aa9875"/><path d="M-26-13v10l19 11V-1z" fill="#7d5f52"/><path d="M-7-1l35-9v9L-7 8z" fill="#bfb599"/><path d="M-18-13l27-6m-14 2 18 10" stroke="#755846" stroke-width="2"/>',
 blanket:'<path d="M-30-14l34-10 28 13-34 13z" fill="#7e858e"/><path d="M-30-14v13L-2 13V2l34-13v12L-2 13z" fill="#555e6a"/><path d="M-22-13l27-8m-28 16 29-8m-20 17 27-9" stroke="#b5aeb0" stroke-width="2"/>',
 photo:'<path d="M-17-45h35v42h-35z" fill="#977e5b" stroke="#423b31" stroke-width="3"/><path d="M-11-39h23v29h-23z" fill="#b0b2a1"/><path d="M-9-11q5-15 11-7q5-17 10-8v15z" fill="#626a68"/><circle cx="-3" cy="-28" r="4" fill="#6c7670"/><circle cx="8" cy="-32" r="5" fill="#78857a"/><path d="M18-26l12 26H18" fill="#5e5140"/>',
 sculpture:'<path d="M-24-1l24-7 24 7-24 5z" fill="#677576"/><path d="M-3-7v-18m6 17 4-15" stroke="#8f9d96" stroke-width="3"/><path d="M-17-30l18-20 17 7-15 24z" fill="#8e9c99"/><path d="M-13-28l-13-20 30 16z" fill="#647b80"/><path d="M8-40l13-15 12 4-11 10z" fill="#b0b9ac"/><path d="M31-51l8 4-8 3" fill="#a7885f"/>',
 shell:'<path d="M-26-8q3-28 24-30q24 4 28 30q-23 19-52 0z" fill="#c6b79c"/><path d="M-2-34v31m-15-25 10 26m21-25-11 25m-26-17 21 19m25-19-19 19" fill="none" stroke="#8e867c" stroke-width="2"/>',
 map:'<path d="M-30-19l20-5 20 7 21-5v23l-21 6-20-7-20 5z" fill="#b2a37e"/><path d="M-10-24V-1m20-16V7" stroke="#7d785d"/><path d="M-23-15q16 12 27 3q9-6 19-1" stroke="#668e94" fill="none" stroke-width="3"/><path d="M-18-9l8-6m14 9 5-6" stroke="#8d755e"/>',
 mug:'<ellipse cy="-27" rx="15" ry="6" fill="#455e62"/><path d="M-15-27v24q15 10 30 0v-24" fill="#b7b7a3" stroke="#75634d" stroke-width="2"/><path d="M15-23q18-6 16 7q-1 13-16 8" fill="none" stroke="#a9b7b1" stroke-width="5"/><path d="M-4-31l4 6 5-5" stroke="#594b3b" fill="none" stroke-width="2"/><path d="M-12-1l6-2 3 4 10-1" stroke="#75624b" stroke-width="3"/>',
 flower:'<path d="M-26-24l42-9 13 30-41 9z" fill="#ad997e"/><path d="M-9-2l4-18m0 6 10-7m-10 2-10-2" stroke="#718061" stroke-width="2"/><circle cx="-4" cy="-22" r="5" fill="#a68687"/><circle cx="8" cy="-22" r="4" fill="#bfafa1"/><circle cx="-16" cy="-22" r="3" fill="#967d8b"/>'
 };
 function render(id,index){if(!shapes[id])return '';return `<g data-room-decor="${id}" transform="translate(${130+index*66} 342)"><ellipse rx="30" ry="7" fill="#050f1855"/>${shapes[id]}</g>`;}
 return {shapes,render};
})();
