'use strict';
// Successful shifts observe existing simulation results; never diagnose or heal.
Abyss.LabDutyObservations=(()=>{
 const rooms={infirmary:'medical',greenhouse:'greenhouse'};
 const gardenCodes=['WATER','HEALTH','PESTS','CONTAMINATION',...Abyss.PlantHealth.catalog.map(d=>'PH_'+d.id)];
 const fresh=()=>({shifts:{infirmary:0,greenhouse:0},lastDay:0,active:[],records:[]});
 const key=r=>[r.kind,r.subject,r.code,r.started].join(':');
 function read(raw,s){const out=fresh(),day=v=>Number.isInteger(v)&&v>=0&&v<=s.day;
  if(!raw||typeof raw!=='object')return out;
  for(const id of Object.keys(rooms))if(day(raw.shifts?.[id]))out.shifts[id]=raw.shifts[id];
  if(day(raw.lastDay))out.lastDay=raw.lastDay;
  const valid=r=>r&&Object.hasOwn(rooms,r.kind)&&typeof r.subject==='string'&&r.subject.length<=80&&day(r.started)&&r.started>0&&day(r.day)&&r.day>=r.started&&(r.kind==='infirmary'?Abyss.DiseaseData.some(d=>d.diseaseId===r.code)&&s.infirmary.patients.some(p=>p.id===r.subject):gardenCodes.includes(r.code)&&(r.subject==='ecology'||/^plant:\d+$/.test(r.subject)));
  out.records=(Array.isArray(raw.records)?raw.records:[]).filter(valid).slice(-80).map(r=>({kind:r.kind,subject:r.subject,code:r.code,started:r.started,day:r.day}));
  const unique=new Map();for(const r of (Array.isArray(raw.active)?raw.active:[]).filter(valid).slice(-512))unique.set(key(r),{kind:r.kind,subject:r.subject,code:r.code,started:r.started,day:r.day});out.active=[...unique.values()];
  return out;
 }
 function successful(s,duty){if(Object.hasOwn(rooms,duty))s.operations.dutyObservations.shifts[duty]=s.day;}
 function medical(s){return s.infirmary.patients.filter(p=>Abyss.Infirmary.living(s,p)&&Abyss.Infirmary.basePatient(s,p)&&!(p.id==='b07'&&s.awaySince)).flatMap(p=>p.conditions.flatMap(c=>{
  const d=Abyss.DiseaseData.find(d=>d.diseaseId===c.id);
  if(!d||['RECOVERED','INCUBATING'].includes(c.status)||c.days<=d.incubation)return [];
  return [{kind:'infirmary',subject:p.id,code:c.id,started:Math.max(1,s.day-c.days),day:s.day}];
 }));}
 function garden(s){const rows=Abyss.PlantHealth.symptoms(s).map(c=>({kind:'greenhouse',subject:'plant:'+c.uid,code:'PH_'+c.id,started:c.since,day:s.day}));
  for(const p of s.greenhouse.plants.filter(p=>p.health>0))for(const code of [p.water<30?'WATER':null,p.health<70?'HEALTH':null].filter(Boolean))rows.push({kind:'greenhouse',subject:'plant:'+p.uid,code,started:p.plantedDay||1,day:s.day});
  for(const code of [s.greenhouse.ecology.pests>50?'PESTS':null,s.greenhouse.ecology.contamination>25?'CONTAMINATION':null].filter(Boolean))rows.push({kind:'greenhouse',subject:'ecology',code,started:1,day:s.day});
  return rows;
 }
 function description(s,r){if(r.kind==='infirmary'){
   const p=s.infirmary.patients.find(p=>p.id===r.subject),d=Abyss.DiseaseData.find(d=>d.diseaseId===r.code),name=r.subject==='jack'?'Jack':r.subject==='b07'?s.name:s.pets.find(p=>p.id===r.subject)?.name||Abyss.StreetData.people.find(p=>p.id===r.subject)?.name||p?.name||r.subject;
   return [name+'的值班观察：'+d.symptoms.join('、')+'。需要进一步评估，尚未作出诊断。',name+' — duty observations: '+Abyss.ClinicalEnglish.records[r.code].symptoms+'. Further assessment is needed; this is not a diagnosis.'];
  }
  const plant=s.greenhouse.plants.find(p=>'plant:'+p.uid===r.subject),d=plant&&Abyss.Garden.find(plant.plantId),names=d?[d.name,d.en]:['温室','Greenhouse'];
  if(r.code.startsWith('PH_')){const c=s.greenhouse.plantHealth.cases.find(c=>c.uid===plant?.uid&&'PH_'+c.id===r.code),def=Abyss.PlantHealth.catalog.find(d=>'PH_'+d.id===r.code),text=c&&s.day-c.since<def.incubation?def.early:def.symptom;return [names[0]+'：'+text[0],names[1]+': '+text[1]];}
  const text={WATER:['水分偏低，检查灌溉。','Low water; check irrigation.'],HEALTH:['生长状态偏弱，检查水分和环境。','Poor plant condition; check water and environment.'],PESTS:['害虫读数升高，检查叶片与种植间距。','Pest readings are elevated; check leaves and planting spacing.'],CONTAMINATION:['污染读数升高，先检查环境和收获安全。','Contamination readings are elevated; check the environment and harvest safety.']}[r.code];
  return [names[0]+'：'+text[0],names[1]+': '+text[1]];
 }
 function finish(before,s){const o=s.operations.dutyObservations;
  if(s.mode!=='raising'||s.day<=before.day||o.lastDay>=s.day)return;
  o.lastDay=s.day;
  for(const [duty,room]of Object.entries(rooms)){
   if(o.shifts[duty]!==s.day||!Abyss.LabRooms.canEnter(s,room)||!Abyss.LabOperations.powered(s,room))continue;
   if(duty==='greenhouse')Abyss.PlantHealth.observeShift(s);
   const rows=duty==='infirmary'?medical(s):garden(s),previous=new Set(o.active.map(key));
   // Resolve only observations actually revisited on a successful shift.
   o.active=o.active.filter(r=>r.kind!==duty);
   for(const r of rows){const id=key(r);o.active.push(r);if(previous.has(id))continue;
    o.records.push(r);Abyss.LabOperations.note(s,room,...description(s,r),'dutyObservation');
   }
   o.records=o.records.slice(-80);o.active=o.active.slice(-512);
  }
 }
 function html(s,room){if(!['medical','greenhouse'].includes(room))return '';const notes=s.operations.notes.filter(n=>n.room===room&&n.kind==='dutyObservation').slice(-6);if(!notes.length)return '';const en=Abyss.I18n.language()==='en',esc=Abyss.Util.escape;return '<article class="ops-duty-observations"><h3>'+ (en?'Duty observations':'值班观察')+'</h3>'+notes.map(n=>'<p>D'+n.day+' · '+esc(en?n.en:n.zh)+'</p>').join('')+'</article>';}
 return {fresh,read,successful,finish,description,html};
})();
