'use strict';
// Physical layout and room-owned controller links. Dedicated system upgrades stay separate.
Abyss.LabRoomData=(()=>{
 const rows=[
 ['containment',0,0,0,'#719fa5','chamber','hatch','plate','tube','observe','观察B-07','Observe B-07',['food','medical','roomMemory']],
 ['quarters',0,1,0,'#a59273','cot','thread','photo','locker','rest','睡眠','Sleep',['journal','inventory','jasmine']],
 ['living',0,2,0,'#8fa48d','nest','cards','fruit','lamp','wardrobe','衣物与收藏','Clothes & collection',['privacy','bedroom','habits']],
 ['medical',0,0,1,'#c1d8d4','bed','monitor','cabinet','blanket','patients','查看患者','Check patients',['pharmacy','recovery','quarantine']],
 ['genetics',-1,0,0,'#988ab9','scanner','samples','microscope','cooler','mutations','突变分析','Mutation analysis',['experiment','serums','plantArchive']],
 ['engineering',-1,1,0,'#b49a6d','toolwall','breaker','blueprint','cable','maintenance','基地维护','Base maintenance',['power','water','roads']],
 ['kitchen',0,1,1,'#bfa47b','stove','pot','jars','rack','cook','准备餐盒','Prepare a meal box',['food','harvest','pharmacy','jasmine']],
 ['storage',0,2,1,'#a39678','racks','crates','pallet','padlock','inventory','整理库存','Check inventory',['valuables','trade','bedroom']],
 ['greenhouse',-1,2,0,'#a3b884','hydroponics','leaves','tree','quarantineBox','plants','检查种植槽','Check beds',['seeds','ecology','harvest']],
 ['workshop',-1,0,1,'#ac916e','weaponbench','vice','blade','parts','weapons','武器工坊','Weapon workshop',['weapons','parts','roads']],
 ['observation',-1,1,1,'#82a7aa','monitors','camera','blinds','recorder','cameras','观察公共区域','Observe public areas',['habits','pets','visitors']],
 ['archive',-1,2,1,'#9ea2a8','files','terminal','roster','photo','storyFiles','查阅档案','Read archives',['medicalArchive','newsArchive','personnel']],
 ['power',-2,0,0,'#a8aa6f','generator','batteries','breaker','cable','power','供电与分配','Power & distribution',['maintenance','powerPolicy','climate']],
 ['water',-2,1,0,'#80b4b5','tank','filter','pump','pipe','water','净水与供水','Water & filtration',['waterTest','maintenance','ecology']],
 ['radio',-1,3,0,'#8bb59d','radios','map','aerial','notes','news','收听新闻','Listen to news',['visitors','deliveries','caravans','climate','dailyReport']],
 ['hall',-1,3,1,'#a7b1a9','whiteboard','projector','stations','charts','research','规划研究','Plan research',['plantArchive','diseaseArchive','mutations']],
 ['lower',-2,2,0,'#a5966e','barrier','cable','debris','lamp','survey','调查下层设施','Survey lower facilities',['restore','materials','leave']],
 ['zero',-3,0,0,'#a9aaa7','airlock','emptyGauge','reader','tube','zeroArchive','零号资料','Zero archive',['continuity','survey','leave']],
 ['black',-3,1,0,'#8d7c81','authority','terminal','seal','orders','blackOrders','权限与指令','Clearance & orders',['research','storyFiles','e3']],
 ['crawl',-2,3,0,'#baa780','pipes','crawlHatch','junction','chalk','repairBypass','检查维修旁路','Inspect service bypass',['maintenance','materials','survey']],
 ['nursery',-2,0,1,'#b2a091','incubators','toy','emptyCot','tags','pets','照看获救生物','Care for rescued creatures',['patients','storyFiles','roomMemory']],
 ['series',-2,1,1,'#98a2b5','relicCases','bowl','roster','tags','seriesRelics','查看B系列遗物','View B-series traces',['storyFiles','objects','roomMemory']],
 ['surgery',-2,2,1,'#b5c4c1','surgicalTable','lamp','sealedTools','monitor','advancedMedical','高级照护','Advanced care',['recovery','medicalArchive','survey']],
 ['sublevel',-3,2,0,'#748f9e','ventShaft','debris','cable','panel','survey','深层设施调查','Survey deep infrastructure',['restore','materials','leave']],
 ['stairs',-3,3,0,'#a39b8d','stairs','chalk','lamp','landing','steps','数台阶','Count steps',['markSteps','listen','leave']],
 ['core',-3,2,1,'#9badbb','reactor','coils','relay','shield','corePower','查看动力核','Check core power',['coreOverride','maintenance','continuity']],
 ['unnumbered',-3,3,1,'#a099ac','unmarked','emptyFrame','offsetDoor','cup','unknownTerminal','查看未登记终端','Inspect unlisted terminal',['objects','dreams','roomMemory']]
 ];
 const rooms=rows.map(([id,floor,x,y,light,model,p1,p2,p3,primary,zh,en,secondary])=>({id,floor,x,y,light,model,props:[p1,p2,p3],primary:{id:primary,name:zh,en},secondary,
  ambientSoundId:'lab_'+id,background:{normal:null,damaged:null,upgraded:null,night:null},eventPool:{light:[],major:[]},specializations:({greenhouse:['food','medicine'],medical:['emergency','recovery'],workshop:['weapon','fabrication']})[id]||[],
  decorAllowed:({medical:['lamp','plant','blanket','flower'],greenhouse:['plant','flower','lamp','sculpture'],surgery:['lamp','blanket'],power:['lamp','map'],core:['lamp','map']})[id]||null}));
 const byId=id=>rooms.find(r=>r.id===id);
 return {rooms,byId};
})();
