'use strict';
// Optional quiet procedural ambience; the IDs can later point at recorded room assets.
Abyss.LabRoomAudio=(()=>{
 const profiles={containment:[58,116,.003],quarters:[43,86,.0015],living:[39,78,.0015],medical:[92,184,.002],genetics:[107,214,.002],engineering:[63,126,.003],kitchen:[47,94,.0018],storage:[31,62,.001],greenhouse:[74,148,.002],workshop:[67,134,.0025],observation:[81,162,.002],archive:[49,98,.0015],power:[55,110,.004],water:[71,142,.003],radio:[88,176,.002],hall:[51,102,.0018],lower:[29,58,.0015],zero:[27,54,.001],black:[34,68,.0017],crawl:[69,138,.0024],nursery:[41,82,.0012],series:[38,76,.0011],surgery:[95,190,.0017],sublevel:[25,50,.0014],stairs:[32,64,.001],core:[45,90,.0035],unnumbered:[23,46,.001]};
 let context=null,room=null,key='',sources=[],gain=null,bound=false;
 function clear(){for(const source of sources){try{source.stop();source.disconnect();}catch{}}sources=[];gain?.disconnect();gain=null;}
 function update(s){if(!context)return;const enabled=room&&s.settings.sound&&!document.hidden&&s.mode==='raising'&&Abyss.LabOperations.atLab(s),next=enabled?room:'off';if(next===key)return;key=next;clear();if(!enabled)return;
  try{const p=profiles[room];gain=context.createGain();gain.gain.value=0;gain.gain.setTargetAtTime(p[2],context.currentTime,.7);gain.connect(context.destination);for(const hz of p.slice(0,2)){const source=context.createOscillator();source.type='sine';source.frequency.value=hz;source.connect(gain);source.start();sources.push(source);}}catch{clear();}
 }
 function set(id,s=Abyss.Engine.snapshot()){room=profiles[id]?id:null;update(s);}
 function stop(){room=null;if(context){key='';clear();}}
 function bind(){if(bound)return;bound=true;document.addEventListener('pointerdown',()=>{const s=Abyss.Engine.snapshot();if(!s.settings.sound)return;try{context||=new (window.AudioContext||window.webkitAudioContext)();context.resume().catch(()=>{});update(s);}catch{}});document.addEventListener('visibilitychange',()=>update(Abyss.Engine.snapshot()));Abyss.Engine.subscribe(update);document.getElementById('modal')?.addEventListener('close',stop);}
 return {profiles,bind,set,stop,update,status:()=>({room:key,sources:sources.length,state:context?.state||'idle'})};
})();
