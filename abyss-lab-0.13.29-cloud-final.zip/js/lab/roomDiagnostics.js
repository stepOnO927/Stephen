'use strict';
// Room-owned readings, derived only from the current save. No resource changes here.
Abyss.LabRoomDiagnostics=(()=>{
 const esc=Abyss.Util.escape,t=(zh,en)=>Abyss.I18n.language()==='en'?en:zh;
 const equipment=(s,id)=>{const d=Abyss.LabOperationsData.equipment.find(d=>d.id===id),e=s.operations.equipment[id];return [t(d.name,d.en),Math.round(e.condition),' / 100',e.condition<20];};
 const actions={power:['generator'],water:['filter','pump'],repairBypass:['pump','airFilter','lock'],corePower:[]};
 function render(s,action){const r=s.climate.labResources,rows=(actions[action]||[]).map(id=>equipment(s,id));
  if(action==='power')rows.unshift([t('当前电力储备','Power reserve'),+r.power.toFixed(1),' / 100',r.power<25],[t('燃料储备','Fuel reserve'),+r.fuel.toFixed(1),' / 100',r.fuel<15]);
  if(action==='water')rows.unshift([t('净水储备','Water reserve'),+r.water.toFixed(1),' / 100',r.water<15],[t('基地潮湿链','Damp fault chain'),s.operations.chains.find(c=>c.id==='waterLeak'&&!c.resolved)?.stage||0,' / 2',s.operations.chains.some(c=>c.id==='waterLeak'&&!c.resolved)]);
  if(action==='corePower')rows.push([t('电力储备','Power reserve'),+r.power.toFixed(1),' / 100',r.power<25],[t('屏蔽环境污染','Shielding contamination'),Math.round(s.home.conditions.contamination),' / 100',s.home.conditions.contamination>50],[t('可用燃料','Available fuel'),+r.fuel.toFixed(1),' / 100',r.fuel<3]);
  const title={power:['供电室读数','Power-room readings'],water:['净水回路','Filtration circuit'],repairBypass:['维修旁路','Service bypass'],corePower:['动力核接口','Core interface']}[action];
  const supply=action==='power'?`<p>${t('连接电网','Grid connected')} · ${s.climate.equipment.grid?t('是','Yes'):t('否','No')}<br>${t('应急供电只保留培养舱与所选优先区。','Emergency power preserves containment and the selected priority zone.')}</p>`:action==='water'?`<p>${t('滤芯和水泵共同决定回收出水；停泵不等于已有净水消失。','The filter and pump determine recovered output; a stopped pump does not erase stored water.')}</p>`:action==='corePower'?`<p>${t('旁路每次消耗3燃料与1行动点，恢复12电力，同时增加2基地污染。一天一次。','Bypass costs 3 fuel and 1 AP, restores 12 power and adds 2 lab contamination. Once per day.')}</p>`:`<p>${t('读数来自同一套设备记录。检查分区后，只回收明确标记的松散废料。','Readings use the shared equipment records. After surveying, recover only marked loose scrap.')}</p>`;
  return `<h3>${t(...title)}</h3><div class="ops-report-grid">${rows.map(([name,value,suffix,warning])=>`<article class="${warning?'ops-reading-warning':''}"><h4>${esc(name)}</h4><strong class="ops-reading-value">${value}<small>${suffix}</small></strong><div class="garden-growth" style="--growth:${Math.max(0,Math.min(100,value))}%"><span></span></div></article>`).join('')}</div>${supply}`;
 }
 return {actions,render};
})();
