'use strict';
Abyss.LabEvents=(()=>{
 const D=Abyss.LabOperationsData,U=Abyss.Util;
 const rows=[...Abyss.LabLifeEventsData,...Abyss.LabMaintenanceEventsData,...Abyss.LabRoomLightData].map(e=>({...e,room:e.room||D.equipment.find(d=>d.id===e.equipment).room}));
 const byId=id=>rows.find(e=>e.id===id);
 for(const room of Abyss.LabRoomData.rooms){room.eventPool.light=rows.filter(e=>e.room===room.id).map(e=>e.id);room.eventPool.major=D.chains.filter(c=>c.room===room.id).map(c=>'fault:'+c.id).concat(Abyss.LabRoomIncidentData.filter(e=>e.room===room.id).map(e=>'incident:'+e.id));}
 function eligible(s,e){if(!Abyss.LabRooms.canEnter(s,e.room))return false;if(e.zh.includes('Jack')&&!Abyss.LabOperations.atLab(s))return false;if(e.kind==='life'&&['living','containment'].includes(e.room)&&(!Abyss.LabOperations.atLab(s)||!s.legacy.active||s.campaign?.creatureAlive===false||s.awaySince))return false;
  if(e.equipment){const d=D.equipment.find(x=>x.id===e.equipment);return Abyss.LabOperations.active(s,d)&&s.operations.equipment[d.id].condition>20;}return true;
 }
 function apply(s,id){const e=byId(id),o=s.operations;if(!e||!eligible(s,e)||o.seen.includes(id))return false;
  if(e.equipment){const p=o.equipment[e.equipment];p.condition=U.clamp(p.condition-e.wear);p.wear+=e.wear;}
  o.seen.push(id);o.seen=o.seen.slice(-rows.length);Abyss.LabOperations.note(s,e.room,e.zh,e.en,e.kind);
  Abyss.LabRooms.remember(s,e.room,e.zh,e.en);return true;
 }
 function tick(s){const o=s.operations;if(s.mode!=='raising'||o.lastEventDay===s.day)return;o.lastEventDay=s.day;
  // Only simulated days roll; inspections and report rendering never consume event RNG.
  if(Abyss.LabOperations.random(s)>.42)return;const life=Abyss.LabOperations.random(s)<.65,kind=life?'life':'maintenance';
  let pool=rows.filter(e=>e.kind===kind&&eligible(s,e)&&!o.seen.includes(e.id));
  if(!pool.length)pool=rows.filter(e=>eligible(s,e)&&!o.seen.includes(e.id));if(!pool.length)return;
  apply(s,pool[Math.floor(Abyss.LabOperations.random(s)*pool.length)].id);
 }
 return {rows,byId,eligible,apply,tick};
})();
