'use strict';
// Operational memories are local records, not new authored main-story scenes.
Abyss.LabOperationalMemories=(()=>{
 const definitions={
  blackout:{room:'power',first:['手电放在地上。Jack在没有顶灯的房间里记下了时间。','The flashlight rests on the floor. Jack notes the time in the room without overhead light.'],recall:['电回来了。Jack把那晚用过的手电放回架子。','Power returns. Jack puts the flashlight from that night back on the shelf.']},
  majorRepair:{room:null,first:['换下的零件留在工具盘边。第一次大修的日期写在旁边。','The replaced part stays beside the tool tray, with the date of the first major repair.'],recall:['Jack翻到第一次大修的记录，再把工具盘推近。','Jack turns to the first major-repair record and pulls the tool tray closer.']},
  patient:{room:'medical',first:['医务记录多了第一条在场患者的病况。托盘重新擦了一遍。','The infirmary records its first patient condition on site. The tray is wiped again.'],recall:['Jack把新的观察放在旧记录旁边。第一次照护的日期还在。','Jack places the new observation beside the old record. The date of the first care is still there.']},
  harvest:{room:'greenhouse',first:['第一批收获离开了种植槽。空出来的位置还湿着。','The first harvest leaves the planting bed. The cleared space is still damp.'],recall:['Jack又把收获放到台面上，翻看第一批的登记。','Jack sets another harvest on the bench and checks the first batch record.']},
  visitor:{room:'observation',first:['入口对讲留下第一次来访记录。门仍然关着。','The entrance intercom records its first visitor. The door stays closed.'],recall:['入口又有人等候。Jack先翻了翻最早的来访登记。','Someone waits at the entrance again. Jack checks the earliest visitor record first.']},
  winter:{room:'living',first:['气候记录进入冬季。Jack在生活区检查了门缝。','The climate record enters winter. Jack checks the gap around the living-area door.'],recall:['Jack又检查了一遍门缝，在冬天第一天的记录后添了一行。','Jack checks the door gap again and adds a line after the first winter-day record.']}
 };
 const fresh=()=>({records:[],legacyKnown:[],lastRecallDay:0}),has=(s,id)=>s.operations.milestones.records.some(r=>r.id===id)||s.operations.milestones.legacyKnown.includes(id);
 function read(raw,s,legacy={}){const out=fresh(),day=n=>Number.isInteger(n)&&n>0&&n<=s.day;legacy=legacy&&typeof legacy==='object'?legacy:{};
  if(!raw||typeof raw!=='object'){out.legacyKnown=Object.keys(definitions).filter(id=>day(legacy[id])||id==='winter'&&s.climate.seasonalFlags.firstWinter===true||id==='blackout'&&(s.climate.seasonalFlags.blackout===true||s.climate.weatherMemories.some(m=>m.id==='first_blackout')));return out;}
  const used=new Set();for(const r of (Array.isArray(raw.records)?raw.records:[]).slice(-6)){
   const d=definitions[r?.id],equipment=Abyss.LabOperationsData.equipment.find(d=>d.id===r?.equipment);
   if(!d||used.has(r.id)||!day(r.day)||!Abyss.HomeData.rooms.some(d=>d.id===r.room)||(r.id==='majorRepair'?(!equipment||equipment.room!==r.room):r.room!==d.room)||r.subject!==undefined&&!s.infirmary.patients.some(p=>p.id===r.subject))continue;
   const witnessed=r.witness===true&&day(r.witnessBirthDay)&&r.witnessBirthDay<=r.day;
   used.add(r.id);out.records.push({id:r.id,day:r.day,room:r.room,witness:witnessed,...(witnessed?{witnessBirthDay:r.witnessBirthDay}:{}),...(equipment?{equipment:equipment.id}:{}),...(r.subject?{subject:r.subject}:{}),...(day(r.recalledDay)&&r.recalledDay>=r.day?{recalledDay:r.recalledDay}:{})});
  }
  out.legacyKnown=[...new Set((Array.isArray(raw.legacyKnown)?raw.legacyKnown:[]).filter(id=>Object.hasOwn(definitions,id)&&!used.has(id)))];if(day(raw.lastRecallDay))out.lastRecallDay=raw.lastRecallDay;return out;
 }
 function record(s,id,details={}){if(s.mode!=='raising'||has(s,id))return;const d=definitions[id],room=details.room||d.room,witness=Abyss.LabRooms.characters(s,room).some(p=>p.id==='b07');
  s.operations.milestones.records.push({id,day:s.day,room,witness,...(witness?{witnessBirthDay:s.legacy.birthDay}:{}),...(details.equipment?{equipment:details.equipment}:{}),...(details.subject?{subject:details.subject}:{})});s.operations.firsts[id]||=s.day;Abyss.LabRooms.remember(s,room,...d.first);Abyss.LabOperations.note(s,room,...d.first,'operationalMemory');
 }
 const harvested=(before,s,c)=>c.type==='garden:harvest'&&s.greenhouse.harvest.reduce((n,b)=>n+b.quantity,0)>before.greenhouse.harvest.reduce((n,b)=>n+b.quantity,0);
 function finish(before,s,c){if(s.mode!=='raising')return;const local=Abyss.LabOperations.atLab(s);
  if(local&&c.type==='climate:repair'){const device=Abyss.LabOperationsData.equipment.find(d=>d.id===c.payload?.id),old=before.climate.maintenance[c.payload?.id],now=s.climate.maintenance[c.payload?.id];if(device&&Abyss.LabOperations.active(s,device)&&Number.isFinite(old)&&old<40&&now>old)record(s,'majorRepair',{room:device.room,equipment:device.id});}
  if(local&&s.climate.labResources.power<10&&(s.day>before.day||before.climate.labResources.power>=10))record(s,'blackout');
  const harvest=local&&harvested(before,s,c);if(harvest)record(s,'harvest');
  const explicit=['medical:assess','medical:treat'].includes(c.type)?c.payload?.patient:null;
  const patient=s.infirmary.patients.find(p=>(explicit?p.id===explicit:s.operations.dutyObservations.records.some(r=>r.kind==='infirmary'&&r.subject===p.id&&r.day===s.day))&&Abyss.Infirmary.living(s,p)&&Abyss.Infirmary.basePatient(s,p)&&!(p.id==='b07'&&s.awaySince)&&p.conditions.some(c=>!['INCUBATING','RECOVERED'].includes(c.status)));
  if(patient&&((c.type==='medical:assess'||c.type==='medical:treat')&&c.payload?.patient===patient.id||s.operations.dutyObservations.records.some(r=>r.kind==='infirmary'&&r.subject===patient.id&&r.day===s.day)))record(s,'patient',{subject:patient.id});
  if(local&&s.day>before.day&&s.climate.currentSeason==='winter'&&s.climate.seasonalFlags.firstWinter===true&&before.climate.seasonalFlags.firstWinter!==true)record(s,'winter');
  const m=s.operations.milestones;if(!local||s.awaySince||m.lastRecallDay===s.day)return;
  for(const r of m.records){if(r.recalledDay||s.day<=r.day+1||!Abyss.LabRooms.canEnter(s,r.room))continue;
   const match=r.id==='blackout'?before.climate.labResources.power<10&&s.climate.labResources.power>=25:r.id==='majorRepair'?c.type==='ops:repair'&&c.payload?.equipment===r.equipment||c.type==='climate:repair'&&c.payload?.id===r.equipment&&s.climate.maintenance[r.equipment]>before.climate.maintenance[r.equipment]:r.id==='harvest'?harvest:r.id==='patient'?['medical:assess','medical:treat'].includes(c.type)&&c.payload?.patient===r.subject:r.id==='visitor'?c.type==='ops:visitor'&&['verify','admit'].includes(c.payload?.action):r.id==='winter'?s.day>before.day&&s.day>=r.day+7&&s.climate.currentSeason==='winter':false;
   if(!match)continue;r.recalledDay=s.day;m.lastRecallDay=s.day;Abyss.LabRooms.remember(s,r.room,...definitions[r.id].recall);Abyss.LabOperations.note(s,r.room,...definitions[r.id].recall,'memoryRecall');break;
  }
 }
 function archive(s,room){const recent=s.roomSystems.rooms[room]?.memories||[],rows=[];for(const r of s.operations.milestones.records.filter(r=>r.room===room)){for(const [day,text]of [[r.day,definitions[r.id].first],...(r.recalledDay?[[r.recalledDay,definitions[r.id].recall]]:[])])if(!recent.some(m=>m.day===day&&m.zh===text[0]))rows.push({day,zh:text[0],en:text[1]});}return rows.sort((a,b)=>a.day-b.day);}
 function creatureContext(s){if(!s.legacy.active||s.campaign?.creatureAlive===false)return [];const language=Abyss.I18n.language()==='en'?1:0;return s.operations.milestones.records.filter(r=>r.witness&&r.witnessBirthDay===s.legacy.birthDay).slice(-2).map(r=>'D'+r.day+': '+definitions[r.id].first[language]);}
 return {fresh,read,record,finish,definitions,archive,creatureContext};
})();
