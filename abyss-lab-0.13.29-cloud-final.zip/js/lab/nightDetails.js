'use strict';
// Endpoint observations only; no simulated events, rewards, RNG or invented times.
Abyss.LabNightDetails=(()=>{
 const statuses=['OPEN','WAITING','FOLLOWUP','RESOLVING','CLOSED','EXPIRED'];
 const number=n=>Number.isFinite(n)&&n>=0&&n<=100;
 const count=n=>Number.isInteger(n)&&n>=0&&n<=12;
 const named=id=>Abyss.StreetData.people.some(p=>p.id===id);
 const topic=n=>Abyss.NewsData.some(d=>d.number===n);
 const empty=()=>({npc:[],weather:null,news:[]});
 function unpack(raw,names){if(raw?.version!==1)return raw;const ids=Array.isArray(names)?names:[];
  const npc=(Array.isArray(raw.npc)?raw.npc:[]).map(n=>typeof n==='string'&&/^[0-9a-z]{1,11}$/.test(n)?parseInt(n,36):n).filter(n=>Number.isSafeInteger(n)&&n>=0).map(n=>{const values=[];for(const base of [10001,10001,13,13,2,2]){values.push(n%base);n=Math.floor(n/base);}return {id:ids[n],beforeHealth:values[0]/100,afterHealth:values[1]/100,beforeCases:values[2],afterCases:values[3],beforeAlive:!!values[4],afterAlive:!!values[5]};});
  const news=(Array.isArray(raw.news)?raw.news:[]).filter(n=>Number.isInteger(n)&&n>0&&n<5000).map(n=>{const number=n%91,code=Math.floor(n/91),before=code%7,after=Math.floor(code/7);return after?{number,kind:'CHAIN',before:before?statuses[before-1]:null,after:statuses[after-1]}:{number,kind:'BULLETIN'};});
  return {npc,weather:raw.weather,news};
 }
 function read(raw,names){raw=unpack(raw,names);const out=empty();if(!raw||typeof raw!=='object')return out;
  const used=new Set();for(const r of (Array.isArray(raw.npc)?raw.npc:[]).slice(0,256)){
   if(!r||!named(r.id)||used.has(r.id)||!number(r.beforeHealth)||!number(r.afterHealth)||!count(r.beforeCases)||!count(r.afterCases)||typeof r.beforeAlive!=='boolean'||typeof r.afterAlive!=='boolean')continue;
   used.add(r.id);out.npc.push({id:r.id,beforeHealth:r.beforeHealth,afterHealth:r.afterHealth,beforeCases:r.beforeCases,afterCases:r.afterCases,beforeAlive:r.beforeAlive,afterAlive:r.afterAlive});
  }
  const weather=w=>w&&Abyss.ClimateData.weather.some(d=>d.id===w.id)&&Number.isFinite(w.temperature)&&Math.abs(w.temperature)<=150;
  if(weather(raw.weather?.before)&&weather(raw.weather?.after))out.weather={before:{id:raw.weather.before.id,temperature:raw.weather.before.temperature},after:{id:raw.weather.after.id,temperature:raw.weather.after.temperature}};
  const news=new Set();for(const r of (Array.isArray(raw.news)?raw.news:[]).slice(0,90)){
   if(!r||!topic(r.number)||news.has(r.number)||!['BULLETIN','CHAIN'].includes(r.kind)||r.kind==='CHAIN'&&(!(r.before===null||statuses.includes(r.before))||!statuses.includes(r.after)||r.before===r.after))continue;
   news.add(r.number);out.news.push(r.kind==='CHAIN'?{number:r.number,kind:r.kind,before:r.before,after:r.after}:{number:r.number,kind:r.kind});
  }
  return out;
 }
 // Compact only the storage boundary. The live game and exports keep named fields.
 // IDs are saved in a per-save dictionary, never derived from catalog ordering.
 function packState(s){if(!s.operations?.nights?.some(n=>n.details))return s;const names=[],nights=s.operations.nights.map(n=>{if(!n.details)return n;const d=read(n.details);
   const npc=d.npc.map(r=>{let index=names.indexOf(r.id);if(index<0){index=names.length;names.push(r.id);}const values=[Math.round(r.beforeHealth*100),Math.round(r.afterHealth*100),r.beforeCases,r.afterCases,+r.beforeAlive,+r.afterAlive,index],bases=[10001,10001,13,13,2,2];let packed=values.at(-1);for(let i=bases.length-1;i>=0;i--)packed=packed*bases[i]+values[i];return packed.toString(36);});
   const news=d.news.map(r=>r.number+(r.kind==='CHAIN'?91*((r.before?statuses.indexOf(r.before)+1:0)+7*(statuses.indexOf(r.after)+1)):0));
   return {...n,details:{version:1,npc,weather:d.weather,news}};
  });return {...s,operations:{...s.operations,nights,nightDetailsNames:names}};
 }
 function capture(before,s){const out=empty(),round=n=>+n.toFixed(2),I=Abyss.Infirmary;
  // Union catches a resident or admitted patient who dies/leaves during this span.
  const ids=new Set([...before.infirmary.patients,...s.infirmary.patients].filter(p=>p.hostType==='NPC'&&(Abyss.LabOperations.npcAtLab(before,p.id)||Abyss.LabOperations.npcAtLab(s,p.id))).map(p=>p.id));
  for(const id of ids){if(!named(id))continue;const a=before.infirmary.patients.find(p=>p.id===id),b=s.infirmary.patients.find(p=>p.id===id);if(!a||!b)continue;
   const cases=p=>p.conditions.filter(c=>!['INCUBATING','RECOVERED'].includes(c.status)).length;
   const row={id,beforeHealth:round(I.health(before,a)),afterHealth:round(I.health(s,b)),beforeCases:cases(a),afterCases:cases(b),beforeAlive:I.living(before,a),afterAlive:I.living(s,b)};
   if(row.beforeHealth!==row.afterHealth||row.beforeCases!==row.afterCases||row.beforeAlive!==row.afterAlive)out.npc.push(row);
  }
  // This is the laboratory's central region, even during a player's expedition.
  const weather=x=>{const w=Abyss.Climate.conditions(x,'central',false);return {id:w.id,temperature:round(w.temperature)};};
  const a=weather(before),b=weather(s);if(a.id!==b.id||a.temperature!==b.temperature)out.weather={before:a,after:b};
  for(const r of s.infirmary.newsChains.records){const old=before.infirmary.newsChains.records.find(x=>x.number===r.number);if(!old||old.status!==r.status)out.news.push({number:r.number,kind:'CHAIN',before:old?.status||null,after:r.status});}
  const previous=new Set(before.infirmary.newsHistory.map(r=>[r.day,r.number,r.actor].join(':'))),used=new Set(out.news.map(r=>r.number));
  for(const r of s.infirmary.newsHistory)if(r.day>before.day&&r.day<=s.day&&!previous.has([r.day,r.number,r.actor].join(':'))&&!used.has(r.number)){out.news.push({number:r.number,kind:'BULLETIN'});used.add(r.number);}
  return read(out);
 }
 function html(details){const d=read(details),en=Abyss.I18n.language()==='en',t=(zh,enText)=>en?enText:zh,esc=Abyss.Util.escape;
  const status=id=>t(...({OPEN:['已收到','Received'],WAITING:['等待后续','Waiting'],FOLLOWUP:['后续可回应','Follow-up available'],RESOLVING:['处理中','Resolving'],CLOSED:['本轮已结束','Closed'],EXPIRED:['回应期限已过','Response window expired']}[id]||['新增','New']));
  const npc=d.npc.map(r=>'<p>'+esc(Abyss.StreetData.people.find(p=>p.id===r.id).name)+' · HP '+r.beforeHealth+' → '+r.afterHealth+' · '+t('活动病例','Active cases')+' '+r.beforeCases+' → '+r.afterCases+(r.beforeAlive&&!r.afterAlive?' · '+t('生命记录已封存','Life record archived'):'')+'</p>').join('');
  const weather=w=>{const found=Abyss.ClimateData.weather.find(p=>p.id===w.id);return esc(en?found.en:found.name)+' '+w.temperature+'°C';};
  const news=d.news.map(r=>'<p>#'+r.number+' · '+(r.kind==='CHAIN'?(r.before?status(r.before):t('未收到','Not received'))+' → '+status(r.after):t('新增已确认播报','New confirmed bulletin'))+'</p>').join('');
  return (npc?'<section data-night-detail="npc"><h4>'+t('在实验室的人','People at the laboratory')+'</h4>'+npc+'</section>':'')+(d.weather?'<section data-night-detail="weather"><h4>'+t('实验室外的天气','Weather outside the laboratory')+'</h4><p>'+weather(d.weather.before)+' → '+weather(d.weather.after)+'</p></section>':'')+(news?'<section data-night-detail="news"><h4>'+t('新闻变化摘要','News changes')+'</h4>'+news+'</section>':'');
 }
 return {empty,read,capture,html,packState};
})();
