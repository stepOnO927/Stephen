'use strict';
Abyss.UI = (() => {
 const $=id=>document.getElementById(id),esc=Abyss.Util.escape;
 const names={hunger:'饥饿',health:'健康',mood:'心情',loyalty:'忠诚',strength:'力量',intelligence:'智力',agility:'敏捷',stability:'稳定性',pollution:'污染度'};
 let commands,modalLocked=false,lastFocus=null,toastTimer,audioContext;
 function toast(text){if(!text)return;clearTimeout(toastTimer);$('toast').textContent=text;$('toast').classList.add('visible');toastTimer=setTimeout(()=>$('toast').classList.remove('visible'),2800);}
 function modal(title,content,locked=false){
   $('modal').classList.remove('wardrobe-modal','accessory-reveal-modal','research-modal','evolution-reveal-modal','hunt-modal','recovery-modal','weather-modal');
   $('modal-title').textContent=title;$('modal-content').innerHTML=content;modalLocked=locked;$('close-modal').hidden=locked;
   document.dispatchEvent(new CustomEvent('abyss:modal',{detail:{title,locked}}));
   if(Abyss.Navigation?.present(title,locked))return;
   if(!$('modal').open){lastFocus=document.activeElement;$('modal').showModal();}
 }
 function close(){if(modalLocked)return;$('modal').close();lastFocus?.focus();}
 const effects=e=>Object.entries(e||{}).map(([k,n])=>`${names[k]} ${n>0?'+':''}${n}`).join(' · ');
 const choice=(label,desc,meta,action,id,disabled=false)=>`<button class="choice" data-command="${action}" data-id="${esc(id||'')}" ${disabled?'disabled':''}><b>${label}</b><small>${desc}</small><em>${meta}</em></button>`;

 // Persistent nodes preserve CSS fill transitions between state snapshots.
 const meters = [
   {key:'health', en:'HEALTH', color:'#8dbbb2', desc:'低于 25 时无法探索或实验；治疗与休息可恢复。', low:true},
   {key:'hunger', en:'HUNGER', color:'#bdad8d', desc:'越低越饱。夜间达到 75 会损伤健康与忠诚。', low:false},
   {key:'mood', en:'MOOD', color:'#95b5c8', desc:'陪伴和奖励可以改善心情。', low:true},
   {key:'loyalty', en:'LOYALTY', color:'#b1a0c8', desc:'低于 30 时可能拒绝命令。伤害会留下长期记忆。', low:true},
   {key:'stability', en:'STABILITY', color:'#829fab', desc:'休息和陪伴有助于稳定，实验会带来波动。', low:true},
   {key:'pollution', en:'CONTAM.', color:'#9f96b8', desc:'越低越安全。高于 60 时，夜间会损伤健康。', low:false}
 ];
 function renderMeters(s) {
   const holder=$('vital-bars');
   if(!holder.children.length) {
     holder.innerHTML=meters.map(m=>`<div class="stat" id="meter-${m.key}" title="${m.desc}" style="--meter:${m.color}"><div class="stat-header"><span class="stat-label">${names[m.key]}<small>${m.en}</small></span><b class="stat-value"><span>0</span> <small>/ 100</small></b></div><div class="bar" role="meter" aria-label="${names[m.key]}" aria-valuemin="0" aria-valuemax="100"><i></i></div></div>`).join('');
   }
   for(const meter of meters) {
     const node=$('meter-'+meter.key),value=s.stats[meter.key];
     const danger=meter.low?value<30:value>=(meter.key==='pollution'?61:75);
     const caution=!danger&&(meter.low?value<50:value>=50);
     node.classList.toggle('danger',danger);node.classList.toggle('caution',caution);
     node.querySelector('.stat-value>span').textContent=value;
     const bar=node.querySelector('.bar');bar.setAttribute('aria-valuenow',value);
     bar.setAttribute('aria-valuetext',value+' / 100。'+meter.desc);
     bar.querySelector('i').style.width=value+'%';
   }
 }
 function render(s){
   $('day').textContent=`DAY ${String(s.day).padStart(2,'0')}`;$('money').textContent=`₵ ${s.money}`;$('ap').textContent='● '.repeat(s.ap)+'○ '.repeat(5-s.ap);
   $('research-footer').textContent='/ LV '+s.progress.research.level+' · '+s.progress.research.points+' RP';
   $('ap').setAttribute('aria-label',`行动点 ${s.ap} / 5`);
   $('stage-label').textContent=`${s.form?'成熟生命':s.age<6?'未知生命':s.age<13?'幼年生命':'成长生命'} / ${s.age} 日龄`;
   $('creature-name').textContent=s.name;$('specimen-name').textContent='SPECIMEN 001 / '+s.name;$('monster').setAttribute('aria-label',s.name+'：模块化二维怪物');
   renderMeters(s);
   $('loyalty-note').textContent=s.stats.loyalty<30?'△ 它在躲避你的目光':s.stats.loyalty>=75?'◇ 它在你身边感到安心':'◇ 信任正在慢慢建立';
   $('attributes').innerHTML=['strength','intelligence','agility'].map(k=>`<div class="attribute"><span>${names[k]}</span><strong>${s.stats[k]}</strong></div>`).join('')+`<div class="attribute"><span>年龄</span><strong>${s.age}<small style="font-size:9px"> 天</small></strong></div>`;
   $('mutation-count').textContent=String(s.mutations.length).padStart(2,'0');
   $('mutation-tags').innerHTML=s.mutations.length?s.mutations.map(id=>{const m=Abyss.Data.mutations.find(m=>m.id===id);return `<span title="${esc(Abyss.Research.has(s,'gene_library')?m.desc:'需要遗传学研究以进一步分类')}">${esc(Abyss.Progression.mutationLabel(s,m))}</span>`;}).join(''):'<span class="empty">基因尚未表达</span>';
   const form=Abyss.Data.forms.find(f=>f.id===s.form);$('form-name').textContent=form?form.name:s.age>=13?'它正在成为自己。':'未知的，亦是珍贵的。';
   $('speech').textContent=s.awaySince?'培养舱空着……它在哪里？':s.stats.hunger>75?'它饿得蜷起了身体。':s.stats.health<30?'它的呼吸有些微弱。':s.stats.loyalty<30?'它警惕地注视着舱门。':s.stats.loyalty>80?'它一见到你，就开心地晃起来。':'它正好奇地看着你。';
   $('chamber-status').textContent=s.awaySince?'△ 实验体失联':s.stats.health<30?'△ 需要医疗干预':s.stats.loyalty<30?'△ 信任水平异常':'● 生命体征稳定';
   $('bio-signal').textContent=`${s.stats.health}.0%`;
   $('bond-title').textContent=s.awaySince?'把它带回家':s.stats.loyalty<30?'信任正在远去':s.stats.loyalty>80?'你是它认得的归途':'一段关系，从未知开始';
   $('bond-desc').textContent=s.awaySince?'前往寻找；两天后救援队会协助找回。':s.stats.loyalty<30?'陪伴、奖励与治疗能够帮助修复关系。':'每一次选择，都将留在它的身体与记忆里。';
   const target=s.age<6?6:s.age<13?13:20;$('growth-label').textContent=s.form?'成熟形态已记录 · 可继续培育':s.age<6?'下一生长阶段 · 幼年期':s.age<13?'下一生长阶段 · 成长期':'下一生长阶段 · 成熟期';
   $('growth-days').textContent=s.form?'持续观察':`${s.age} / ${target} 日龄`;$('growth-bar').style.width=`${s.form?100:Math.min(100,s.age/target*100)}%`;
   $('daily-tip').textContent=Abyss.StoryDay.locked(s)?Abyss.StoryDay.message():s.mode==='story'?Abyss.HomeData.t('日末活动 · 可以照料、换装、研究或探索；休息后进入新一天的剧情。','Evening activities · Care, dress, research or explore. Rest starts the next day’s story.'):s.stats.hunger>65?'饥饿超过 75 时，夜间会损失健康与信任。先吃点东西吧。':s.stats.pollution>60?'高污染会在夜间损伤身体。治疗可以清除一部分污染。':s.experimentsToday>0?'同一天反复实验会额外降低忠诚与稳定性。它需要喘息。':'忠诚不是一串数字。温柔会被记住，伤害也是。';
   $('logs').innerHTML=s.logs.map(l=>`<div class="log ${l.type}"><time>D${String(l.day).padStart(2,'0')}</time><span class="log-tag">${({warning:'警告',rare:'发现',story:'观察',normal:'记录'})[l.type]}</span><p>${esc(l.text)}</p></div>`).join('');$('log-count').textContent=String(s.logs.length).padStart(2,'0');
   document.body.classList.toggle('alert',s.stats.loyalty<30);document.body.classList.toggle('reduced-motion',!s.settings.motion);
   document.querySelectorAll('[data-action]').forEach(el=>{
     const a=el.dataset.action;if(Abyss.StoryDay.locked(s)&&!Abyss.StoryDay.canOpen(s,a)){el.disabled=true;el.title=Abyss.StoryDay.message();return;}el.title='';el.disabled=false;const map={food:'feed',experiment:'experiment',train:'train',explore:'explore',heal:'heal',reward:'reward',companion:s.awaySince?'search':'companion',rest:'rest'};
     if(map[a]&&a!=='explore')el.disabled=!!s.exploration?.active||!!s.pendingEvent||s.ap<Abyss.Actions.costs[map[a]]||(!!s.awaySince&&!['companion','rest'].includes(a));
     if(a==='companion'&&el.classList.contains('action-button')){el.querySelector('b').textContent=s.awaySince?'寻找':'陪伴';el.querySelector('small').textContent=s.awaySince?'追踪足迹 · 带它回家':'建立信任 · 安抚情绪';el.querySelector('em').innerHTML=s.awaySince?'2 <span>AP</span>':'1 <span>AP</span>';el.querySelector('.action-en').textContent=s.awaySince?'SEARCH':'INTERACT';}
   });
   $('save-status').textContent=Abyss.Save.warning()?'⚠ 存档需注意':'● 已自动保存至本机';
   Abyss.Renderer.render(s);Abyss.StoryUI?.render(s);
 }
 function sound(){
   if(!commands.snapshot().settings.sound)return;
   try{audioContext ||= new (window.AudioContext||window.webkitAudioContext)();audioContext.resume();const oscillator=audioContext.createOscillator(),gain=audioContext.createGain();oscillator.type='sine';oscillator.frequency.setValueAtTime(520,audioContext.currentTime);gain.gain.setValueAtTime(.04,audioContext.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audioContext.currentTime+.15);oscillator.connect(gain);gain.connect(audioContext.destination);oscillator.start();oscillator.stop(audioContext.currentTime+.15);}catch(error){/* Audio is optional. */}
 }
 function act(type,payload){
   const r=commands.dispatch({type,payload});if(!r.ok){toast(r.message);return;}
   modalLocked=false;close();toast(r.saved===false?Abyss.Save.warning():r.message);sound();showPending();
 }
 function showPending(){
   const s=commands.snapshot();
   if(s.hunt.active){Abyss.HuntUI.open('expedition');return;}if(s.dreams.active){Abyss.ExpansionUI.dream();return;}if(s.journey.active){Abyss.ExpansionUI.map();return;}
   if(s.wasteland.active){Abyss.WastelandUI.open();return;}if(s.exploration?.active){Abyss.ExpeditionUI.open();return;}
   if(s.pendingEvent){Abyss.NarrativeUI.showEvent(s);return;}
   if(s.endingNotice){const f=Abyss.Data.forms.find(f=>f.id===s.form);modal('一个新的名字',`<div class="ending-card"><div class="event-art">✧</div><span class="eyebrow">MATURE FORM DISCOVERED</span><h3>${f.name}</h3><p class="result-text">${f.desc}</p><p class="modal-intro">长期行为、属性与突变共同塑造了这个结果。图鉴已记录，你仍可以继续探索和培育。</p><button class="wide-button" data-command="ackEnding">继续我们的故事 →</button></div>`,true);return;}
   if(Abyss.ProgressionUI.notice())return;
   Abyss.Wardrobe.showReveal();
   Abyss.LabOperationsUI?.morning();
 }
 function open(name){if(name==='storyCG')return Abyss.StoryPlayer.open('gallery');Abyss.Navigation?.adopt(name);if(commands.snapshot().mode==='story'&&['archive','status','regionmap','people','interactions'].includes(name))return Abyss.StoryUI.open('files');if(!Abyss.StoryDay.canOpen(commands.snapshot(),name)){toast(Abyss.StoryDay.message());return;}if(name==='hunt')return Abyss.HuntUI.open('expedition');if(name==='home')return Abyss.ExpansionUI.home();if(name==='regionmap')return Abyss.ExpansionUI.map();if(name==='legacy')return Abyss.ExpansionUI.legacy();if(name==='dreams')return Abyss.ExpansionUI.dream();if(name==='continuity')return Abyss.ExpansionUI.continuity();if(name==='people')return Abyss.ExpansionUI.social();if(name==='wallpapers')return Abyss.WallpaperUI.open();if(name==='wasteland')return Abyss.WastelandUI.open();
   const life=commands.snapshot();if(life.mode==='story'&&life.campaign?.creatureAlive===false&&['food','companion','train','heal','experiment','interactions','chat'].includes(name)){toast('它已经离世。共同记忆仍保留，可以继续调查与研究。');return;}
   if(Abyss.ModeUI&&['menu','new','saves','collection','achievements'].includes(name)){Abyss.ModeUI.open(name);return;}
   if(name==='interactions'){Abyss.NarrativeUI.interactions();return;}
   if(name==='archive'){Abyss.NarrativeUI.archive();return;}
   if(name==='status'){modal('生命监测',document.querySelector('.vitals').innerHTML.replace(/id="[^"]*"/g,''));return;}
   if(name==='inventory'){Abyss.ExpeditionUI.open('inventory');return;}
   if(['food','companion','train','heal','experiment','rest'].includes(name)&&!commands.snapshot().awaySince){Abyss.NarrativeUI.openInteraction(({food:'feed',companion:'pet',train:'train',heal:'examine',experiment:'experiment',rest:'night'})[name]);return;}
   if(name.startsWith('legacy:'))name=name.slice(7);
   if(name==='chat'){Abyss.Chat.open();return;}
   const s=commands.snapshot();if(s.exploration?.active&&!['explore','settings','menu','close','name','research'].includes(name)){Abyss.ExpeditionUI.open();return;}if(s.pendingEvent||s.endingNotice){showPending();return;}
   if(name==='name'){
    modal('给它一个名字',`<form id="name-form" class="naming-form"><span class="eyebrow">SPECIMEN IDENTITY / 001</span><p class="result-text">它会记住你呼唤它的声音。这个名字，只属于你们。</p><label for="name-input">怪物的名字 <small>1–12 个字符 · 免费改名</small></label><input id="name-input" name="creature-name" maxlength="24" value="${esc(s.name)}" autocomplete="off" placeholder="例如：苔灯、小墨、月芽"><div class="name-suggestions">${Abyss.Identity.suggestions.map(n=>`<button type="button" data-name-suggestion="${n}">${n}</button>`).join('')}</div><p id="name-error" class="name-error" role="status"></p><div class="modal-buttons"><button type="submit">确认名字</button><button type="button" data-open="close">暂时保留</button></div></form>`);
    $('name-input').focus();$('name-input').select();return;
   }
   if(name==='research'){Abyss.ProgressionUI.open();return;}
   if(name==='wardrobe'){Abyss.Wardrobe.open();return;}
   if(name==='accessoryArchive'){Abyss.Wardrobe.open('archive');return;}
   if(name==='food')modal('喂食 · 生长的起点',`<p class="modal-intro">消耗 1 AP。优先使用库存；没有库存时自动购买。饥饿越低越好。</p><div class="choices">${Abyss.Data.foods.filter(f=>!f.technology||Abyss.Research.has(s,f.technology)).map(f=>choice(`${f.symbol} ${f.name}`,`${f.desc}<br>${effects(f.effects)}`,`库存 ${s.inventory[f.id]||0} · ${(s.inventory[f.id]||0)>0?'免费使用':`₵ ${f.price}`} · 1 AP`,'feed',f.id,s.ap<1||(!(s.inventory[f.id]>0)&&s.money<f.price))).join('')}</div>`);
   if(name==='train')modal('训练 · 激发潜力',`<p class="modal-intro">消耗 1 AP。低忠诚时可能拒绝命令；拒绝仅消耗 1 AP。健康低于 20 时需要先恢复。</p><div class="choices">${Abyss.Data.training.map(t=>choice(t.name,`${t.desc}<br>${effects(t.effects)}`,'1 AP','train',t.id,s.ap<1||s.stats.health<20)).join('')}</div>`);
   if(name==='experiment')modal('实验 · 未知的代价',`<p class="modal-intro">需 2 AP，健康至少 25。满足条件的基因才可能表达；没有固定公开进化树。同日重复实验会额外损伤信任。高强度实验会留下持久记忆。</p><div class="choices">${Abyss.Data.experiments.filter(e=>!e.technology||Abyss.Research.has(s,e.technology)).map(e=>choice(e.name,`${e.desc}<br>${effects(e.effects)}`,`₵ ${e.price} · 2 AP`,'experiment',e.id,s.ap<2||s.money<e.price||s.stats.health<25)).join('')}</div><div class="modal-buttons"><button class="danger" data-open="punish">强制约束 / 风险操作</button></div>`);
   if(name==='explore'){Abyss.ExpeditionUI.open();return;}
   if(name==='companion')act(s.awaySince?'search':'companion');
   if(['heal','reward'].includes(name))act(name);
   if(name==='rest')modal('结束今天的观察？',`${Abyss.LabOperationsUI?.eveningPreview(s)||''}<p class="result-text">剩余 ${s.ap} 行动点不会保留。夜间饥饿 +18、心情 −3、健康 +4、稳定性 +3；新一天恢复 5 AP，发放 ₵ 22 补助。</p><p class="modal-intro">饥饿、高污染与忽视可能产生额外损伤。${s.stats.hunger>=57?'目前饥饿较高，建议先喂食。':''}</p><div class="modal-buttons"><button data-command="rest">☾ 进入下一天</button><button data-open="close">再待一会儿</button></div>`);
   if(name==='punish')modal('强制约束',`<p class="result-text">稳定性 +3，但忠诚 −16、心情 −18，并留下长期怨恨。即使日后忠诚恢复，旧日伤害仍可能引发罕见袭击。</p><p class="modal-intro">消耗 1 AP。这并不是维持稳定的必要手段。</p><div class="modal-buttons"><button class="danger" data-command="punish" ${s.ap<1?'disabled':''}>执行强制约束</button><button data-open="close">取消</button></div>`);
   if(name==='menu')modal('深渊研究终端',`<p class="modal-intro">ABYSS LAB · 收藏版 0.2<br>在黑暗里，培育一种属于你们的可能。</p><button class="wide-button" data-open="close">继续游戏 →</button><button class="wide-button" data-open="interactions">互动与共同记忆</button><button class="wide-button" data-open="chat">与实验体交流</button><button class="wide-button" data-open="name">怪物取名 / 改名</button><button class="wide-button" data-open="new">新游戏</button><button class="wide-button" data-open="research">研究与设施档案</button><button class="wide-button" data-open="wardrobe">衣橱 / WARDROBE</button><button class="wide-button" data-open="codex">生物图鉴与饰品档案</button><button class="wide-button" data-open="achievements">成就</button><button class="wide-button" data-open="settings">设置与存档</button><button class="wide-button" data-open="guide">操作指南</button>`);
   if(name==='new')modal('开始新的培育记录？',`<p class="result-text">这会覆盖当前进度与本轮图鉴、成就。可以先在设置中导出当前存档。</p><div class="modal-buttons"><button class="danger" data-command="new">确认新游戏</button><button data-open="settings">先导出存档</button><button data-open="menu">返回</button></div>`);
   if(name==='codex')codex('mutations');
   if(name==='achievements')modal('成就 · 微小的里程碑',`<p class="modal-intro">本轮已完成 ${s.achievements.length} / ${Abyss.Data.achievements.length}</p><div class="catalog">${Abyss.Data.achievements.map(a=>`<div class="catalog-item ${s.achievements.includes(a.id)?'unlocked':'locked'}"><b>${s.achievements.includes(a.id)?'✧':'◇'} ${a.id==='climate_cold'&&Abyss.StoryPresentation.intensity()==='full'?(Abyss.I18n.language()==='en'?'Fucking Cold':'真他妈冷'):a.name}</b><p>${a.desc}</p></div>`).join('')}</div>`);
   if(['personnel','journal'].includes(name))return Abyss.JackUI.open(name);
   if(name==='settings')modal('设置与存档',`<p class="modal-intro">进度在每次操作后自动保存。不计算离线时间，离开期间不会扣除状态。${esc(Abyss.Save.warning())}</p><label class="settings-row">Language / 语言<select id="setting-language"><option value="zh" ${Abyss.I18n.language()==='zh'?'selected':''}>中文</option><option value="en" ${Abyss.I18n.language()==='en'?'selected':''}>English</option></select></label>${Abyss.JackUI.preference()}<label class="settings-row">柔和动画<input type="checkbox" id="setting-motion" ${s.settings.motion?'checked':''}></label><label class="settings-row">操作音效<input type="checkbox" id="setting-sound" ${s.settings.sound?'checked':''}></label><div class="modal-buttons"><button data-command="export">导出存档</button><button data-command="import">导入存档</button></div><p class="modal-intro" style="margin-top:20px">存档仅保存在当前浏览器和文件位置下。搬动文件、更换浏览器或清理浏览器数据前，请先导出备份。</p><input type="file" id="import-file" accept="application/json,.json" hidden>`);
   if(name==='guide')modal('研究员入门手册',`<p class="result-text">每天有 5 点行动能源。喂食、训练、陪伴、治疗和奖励消耗 1 点；实验与探索消耗 2 点。结束今日后会获得补助、恢复行动点，并推进生长。</p><p class="result-text">先喂一份营养凝胶，再陪它玩耍，然后尝试训练或探索。日龄达到 2 天后，有机会在夜间或实验中表达突变；第 21 天将根据你的长期选择形成成熟形态，之后仍可继续游玩。</p><p class="result-text">饥饿越低越好，其余状态条越高通常越好；污染度过高有代价。忠诚低时可能拒绝命令、偷吃、破坏或逃跑。虐待留下的隐藏怨恨不会因为几次奖励而消失，背刺只是低概率事件。</p><p class="result-text">资金不足时，休息可领取补助；重伤时有紧急医疗托底；逃跑后可花费 2 AP 寻找，救援队最迟在两天后协助带回。</p><p class="modal-intro">日常照料、词语练习、共同记忆与探索推动 Project Abyss。完整对话由本地数据驱动，不需要 API；研究、衣橱与原有配方仍可使用。</p><button class="wide-button" data-open="close">开始观察 →</button>`);
   if(name==='close')close();
 }
 function codex(tab){
   if(tab==='evolution'){Abyss.ProgressionUI.open('evolution');return;}
   if(tab==='accessories'){Abyss.Wardrobe.open('archive');return;}
   const s=commands.snapshot();let content='';
   if(tab==='mutations')content=Abyss.Data.mutations.map(m=>`<div class="catalog-item ${s.mutations.includes(m.id)?'unlocked':'locked'}"><b>${s.mutations.includes(m.id)?esc(Abyss.Progression.mutationLabel(s,m)):'◇ 未知基因'}</b><p>${s.mutations.includes(m.id)&&Abyss.Research.has(s,'gene_library')?m.desc:'尚未表达。日常行为与身体状态可能唤醒它。'}</p></div>`).join('');
   if(tab==='forms')content=Abyss.Data.forms.map(f=>`<div class="catalog-item ${s.discoveredForms.includes(f.id)?'unlocked':'locked'}"><b>${s.discoveredForms.includes(f.id)?f.name:'◇ 未知成熟形态'}</b><p>${s.discoveredForms.includes(f.id)?f.desc:'漫长的共同生活，将赋予它独特的模样。'}</p></div>`).join('');
   if(tab==='foods')content=Abyss.Data.foods.filter(f=>!f.huntRecipe||s.hunt.recipes.includes(f.id)||s.inventory[f.id]>0).map(f=>`<div class="catalog-item"><b>${f.name}</b><p>${f.desc}<br>${effects(f.effects)}</p></div>`).join('');
   modal('生物图鉴',`<div class="codex-tabs">${[['mutations','突变'],['forms','成熟形态'],['foods','食物'],['accessories','饰品档案'],['evolution','进化记录']].map(([id,n])=>`<button class="${tab===id?'active':''}" data-tab="${id}">${n}</button>`).join('')}</div><div class="catalog">${content}</div>`);
 }
 function exportSave(){const blob=new Blob([Abyss.Save.serialize(commands.snapshot())],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`abyss-day-${commands.snapshot().day}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('存档已导出');}
 function bind(controller){
   commands=controller;
   document.addEventListener('click',event=>{
     const el=event.target.closest('button,[data-action]');if(!el||el.disabled)return;
     if(el.dataset.nameSuggestion){$('name-input').value=el.dataset.nameSuggestion;$('name-input').focus();return;}
       if(el.dataset.action)open(el.dataset.action);
     if(el.dataset.open)open(el.dataset.open);
     if(el.dataset.tab)codex(el.dataset.tab);
     if(el.dataset.command){
       const type=el.dataset.command;
       if(type==='new'){Abyss.Chat?.clear();commands.replace(Abyss.State.create());modalLocked=false;close();toast('新的培育记录已建立');open('name');return;}
       if(type==='export'){exportSave();return;}
       if(type==='import'){$('import-file').click();return;}
       if(type==='confirmImport'){try{Abyss.Save.importText(pendingImportText);}catch(error){toast('导入失败：'+error.message);return;}pendingImport=null,pendingImportText=null;modalLocked=false;close();showPending();toast('存档已导入');return;}
       act(type,type==='event'?Number(el.dataset.id):el.dataset.id);
     }
   });
   document.addEventListener('submit',e=>{if(e.target.id!=='name-form')return;e.preventDefault();const r=commands.dispatch({type:'rename',payload:$('name-input').value});if(!r.ok){$('name-error').textContent=r.message;return;}close();toast(r.saved===false?Abyss.Save.warning():r.message);});
   $('close-modal').addEventListener('click',close);
   $('modal').addEventListener('cancel',e=>{if(modalLocked)e.preventDefault();});
   $('brand').addEventListener('click',e=>{e.preventDefault();open('menu');});
   document.addEventListener('change',async e=>{
     if(['setting-motion','setting-sound'].includes(e.target.id)){
       commands.dispatch({type:'settings',payload:{motion:$('setting-motion').checked,sound:$('setting-sound').checked}});sound();return;
     }
     if(e.target.id==='import-file'){
       const file=e.target.files[0];if(!file)return;
       try{if(file.size>1000000)throw new Error('文件过大');pendingImportText=await file.text();pendingImport=Abyss.Save.parse(pendingImportText);modal('导入这份存档？',`<p class="result-text">第 ${pendingImport.day} 天，资金 ₵ ${pendingImport.money}，${pendingImport.mutations.length} 个突变。导入至原模式的新槽位，不覆盖当前进度。</p><div class="modal-buttons"><button data-command="confirmImport">确认导入</button><button data-open="settings">取消</button></div>`);}catch(error){toast(`导入失败：${error.message}`);}
     }
   });
 }
 let pendingImport=null,pendingImportText=null;
 return {bind,render,toast,open,showPending,modal,close};
})();
