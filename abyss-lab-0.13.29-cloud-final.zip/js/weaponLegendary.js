'use strict';
// Legendary encounter rules. Echoes store a primary hit, never an echo or combo total.
Abyss.WeaponLegendary=(()=>{
 const rank=(s,w)=>Abyss.WeaponRare.rank(s,w),t=Abyss.HomeData.t;
 const designs={
  weapon_railgun:['射程提高5%','远距离射击增加防御穿透','攻击时间缩短','穿过同一直线的第二目标','极远距离提高暴击率','极远距离首次命中获得精确校准'],
  weapon_tool:['拆盾伤害提高','拆开护盾后获得下一击校准','拆卸动作时间缩短','针对机械接缝增加破甲','首次拆盾短暂打断目标','首次拆开首领护盾形成三回合结构弱点'],
  weapon_relay:['无人机辅助闪避','每三次命中无人机发送一次脉冲','中继指令时间缩短','扫描机械目标增加防御穿透','三次命中恢复少量战斗体力','首次第三次闪避触发保护盾'],
  ud_weapon_17:["精英目标伤害提高","对深渊计划相关目标获得额外优势","攻击时间缩短","首次遭遇的护盾防御减半","精英击杀为下一场提供短暂强化","精英或首领开战时扫描真实情报并获得对应优势"],
  ud_weapon_18:["格挡减伤进一步提高","满生命首次命中获得仪式强化","攻击时间缩短","受击后下一次命中强化","成功格挡恢复少量稳定性","仅对政府或权力阵营获得特殊优势"],
  weapon_dawn:['首击伤害进一步提高','满生命首击提高暴击率','攻击时间缩短','击杀后为下一场交战恢复部分首击强化','攻击范围略微增加','首次命中绽放黎明光效并短暂提高防御'],
  ud_weapon_16:['远距离伤害提高','准备或防守后提高下一击暴击','瞄准时间缩短','命中留下三回合霜线标记','攻击标记目标提高穿甲','极远距离攻击标记目标有概率精准重击'],
  ud_weapon_19:['上一击复制概率提高','复制保留更多暴击伤害','攻击时间缩短','连续命中同目标提高复制比例','首次暴击留下可供下一击复制的记录','每场一次显示上一击残影并复制部分伤害与状态']};
 const en={
  weapon_railgun:['Five percent increased range','Far-range shots improve defense penetration','Shorter attack time','Pierce the second target on the same line','Improved critical chance at extreme range','The first extreme-range hit gains precision calibration'],
  weapon_tool:['Increased shield dismantling damage','Breaking a shield calibrates the next hit','Shorter dismantling time','Improved armor penetration at machine seams','The first shield break briefly interrupts the target','The first boss shield break exposes structure for three turns'],
  weapon_relay:['Drone-assisted evasion','Every third hit sends a drone pulse','Shorter relay command time','Machine scans improve defense penetration','Every third hit recovers a little combat energy','The third dodge grants a one-time protective shield'],
  ud_weapon_17:["Increased damage against elites","Extra effectiveness against Project Abyss targets","Shorter attack time","Halve the first shield defense encountered","Elite kills grant a brief bonus next encounter","Scan real elite or boss intel at encounter start for a matching advantage"],
  ud_weapon_18:["Improved block reduction","Full-health first hit gains Ceremony damage","Shorter attack time","Taking a hit strengthens the next successful hit","A successful block restores a little stability","Special advantages against government or authority factions only"],
  weapon_dawn:['Stronger opening hit','Full-health opening hit gains critical chance','Shorter attack time','A kill refreshes part of the opening bonus for the next encounter','Slightly increased range','First hit emits dawn light and briefly raises defense'],
  ud_weapon_16:['Increased long-range damage','Guarding or preparing improves the next critical chance','Shorter aiming time','Hits leave a three-turn frost mark','Marked targets grant armor penetration','Extreme-range hits on marked targets may trigger a precision strike'],
  ud_weapon_19:['Higher chance to echo the previous hit','Echoes retain more critical damage','Shorter attack time','Consecutive hits on the same target increase echo strength','The first critical hit leaves a record for the next hit','Once per battle: replay part of the previous hit and its status with an afterimage']};
 const dictionary={};for(const [id,lines]of Object.entries(designs)){const w=Abyss.WeaponData.weapons.find(w=>w.id===id);if(w)w.legendaryResonance=lines;lines.forEach((x,i)=>dictionary[x]=en[id][i]);}Abyss.I18n.register(dictionary);
 function stats(s,w,f={},e={}){f=f||{};const r=rank(s,w),o={},far=(f.distance??0)>=8,extreme=(f.distance??0)>=10.2;
  if(w?.id==='weapon_railgun'){if(r>=1)o.range=1.05;if(r>=2&&far)o.defensePen=.12;if(r>=3)o.time=.9;if(r>=5&&extreme)o.crit=.08;if(r>=6&&extreme&&!f.weaponRailUsed){o.accuracy=.3;o.critPen=.15;}}
  if(w?.id==='weapon_tool'){if(r>=1)o.shieldDamageBonus=.15;if(r>=2&&f.weaponToolReady)o.crit=.08;if(r>=3)o.time=.92;if(r>=4&&Abyss.WeaponRare.mechanical(e))o.armorPen=.12;if(f.weaponToolUntil>f.turn){o.weak=true;o.weakPointDamage=.18;o.armorPen=(o.armorPen||0)+.15;}}
  if(w?.id==='weapon_relay'){if(r>=1)o.dodge=.06;if(r>=3)o.time=.92;if(r>=4&&Abyss.WeaponRare.mechanical(e))o.defensePen=.1;}
  if(w?.id==='ud_weapon_17'){o.damage=(e?.elite?1.15+(r>=1?.1:0):1)*(r>=2&&e?.projectAbyss?1.1:1)*(f.weaponClearanceUntil>f.turn?1.1:1);if(r>=3)o.time=.92;if(f.weaponClearanceScan===1)o.defensePen=.08;if(f.weaponClearanceScan===2)o.statusPen=.1;if(f.weaponClearanceScan===3)o.resist=.08;}
  if(w?.id==='ud_weapon_18'){o.damage=(!f.weaponCeremonyUsed&&f.hp>=f.maxHp?(r>=2?1.35:1.2):1)*(r>=4&&f.weaponAuthorityReady?1.15:1);if(r>=3)o.time=.92;if(r>=6&&['government','authority'].includes(e?.faction)){o.resist=.12;o.defensePen=.1;}}
  if(w?.id==='weapon_dawn'){if(!f.weaponDawnUsed){o.damage=1.25+(r>=1?.15:0)+(f.weaponDawnRefresh?.1:0);if(r>=2&&f.hp>=f.maxHp)o.crit=.1;}if(r>=3)o.time=.92;if(r>=5)o.range=1.05;if(r>=6&&f.weaponDawnGuardUntil>f.turn)o.defense=.18;}
  if(w?.id==='ud_weapon_16'){if(far)o.crit=.05;if(r>=1&&far)o.damage=1.12;if(r>=2&&['guard','counter','shield','shell','resist','focus'].includes(f.lastAttack))o.crit=(o.crit||0)+.08;if(r>=3)o.time=.9;if(r>=5&&f.weaponFrostUntil>f.turn)o.armorPen=.15;if(r>=6&&extreme&&f.weaponFrostUntil>f.turn)o.accuracy=.06;}
  if(w?.id==='ud_weapon_19'&&r>=3)o.time=.92;
  return o;
 }
 function hit(s,w,f,e,n){if(w?.id==='weapon_railgun'&&rank(s,w)>=6&&(f.distance??0)>=10.2&&!f.weaponRailUsed){f.weaponRailUsed=true;f.logs.push('END OF THE LINE');}if(w?.id==='weapon_tool'){f.weaponToolReady=false;return n;}if(w?.id==='weapon_relay'){const r=rank(s,w);f.weaponRelayHits=(f.weaponRelayHits||0)+1;if(r>=2&&f.weaponRelayHits%3===0){f.weaponRelayPulse=Math.min(150,Math.round(n*.2));if(r>=5)f.energy=Math.min(12,f.energy+1);f.logs.push('DRONE PULSE');}return n;}if(w?.id==='ud_weapon_18'){if(!f.weaponCeremonyUsed){if(f.hp>=f.maxHp)f.weaponCeremonyUntil=f.turn+2;f.weaponCeremonyUsed=true;}f.weaponAuthorityReady=false;return n;}if(w?.id==='weapon_dawn'&&!f.weaponDawnUsed){f.weaponDawnUsed=true;if(rank(s,w)>=6){f.weaponDawnGuardUntil=f.turn+3;f.weaponDawnFlash=f.turn;f.logs.push('DAWN');}return n;}if(w?.id!=='ud_weapon_16')return n;const r=rank(s,w),marked=f.weaponFrostUntil>f.turn;
  if(r>=6&&marked&&(f.distance??0)>=10.2&&Abyss.Util.random(s)<.18){n=Math.round(n*1.65);f.weaponFrostFlash=f.turn;f.logs.push('WHITE HORIZON');}
  if(r>=4)f.weaponFrostUntil=f.turn+3;return n;
 }
 function afterHit(s,w,f,e,n,critical,status,hurt){if(w?.id==='weapon_tool'&&f.weaponToolShieldBefore>0&&f.enemyShield===0){const r=rank(s,w);if(r>=2)f.weaponToolReady=true;if(r>=5&&!f.weaponToolStunUsed){f.weaponToolStunUsed=true;f.enemyStatus.push({id:'stun',turns:2});}if(r>=6&&e.boss&&!f.weaponToolBossUsed){f.weaponToolBossUsed=true;f.weaponToolUntil=f.turn+3;f.logs.push('STRUCTURE EXPOSED');}}if(w?.id==='weapon_relay'&&f.weaponRelayPulse){hurt(f,'enemy',f.weaponRelayPulse);f.weaponRelayPulse=0;}if(w?.id!=='ud_weapon_19'||n<=0)return;const r=rank(s,w),previous=Math.min(150,f.weaponEchoDamage||0),previousCrit=f.weaponEchoCritical,previousStatus=f.weaponEchoStatus;let copy=0,copyStatus=null;
  if(previous>0){const consecutive=f.weaponEchoHitTurn===f.turn||f.weaponEchoHitTurn===f.turn-1,ratio=(r>=4&&consecutive?.4:.3)+(r>=2&&previousCrit?.1:0);if(Abyss.Util.random(s)<(r>=1?.16:.08))copy=Math.round(previous*ratio);
   if(r>=5&&f.weaponRecordDamage>0){copy=Math.max(copy,Math.round(f.weaponRecordDamage*.5));f.weaponRecordDamage=0;f.logs.push('YESTERDAY RECORD');}
   if(r>=6&&!f.weaponEchoUsed){f.weaponEchoUsed=true;copy=Math.max(copy,Math.round(previous*.65));copyStatus=previousStatus;f.logs.push('IT ALREADY HAPPENED');}
  }
  if(copy>0){hurt(f,'enemy',copy);f.weaponEchoFlash=f.turn;f.logs.push(t('昨日残影 · '+copy,'Yesterday echo · '+copy));if(copyStatus&&['poison','burn','slow','weaken','fear','break'].includes(copyStatus)){const old=f.enemyStatus.find(v=>v.id===copyStatus);if(old)old.turns=Math.max(old.turns,2);else f.enemyStatus.push({id:copyStatus,turns:2});}}
  if(r>=5&&critical&&!f.weaponRecordUsed){f.weaponRecordUsed=true;f.weaponRecordDamage=Math.min(150,n);f.logs.push('I REMEMBER');}
  f.weaponEchoDamage=Math.min(150,n);f.weaponEchoCritical=!!critical;f.weaponEchoStatus=status&&f.enemyStatus.some(v=>v.id===status&&v.turns>0)?status:null;f.weaponEchoHitTurn=f.turn;
 }
 function interrupt(w,f){if(w?.id==='ud_weapon_19')f.weaponEchoHitTurn=-1;}
 function start(s,w,f){const a=s.hunt.active,e=Abyss.HuntData.enemies.find(e=>e.id===f.enemy);if(a.clearanceCarry){if(w?.id==='ud_weapon_17'&&rank(s,w)>=5)f.weaponClearanceUntil=3;delete a.clearanceCarry;}if(w?.id==='ud_weapon_17'&&rank(s,w)>=6&&(e.elite||e.boss)){const scan=1+Math.floor(Abyss.Util.random(s)*3);f.weaponClearanceScan=scan;const layers=Abyss.WeaponRare.defenses(e),intel=scan===1?'DEFENSE '+layers.defense:scan===2?'STATUS RESIST '+Math.round(layers.statusResistance*100)+'%':'BEHAVIOR '+e.behavior+(e.pattern?' / '+e.pattern:'');f.logs.push('BLACK CLEARANCE · '+intel);}if(a.dawnCarry){if(w?.id==='weapon_dawn'&&rank(s,w)>=4)f.weaponDawnRefresh=true;delete a.dawnCarry;}}
 function victory(s,w){if(w?.id==='ud_weapon_17'&&rank(s,w)>=5&&Abyss.HuntData.enemies.find(e=>e.id===s.hunt.active.fight?.enemy)?.elite)s.hunt.active.clearanceCarry=true;if(w?.id==='weapon_dawn'&&rank(s,w)>=4)s.hunt.active.dawnCarry=true;}
 function incoming(s,w,f,n){if(w?.id==='weapon_relay'&&rank(s,w)>=6&&f.dodges>=3&&!f.weaponRelayShieldUsed){f.weaponRelayShieldUsed=true;f.shield=Math.min(100,f.shield+8);f.logs.push('RELAY COVER');}if(w?.id!=='ud_weapon_18')return n;const r=rank(s,w),blocked=f.guarding||f.weaponCeremonyUntil>f.turn;let result=n;if(blocked&&n>0){result=Math.max(0,Math.round(n*(r>=1?.8:.9)));if(r>=5&&result<n&&f.weaponAuthorityBlockTurn!==f.turn){s.stats.stability=Math.min(100,s.stats.stability+1);f.weaponAuthorityBlockTurn=f.turn;f.logs.push('CEREMONY · BLOCK');}}if(r>=4&&result>0)f.weaponAuthorityReady=true;return result;}
 function beforeHit(s,w,f){if(w?.id==='weapon_tool')f.weaponToolShieldBefore=f.enemyShield;if(w?.id==='ud_weapon_17'&&rank(s,w)>=4&&!f.weaponAccessUsed&&f.enemyShield>0){f.weaponAccessUsed=true;f.enemyShield=Math.floor(f.enemyShield*.5);f.logs.push('ACCESS GRANTED');}}
 function dodged(s,w,f){if(w?.id==='weapon_relay'&&rank(s,w)>=6&&f.dodges>=3&&!f.weaponRelayShieldUsed){f.weaponRelayShieldUsed=true;f.shield=Math.min(100,f.shield+8);f.logs.push('RELAY COVER');}}
 return {designs,stats,hit,afterHit,interrupt,start,victory,incoming,beforeHit,dodged};
})();
