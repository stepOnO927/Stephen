'use strict';
Abyss.Exploration = {
 chance(s,loc){return Abyss.Util.clamp(.57+(s.stats[loc.stat]-loc.difficulty)*.008+s.stats.loyalty*.0015,.22,.95);},
 run(s,loc){
   s.history.explore++;s.bias[loc.bias]++;
   Abyss.State.effects(s,{hunger:12,mood:3});
   if(Abyss.Util.random(s)<this.chance(s,loc)){
     const money=loc.reward[0]+Math.floor(Abyss.Util.random(s)*(loc.reward[1]-loc.reward[0]+1));
     const food=Abyss.Util.pick(s,loc.food);s.money+=money;s.inventory[food]=(s.inventory[food]||0)+1;
     Abyss.State.effects(s,{[loc.stat]:2,loyalty:2});
     Abyss.State.log(s,`从${loc.name}返回：找到了 ₵ ${money} 与${Abyss.Data.foods.find(f=>f.id===food).name} ×1。`,'rare');
     return `探索成功 · ₵ ${money} + 食物`;
   }
   Abyss.State.effects(s,{health:-10,mood:-6,stability:-3});s.money+=5;
   Abyss.State.log(s,`${loc.name}的路线被封锁。带回 ₵ 5 零件，但受了轻伤（健康 −10）。`,'warning');
   return '探索受阻 · 健康 −10，回收 ₵ 5';
 }
};
