'use strict';
Abyss.DialogueRules={
 matches(s,r={}){const n=s.narrative;return Object.entries(r).every(([key,v])=>{
 const handlers={metaItem:()=>v.every(id=>Abyss.Meta?.hasItem(id)),memory:()=>v.every(id=>Abyss.Memory.has(s,id)),flag:()=>v.every(id=>n.flags[id]),notFlag:()=>v.every(id=>!n.flags[id]),mutation:()=>v.every(id=>s.mutations.includes(id)),technology:()=>v.every(id=>Abyss.Research.has(s,id)),document:()=>v.every(id=>s.exploration.documents.includes(id)),item:()=>v.every(id=>s.exploration.items[id]?.discovered),world:()=>v.every(id=>s.exploration.flags[id]),route:()=>s.progress.evolution.route===v,stage:()=>s.progress.evolution.stage>=v,research:()=>s.progress.research.level>=v,mutations:()=>s.mutations.length>=v,explore:()=>s.history.explore>=v,visit:()=>s.exploration.records.some(e=>e.location===v),lastLocation:()=>n.lastLocation===v,clearance:()=>s.progress.research.clearance===v,word:()=>v.every(id=>n.learnedWords.includes(id)),milestone:()=>v.every(id=>n.milestones[id]),secret:()=>v.every(id=>n.hiddenChapters.includes(id))};
 if(handlers[key])return handlers[key]();return Abyss.Util.matches(s,{[key]:v});});},
 available(s,node){return this.matches(s,node.requirements)&&!(node.once&&s.narrative.seen[node.id])&&(!s.narrative.seen[node.id]||s.day-s.narrative.seen[node.id]>=(node.cooldown||0));}
};
