 'use strict';
// Explicit authored cues, independent of translated wording and simulation state.
Abyss.StoryEffects=(()=>{
 const cues={'project_second_abyss:0':'pressure','p6_ending_collapse:13':'impact','p6_ending_collapse:15':'collapse','p6_ending_together_end:13':'impact'};
 let last='',timer=null,layer=null;
 function cue(s,node){return s.mode==='story'?cues[node?.id+':'+(s.narrative.active?.line||0)]||null:null;}
 function stop(){clearTimeout(timer);layer?.remove();layer=null;for(const root of document.querySelectorAll('.game-grid,#story-player'))root.classList.remove('story-impact','story-pressure','story-collapse');}
 function present(s,node){const token=(node?.id||'')+':'+(s.narrative.active?.line||0)+':'+s.day,kind=cue(s,node);if(token===last){if(!s.settings.motion)stop();return;}last=token;stop();if(!kind||!s.settings.motion||document.hidden||window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)return;
 const root=document.body.classList.contains('story-player-active')?document.getElementById('story-player'):document.querySelector('.game-grid');if(!root)return;root.classList.add('story-'+kind);layer=document.createElement('div');layer.className='story-shock story-shock-'+kind;layer.setAttribute('aria-hidden','true');document.body.append(layer);timer=setTimeout(stop,kind==='pressure'?1000:650);
 }
 return {cue,present,stop};
})();
