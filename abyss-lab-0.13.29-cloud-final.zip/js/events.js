'use strict';
Abyss.Events = (() => {
 function trigger(s){
   if(s.pendingEvent||s.awaySince||Abyss.Util.random(s)>.48)return;
   const list=Abyss.Data.events.filter(e=>Abyss.EventRules.available(s,e)&&!(e.once&&s.seenEvents.includes(e.id))&&(!s.eventDays[e.id]||s.day-s.eventDays[e.id]>=(e.cooldown||1)));
   if(!list.length)return;
   let roll=Abyss.Util.random(s)*list.reduce((a,e)=>a+Abyss.Personality.eventWeight(s,e),0);
   const event=list.find(e=>(roll-=Abyss.Personality.eventWeight(s,e))<=0)||list[0];
   s.pendingEvent=event.id;s.eventDays[event.id]=s.day;
   if(!s.seenEvents.includes(event.id))s.seenEvents.push(event.id);
   Abyss.State.log(s,`事件：${event.name}。等待你的决定。`,'story');
 }
 function resolve(s,index){
   const e=Abyss.Data.events.find(e=>e.id===s.pendingEvent),choice=e?.choices[index];
   if(!choice)return {ok:false,message:'没有可处理的事件选项。'};
   if(choice.money<0&&s.money+choice.money<0)return {ok:false,message:'资金不足，请选择另一种应对方式。'};
   Abyss.State.apply(s,choice);Abyss.EventRules.extra(s,choice,e.id);s.pendingEvent=null;Abyss.State.log(s,`${e.name}：${choice.label}。`,'story');
   return {ok:true,message:'已记录你的决定。'};
 }
 // Resentment persists across days and is deliberately absent from the public HUD.
 function incident(s){
   if(s.awaySince)return;
   const loyalty=s.stats.loyalty,r=s.resentment;
   const betrayal=loyalty<35&&r>10?Math.min(.07,.015+r*.0005):(r>25?r*.00012:0);
   if(Abyss.Util.random(s)<betrayal){
     s.money=Math.max(0,s.money-20);Abyss.State.effects(s,{health:-6,stability:-10});
     Abyss.State.log(s,'旧日的伤害突然被唤醒：它袭击了操作台。紧急防护启动，损失了部分资金。背刺并非必然，但记忆仍在。','warning');return;
   }
   if(loyalty>=35||Abyss.Util.random(s)>.27)return;
   const id=Abyss.Util.pick(s,loyalty<20?['steal','break','escape']:['steal','break']);
   if(id==='steal'){
     const food=Object.keys(s.inventory).find(id=>s.inventory[id]>0);
     if(food){s.inventory[food]--;Abyss.State.effects(s,{hunger:-15});}else{s.money=Math.max(0,s.money-5);}
     Abyss.State.log(s,'它趁你不在翻开了储藏柜，偷偷取走了一份补给。','warning');
   }else if(id==='break'){
     s.money=Math.max(0,s.money-12);Abyss.State.effects(s,{stability:-5});Abyss.State.log(s,'它撕裂了一段设备管线。修理消耗了最多 ₵ 12。','warning');
   }else{s.awaySince=s.day;Abyss.State.log(s,'零号从通风管逃走了。使用「寻找」带它回来；救援队也会在两天后协助。','warning');}
 }
 return {trigger,resolve,incident};
})();
