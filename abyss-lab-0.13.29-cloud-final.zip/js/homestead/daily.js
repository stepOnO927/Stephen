'use strict';
Abyss.HomesteadDaily=(()=>{
 const A=Abyss,D=A.HomesteadData,M=A.HomesteadModel,G=A.HomesteadGenetics,T=A.HomesteadTraits,clamp=n=>Math.max(0,Math.min(100,n));
 const definition=a=>D.species.find(d=>d.id===a.speciesId);
 function note(f,day,text){f.events.push({day,text});f.events=f.events.slice(-100);}
 function used(f){return (f.rescues||[]).filter(r=>r.status==='IN_TRANSIT').reduce((n,r)=>n+definition(r.animal).space,0)+(f.auction&&!f.auction.settled&&f.auction.leader==='PLAYER'?definition(f.auction.animal).space:0)+(f.shipments||[]).reduce((n,r)=>n+definition(r.animal).space,0)+f.animals.filter(a=>a.alive).reduce((n,a)=>n+definition(a).space,0)+f.pregnancies.reduce((n,p)=>n+p.reserved*D.species.find(d=>d.id===p.speciesId).space,0);}
 function uid(f,prefix,counter){let id;do{id=prefix+f[counter]++;}while(f.animals.concat(f.archive).some(a=>a.id===id)||f.products.some(b=>b.uid===id)||f.pregnancies.some(p=>p.id===id));return id;}
 function batch(f,a,product,quantity,day,s){if(!quantity||f.products.length>=400)return;const d=definition(a),trait=product==='manure'?{qualityBonus:0,yieldBonus:0}:T.product(a,product);quantity+=trait.yieldBonus;f.products.push({uid:uid(f,'farm_batch_', 'nextBatch'),product,quantity,day,quality:Math.round(clamp(a.health*.35+a.hygiene*.25+(100-a.stress)*.2+a.geneProfile.production*.2+trait.qualityBonus)),contamination:Math.round(clamp((s.home.conditions.contamination||0)*.6+(100-a.hygiene)*.2)),source:a.id,held:false,rarity:d.rarity});a.production[product]=(a.production[product]||0)+quantity;}
 function death(f,a,day,cause){a.alive=false;a.deathDay=day;a.health=0;a.healthHistory.push({day,cause,health:0});a.healthHistory=a.healthHistory.slice(-20);note(f,day,A.HomeData.t('一只动物离世，记录保留；没有自动获得肉类。','An animal died. Its record remains; no meat was granted.')+' '+(a.name||definition(a).name));f.pregnancies=f.pregnancies.filter(p=>p.mother!==a.id);}
 function birth(s,f,p,day){const mother=f.animals.find(a=>a.id===p.mother);if(!mother?.alive)return;for(let i=0;i<p.reserved;i++){if(f.animals.filter(a=>a.alive).length>=100||used(f)+definition(mother).space>D.capacity[f.level]){note(f,day,A.HomeData.t('幼畜安置空间不足，等待空位。','Birth placement is waiting for capacity.'));f.pregnancies.push({...p,reserved:p.reserved-i,due:day+1});break;}const seed=(p.seed+i*2654435761)>>>0,a=M.individual(p.speciesId,seed,day,uid(f,'farm_', 'nextId'),'birth'),inherit=G.offspring(p.parentA,p.parentB,seed,{facility:p.facility,traitPool:T.birthPool});Object.assign(a,{geneProfile:inherit.geneProfile,specialTraits:inherit.specialTraits,parents:inherit.parents,grandparents:inherit.grandparents,generation:inherit.generation,bloodlineId:mother.bloodlineId,lineageName:mother.lineageName,health:inherit.defect?(T.has(p.parentA,'STRONG_MATERNAL')?85:80):100,pen:[...f.pens.filter(p=>p.kind==='nursery'),...f.pens.filter(p=>p.id===mother.pen)].find(pen=>f.animals.filter(b=>b.alive&&b.pen===pen.id).reduce((n,b)=>n+definition(b).space,0)+definition(mother).space<=pen.capacity)?.id||null});f.animals.push(a);if(!f.discovered.includes(a.speciesId))f.discovered.push(a.speciesId);note(f,day,A.HomeData.t('幼畜出生，父母与血统记录已保存。','An offspring was born. Parent and bloodline records were saved.')+' '+definition(a).name);}}
 function one(s,f,day){const water=s.climate.labResources.water;let waterUsed=0;
  for(const a of f.animals){if(!a.alive)continue;const d=definition(a),stage=M.stage(a,day),young=['NEWBORN','YOUNG'].includes(stage),pen=f.pens.find(p=>p.id===a.pen),feed=young&&!d.colony?'milk':d.feed,need=T.feed(a,d),supplied=(f.feed[feed]||0)>=need,drink=water-waterUsed>=.2*d.space;
   if(supplied){f.feed[feed]-=need;a.hunger=clamp(a.hunger-18);}else a.hunger=clamp(a.hunger+12);
   if(drink)waterUsed+=.2*d.space;else a.health=clamp(a.health-2);
   if(supplied&&drink&&a.health>60){a.experience+=3;a.level=Math.min(20,1+Math.floor(a.experience/20));}
   const neighbors=f.animals.filter(b=>b.alive&&b.id!==a.id&&b.pen===a.pen&&!b.quarantined).length;
   a.socialState=a.stress>70?'STRESSED':a.pen&&neighbors&&!a.quarantined?'CONTENT':'ISOLATED';a.stress=clamp(a.stress+T.stress(a,a.socialState==='ISOLATED')+(a.hunger>80?4:0));a.hygiene=clamp(a.hygiene-3+(pen&&pen.hygiene>70?1:0));
   if(a.hunger>85)a.health=clamp(a.health-3);else if(supplied&&drink&&a.stress<50)a.health=clamp(a.health+.5+a.geneProfile.constitution*.005);
   const weather=s.climate.weatherByRegion.central,environment=T.environment(a,pen,weather.temperature,s.home.conditions.contamination);a.health=clamp(a.health-environment.health);a.stress=clamp(a.stress+environment.stress);if(young&&(!pen||pen.warmth<45))a.health=clamp(a.health-(T.has(a,'COLD_HARDY')?1:2));A.HomesteadClinic.day(s,a);A.HomesteadClinic.risk(s,a,pen);
   const age=(a.ageAtAcquisition||0)+day-a.birthDay,life=d.lifespan*(a.specialTraits.includes('LONG_LIVED')?1.15:1)*(a.specialTraits.includes('SHORT_LIVED')?.8:1);
   if(a.health<=0||age>=life){death(f,a,day,a.health<=0?'health':'old_age');continue;}
   if(supplied)batch(f,a,'manure',1,day,s);
   const adult=['ADULT','PRIME','OLD'].includes(stage),healthy=!a.medical.conditions.some(c=>c.status!=='RECOVERED');
   if(adult&&supplied&&drink&&healthy&&a.health>=55&&a.hunger<60&&a.stress<65&&a.hygiene>=35&&!a.quarantined&&(!d.femaleProduct||a.sex==='FEMALE')&&!['travel','cargo'].includes(d.product)){
    const period=['wool','fiber','feathers','material'].includes(d.product)?5:2;if((day-a.acquiredDay)%period===0)batch(f,a,d.product,1+(a.geneProfile.production>=75?1:0)+(a.geneProfile.production>=98?1:0),day,s);
   }
  }
  s.climate.labResources.water=Math.max(0,water-waterUsed);for(const pen of f.pens)pen.hygiene=clamp(pen.hygiene-2);A.HomesteadClinic.contacts(s);
  f.archive.push(...f.animals.filter(a=>!a.alive));f.archive=f.archive.slice(-200);f.animals=f.animals.filter(a=>a.alive);
  const due=f.pregnancies.filter(p=>p.due<=day);f.pregnancies=f.pregnancies.filter(p=>p.due>day);for(const p of due)birth(s,f,p,day);
 }
 function observe(before,s){const f=s.homestead;if(s.mode!=='raising'||!f?.unlocked)return;const end=s.day;if(end<=f.lastDay)return;const start=Math.max(f.lastDay+1,end-364);if(start>f.lastDay+1)note(f,start,A.HomeData.t('过久的缺失日程不补发产物。','Products are not backfilled for the omitted interval.'));for(let day=start;day<=end;day++){s.day=day;one(s,f,day);f.lastDay=day;}s.day=end;}
 return {used,uid,batch,death,observe};
})();
