'use strict';
Abyss.HomesteadLineages=(()=>{
 const A=Abyss,D=A.HomesteadData,t=A.HomeData.t;
 const subjects=f=>f.animals.concat(f.archive),definition=a=>D.species.find(d=>d.id===a.speciesId);
 function pedigree(f,id){const all=subjects(f),root=all.find(a=>a.id===id);if(!root)return null;const lookup=id=>{const a=all.find(a=>a.id===id);return a?{id:a.id,name:a.name,speciesId:a.speciesId,generation:a.generation,alive:a.alive,birthDay:a.birthDay,deathDay:a.deathDay}: {id,missing:true};};return {self:lookup(id),parents:root.parents.map(lookup),grandparents:root.grandparents.map(lookup),children:all.filter(a=>a.parents.includes(id)).map(a=>lookup(a.id)),bloodlineId:root.bloodlineId,lineageName:root.lineageName};}
 function groups(f){const map=new Map();for(const a of subjects(f)){const key=a.bloodlineId;if(!map.has(key))map.set(key,{id:key,name:a.lineageName,members:[],maxGeneration:1});const g=map.get(key);g.members.push(a.id);g.maxGeneration=Math.max(g.maxGeneration,a.generation);if(a.lineageName)g.name=a.lineageName;}return [...map.values()];}
 function quality(a){const genes=D.geneAxes.map(k=>a.geneProfile[k]),average=genes.reduce((sum,n)=>sum+n,0)/5;return {average:Math.round(average*10)/10,grade:D.grade(average),weakest:Math.min(...genes),strongest:Math.max(...genes),heritageScore:Math.round(average*.7+a.geneProfile.heritability*.3),healthy:a.alive&&a.health>=70&&!a.medical.conditions.some(c=>c.status!=='RECOVERED')};}
 function eligible(a,day){const d=definition(a);return !d.sterile&&!d.colony&&quality(a).healthy&&a.ageAtAcquisition+day-a.birthDay>=d.maturity&&a.hunger<=50&&a.stress<=50&&!a.quarantined;}
 function command(s,action,p={}){const f=s.homestead,a=f?.animals.find(a=>a.id===p.id);if(s.mode!=='raising'||!A.Road.atLab(s)||s.pendingEvent||s.awaySince||!f?.unlocked||!a?.alive)return {ok:false,message:t('需要回到养殖区查看在场个体。','Return to the farm to inspect a living animal.')};
  if(action==='stock'){if(typeof p.value!=='boolean'||p.value&&!eligible(a,s.day))return {ok:false,message:t('种畜需要成熟、健康、低压力；群落和骡不能作为普通种畜。','Breeding stock must be mature, healthy and settled. Colonies and mules do not qualify.')};a.breedingStock=p.value;a.heritageScore=quality(a).heritageScore;}
  else if(action==='name'){if(typeof p.name!=='string'||!p.name.trim()||p.name.trim().length>40)return {ok:false,message:t('血统名需要1–40字。','A lineage name needs 1–40 characters.')};for(const member of subjects(f).filter(b=>b.bloodlineId===a.bloodlineId))member.lineageName=p.name.trim();for(const preg of f.pregnancies)for(const key of ['parentA','parentB'])if(preg[key].bloodlineId===a.bloodlineId)preg[key].lineageName=p.name.trim();}
  else return {ok:false,message:t('未知血统操作。','Unknown lineage action.')};return {ok:true,message:t('血统档案已保存；物种稀有度与基因没有改变。','Lineage record saved. Species rarity and genes are unchanged.')};
 }
 return {pedigree,groups,quality,eligible,command};
})();
