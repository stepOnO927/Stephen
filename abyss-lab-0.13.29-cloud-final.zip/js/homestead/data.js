'use strict';
// Species rarity, individual genes and lineage quality are deliberately independent.
(function(root,factory){const data=factory();if(typeof module==='object'&&module.exports)module.exports=data;if(root.Abyss){root.Abyss.HomesteadData=data;root.Abyss.I18n?.register(Object.fromEntries(data.species.map(d=>[d.name,d.en])));}})(globalThis,()=>{
 const rows=[
 ['chicken','鸡','Chicken','poultry','COMMON','eggs',1,7,180,'grain'],
 ['duck','鸭','Duck','waterfowl','COMMON','eggs',1,8,200,'grain'],
 ['goose','鹅','Goose','waterfowl','UNCOMMON','eggs',2,10,240,'grass'],
 ['turkey','火鸡','Turkey','poultry','UNCOMMON','eggs',2,12,220,'grain'],
 ['quail','鹌鹑','Quail','poultry','COMMON','eggs',1,5,120,'grain'],
 ['rabbit','兔','Rabbit','rabbit','COMMON','fiber',1,7,140,'vegetable'],
 ['goat','山羊','Goat','goat','COMMON','goat_milk',2,14,320,'grass'],
 ['sheep','羊','Sheep','sheep','COMMON','wool',2,15,320,'grass'],
 ['cow','牛','Cow','cattle','COMMON','milk',3,20,500,'grass'],
 ['highland_cow','高地牛','Highland Cow','cattle','UNCOMMON','milk',3,22,520,'grass'],
 ['pig','猪','Pig','pig','COMMON','manure',2,14,300,'root'],
 ['mini_pig','小型猪','Mini Pig','pig','UNCOMMON','manure',1,13,320,'root'],
 ['horse','马','Horse','horse','UNCOMMON','travel',3,25,600,'grass'],
 ['donkey','驴','Donkey','donkey','COMMON','cargo',2,23,620,'grass'],
 ['mule','骡','Mule','mule','UNCOMMON','cargo',3,24,620,'grass'],
 ['alpaca','羊驼','Alpaca','camelid','UNCOMMON','fiber',2,18,420,'grass'],
 ['llama','美洲驼','Llama','camelid','UNCOMMON','cargo',3,21,460,'grass'],
 ['yak','牦牛','Yak','yak','RARE','milk',4,25,520,'grass'],
 ['reindeer','驯鹿','Reindeer','deer','RARE','travel',3,22,480,'lichen'],
 ['water_buffalo','水牛','Water Buffalo','buffalo','RARE','milk',4,24,520,'grass'],
 ['camel','骆驼','Camel','camel','RARE','travel',4,27,580,'grass'],
 ['desert_goat','沙漠山羊','Desert Goat','goat','RARE','goat_milk',2,16,350,'grass'],
 ['snow_goat','雪山羊','Snow Goat','goat','RARE','goat_milk',2,17,360,'grass'],
 ['forest_boar','森林猪','Forest Boar','pig','UNCOMMON','manure',3,17,330,'root'],
 ['wasteland_chicken','废土鸡','Wasteland Chicken','poultry','UNCOMMON','eggs',1,8,220,'grain'],
 ['grey_duck','灰鸭','Grey Duck','waterfowl','RARE','eggs',1,9,240,'grain'],
 ['ironhorn_goat','铁角山羊','Ironhorn Goat','goat','EPIC','goat_milk',3,20,400,'grass'],
 ['frost_cow','霜牛','Frost Cow','cattle','EPIC','milk',4,26,540,'grass'],
 ['ash_sheep','灰羊','Ash Sheep','sheep','RARE','wool',2,18,380,'grass'],
 ['glass_rabbit','玻璃兔','Glass Rabbit','rabbit','EPIC','fiber',1,10,180,'vegetable'],
 ['old_world_dairy_cow','旧世奶牛','Old-World Dairy Cow','cattle','LEGENDARY','milk',3,23,520,'grass'],
 ['archive_chicken','档案鸡','Archive Chicken','poultry','LEGENDARY','eggs',1,9,260,'grain'],
 ['black_wool_sheep','黑毛羊','Black Wool Sheep','sheep','RARE','wool',2,17,360,'grass'],
 ['giant_goose','巨鹅','Giant Goose','waterfowl','EPIC','feathers',3,16,350,'grass'],
 ['long_ear_rabbit','长耳兔','Long-Ear Rabbit','rabbit','RARE','fiber',1,8,170,'vegetable'],
 ['medic_goat','药草山羊','Medic Goat','goat','LEGENDARY','goat_milk',2,19,420,'herb'],
 ['bee_colony','授粉蜂群','Pollinator Bee Colony','colony','COMMON','honey',1,10,250,'flower'],
 ['silk_worm_colony','蚕群','Silk Worm Colony','colony','EPIC','fiber',1,6,100,'leaf'],
 ['cave_beetle_colony','洞穴甲虫群','Cave Beetle Colony','colony','EPIC','material',1,12,210,'fungus'],
 ['anomalous_pale_cow','异常苍白牛','Anomalous Pale Cow','cattle','ANOMALOUS','milk',4,26,520,'grass']
 ];
 const prices={COMMON:900,UNCOMMON:3200,RARE:9000,EPIC:28000,LEGENDARY:85000,ANOMALOUS:null};
 const species=rows.map(([id,name,en,family,rarity,product,space,maturity,lifespan,feed],i)=>Object.freeze({id,name,en,family,rarity,product,space,maturity,lifespan,feed,price:prices[rarity]===null?null:prices[rarity]+i*17,role:['travel','cargo'].includes(product)?'WORK_ANIMAL':rarity==='ANOMALOUS'?'ANOMALOUS_FAUNA':'LIVESTOCK',sterile:id==='mule',colony:family==='colony',femaleProduct:['milk','goat_milk','eggs'].includes(product),acquisition:rarity==='ANOMALOUS'?['research_facility','hidden_event']:rarity==='LEGENDARY'?['certified_caravan','auction','breeding_center']:['caravan','farm_npc','rescue','breeding',...(['RARE','EPIC'].includes(rarity)?['auction']:[])],visual:Object.freeze({family,variant:id,palette:['#d6bd85','#c7c4b8','#9b8572','#899b8d'][i%4]})}));
 const grade=n=>n>=98?'SS':n>=90?'S':n>=75?'A':n>=60?'B':n>=40?'C':n>=20?'D':'E';
 return Object.freeze({species:Object.freeze(species),geneAxes:Object.freeze(['constitution','production','fertility','diseaseResistance','heritability']),grade,unlock:Object.freeze({day:20,labLevel:8,money:3000,scrap:120,wood:80,waterLevel:2}),upgradePrices:Object.freeze([3000,8000,15000,30000,60000,120000]),capacity:Object.freeze([0,12,24,40,60,80,100])});
});
