'use strict';
Abyss.Progression=(()=>{
 const fail=message=>({ok:false,message}),ok=message=>({ok:true,message});
 function observe(before,s,c){const final=Abyss.Phase3Data.forms.find(f=>f.id===s.progress.evolution.form);if(final&&c.type===final.preferred&&c.type!=='rest')Abyss.Research.award(s,'preference:'+s.day+':'+final.id,3);
 if(c.type==='feed'&&s.history.feed>before.history.feed)s.progress.diet[c.payload]=(s.progress.diet[c.payload]||0)+1;Abyss.Research.observe(before,s,c);if(Abyss.Research.has(s,'impossible_geometry')&&Abyss.Evolution.abilities(s).includes('anomaly')&&!s.exploration.flags.anomaly_gate_open){Abyss.WorldState.setWorldFlag(s,'anomaly_gate_open');Abyss.State.log(s,'设施识别到异常组织；深层管线的一道旧隔离门打开了。','rare');}if(c.type==='rest'||s.mutations.length!==before.mutations.length||c.type.startsWith('progress:'))Abyss.Evolution.sync(s);if(!s.progress.evolution.pending&&(c.type==='rest'||c.type.startsWith('progress:')||before.exploration.active&&!s.exploration.active))Abyss.Story.sync(s);}
 function optionAvailable(s,c){return (!c.dialogueRequirements||Abyss.DialogueRules.matches(s,c.dialogueRequirements))&&(!c.technology||Abyss.Research.has(s,c.technology))&&(!c.ability||Abyss.Evolution.abilities(s).includes(c.ability));}
 function locationAvailable(s,l){return !l.technology||Abyss.Research.has(s,l.technology)&&(!l.clearance&&l.id!=='black_floor'||s.progress.research.clearance==='black');}
 function command(s,type,payload){if(s.pendingEvent||s.endingNotice)return fail('请先处理实验室观察提示');if(type==='tech')return Abyss.Research.purchase(s,payload);if(type==='identify')return Abyss.Research.identify(s,payload);if(type==='evolution')return Abyss.Evolution.choose(s,payload);if(type==='story')return Abyss.Story.choice(s,payload);
 const requirements={culture:'sample_culture',medicine:'medicine',talk:'communication',stabilize:'stabilizer',redirect:'redirection'};
 if(!requirements[type]||!Abyss.Research.has(s,requirements[type]))return fail('研究协议未开放');if(s.awaySince||s.progress.evolution.pending)return fail('请先完成生命体观察');if(s.ap<1)return fail('需要 1 AP');if(s.progress.protocols[type]===s.day)return fail('该协议每天执行一次');
 if(['culture','medicine','stabilize'].includes(type)&&!(s.inventory.bio_sample>0))return fail('需要生物样本 ×1');if(type==='redirect'&&(s.progress.evolution.redirected||s.progress.evolution.stage>=4))return fail('该个体的重定向额度已用完或已完成定型');
 s.ap--;s.progress.protocols[type]=s.day;
 if(type==='culture'){Abyss.Inventory.consumeItem(s,'bio_sample');Abyss.Inventory.grantItem(s,'bio_sample',2,'实验室组织培养');Abyss.Research.award(s,'repeat:culture',4,false);}
 if(type==='medicine'){Abyss.Inventory.consumeItem(s,'bio_sample');Abyss.State.effects(s,{health:22,pollution:-5,loyalty:3});}
 if(type==='talk'){Abyss.State.effects(s,{loyalty:4,intelligence:2});Abyss.State.log(s,Abyss.Story.context(s),'story');Abyss.Research.award(s,'behavior:communication',30);}
 if(type==='stabilize'){Abyss.Inventory.consumeItem(s,'bio_sample');Abyss.State.effects(s,{stability:10,pollution:-8});}
 if(type==='redirect'){if(!['gentle','mechanical'].includes(payload))return fail('未知环境协议');s.progress.evolution.redirected=true;s.progress.evolution.stage=Math.max(1,s.progress.evolution.stage-1);s.progress.evolution.route=null;s.progress.evolution.scores={};s.bias[payload==='gentle'?'gentle':'armored']+=8;Abyss.State.effects(s,{health:-12,stability:-10});Abyss.Evolution.record(s,'受限环境重定向，保留所有既有器官。','intervention');}
 Abyss.State.log(s,'执行研究协议：'+type+'。','story');return ok('研究协议已执行');
 }
 const mutationLabel=(s,m)=>Abyss.Research.has(s,'gene_library')?m.name:Abyss.Research.has(s,'gene_scan')?'适应组织 / '+({body:'体态',skin:'表皮',eyes:'视器',head:'颅部',horns:'感角',tail:'尾部',back:'背部',limbs:'肢体',effects:'微环境'})[m.category]:'未分类的生理变化';
 return {observe,command,optionAvailable,locationAvailable,mutationLabel};
})();
