'use strict';
// Art assembly only. Palettes and model geometry live in separate modules.
Abyss.AccessoryArt=(()=>{
 const draw=Abyss.AccessoryModels.draw;draw.atelier=Abyss.TailoredModels.geometry;draw.weather=Abyss.WeatherArt.geometry;draw.underground=Abyss.UndergroundArt.accessory;let sequence=0;
 function markup(a,s){
  if(a.visual.renderer==='road')return Abyss.RoadArt.markup(a,s);if(a.visual.renderer==='hunt')return Abyss.HuntArt.accessory(a,s);const v=a.visual;if(v.asset)return `<image href="${Abyss.Util.escape(v.asset)}" x="0" y="0" width="480" height="430"/>`;
  const p=Abyss.AccessoryStyle.get(a),id='accessory-material-'+(++sequence);let transform='',model=(draw[v.renderer]||draw.star)(a);
  if(a.slot==='tail'){
   const [x,y]=Abyss.AttachmentRig.tail(s);transform=`translate(${x} ${y})`;
   if(v.renderer==='ribbon')model='<path d="m0 0-24-13q-7 13 0 29L0 5l24 11q7-14 0-29zM-4 4l-9 32 10-6 7 3 5-26z"/><path d="m-20-5 15 7-14 6m39-13-15 7 14 6" fill="none" stroke="var(--art-light)" stroke-width="2"/><ellipse cx="0" cy="3" rx="5" ry="7" fill="var(--art-shade)"/>';
   if(v.renderer==='bell')model='<path d="M-13 3q0-23 13-23T13 3l5 6h-36z" fill="var(--art-metal)"/><ellipse cy="9" rx="18" ry="4" fill="var(--art-shade)"/><circle cy="15" r="4" fill="var(--art-metal)"/><path d="M-5-13v9" stroke="var(--art-trim)" stroke-width="2"/>';
  }else if(a.slot==='charm')transform='translate(303 303)';
  else if(a.slot==='head'&&s?.progress&&(s.mutations.includes('horns')||Abyss.Evolution.profile(s).horns))transform='translate(0 -10)';
  else if(a.slot==='back'&&s?.progress&&(s.mutations.includes('wings')||Abyss.Evolution.profile(s).back?.variant==='wings'))transform='translate(-8 4)';
  const premium=['atelier','weather'].includes(a.visual.renderer)?null:Abyss.Couture.premium(a);if(premium)return `<g transform="${transform}">${premium}</g>`;
  return `<g transform="${transform}" style="--art-light:${p.light};--art-shade:${p.shade};--art-ink:${p.shade};--art-trim:${p.trim};--art-metal:url(#${id}-metal)" fill="url(#${id})" stroke="${p.shade}" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"><defs><linearGradient id="${id}" x1="0" y1="0" x2=".75" y2="1"><stop stop-color="${p.light}"/><stop offset=".38" stop-color="${p.base}"/><stop offset="1" stop-color="${p.shade}"/></linearGradient><linearGradient id="${id}-metal" x2=".85" y2=".65"><stop stop-color="${p.shade}"/><stop offset=".25" stop-color="${p.metal}"/><stop offset=".4" stop-color="${p.trim}"/><stop offset=".58" stop-color="${p.metal}"/><stop offset="1" stop-color="${p.shade}"/></linearGradient></defs><g class="model-depth" transform="translate(3 4)" opacity=".5" style="filter:brightness(.2)">${model}</g>${model}</g>`;
 }
 const closeups={pack:'99 190 94 166',tank:'97 150 112 197',container:'91 193 95 144',button:'277 277 52 52',key:'277 272 52 72',knot:'263 270 80 75',pouch:'272 279 62 67',tag:'279 280 48 64',star:'266 266 74 74',prism:'262 262 84 87',compass:'266 256 99 93'};
 const boxes={head:'115 18 250 177',face:'143 160 193 170',neck:'158 237 164 114',body:'127 245 223 125',back:'26 58 428 323',tail:'285 236 177 177',charm:'264 260 80 97',utility:'93 236 94 108',weapon:'325 198 87 190',effect:'77 273 333 113'};
 function icon(a,locked=false){if(a.visual.renderer==='road')return Abyss.RoadArt.icon(a,locked);if(a.visual.renderer==='hunt')return Abyss.HuntArt.icon(a,locked);return `<svg class="accessory-art ${locked?'silhouette':''}" viewBox="${a.slot==='tail'?(a.visual.renderer==='atelier'?'252 250 155 168':'282 256 102 145'):closeups[a.visual.renderer]||boxes[a.slot]}" aria-hidden="true">${markup(a,{mutations:[]})}</svg>`;}
 draw.road=(a,s)=>Abyss.RoadArt.markup(a,s);
 return {markup,icon,draw};
})();


