'use strict';
// Shared lighting, not shared silhouettes. Each draw function receives local material IDs.
Abyss.ArtMaterials=(()=>{
 let sequence=0;
 const palettes={road:['#cf814e','#f1d6a4','#503c35'],military:['#7d927a','#d6cfab','#263d37'],casual:['#ad7d8d','#f4d9c5','#55394c'],lab:['#87b7bf','#edf2dd','#29475b'],punk:['#955567','#d7b37c','#282636'],industrial:['#ac8356','#e5c99a','#35474b'],absurd:['#d39e83','#efe0ae','#67546e'],formal:['#65708f','#e5cca0','#242d48'],garden:['#749877','#e3d7a8','#304e45'],anomaly:['#79678e','#dacbce','#1c202e']};
 function make(theme='lab'){const [base,light,dark]=palettes[theme]||palettes.lab,id='atelier-'+(++sequence);return {base,light,dark,id,fill:`url(#${id}-fabric)`,metal:`url(#${id}-metal)`,glass:`url(#${id}-glass)`,defs:`<defs><linearGradient id="${id}-fabric" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${light}"/><stop offset=".18" stop-color="${base}"/><stop offset=".55" stop-color="${base}"/><stop offset="1" stop-color="${dark}"/></linearGradient><linearGradient id="${id}-metal" x1="0" y1="0" x2=".85" y2=".7"><stop stop-color="${dark}"/><stop offset=".22" stop-color="${light}"/><stop offset=".37" stop-color="#fff3d9"/><stop offset=".49" stop-color="${base}"/><stop offset=".75" stop-color="${dark}"/><stop offset="1" stop-color="${light}"/></linearGradient><linearGradient id="${id}-glass" x1="0" y1="0" x2="1" y2=".8"><stop stop-color="#def5ed" stop-opacity=".6"/><stop offset=".2" stop-color="#6dacae" stop-opacity=".16"/><stop offset=".5" stop-color="#152b42" stop-opacity=".88"/><stop offset=".75" stop-color="#a8d9dc" stop-opacity=".3"/><stop offset="1" stop-color="#243c4b" stop-opacity=".8"/></linearGradient></defs>`};}
 const path=(d,fill='currentColor',extra='')=>`<path d="${d}" fill="${fill}" ${extra}/>`;
 const line=(d,c='#d4d6be',w=1.4)=>path(d,'none',`stroke="${c}" stroke-width="${w}" stroke-linecap="round"`);
 const circle=(x,y,r,fill,extra='')=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${fill}" ${extra}/>`;
 const rect=(x,y,w,h,r,fill)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="${fill}"/>`;
 const rivets=(points,m)=>points.map(([x,y])=>circle(x,y,2.3,m.metal)+line(`M${x-1} ${y}h2`,m.dark,.8)).join('');
 return {make,path,line,circle,rect,rivets,palettes};
})();
