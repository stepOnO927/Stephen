'use strict';
// Dedicated wardrobe + archive UI. All changes go through Engine commands.
Abyss.Wardrobe = (() => {
 const $=id=>document.getElementById(id),esc=Abyss.Util.escape;
 let engine,mode='wardrobe',filters={slot:'all',rarity:'all',owned:'owned',sort:'rarity'},selected=null,previewLocked=false,returnAfterReveal=null,lastReveal=null;
 const rarity=id=>Abyss.Data.rarities.find(r=>r.id===id);
 function progress(s){
  const knownAnomaly=Abyss.Data.accessories.some(a=>a.rarity==='anomalous'&&s.collection.owned[a.id]);
  const count=Object.keys(s.collection.owned).length;
  return `<div class="collection-total"><small>ACCESSORIES</small><strong>${count}<span> / ${knownAnomaly?Abyss.Data.accessories.length:Abyss.Data.accessories.filter(a=>a.rarity!=='anomalous').length+' + ?'}</span></strong></div><div class="rarity-progress">${Abyss.Data.rarities.map(r=>{const list=Abyss.Data.accessories.filter(a=>a.rarity===r.id),owned=list.filter(a=>s.collection.owned[a.id]).length;return `<span class="rarity-${r.id}"><i></i>${r.zh}<b>${r.id==='anomalous'&&!knownAnomaly?'? / ?':owned+' / '+list.length}</b></span>`;}).join('')}</div>`;
 }
 function card(s,a){
  const own=s.collection.owned[a.id],worn=s.collection.equipped[a.slot]===a.id,r=rarity(a.rarity);
  return `<button class="accessory-card rarity-${a.rarity} ${own?'owned':'unknown'} ${selected===a.id?'selected':''}" data-wardrobe="select" data-item="${a.id}" aria-label="${own?esc(a.zh):'未知饰品'}，${Abyss.Data.slots[a.slot]}，${r.zh}"><span class="accessory-thumbnail">${Abyss.AccessoryArt.icon(a,!own)}</span><span class="accessory-card-title">${own?esc(a.zh):'???'}</span><span class="accessory-card-meta">${r.zh} <i>·</i> ${Abyss.Data.slots[a.slot]}</span><span class="accessory-card-state">${worn?'● 穿戴中':own?'已收藏':'◇ 未知'}</span></button>`;
 }
 function filtered(s){return Abyss.Accessories.visible(s).filter(a=>(filters.slot==='all'||a.slot===filters.slot)&&(filters.rarity==='all'||a.rarity===filters.rarity)&&(filters.owned==='all'||(filters.owned==='owned'?!!s.collection.owned[a.id]:!s.collection.owned[a.id]))).sort((a,b)=>filters.sort==='date'?((s.collection.owned[b.id]?.order||0)-(s.collection.owned[a.id]?.order||0)||a.id.localeCompare(b.id)):(rarity(b.rarity).rank-rarity(a.rarity).rank||a.id.localeCompare(b.id)));}
 function options(list,value){return list.map(([id,text])=>`<option value="${id}" ${value===id?'selected':''}>${text}</option>`).join('');}
 function toolbar(){return `<div class="wardrobe-filters"><label>稀有度<select data-filter="rarity" aria-label="稀有度筛选">${options([['all','全部稀有度'],...Abyss.Data.rarities.map(r=>[r.id,r.zh])],filters.rarity)}</select></label><label>收藏状态<select data-filter="owned" aria-label="收藏状态筛选">${options([['all','全部'],['owned','已获得'],['unowned','未获得']],filters.owned)}</select></label><label>排序<select data-filter="sort" aria-label="排序方式">${options([['rarity','稀有度优先'],['date','最近获得']],filters.sort)}</select></label></div>`;}
 function slots(s){return `<div class="outfit-slots">${Object.entries(Abyss.Data.slots).map(([slot,zh])=>{const a=Abyss.Accessories.find(s.collection.equipped[slot]);return `<div class="outfit-slot"><small>${slot.toUpperCase()} / ${zh}</small><span>${a?esc(a.zh):'— 空位 —'}</span><button data-wardrobe="unequip" data-slot="${slot}" ${!a||s.awaySince?'disabled':''} aria-label="取下${zh}饰品">取下</button></div>`;}).join('')}</div>`;}
 function detail(s){
  const a=Abyss.Accessories.find(selected);if(!a)return '<div class="accessory-detail"><p>选择一件饰品，查看细节或试穿。</p><small>换装不消耗行动点 · 纯外观收藏</small></div>';
  const own=s.collection.owned[a.id],worn=s.collection.equipped[a.slot]===a.id,r=rarity(a.rarity);
  const canBuy=['shop','merchant'].includes(a.unlock.type),merchant=a.unlock.type==='merchant',available=!merchant||(s.collection.merchantUntil>=s.day&&s.collection.merchantUntil>0);
  return `<div class="accessory-detail rarity-${a.rarity}"><span class="rarity-label">${r.name} / ${r.zh} <i>·</i> ${a.slot.toUpperCase()}</span><h3>${own?esc(a.zh):'???'}</h3><small>${own?esc(a.name):'UNIDENTIFIED ACCESSORY'}</small><p>${own?esc(a.description):'尚未收入档案。只能观察它留下的轮廓。'}</p>${own?`<div class="accessory-design-note"><i></i>${esc(Abyss.AccessoryStyle.get(a).label)}</div>`:''}<p class="accessory-source">${own?`D${own.day} · ${esc(own.source)}`:`线索：${esc([a.unlock.hint,...a.alternatives.map(u=>u.hint)].join('；或 '))}`}</p>${own&&s.progress.evolution.stage>=2?'<p class="accessory-fit-note">成长适配：保留原图层，帽饰避让感角，尾饰随尾部移位。</p>':''}<div class="accessory-detail-actions">${own?`<button data-wardrobe="equip" data-item="${a.id}" ${worn||s.awaySince?'disabled':''}>${worn?'正在穿戴':'穿戴'}</button>${worn?`<button data-wardrobe="unequip" data-slot="${a.slot}" ${s.awaySince?'disabled':''}>取下</button>`:''}`:`<button data-wardrobe="preview" data-item="${a.id}">${previewLocked?'结束轮廓预览':'预览轮廓'}</button>${canBuy?`<button data-wardrobe="buy" data-item="${a.id}" ${!available||s.money<a.unlock.price?'disabled':''}>${available?`购入 ₵ ${a.unlock.price}`:'等待商人来访'}</button>`:''}`}</div></div>`;
 }
 function presets(s){return `<div class="preset-list">${Array.from({length:5},(_,i)=>{const id=i+1,p=s.collection.presets.find(p=>p.id===id);return `<div class="preset-row"><span class="preset-number">0${id}</span><label><span class="sr-only">穿搭 ${id} 名称</span><input data-preset-name="${id}" aria-label="穿搭 ${id} 名称" maxlength="24" value="${esc(p?.name||'OUTFIT 0'+id)}" ${!p?'disabled':''}></label><button data-wardrobe="preset-save" data-preset="${id}">${p?'覆盖当前':'保存当前'}</button><button data-wardrobe="preset-load" data-preset="${id}" ${!p||s.awaySince?'disabled':''}>载入</button><button data-wardrobe="preset-rename" data-preset="${id}" ${!p?'disabled':''}>重命名</button><button data-wardrobe="preset-delete" data-preset="${id}" ${!p?'disabled':''}>删除</button></div>`;}).join('')}</div>`;}
 function paint(){
  if(!$('modal').open||!$('modal').classList.contains('wardrobe-modal'))return;
  if(mode==='colors'){Abyss.ColorUI.paint();return;}
  const s=engine.snapshot(),scroll=$('accessory-inventory')?.scrollTop||0;
  const active=document.activeElement?.dataset.item;
  const list=filtered(s).filter(a=>mode!=='shop'||['shop','merchant'].includes(a.unlock.type));if(!list.some(a=>a.id===selected)){selected=list.find(a=>s.collection.owned[a.id])?.id||list[0]?.id||null;previewLocked=false;}
  $('modal-content').innerHTML=`<div class="wardrobe-nav"><div class="wardrobe-mode-tabs">${[['wardrobe','衣橱'],['archive','饰品档案'],['shop','补给商店'],['presets','常用穿搭'],['colors','改颜色']].map(([id,label])=>`<button data-wardrobe="mode" data-mode="${id}" class="${mode===id?'active':''}">${label}</button>`).join('')}</div><span>纯外观 · 无属性加成 <b>₵ ${s.money}</b></span></div><div class="wardrobe-layout"><nav class="wardrobe-categories" aria-label="穿戴部位"><small>SLOTS / 部位</small>${[['all','全部部位'],...Object.entries(Abyss.Data.slots)].map(([slot,zh])=>`<button data-wardrobe="slot" data-slot="${slot}" class="${filters.slot===slot?'active':''}">${zh}<small>${slot.toUpperCase()}</small></button>`).join('')}<div class="wardrobe-set-note">${s.collection.discoveredSets.length?'已发现的共鸣<br>'+s.collection.discoveredSets.map(id=>esc(Abyss.Data.outfitSets.find(set=>set.id===id).name)).join('<br>'):'有些搭配会唤醒特别的反应。'}</div></nav><section class="wardrobe-preview"><div class="wardrobe-preview-heading"><small>LIVE OUTFIT PREVIEW</small><span>${esc(s.name)} · ${previewLocked?'轮廓试穿':'当前穿搭'}</span></div><div id="wardrobe-creature-mount"></div><div class="wardrobe-preview-floor"></div>${detail(s)}</section><section class="wardrobe-inventory-panel">${mode==='presets'?`<h3>常用穿搭</h3><p class="modal-intro">最多 5 套，保存完整七部位组合。载入时空位也会同步。</p>${presets(s)}`:`${progress(s)}${toolbar()}<div id="accessory-inventory" class="accessory-inventory">${(mode==='shop'?list.filter(a=>['shop','merchant'].includes(a.unlock.type)):list).map(a=>card(s,a)).join('')||'<p class="collection-empty">没有符合筛选条件的饰品。</p>'}</div>`}</section></div>${slots(s)}`;
  const preview=Abyss.Util.clone(s);
  if(previewLocked&&selected&&!s.collection.owned[selected]){const a=Abyss.Accessories.find(selected);preview.collection.equipped[a.slot]=a.id;}
  const svg=Abyss.Renderer.clone(preview);$('wardrobe-creature-mount').appendChild(svg);
  if(previewLocked&&selected){const a=Abyss.Accessories.find(selected);svg.querySelector(`[data-accessory-slot="${a.slot}"]`)?.classList.add('silhouette');}
  if($('accessory-inventory'))$('accessory-inventory').scrollTop=scroll;
  if(active)$('accessory-inventory')?.querySelector(`[data-item="${active}"]`)?.focus({preventScroll:true});
 }
 function open(nextMode='wardrobe'){
  const s=engine.snapshot();if(s.pendingEvent||s.endingNotice){Abyss.UI.showPending();return;}
  mode=nextMode;previewLocked=false;if(mode==='archive'){filters.owned='all';filters.slot='all';filters.rarity='all';}
  if(mode==='shop'){filters.owned='unowned';filters.slot='all';filters.rarity='all';}
  Abyss.UI.modal('衣橱与饰品档案','');$('modal').classList.add('wardrobe-modal');paint();
 }
 function showReveal(back=null){
  const s=engine.snapshot(),id=s.collection.reveals[0];if(!id)return false;
  const a=Abyss.Accessories.find(id),r=rarity(a.rarity);returnAfterReveal=back;
  Abyss.UI.modal('新饰品已发现',`<section class="accessory-reveal rarity-${a.rarity}"><small>NEW SPECIMEN ACCESSORY</small><div class="reveal-art"><i></i><i></i><i></i>${Abyss.AccessoryArt.icon(a)}</div><span class="rarity-label">${r.name} / ${r.zh}</span><h3>${esc(a.name)}</h3><h4>${esc(a.zh)}</h4><p>${esc(s.collection.owned[id].source)}</p><p class="reveal-lore">${esc(a.description)}</p><button data-wardrobe="ack" data-item="${id}">加入档案 / ADD TO ARCHIVE</button><small>已自动保存 · ${s.collection.reveals.length>1?'还有 '+(s.collection.reveals.length-1)+' 件新发现':'这一刻已被记录'}</small></section>`);
  $('modal').classList.add('accessory-reveal-modal');
  // Future sound implementation subscribes here; no new audio dependency or autoplay.
  if(lastReveal!==id){document.dispatchEvent(new CustomEvent('abyss:accessory-reveal',{detail:{id,rarity:a.rarity,soundKey:'accessory.reveal.'+a.rarity,soundEnabled:s.settings.sound}}));lastReveal=id;}
  return true;
 }
 function run(type,payload){const r=engine.dispatch({type,payload});Abyss.UI.toast(r.saved===false?Abyss.Save.warning():r.message);return r.ok;}
 function bind(controller){
  engine=controller;engine.subscribe(paint);
  document.addEventListener('click',event=>{
   const el=event.target.closest('[data-wardrobe]');if(!el||el.disabled)return;
   const action=el.dataset.wardrobe,id=el.dataset.item;
   if(action==='mode'){mode=el.dataset.mode;previewLocked=false;if(mode==='archive'){filters.owned='all';filters.slot='all';filters.rarity='all';}if(mode==='wardrobe')filters.owned='owned';if(mode==='shop'){filters.owned='unowned';filters.slot='all';filters.rarity='all';}paint();return;}
   if(action==='slot'){filters.slot=el.dataset.slot;previewLocked=false;paint();return;}
   if(action==='select'){selected=id;previewLocked=false;paint();return;}
   if(action==='preview'){previewLocked=!previewLocked;paint();return;}
   if(action==='equip'){previewLocked=false;run('accessory:equip',{id});return;}
   if(action==='unequip'){previewLocked=false;run('accessory:unequip',{slot:el.dataset.slot});return;}
   if(action==='buy'){if(run('accessory:buy',{id}))showReveal(mode);return;}
   if(action==='ack'){const back=returnAfterReveal;if(run('accessory:ack',{id})){if(!showReveal(back)){Abyss.UI.close();if(back)open(back);else Abyss.UI.showPending();}}return;}
   if(action.startsWith('preset-')){
    const preset=Number(el.dataset.preset),operation=action.slice(7),name=document.querySelector(`[data-preset-name="${preset}"]`)?.value;
    run('outfit:'+operation,{id:preset,name});
   }
  });
  document.addEventListener('change',event=>{const key=event.target.dataset.filter;if(key){filters[key]=event.target.value;previewLocked=false;paint();}});
 }
 return {bind,open,paint,showReveal,filtered};
})();
