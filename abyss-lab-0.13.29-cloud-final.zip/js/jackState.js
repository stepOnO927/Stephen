'use strict';
Abyss.JackState=(()=>{
 const traits=['compassion','pragmatism','curiosity','control','honesty','fear','attachment','sacrifice','ambition','nihilism'];
 const fresh=()=>({version:1,tendencies:Object.fromEntries(traits.map(k=>[k,0])),flags:{},journal:[],readBeats:[],miaEvidence:[],pendingEnding:null});
 function read(raw,s){const j=fresh(),r=raw.narrative?.jack;if(!r){const p=raw.campaign?.philosophy||{},n=raw.narrative?.profile||{};for(const [a,b]of [['compassion','compassion'],['attachment','attachment'],['sacrifice','sacrifice'],['ambition','ambition'],['nihilism','nihilism']])j.tendencies[a]=Math.min(10000,Math.max(0,Number(p[b])||0));j.tendencies.control=Math.min(10000,n.controlling||0);j.tendencies.curiosity=Math.min(10000,n.curious||0);j.tendencies.honesty=raw.campaign?.flags?.honest?1:0;return j;}
 const D=Abyss.JackData;for(const k of traits)j.tendencies[k]=Number.isFinite(r.tendencies?.[k])?Math.max(0,Math.min(10000,r.tendencies[k])):0;
 for(const k of D.flagIds)if(r.flags?.[k]===true)j.flags[k]=true;
 j.readBeats=Array.isArray(r.readBeats)?[...new Set(r.readBeats.filter(id=>D.beatIds.includes(id)))]:[];
 j.miaEvidence=Array.isArray(r.miaEvidence)?[...new Set(r.miaEvidence.filter(id=>D.evidence.some(e=>e.id===id)))]:[];
 j.journal=Array.isArray(r.journal)?r.journal.slice(-60).filter(x=>D.journals[x?.id]&&Number.isInteger(x.day)&&x.day>0&&x.day<=s.day).map(x=>({id:x.id,day:x.day,branch:D.journals[x.id][x.branch]?x.branch:'default'})):[];
 j.pendingEnding=D.expandedEndings.includes(r.pendingEnding)?r.pendingEnding:null;return j;
 }
 return {fresh,read,traits};
})();
