'use strict';
Abyss.Mutations = (() => {
 function attempt(s,bonus=0){
   if(s.age<2)return null;
   const candidates=Abyss.Data.mutations.filter(m=>!s.mutations.includes(m.id)&&Abyss.Util.matches(s,m.rules)&&Abyss.Evolution.compatible(s,m));
   if(!candidates.length||Abyss.Util.random(s)>Math.min(.85,.13+s.stats.pollution*.002+bonus))return null;
   const weights=candidates.map(m=>1+(s.bias[m.affinity]||0));
   let roll=Abyss.Util.random(s)*weights.reduce((a,b)=>a+b,0),selected=candidates[0];
   for(let i=0;i<candidates.length;i++){roll-=weights[i];if(roll<=0){selected=candidates[i];break;}}
   s.mutations.push(selected.id);Abyss.State.effects(s,selected.effects);Abyss.State.log(s,`新生理变化：${Abyss.Progression.mutationLabel(s,selected)}。`,'rare');return selected;
 }
 function mature(s){
   if(s.age<20||s.form)return;
   const score=f=>Object.entries(f.weights).reduce((n,[path,w])=>n+path.split('.').reduce((o,k)=>o[k],s)*w,0)+Object.entries(f.mutations).reduce((n,[id,w])=>n+(s.mutations.includes(id)?w:0),0);
   s.form=Abyss.Data.forms.filter(f=>!f.phase3).sort((a,b)=>score(b)-score(a))[0].id;
   s.discoveredForms.push(s.form);s.endingNotice=true;
   Abyss.State.log(s,`成熟形态已确认：${Abyss.Data.forms.find(f=>f.id===s.form).name}。它的故事还在继续。`,'rare');
 }
 return {attempt,mature};
})();
