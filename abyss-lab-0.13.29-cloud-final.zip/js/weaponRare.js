 'use strict';
// Conditional Rare builds. Penetration channels and shield damage are deliberately separate.
Abyss.WeaponRare=(()=>{
 const fields=['armorPen','defensePen','shieldDamageBonus','statusPen','critPen','guardBreak','weakPointDamage','bossDamage'];
 const designs={weapon_fork:'FURNACE OPEN',weapon_sling:'SLIP AWAY',weapon_lance:'MEASURE TWICE',weapon_bracer:'HOLD THEM BACK',weapon_jaw:'BITE DEEPER',weapon_tether:'TANGLED',weapon_harpoon:'PULL BACK',weapon_scrambler:'SIGNAL LOST',weapon_ram:'OPEN THE DAMN DOOR',weapon_disc:'RETURN TO SENDER',weapon_crescent:'CRESCENT MARK',weapon_service:'NIGHT SHIFT',ud_weapon_8:'IMPALE',ud_weapon_9:'OLD DRILL',ud_weapon_10:'POINT BLANK',ud_weapon_11:'FULL DRAW'};
 const has=(f,id)=>f?.enemyStatus?.some(x=>x.id===id&&x.turns>0),rank=(s,w)=>s.hunt.weapons[w?.id]?.resonanceLevel||0,mechanical=e=>/machine|robot|security/.test(e?.category||'')||/drone|turret|robot|watchdog/.test(e?.id||'');
 for(const w of Abyss.WeaponData.weapons){for(const k of fields)w[k]=0;if(designs[w.id])w.rareResonance=designs[w.id];}
 function stats(s,w,f,e={},critical=false){const o=Object.fromEntries(fields.map(k=>[k,w?.[k]||0]));Object.assign(o,{attack:0,time:1,range:1,dodge:0,crit:0,critDamage:0,counter:0,counterDamage:1,damage:1,accuracy:0,weak:false});const r=rank(s,w),first=!(f?.weaponHits>0),close=(f?.distance??2.5)<=1.5,far=(f?.distance??0)>=w?.range*.85,dodged=(f?.dodges||0)>(f?.weaponLastDodge||0),guarded=(f?.weaponGuardTurn||0)>=(f?.turn||1)-1;
 if(['common','uncommon'].includes(w?.rarity)){o.attack=(r>=1?.08:0)+(r>=3?.1:0)+(r>=6?.18:0);o.time=Math.max(.65,1-(r>=2?.05:0)-(r>=3&&w.rarity==='uncommon'?.08:0)-(r>=5&&w.rarity==='uncommon'?.08:0));if(r>=4){if(w.trait==='pierce'||w.trait==='break')o.defensePen=.05;if(w.trait==='crit'||w.trait==='first')o.crit=.03;if(w.trait==='guard')o.defense=.08;if(w.trait==='counter')o.counter=.04;if(w.trait==='combo')o.combo=.04;if(['burn','poison','stun','fear'].includes(w.trait))o.statusPen=.05;}if(r>=5)o.range=1.03;if(r>=6&&w.rarity==='uncommon'){if(w.trait==='first'&&!(f?.weaponHits>0))o.damage=1.12;if(w.trait==='guard')o.guardBreak=.05;}}
 if(!designs[w?.id]){Object.assign(o,Abyss.WeaponEpic?.stats(s,w,f,e)||{},Abyss.WeaponNamed?.stats(s,w,f)||{},Abyss.WeaponLegendary?.stats(s,w,f,e)||{},Abyss.WeaponAnomalous?.stats(s,w,f)||{});o.armorPen=Math.min(.65,o.armorPen+(f?.weaponArmor||0));return o;}
 switch(w.id){
 case 'weapon_fork':if(has(f,'burn')){o.armorPen+=(r>=1?.08:0)+(r>=5?.1:0);if(r>=4)o.shieldDamageBonus+=.15;}if(r>=3)o.attack=.08;break;
 case 'weapon_sling':if(r>=1)o.dodge=.06;if(r>=2&&f?.weaponHits>0)o.defensePen=.08;if(r>=3)o.time=.92;if(r>=4&&has(f,'slow')){o.weak=true;o.weakPointDamage=.12;}if(r>=5&&dodged)o.defensePen+=.12;if(r>=6&&dodged)o.guardBreak=.5;break;
 case 'weapon_lance':if(first&&r>=1){o.weak=true;o.weakPointDamage=.12+(r>=5?.1:0);}if(r>=2)o.range=1.05;if(r>=3)o.attack=.08;if(r>=4)o.critPen=.1;break;
 case 'weapon_bracer':if(r>=1)o.counterDamage=1.1;if(r>=2)o.guardBreak=.1;if(r>=3)o.attack=.08;if(r>=4&&guarded)o.defensePen=.12;if(r>=5)o.counter=.08;break;
 case 'weapon_jaw':if(r>=1)o.crit=.05;if(r>=2)o.critPen=.1;if(r>=3)o.attack=.08;if(r>=4&&critical)o.armorPen=.12;if(r>=5)o.critDamage=.12;break;
 case 'weapon_tether':if(r>=1)o.statusPen=.1;if(r>=3)o.time=.92;if(r>=4&&has(f,'slow'))o.defensePen=.1;break;
 case 'weapon_harpoon':if(r>=1)o.armorPen=.08;if(r>=2)o.counterDamage=1.1;if(r>=3)o.range=1.05;if(r>=4&&far)o.guardBreak=.1;if(r>=5&&(f?.weaponCounterTurn||0)>=(f?.turn||1)-1)o.time=.85;break;
 case 'weapon_scrambler':if(r>=1)o.statusPen=.12;if(r>=3)o.time=.93;if(r>=4&&mechanical(e))o.defensePen=.12;break;
 case 'weapon_ram':if(r>=1)o.bossDamage=.08+(r>=5?.1:0);if(r>=2)o.guardBreak=.12;if(r>=3)o.attack=.08;if(r>=4)o.shieldDamageBonus=.15;if(r>=6&&e.boss&&f?.enemyShield>0&&!f.weaponBreachUsed)o.guardBreak+=.55;break;
 case 'weapon_disc':if(r>=1)o.critPen=.08;if(r>=2)o.counterDamage=1.1;if(r>=3)o.time=.92;if(r>=4&&(f?.weaponCounterTurn||0)>=(f?.turn||1)-1)o.crit=.12;if(r>=5)o.range=1.05;break;
 case 'weapon_crescent':if(r>=1&&first)o.damage=1.1;if(r>=2)o.armorPen=.08;if(r>=3)o.range=1.05;if(r>=4&&f?.weaponWeakUntil>=f?.turn){o.weak=true;o.weakPointDamage=.12;}if(r>=5)o.critPen=.1;if(r>=6&&f?.weaponHits===1)o.armorPen+=.2;break;
 case 'weapon_service':if(r>=1)o.time=.94;if(r>=2)o.critPen=.08;if(r>=3&&f?.combo>1)o.damage=1.08;if(r>=4)o.defensePen=.1;if(r>=5&&f?.weaponHits===1)o.crit=.12;if(r>=6&&f?.weaponHits>0&&(f.weaponHits+1)%4===0){o.weak=true;o.weakPointDamage=.3;}break;
 case 'ud_weapon_8':if(r>=1)o.armorPen=.12+(r>=5?.1:0);if(r>=2)o.shieldDamageBonus=.12;if(r>=3)o.attack=.08;if(r>=4&&f?.weaponWeakUntil>=f?.turn){o.weak=true;o.weakPointDamage=.1;}if(r>=6&&far)o.armorPen+=.2;break;
 case 'ud_weapon_9':if(r>=1)o.defensePen=.08;if(r>=2)o.accuracy=Math.min(.1,(f?.weaponHits||0)*.025);if(r>=3)o.attack=.08;if(r>=4)o.critPen=.08;if(r>=5)o.damage=1+Math.min(.12,(f?.weaponHits||0)*.02);if(r>=6&&f?.weaponPrecisionUntil>=f?.turn)o.accuracy+=.2;break;
 case 'ud_weapon_10':if(r>=1&&close)o.shieldDamageBonus=.12;if(r>=2&&close)o.armorPen=.1;if(r>=3)o.attack=.08;if(r>=4)o.guardBreak=.12;if(r>=5&&close)o.crit=.1;if(r>=6&&close&&!f?.weaponPointUsed)o.guardBreak+=.55;break;
 case 'ud_weapon_11':if(r>=1)o.armorPen=.08;if(r>=2&&f?.weaponCharged)o.damage=1.18;if(r>=3)o.range=1.05;if(r>=4&&f?.weaponWeakUntil>=f?.turn){o.weak=true;o.weakPointDamage=.12;}if(r>=5&&f?.weaponCharged)o.critPen=.12;break;
 }
 o.armorPen+=f?.weaponArmor||0;if(f?.weaponWeakUntil>=(f?.turn||1)){o.weak=true;o.weakPointDamage+=.12;}if(f?.weaponPrecisionUntil>=(f?.turn||1))o.accuracy+=.12;
 for(const k of fields)o[k]=Math.min(.65,o[k]);return o;
 }
 function defenses(e){const armored=mechanical(e)||['tank','defensive'].includes(e.behavior),armor=Number.isFinite(e.armor)?e.armor:armored?e.defense*.7:0;return {armor,defense:Math.max(0,e.defense-armor),critResistance:e.critResistance??(armored?.12:e.boss?.08:0),statusResistance:e.statusResistance??(armored?.35:e.boss?.2:.08)};}
 function beforeHit(s,w,f){if(rank(s,w)>=6&&w?.id==='weapon_lance'&&!f.weaponMeasured){f.weaponMeasured=true;f.weaponWeakUntil=f.turn+3;}}
 function hit(s,w,f,e,damage,crit,shieldBefore=f.enemyShield){if(['common','uncommon'].includes(w?.rarity))f.weaponHits=(f.weaponHits||0)+1;if(!designs[w?.id])return damage;const r=rank(s,w);f.weaponHits=(f.weaponHits||0)+1;if(r<6)return damage;switch(w.id){
 case 'weapon_fork':if(has(f,'burn')&&Abyss.Util.random(s)<.35)f.weaponArmor=Math.min(.3,(f.weaponArmor||0)+.1);break;
 case 'weapon_sling':f.weaponLastDodge=f.dodges;break;
 case 'weapon_jaw':f.weaponArmor=crit?Math.min(.24,(f.weaponArmor||0)+.06):0;break;
 case 'weapon_tether':if(has(f,'slow')&&Abyss.Util.random(s)<.3)f.weaponPrecisionUntil=f.turn+2;break;
 case 'weapon_ram':if(e.boss&&shieldBefore>0)f.weaponBreachUsed=true;break;
 case 'weapon_crescent':if(f.weaponHits===1)f.weaponWeakUntil=f.turn+3;break;
 case 'ud_weapon_9':if(f.weaponHits>=3)f.weaponPrecisionUntil=f.turn+2;break;
 case 'ud_weapon_10':if((f.distance??2.5)<=1.5)f.weaponPointUsed=true;break;
 case 'ud_weapon_11':if(f.weaponCharged){f.weaponBypass=Math.round(damage*.25);}break;
 }return damage;}
 function counter(s,w,f,e,damage){const p=stats(s,w,f,e),r=rank(s,w);damage*=p.counterDamage;f.weaponCounterTurn=f.turn;if(r>=6&&w?.id==='weapon_bracer'&&f.guarding){f.enemyShield=Math.max(0,f.enemyShield-Math.round(damage*.55));f.weaponGuardTurn=f.turn;}if(r>=6&&w?.id==='weapon_harpoon'){f.distance=Math.max(.5,(f.distance??2.5)-1);f.weaponWeakUntil=f.turn+1;}if(r>=6&&w?.id==='weapon_disc'&&!f.weaponReturnUsed&&(e.range>=4||e.behavior==='sniper')){f.weaponReturnUsed=true;damage*=1.35;}return Math.round(Abyss.WeaponRed.counter(s,w,f,e,damage));}
 function interrupt(s,w,f,e){if(w?.id!=='weapon_scrambler'||rank(s,w)<6||!mechanical(e)||!has(f,'weaken')||f.weaponSignalUsed)return false;f.weaponSignalUsed=true;return Abyss.Util.random(s)<.4;}
 function statusTurns(s,w,id){const r=rank(s,w);if(w?.rarity==='uncommon'&&r>=6&&['burn','poison','fear'].includes(id))return 4;return id==='burn'&&w?.id==='weapon_fork'&&r>=2||id==='slow'&&w?.id==='weapon_tether'&&r>=5||id==='weaken'&&w?.id==='weapon_scrambler'&&r>=5?4:3;}
 function miss(w,f){if(['weapon_service','ud_weapon_9'].includes(w?.id)){f.weaponHits=0;f.weaponPrecisionUntil=0;}}
 return {fields,designs,miss,stats,hit,beforeHit,defenses,counter,interrupt,statusTurns,rank,mechanical};
})();
