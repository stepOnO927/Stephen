'use strict';
// Anomalous randomness uses the game's saved RNG; no browser or operating-system effects.
Abyss.WeaponAnomalous=(()=>{
 const rank=(s,w)=>Abyss.WeaponRare.rank(s,w),supported=w=>w?.id==='weapon_null';
 const designs={weapon_null:['伤害归零概率降低','正面随机伤害上限提高','暴击让下一次随机结果更有利','敌方命中时极低概率将伤害归零','连续正面结果逐步强化下一击，最多五层','每场一次将伤害归零改为本回合敌人防御归零']};
 const english=['Reduced chance of zero damage','Higher positive random damage ceiling','Critical hits favor the next random outcome','A very rare chance to nullify incoming damage','Positive outcomes strengthen the next hit, capped at five stacks','Once per fight: a zero-damage result instead zeroes enemy defense for this turn'];
 const dictionary={};designs.weapon_null.forEach((v,i)=>dictionary[v]=english[i]);Abyss.I18n.register(dictionary);const weapon=Abyss.WeaponData.weapons.find(supported);if(weapon)weapon.anomalousResonance=designs.weapon_null;
 function prepare(s,w,f){if(!supported(w))return;const r=rank(s,w),favored=r>=3&&f.weaponNullFavored===true,zeroChance=favored?.08:r>=1?.22:.3;f.weaponNullFavored=false;let good=Abyss.Util.random(s)>=zeroChance,modifier=0;
  if(!good&&r>=6&&!f.weaponNullConverted){f.weaponNullConverted=true;f.weaponNullDefenseTurn=f.turn;good=true;modifier=1;f.logs.push('DEREFERENCE · DEFENSE 0');}
  else if(good)modifier=r>=2?(favored?1.4:1.2)+Abyss.Util.random(s)*(favored?.4:.6):1.5;
  f.weaponNullPositive=good;f.weaponNullMultiplier=Number((modifier*(r>=5?1+Math.min(5,f.weaponNullStreak||0)*.03:1)).toFixed(4));
 }
 function stats(s,w,f){if(Abyss.WeaponRed.supported(w))return Abyss.WeaponRed.stats(s,w,f);if(Abyss.WeaponTimed.supported(w))return Abyss.WeaponTimed.stats(s,w,f);if(Abyss.WeaponPopup.supported(w))return Abyss.WeaponPopup.stats(s,w,f);if(!supported(w)||!f)return {};return {damage:f.weaponNullMultiplier??1};}
 function zeroDefense(w,f){return supported(w)&&f.weaponNullDefenseTurn===f.turn;}
 function hit(s,w,f,n,critical){if(!supported(w))return;const r=rank(s,w);f.weaponNullStreak=f.weaponNullPositive?Math.min(5,(f.weaponNullStreak||0)+1):0;if(r>=3&&critical&&n>0)f.weaponNullFavored=true;}
 function incoming(s,w,f,n){if(supported(w)&&rank(s,w)>=4&&Abyss.Util.random(s)<.04){f.logs.push('INVALID TARGET · 0');return 0;}return n;}
 return {designs,supported,prepare,stats,zeroDefense,hit,incoming};
})();
