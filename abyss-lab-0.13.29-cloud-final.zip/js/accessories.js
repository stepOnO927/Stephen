'use strict';
Abyss.Accessories = (() => {
 const find=id=>Abyss.Data.accessories.find(a=>a.id===id);
 const validSlot=slot=>Object.prototype.hasOwnProperty.call(Abyss.Data.slots,slot);
 const ok=message=>({ok:true,message});const fail=message=>({ok:false,message});
 function grant(s,id,source){
  const a=find(id);if(!a||s.collection.owned[id])return false;
  s.collection.owned[id]={day:s.day,order:++s.collection.sequence,source,date:new Date().toISOString()};
  s.collection.reveals.push(id);Abyss.State.log(s,`发现饰品「${a.zh}」：${source}。`,'rare');
  if(!Abyss.Memory.has(s,'first_accessory'))Abyss.Memory.remember(s,'first_accessory',`第一次收到了${a.zh}。`);
  return true;
 }
 function met(s,u){
  if(u.rules&&!Abyss.Util.matches(s,u.rules))return false;
  switch(u.type){
   case 'explore':return s.collection.visits[u.place]>=u.visits;
   case 'milestone':return true;
   case 'event':return s.seenEvents.includes(u.event)&&s.pendingEvent!==u.event;
   case 'achievement':return s.achievements.includes(u.achievement);
   case 'form':return s.discoveredForms.includes(u.form);
   case 'memory':return Abyss.Memory.has(s,u.memory);
   default:return false;
  }
 }
 function reconcile(s){Abyss.Redeem.completeCollection(s);for(const a of Abyss.Data.accessories){const source=[a.unlock,...a.alternatives].find(u=>met(s,u));if(source)grant(s,a.id,source.hint==='未知'?'一段无法归类的共同经历':source.hint);}}
 function after(before,s,command){
  if(s.history.explore>before.history.explore){const place=command.payload==='sewers'?'sewer':command.payload;s.collection.visits[place]=(s.collection.visits[place]||0)+1;Abyss.Personality.exploration(s);}
  if(command.type==='event'&&before.pendingEvent==='merchant')s.collection.merchantUntil=s.day+2;
  reconcile(s);
 }
 function activeSets(s){const worn=Object.values(s.collection.equipped);return Abyss.Data.outfitSets.filter(set=>set.items.every(id=>worn.includes(id)));}
 function changed(s,item){
  s.collection.changes++;
  for(const set of activeSets(s))if(!s.collection.discoveredSets.includes(set.id)){s.collection.discoveredSets.push(set.id);Abyss.State.log(s,`服装共鸣「${set.name}」：${set.text}`,'rare');}
  if(item){const text=Abyss.Personality.reaction(s,item);if(text)Abyss.State.log(s,text,'story');}
 }
 function command(s,type,payload={}){
  const c=s.collection;
  if(type==='accessory:ack'){if(c.reveals[0]!==payload.id)return fail('这件饰品已归档。');c.reveals.shift();return ok('已加入饰品档案');}
  if(s.pendingEvent||s.endingNotice)return fail('请先处理当前事件。');
  if(['accessory:equip','accessory:unequip','outfit:load'].includes(type)&&s.awaySince)return fail('零号尚未回来，暂时无法换装。');
  if(type==='accessory:equip'){
   const a=find(payload.id);if(!a||!c.owned[a.id])return fail('尚未获得这件饰品。');
   if(c.equipped[a.slot]===a.id)return ok('已穿戴这件饰品');
   c.equipped[a.slot]=a.id;changed(s,a);return ok(`已穿戴 · ${a.zh}`);
  }
  if(type==='accessory:unequip'){
   if(!validSlot(payload.slot))return fail('未知部位。');
   c.equipped[payload.slot]=null;changed(s);return ok('已取下饰品');
  }
  if(type==='accessory:buy'){
   const a=find(payload.id);if(!a||!['shop','merchant'].includes(a.unlock.type))return fail('这件饰品不出售。');
   if(c.owned[a.id])return fail('已经收藏了这件饰品。');
   if(a.unlock.type==='merchant'&&(!c.merchantUntil||s.day>c.merchantUntil))return fail('稀客已经离开，等待下次商人来访。');
   if(s.money<a.unlock.price)return fail('资金不足。');
   s.money-=a.unlock.price;grant(s,a.id,a.unlock.type==='merchant'?'地下商人的短暂停留':'衣橱补给商店');return ok('购入成功 · 不消耗行动点');
  }
  if(type.startsWith('outfit:')){
   const id=Number(payload.id);if(!Number.isInteger(id)||id<1||id>5)return fail('最多保存五套穿搭。');
   const preset=c.presets.find(p=>p.id===id);
   if(type==='outfit:save'){
    const data={id,name:preset?.name||`OUTFIT 0${id}`,outfit:{...c.equipped}};
    if(preset)c.presets[c.presets.indexOf(preset)]=data;else c.presets.push(data);
    return ok('当前穿搭已保存');
   }
   if(!preset)return fail('这个预设尚未保存。');
   if(type==='outfit:load'){c.equipped={...preset.outfit};changed(s,find(Object.values(c.equipped).find(Boolean)));return ok(`已载入 · ${preset.name}`);}
   if(type==='outfit:delete'){c.presets=c.presets.filter(p=>p.id!==id);return ok('已删除预设');}
   if(type==='outfit:rename'){
    if(typeof payload.name!=='string'||!payload.name.trim()||payload.name.trim().length>24)return fail('名称需为 1–24 个字符。');
    preset.name=payload.name.trim();return ok('预设已重命名');
   }
  }
  return fail('未知衣橱操作。');
 }
 function view(s,a){return {...a,obtained:!!s.collection.owned[a.id],equipped:s.collection.equipped[a.slot]===a.id,acquired:s.collection.owned[a.id]||null};}
 function visible(s){return Abyss.Data.accessories.filter(a=>!a.secret||s.collection.owned[a.id]);}
 return {find,grant,met,reconcile,after,activeSets,command,view,visible};
})();
