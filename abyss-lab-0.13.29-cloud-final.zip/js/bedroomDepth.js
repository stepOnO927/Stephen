'use strict';
// All furniture uses the room's XYZ camera. Rotation changes geometry, never a flat sprite.
(()=>{
 const old=Abyss.BedroomArt, esc=Abyss.Util.escape;
 const camera=(x,y,z=0)=>[425+(x-y)*43,125+(x+y)*23-z*45];
 function geometry(d,rotation=0,origin=[0,0,0]){
  const v=d.variant||0,[w,l]=d.floorFootprint,h=d.height,angle=rotation*Math.PI/180;
  const colors=[['#849b89','#52665b','#283e38'],['#b09278','#77604e','#493d37'],['#94abb5','#607e8d','#314951'],['#7d91aa','#4f607c','#29374e'],['#a195b0','#6a5a80','#3c304b'],['#c1ab83','#8a724f','#52462f']][v%6];
  const point=(x,y,z)=>{const a=camera(origin[0]+x*Math.cos(angle)-y*Math.sin(angle),origin[1]+x*Math.sin(angle)+y*Math.cos(angle),origin[2]+z);return a.join(',');};
  const face=(pts,color,extra='')=>`<polygon points="${pts.map(p=>point(...p)).join(' ')}" fill="${color}" stroke="#17262d" stroke-width=".8" ${extra}/>`;
  let out='';
  function box(x,y,z,a,b,c,palette=colors){const X=x+a,Y=y+b,Z=z+c;const sides=[{depth:(y+Y)/2+x,p:[[x,y,z],[x,Y,z],[x,Y,Z],[x,y,Z]],color:palette[2]}, {depth:(x+X)/2+y,p:[[x,y,z],[X,y,z],[X,y,Z],[x,y,Z]],color:palette[2]}, {depth:(x+X)/2+Y,p:[[x,Y,z],[X,Y,z],[X,Y,Z],[x,Y,Z]],color:palette[1]}, {depth:X+(y+Y)/2,p:[[X,y,z],[X,Y,z],[X,Y,Z],[X,y,Z]],color:palette[1]}];for(const f of sides.sort((a,b)=>{const depth=f=>f.p.reduce((n,[X,Y])=>n+X*(Math.cos(angle)+Math.sin(angle))+Y*(Math.cos(angle)-Math.sin(angle)),0)/4;return depth(a)-depth(b);}))out+=face(f.p,f.color);out+=face([[x,y,Z],[X,y,Z],[X,Y,Z],[x,Y,Z]],palette[0]);}
  function leg(x,y,z){box(x,y,0,.1,.1,z,['#81908b','#536563','#2c4144']);}
  const x=-w/2,y=-l/2;
  function supports(z){for(const a of [x+.06,x+w-.16])for(const b of [y+.06,y+l-.16])leg(a,b,z);}
  function cushion(a,b,z,W,L,H){box(a,b,z,W,L,H,['#d1cbb5','#999c88','#676e62']);out+=face([[a+.08,b+.08,z+H+.005],[a+W-.08,b+.08,z+H+.005],[a+W-.08,b+L-.08,z+H+.005],[a+.08,b+L-.08,z+H+.005]],colors[0],'opacity=".3"');}
  switch(d.kind){
   case 'climate_heater':supports(.12);box(x,y,.12,w,l*.75,h*.75);for(let i=0;i<7;i++)box(x+.06+i*w/8,y+l*.77,.18,.035,.08,h*.63,['#b5b8ae','#808e88','#3a5050']);box(x+w*.7,y,.15,.15,l,.14);break;
   case 'climate_dehumidifier':box(x,y,0,w,l,h*.8);box(x+.03,y+l*.75,h*.4,w-.06,.07,h*.28,['#b5cbc5','#6d9a94','#314d52']);for(let i=0;i<5;i++)box(x+.06,y+l*.95,h*.45+i*.06,w-.12,.02,.02);break;
   case 'climate_tank':box(x,y,0,w,l,.1);box(x+.06,y+.04,.1,w-.12,l-.08,h-.2,['#9fbbc0','#668b99','#36505f']);box(x+.25,y+.18,h-.1,w*.4,l*.4,.09);box(x+w-.12,y+l-.1,.15,.17,.06,.07);break;
   case 'climate_solar':supports(.3);out+=face([[x,y,.35],[x+w,y,.35],[x+w,y+l,h],[x,y+l,h]],'#3f657e');for(let i=1;i<5;i++){out+=face([[x+i*w/5,y,.351],[x+i*w/5+.015,y,.351],[x+i*w/5+.015,y+l,h+.001],[x+i*w/5,y+l,h+.001]],'#9db4be');}box(x+w*.65,y,.01,.2,.3,.15);break;
   case 'bed':supports(.28);box(x,y,.28,w,l,.18);cushion(x+.07,y+.05,.46,w-.14,l-.1,.2);box(x,y,0,w,.11,h);cushion(x+.14,y+.19,.66,w-.28,Math.min(.45,l/3),.15);box(x+.1,y+l*.48,.67,w-.2,l*.43,.035,colors);break;
   case 'sofa':supports(.22);box(x,y,.22,w,l,.24);box(x,y,.4,w,.16,h-.4);for(const a of [x,x+w-.16])box(a,y,.4,.16,l,.32);for(let i=0;i<2;i++)cushion(x+.18+i*(w-.36)/2,y+.19,.46,(w-.4)/2,l-.26,.17);break;
   case 'chair':supports(h*.42);cushion(x,y,h*.42,w,l,.12);box(x,y,0,.08,.12,h);box(x+w-.08,y,0,.08,.12,h);box(x,y,h*.65,w,.12,h*.3);break;
   case 'table':case 'desk':case 'workbench':case 'bench':{const z=d.supportHeight||h*.85;supports(z-.09);box(x,y,z-.09,w,l,.09);if(d.kind==='desk')box(x+.05,y+.08,.18,w*.32,l*.78,z-.3);if(d.kind==='workbench')box(x,y,z,w,.09,.55);break;}
   case 'cabinet':case 'trunk':case 'shelf':{box(x,y,0,w,l,h);const n=d.kind==='shelf'?3+v%3:2+v%3;for(let i=0;i<n;i++){const Z=.12+i*(h-.15)/n;box(x+.055,y+l+.008,Z,w-.11,.02,(h-.2)/n-.06,d.kind==='shelf'?['#21343b','#1c3037','#14242c']:colors);box(x+w*.43,y+l+.03,Z+.08,w*.14,.035,.025,['#d2c0a0','#aa9b80','#6b6257']);}break;}
   case 'rug':box(x,y,.005,w,l,.025);for(let i=1;i<6;i++)box(x+w*i/7,y+.07,.032,.035,l-.14,.005,['#c5b69a','#887a64','#514c40']);break;
   case 'computer':{
    const key=d.id.replace('computer_',''),desktop=!['field','laptop'].includes(key);
    const metal=key==='terminal'?['#a4ac98','#6c7c68','#3e5046']:colors;
    if(key==='server'){box(x,y,0,w,l,h,metal);for(let i=0;i<5;i++){box(x+.06,y+l+.006,.04+i*h/5,w-.12,.018,h/5-.04,metal);box(x+w-.12,y+l+.028,.07+i*h/5,.035,.015,.02,['#c2c79b','#a9bf95','#6b906b']);}}
    else if(desktop){box(x+w*.68,y,0,w*.32,l*.8,h,metal);for(let i=0;i<3;i++)box(x+w*.73,y+l*.8+.01,.08+i*h*.23,w*.21,.01,h*.12,['#7fadc0','#557e92','#364b63']);box(x+w*.12,y+l*.2,0,w*.28,l*.4,.03,metal);box(x+w*.25,y+l*.3,.03,w*.06,.05,h*.28,metal);box(x,y,h*.3,w*.64,l*.15,h*.58,metal);out+=face([[x+.03,y+l*.15+.005,h*.35],[x+w*.61,y+l*.15+.005,h*.35],[x+w*.61,y+l*.15+.005,h*.83],[x+.03,y+l*.15+.005,h*.83]],'#477c82');}
    else{box(x,y,0,w,l,.045,metal);box(x,y,.045,w,l*.16,h-.045,metal);out+=face([[x+.045,y+l*.16+.005,.1],[x+w-.045,y+l*.16+.005,.1],[x+w-.045,y+l*.16+.005,h-.045],[x+.045,y+l*.16+.005,h-.045]],'#487f86');}
    if(key!=='server')for(let row=0;row<4;row++)for(let col=0;col<8;col++)box(x+.06+col*w*.065,y+l*.42+row*l*.09,desktop?.015:.046,w*.052,l*.065,.01,['#b2b9a8','#718782','#415e62']);
    break;}
   case 'screen':for(let i=0;i<3;i++)box(x+i*w/3,y,0,w/3-.03,.1,h);break;
   case 'tank':box(x,y,0,w,l,.16);box(x,y,.16,w,l,h-.22,['#83adad99','#437e8555','#294d6266']);box(x,y,h-.06,w,l,.06);for(let i=0;i<3;i++)box(x+.12+i*w/4,y+.15,.16,.1,.13,.15+i*.06,['#83956e','#4e725c','#2b4c3c']);break;
   case 'radio':box(x,y,0,w,l,h);for(let i=0;i<5;i++)box(x+.06,y+l,.07+i*h/7,w*.5,.025,.016,['#a9b4a9','#677c79','#364a4d']);box(x+w*.73,y+l+.01,h*.4,.08,.06,.08);leg(x+w*.8,y,h+.35);break;
   case 'painting':case 'mirror':case 'clock':box(x,-.08,0,w,.13,h);box(x+.07,.055,.07,w-.14,.01,h-.14,d.kind==='mirror'?['#a8c9c777','#799da277','#536f8877']:['#7b8793','#526577','#344658']);break;
   case 'lamp':case 'floorlamp':box(-w*.22,-l*.22,0,w*.44,l*.44,.06);box(-.035,-.035,.06,.07,.07,h*.73);box(x,y,h*.72,w,l,h*.24,['#ddcdaa','#ac9674','#665944']);out+=face([[x,y,h*.72],[x+w,y,h*.72],[x+w,y+l,h*.72],[x,y+l,h*.72]],'#efce8888');break;
   case 'plant':case 'vase':case 'bowl':case 'basket':{box(x+w*.12,y+l*.12,0,w*.76,l*.76,h*.55);box(x,y,h*.55,w,l,.06);if(d.kind==='plant')for(let i=0;i<4;i++){const a=x+w*.18+i*w*.16;box(a,y+l*.45,h*.58,.025,.025,h*.32);out+=face([[a,y+l*.46,h*.67],[a-.18,y+l*.3,h*.9],[a+.16,y+l*.55,h*.94]],['#6e9678','#849e6e','#487460'][i%3]);}break;}
   default:box(x,y,0,w,l,Math.min(h,.3));out+=`<g transform="translate(${point(0,0,.3).replace(',',' ')}) scale(.55)">${old.model(d)}</g>`;
  }
  // Joinery / structural variants remain real XYZ faces and rotate with the object.
  if(v)for(let i=0;i<Math.min(v,8);i++)box(x+.025+i*(w-.05)/Math.max(1,Math.min(v,8)),y+l+.025,h*.24,.025,.02,h*.25,['#c6b899','#94846d','#4d514d']);
  return out;
 }
 function model(d){return `<g transform="translate(-425 -125)">${geometry(d)}</g>`;}
 function item(p,all){const d=Abyss.Bedroom.get(p.id);let z=d.placementType==='wall'?1.5:d.placementType==='ceiling'?3:0;if(p.support)z=Abyss.Bedroom.get(all.find(a=>a.uid===p.support)?.id)?.supportHeight||0;const b=Abyss.Bedroom.bounds(p),corners=[[b.x,b.y,0],[b.x+b.w,b.y,0],[b.x+b.w,b.y+b.h,0],[b.x,b.y+b.h,0]];return `<g class="bedroom-object" data-room-uid="${esc(p.uid)}" data-rotation="${p.rotation}"><polygon points="${corners.map(q=>camera(...q).join(',')).join(' ')}" fill="#0008" filter="url(#room-soft-shadow)"/><polygon points="${corners.map(q=>camera(q[0],q[1],z).join(',')).join(' ')}" fill="transparent" pointer-events="all"/>${geometry(d,p.rotation,[p.x,p.y,z])}<title>${esc(d.name)}</title></g>`;}
 function render(s,placed=s.bedroom.placed){const poly=(points,fill)=>`<polygon points="${points.map(p=>camera(...p).join(',')).join(' ')}" fill="${fill}" stroke="#476069" stroke-width="1"/>`;let room=poly([[0,0,0],[8,0,0],[8,8,0],[0,8,0]],'url(#room-floor)')+poly([[0,0,0],[0,8,0],[0,8,2.7],[0,0,2.7]],'url(#room-left)')+poly([[0,0,0],[8,0,0],[8,0,2.7],[0,0,2.7]],'url(#room-right)');for(let i=0;i<=8;i++){room+=`<path d="M${camera(i,0)}L${camera(i,8)}M${camera(0,i)}L${camera(8,i)}" stroke="#566164" opacity=".28"/>`;if(i<8)room+=poly([[i+.05,0,.2],[i+.95,0,.2],[i+.95,0,2.45],[i+.05,0,2.45]],i%2?'#3b4b5266':'#27394166');}room+=poly([[.2,0,2.45],[7.8,0,2.45],[7.8,0,2.51],[.2,0,2.51]],'#c6d6bf')+poly([[0,.2,.11],[0,7.8,.11],[0,7.8,.19],[0,.2,.19]],'#607678')+poly([[3,7,0],[5,7,0],[5,8,0],[3,8,0]],'#ab987933');const roots=placed.filter(p=>!p.support).sort((a,b)=>a.x+a.y-b.x-b.y);for(const p of roots){room+=item(p,placed);for(const child of placed.filter(q=>q.support===p.uid).sort((a,b)=>a.x+a.y-b.x-b.y))room+=item(child,placed);}for(const [i,p]of s.pets.filter(p=>p.active&&p.alive&&!p.escaped&&p.room==='quarters').entries()){const [x,y]=camera(3+i*.8,5.5);room+=`<g transform="translate(${x} ${y})">${old.pet(p)}</g>`;}return `<svg id="bedroom-canvas" viewBox="45 -30 760 590" role="img" aria-label="Bedroom layout"><defs><linearGradient id="room-floor" x2="1" y2="1"><stop stop-color="#596264"/><stop offset="1" stop-color="#202f38"/></linearGradient><linearGradient id="room-left" x2="1" y2="1"><stop stop-color="#273d48"/><stop offset="1" stop-color="#172a33"/></linearGradient><linearGradient id="room-right" x2="0" y2="1"><stop stop-color="#657175"/><stop offset="1" stop-color="#34464e"/></linearGradient><filter id="room-soft-shadow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="4"/></filter></defs>${room}<text x="425" y="535" text-anchor="middle" fill="#9db0ad" font-family="monospace" font-size="10">JACK / QUARTERS · XYZ CONSTRUCTION / 01</text></svg>`;}
 Abyss.BedroomArt={...old,model,render,project:camera,geometry};
})();
