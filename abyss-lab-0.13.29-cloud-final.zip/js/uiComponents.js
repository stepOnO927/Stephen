
'use strict';
Abyss.UIComponents=(()=>{
 const esc=x=>Abyss.Util.escape(String(x)),label=d=>Abyss.I18n.language()==='en'?(d.tabs?d.en[0]+d.en.slice(1).toLowerCase():d.en):d.zh;
 function NavSidebar(data,active,collapsed){return `<button class="nav-collapse" data-nav-collapse aria-label="Collapse navigation" aria-expanded="${!collapsed}">☰ <span>ABYSS / LAB</span></button><nav aria-label="Primary navigation">${data.map(d=>`<button data-section="${d.id}" aria-label="${label(d)}" title="${label(d)}" aria-current="${d.id===active?'page':'false'}"><i>${d.icon}</i><span>${label(d)}${Abyss.I18n.language()==='en'?'':`<small>${d.en}</small>`}</span></button>`).join('')}</nav><button data-quick-menu class="nav-search">⌕ <span>${Abyss.I18n.language()==='en'?'Quick menu':'快速导航'}<small>Ctrl + K</small></span></button>`;}
 function TabBar(tabs,active){return tabs.map(d=>`<button role="tab" aria-selected="${d.id===active}" data-subtab="${d.id}">${label(d)}</button>`).join('');}
 function SectionHeader(group,tab){return `<small>${group.en} / ${tab?.en||'OVERVIEW'}</small><h1>${tab?label(tab):label(group)}</h1>`;}
 function EmptyState(text){return `<div class="nav-empty"><span>◇</span><p>${esc(text)}</p></div>`;}
 function ItemGrid(items){return `<div class="nav-card-grid">${items.map(d=>`<button data-route="${esc(d.action)}"><small>${esc(d.en)}</small><b>${esc(label(d))}</b><span>↗</span></button>`).join('')}</div>`;}
 function AlertBadge(text){return `<div class="nav-alert" role="status">△ ${esc(text)}</div>`;}
 function ContextMenu(name,items){return `<div class="nav-context"><p>${esc(name)}</p>${items.map(d=>`<button data-route="${esc(d.action)}">${label(d)} ↗</button>`).join('')}</div>`;}
 return {NavSidebar,TabBar,SectionHeader,EmptyState,ItemGrid,AlertBadge,ContextMenu,label};
})();
