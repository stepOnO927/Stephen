'use strict';
// Permanent, safe forest venue. Loaded before the road graph is built.
Abyss.RoadData.locations.push({id:'happy_club',name:'快乐俱乐部',en:'Happy Club',biome:'forest',tier:1,x:-3,y:3,rooms:['停车场','售票窗口','靶场','奖品区','休息区','宠物等待区'],safe:true});
