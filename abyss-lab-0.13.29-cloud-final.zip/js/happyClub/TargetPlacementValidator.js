'use strict';
// Geometry only: no DOM, random rolls, currency, saves or reward side effects.
((root,factory)=>{
 const Validator=factory();
 if(typeof module==='object'&&module.exports)module.exports=Validator;
 if(root.Abyss)root.Abyss.TargetPlacementValidator=Validator;
})(typeof globalThis==='object'?globalThis:this,()=>{
 const registry=new WeakMap();
 const EPS=1e-9,FACTORS=Object.freeze({COMMON:1,UNCOMMON:.82,RARE:.65,EPIC:.5,LEGENDARY:.38,ANOMALOUS:.29});
 const finite=n=>typeof n==='number'&&Number.isFinite(n)&&Math.abs(n)<=1e6;
 const point=p=>p&&finite(p.x)&&finite(p.y);
 const rect=r=>r&&finite(r.x)&&finite(r.y)&&finite(r.width)&&finite(r.height)&&r.width>0&&r.height>0;
 const box=points=>({x:Math.min(...points.map(p=>p.x)),y:Math.min(...points.map(p=>p.y)),width:Math.max(...points.map(p=>p.x))-Math.min(...points.map(p=>p.x)),height:Math.max(...points.map(p=>p.y))-Math.min(...points.map(p=>p.y))});
 const expand=(b,x,y=x)=>({x:b.x-x,y:b.y-y,width:b.width+2*x,height:b.height+2*y});
 const inside=(a,b)=>a.x+EPS>=b.x&&a.y+EPS>=b.y&&a.x+a.width<=b.x+b.width+EPS&&a.y+a.height<=b.y+b.height+EPS;
 const overlaps=(a,b)=>a.x<b.x+b.width-EPS&&a.x+a.width>b.x+EPS&&a.y<b.y+b.height-EPS&&a.y+a.height>b.y+EPS;
 const distance=(a,b)=>Math.hypot(Math.max(0,a.x-b.x-b.width,b.x-a.x-a.width),Math.max(0,a.y-b.y-b.height,b.y-a.y-a.height));
 const freeze=o=>{if(o&&typeof o==='object'&&!Object.isFrozen(o)){for(const v of Object.values(o))freeze(v);Object.freeze(o);}return o;};
 const fail=(stage,reason,extra={})=>({ok:false,stage,reason,...extra});
 function split(points){let row=points.map(p=>({...p})),left=[row[0]],right=[row.at(-1)];while(row.length>1){row=row.slice(1).map((p,i)=>({x:(row[i].x+p.x)/2,y:(row[i].y+p.y)/2}));left.push(row[0]);right.unshift(row.at(-1));}return [left,right];}
 function bezier(points,t){let row=points;while(row.length>1)row=row.slice(1).map((p,i)=>({x:row[i].x*(1-t)+p.x*t,y:row[i].y*(1-t)+p.y*t}));return {...row[0]};}
 function certify(path){
  if(path.type==='static')return [box(path.points)];
  if(path.type==='polyline')return path.points.slice(1).map((p,i)=>box([path.points[i],p]));
  // Each box contains a complete Bezier subcurve by the convex-hull property.
  // These are continuous interval certificates, not sampled positions.
  let pieces=[path.points];for(let depth=0;depth<4;depth++)pieces=pieces.flatMap(split);
  return pieces.map(box);
 }
 function location(path,t){if(path.type==='static')return {...path.points[0]};if(path.type!=='polyline')return bezier(path.points,t);const u=t*(path.points.length-1),i=Math.min(path.points.length-2,Math.floor(u)),p=path.points[i],q=path.points[i+1],v=u-i;return {x:p.x+(q.x-p.x)*v,y:p.y+(q.y-p.y)*v};}
 function morphAt(frames,t){const i=frames.findIndex(f=>f.at>=t);if(i<=0)return frames[0];const a=frames[i-1],b=frames[i],v=(t-a.at)/(b.at-a.at);return {scaleX:a.scaleX+(b.scaleX-a.scaleX)*v,scaleY:a.scaleY+(b.scaleY-a.scaleY)*v};}
 class TargetPlacementValidator{
  constructor(options={}){
   const defaults={baseWidth:100,baseHeight:100,referenceWidth:1280,referenceHeight:720,fixedGap:80,gapRatio:.55,bombGapMultiplier:1.2,edgeInset:8,maxTargets:3,minTargetExtent:8};
   if(!options||typeof options!=='object'||Object.keys(options).some(k=>!Object.hasOwn(defaults,k)))throw new RangeError('Unknown placement settings');
   const settings={...defaults,...options};
   for(const k of ['baseWidth','baseHeight','referenceWidth','referenceHeight','fixedGap','minTargetExtent'])if(!finite(settings[k])||settings[k]<1)throw new RangeError('Invalid '+k);
   if(!finite(settings.edgeInset)||settings.edgeInset<0||!finite(settings.gapRatio)||settings.gapRatio<.4||settings.gapRatio>.7||!finite(settings.bombGapMultiplier)||settings.bombGapMultiplier<1.2||!Number.isInteger(settings.maxTargets)||settings.maxTargets<1||settings.maxTargets>3)throw new RangeError('Unsafe placement settings');
   this.settings=freeze(settings);registry.set(this,new WeakSet());Object.freeze(this);
  }
  prepare(candidate){
   if(!candidate||typeof candidate.id!=='string'||!candidate.id||candidate.id.length>100)return fail('spawn','INVALID_TARGET_ID');
   if(!point(candidate.position))return fail('spawn','INVALID_SPAWN_POINT');
   if(candidate.width!==undefined||candidate.height!==undefined||candidate.rotation!==undefined)return fail('size','UNSUPPORTED_SIZE_OVERRIDE');
   const rawType=candidate.type===undefined?'REWARD':candidate.type,type=typeof rawType==='string'?rawType.toUpperCase():rawType,bomb=type==='BOMB';
   if(!['BOMB','REWARD'].includes(type)||bomb&&candidate.rarity!==undefined)return fail('size','INVALID_TARGET_TYPE');
   const rarity=bomb?null:typeof candidate.rarity==='string'?candidate.rarity.toUpperCase():candidate.rarity;
   if(!bomb&&(typeof rarity!=='string'||!Object.hasOwn(FACTORS,rarity)))return fail('size','INVALID_RARITY');
   const factor=candidate.sizeFactor===undefined?(bomb?1:FACTORS[rarity]):candidate.sizeFactor;
   if(!finite(factor)||(rarity==='ANOMALOUS'?factor<.26||factor>.32:factor!==(bomb?1:FACTORS[rarity])))return fail('size','INVALID_RARITY_SIZE');
   const path=candidate.path||{type:'static',points:[candidate.position]},types={static:1,polyline:0,quadratic:3,cubic:4};
   if(!path||typeof path.type!=='string'||!Object.hasOwn(types,path.type)||!Array.isArray(path.points)||path.points.length>64||Array.from(path.points).some(p=>!point(p))||(path.type==='polyline'?path.points.length<2:path.points.length!==types[path.type]))return fail('path','INVALID_MOVEMENT_PATH');
   if(path.points[0].x!==candidate.position.x||path.points[0].y!==candidate.position.y)return fail('spawn','PATH_START_MISMATCH');
   const frames=candidate.morph||[{at:0,scaleX:1,scaleY:1},{at:1,scaleX:1,scaleY:1}],max=bomb?1.05:rarity==='COMMON'?1:rarity==='UNCOMMON'?1.05:rarity==='LEGENDARY'?1.2:1.15,min=bomb?.95:rarity==='COMMON'?1:.5;
   if(!Array.isArray(frames)||frames.length<2||frames.length>32||frames[0]?.at!==0||frames.at(-1)?.at!==1||Array.from(frames).some((f,i)=>!f||!finite(f.at)||f.at<0||f.at>1||i>0&&f.at<=frames[i-1].at||!finite(f.scaleX)||!finite(f.scaleY)||f.scaleX<min||f.scaleY<min||f.scaleX>max||f.scaleY>max||f.rotation!==undefined))return fail('size','INVALID_MORPH_ENVELOPE');
   const source={id:candidate.id,type,position:{x:candidate.position.x,y:candidate.position.y},...(bomb?{}:{rarity}),sizeFactor:factor,path:{type:path.type,points:path.points.map(p=>({x:p.x,y:p.y}))},morph:frames.map(f=>({at:f.at,scaleX:f.scaleX,scaleY:f.scaleY}))};
   const width=this.settings.baseWidth*factor,height=this.settings.baseHeight*factor,maxWidth=width*Math.max(...frames.map(f=>f.scaleX)),maxHeight=height*Math.max(...frames.map(f=>f.scaleY));
   if(width*Math.min(...frames.map(f=>f.scaleX))<this.settings.minTargetExtent||height*Math.min(...frames.map(f=>f.scaleY))<this.settings.minTargetExtent)return fail('size','TARGET_TOO_SMALL');
   const certificates=certify(source.path),bounds=certificates.map(b=>expand(b,maxWidth/2,maxHeight/2));
   const union=box(bounds.flatMap(b=>[{x:b.x,y:b.y},{x:b.x+b.width,y:b.y+b.height}]));
   const plan=freeze({validatorVersion:1,id:source.id,type,rarity,sizeFactor:factor,width,height,maxWidth,maxHeight,bodyRadius:Math.hypot(maxWidth,maxHeight)/2,source,certificates,movementPathBounds:union});
   registry.get(this).add(plan);return {ok:true,plan};
  }
  scene(scene){
   if(!scene||!rect(scene.viewport))return fail('spawn','INVALID_VIEWPORT');
   const existing=scene.existingTargets===undefined?[]:scene.existingTargets,ui=scene.uiBounds===undefined?[]:scene.uiBounds,foreground=scene.foregroundBounds===undefined?[]:scene.foregroundBounds;
   if(!Array.isArray(existing)||existing.length>3||Array.from(existing).some(p=>!registry.get(this).has(p))||new Set(existing.map(p=>p.id)).size!==existing.length)return fail('spawn','INVALID_EXISTING_TARGETS');
   if(!Array.isArray(ui)||!Array.isArray(foreground)||ui.length+foreground.length>256||[...ui,...foreground].some(r=>!rect(r)))return fail('spawn','INVALID_OCCLUDERS');
   const inset=this.settings.edgeInset,v=scene.viewport,area={x:v.x+inset,y:v.y+inset,width:v.width-2*inset,height:v.height-2*inset};
   if(area.width<=0||area.height<=0)return fail('spawn','NO_PLAYABLE_AREA');
   return {ok:true,existing,ui,foreground,area,viewport:v};
  }
  gap(a,b,viewport,bombExtra=true){const scale=Math.min(viewport.width/this.settings.referenceWidth,viewport.height/this.settings.referenceHeight),normal=Math.max(this.settings.fixedGap*scale,this.settings.gapRatio*Math.max(a.maxWidth,b.maxWidth));return normal*(bombExtra&&(a.type==='BOMB'||b.type==='BOMB')?this.settings.bombGapMultiplier:1);}
  poseAt(plan,t){
   if(!registry.get(this).has(plan)||!finite(t)||t<0||t>1)throw new RangeError('Invalid plan or progress');
   const center=location(plan.source.path,t),m=morphAt(plan.source.morph,t),width=plan.width*m.scaleX,height=plan.height*m.scaleY;
   return {center,width,height,targetBounds:{x:center.x-width/2,y:center.y-height/2,width,height}};
  }
  blocked(bounds,scene){if(!inside(bounds,scene.area))return 'OUT_OF_BOUNDS';if(scene.ui.some(r=>overlaps(bounds,r)))return 'UI_OCCLUSION';if(scene.foreground.some(r=>overlaps(bounds,r)))return 'FOREGROUND_OCCLUSION';return null;}
  validatePlan(plan,scene){
   const s=this.scene(scene);if(!s.ok)return s;
   if(!registry.get(this).has(plan))return fail('size','INVALID_PREPARED_PLAN');
   if(s.existing.some(p=>p.id===plan.id))return fail('spawn','DUPLICATE_TARGET_ID');
   if(s.existing.length>=this.settings.maxTargets)return fail('spawn','TARGET_LIMIT');
   const birth=this.poseAt(plan,0),spawnBlock=this.blocked(birth.targetBounds,s);if(spawnBlock)return fail('spawn','SPAWN_'+spawnBlock);
   const spawnBox=box([birth.center]);
   for(const other of s.existing){const required=plan.bodyRadius+other.bodyRadius+this.gap(plan,other,s.viewport,false);if(distance(spawnBox,box([other.source.position]))+EPS<required)return fail('gap','SPAWN_SAFE_GAP',{otherId:other.id});}
   for(const envelope of plan.certificates){const block=this.blocked(expand(envelope,plan.maxWidth/2,plan.maxHeight/2),s);if(block)return fail('path','PATH_'+block);}
   for(const other of s.existing){const required=plan.bodyRadius+other.bodyRadius+this.gap(plan,other,s.viewport,false);for(const a of plan.certificates)for(const b of other.certificates)if(distance(a,b)+EPS<required)return fail('path','MOVEMENT_PATH_CONFLICT',{otherId:other.id});}
   for(const other of s.existing)if(plan.type==='BOMB'||other.type==='BOMB'){const required=plan.bodyRadius+other.bodyRadius+this.gap(plan,other,s.viewport,true);for(const a of plan.certificates)for(const b of other.certificates)if(distance(a,b)+EPS<required)return fail('bomb','BOMB_EXTRA_SAFE_GAP',{otherId:other.id});}
   const minimumGap=this.gap(plan,plan,s.viewport,true);
   return {ok:true,stage:'complete',plan,targetBounds:birth.targetBounds,safeRadius:plan.bodyRadius+minimumGap/2,movementPathBounds:plan.movementPathBounds,minimumGap,visibleFractionGuarantee:1};
  }
  validate(candidate,scene){const prepared=this.prepare(candidate);return prepared.ok?this.validatePlan(prepared.plan,scene):prepared;}
  // Reserve the whole spawn batch before the caller mounts any clickable target.
  // A rejected batch never mutates the caller's active targets or partially spawns.
  validateBatch(candidates,scene){
   const checked=this.scene(scene);if(!checked.ok)return {...checked,action:'DELAY_SPAWN',placements:[]};
   if(!Array.isArray(candidates)||candidates.length<1||candidates.length>this.settings.maxTargets)return {...fail('spawn','INVALID_SPAWN_BATCH'),action:'DELAY_SPAWN',placements:[]};
   if(checked.existing.length+candidates.length>this.settings.maxTargets)return {...fail('spawn','TARGET_LIMIT'),action:'DELAY_SPAWN',placements:[]};
   const reserved=checked.existing.slice(),placements=[];
   for(let index=0;index<candidates.length;index++){
    const result=this.validate(candidates[index],{...scene,existingTargets:reserved});
    if(!result.ok)return {...result,action:'DELAY_SPAWN',candidateIndex:index,placements:[]};
    reserved.push(result.plan);placements.push(result);
   }
   return {ok:true,stage:'complete',action:'SPAWN',placements};
  }
  findPlacement(candidates,scene){
   if(!Array.isArray(candidates)||candidates.length>32)return {...fail('spawn','INVALID_CANDIDATE_LIST'),action:'DELAY_SPAWN'};
   const failures=[];for(const [index,candidate]of candidates.entries()){const result=this.validate(candidate,scene);if(result.ok)return {...result,action:'SPAWN',candidateIndex:index,attempts:index+1};failures.push({index,stage:result.stage,reason:result.reason});}
   return {ok:false,action:'DELAY_SPAWN',reason:'NO_SAFE_PLACEMENT',attempts:failures.length,failures};
  }
  validateAdvance(plan,fromProgress,toProgress,scene){
   if(!registry.get(this).has(plan)||!finite(fromProgress)||!finite(toProgress)||fromProgress<0||toProgress<fromProgress||toProgress>1)return {...fail('path','INVALID_ADVANCE'),action:'HIDE',pose:null};
   const original=this.scene(scene);if(!original.ok)return {...original,action:'HIDE',pose:null};
   const others=Array.isArray(scene?.existingTargets)?scene.existingTargets.filter(p=>p!==plan):scene?.existingTargets;
   const adjusted={...scene,existingTargets:others},result=this.validatePlan(plan,adjusted);
   if(result.ok)return {...result,action:'MOVE',pose:this.poseAt(plan,toProgress)};
   const s=this.scene(adjusted);let unsafe=!s.ok||result.reason==='TARGET_LIMIT'||result.reason==='DUPLICATE_TARGET_ID';
   if(s.ok){const current=this.poseAt(plan,fromProgress);unsafe=unsafe||!!this.blocked(current.targetBounds,s)||s.existing.some(other=>other.certificates.some(b=>distance(box([current.center]),b)+EPS<plan.bodyRadius+other.bodyRadius+this.gap(plan,other,s.viewport,true)));}
   return {...result,action:unsafe?'HIDE':'PAUSE',pose:unsafe?null:this.poseAt(plan,fromProgress)};
  }
 }
 Object.defineProperty(TargetPlacementValidator,'RARITY_FACTORS',{value:FACTORS});
 return TargetPlacementValidator;
});
