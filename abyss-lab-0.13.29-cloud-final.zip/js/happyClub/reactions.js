'use strict';
Abyss.HappyClubReactions=(()=>{
 const t=(a,b)=>Abyss.HomeData.t(a,b);
 const fresh=()=>({visit:false,bombSeen:false,bombHit:false});
 function read(r,visits=0){return {visit:r?.visit===true||r?.visit===undefined&&visits>0,bombSeen:r?.bombSeen===true,bombHit:r?.bombHit===true};}
 function respond(s,h,key){if(h.reactions[key]||!s.legacy.active||s.campaign?.creatureAlive===false||s.awaySince)return '';h.reactions[key]=true;const stage=s.narrative.languageStage;let line;
 if(key==='visit')line=stage>=3&&Abyss.HappyClub.price(s)!==8000?t('B-07：“这张票？” Jack：“嗯。” B-07：“打木板？” Jack：“……嗯。”','B-07: “This ticket?” Jack: “Yes.” B-07: “To hit wood?” Jack: “…Yes.”'):stage>=3?t('B-07：“八千？” Jack：“嗯。” B-07：“打木板？” Jack：“……嗯。”','B-07: “Eight thousand?” Jack: “Yes.” B-07: “To hit wood?” Jack: “…Yes.”'):stage>=1?t('B-07：“木。” Jack：“对。打两次。”','B-07: “Wood.” Jack: “Yes. Two hits.”'):t('它隔着围栏望着木牌。Jack把门票折了两折。','It watches the wooden signs beyond the fence. Jack folds the ticket twice.');
 if(key==='bombSeen')line=stage>=2?t('B-07：“黑的不能打？” Jack：“对。”','B-07: “Do not hit the black ones?” Jack: “Right.”'):stage>=1?t('B-07：“黑。” Jack：“那个不打。”','B-07: “Black.” Jack: “Do not hit that one.”'):t('它的视线停在黑色牌上。Jack把手指收回来。','Its gaze stops on the black sign. Jack draws his finger back.');
 if(key==='bombHit')line=stage>=3?t('B-07：“你刚才说不能打。” Jack：“我知道。”','B-07: “You just said not to hit it.” Jack: “I know.”'):stage>=1?t('B-07：“不打。” Jack：“……我知道。”','B-07: “Do not.” Jack: “…I know.”'):t('哨子响了一声。它望向Jack，又望向黑牌。','A whistle sounds once. It looks at Jack, then at the black sign.');
 Abyss.State.log(s,line,'story');return line;
 }
 return {fresh,read,respond};
})();
