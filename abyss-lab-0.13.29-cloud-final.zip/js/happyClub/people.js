'use strict';
Abyss.HappyClubPeople=(()=>{
 const rows=[
 {id:'manager',zh:'俱乐部管理员',en:'Club Manager',coat:'#75634b',feature:'cap',line:['规则贴了三遍。黑色的那个，不是贵宾靶。','Rules are posted three times. The black one is not a VIP target.']},
 {id:'attendant',zh:'靶场工作人员',en:'Range Attendant',coat:'#496c61',feature:'whistle',line:['木轨磨坏了就换。你瞄准牌子，不用瞄准我。','We replace worn rails. Aim at the targets. You do not need to aim at me.']},
 {id:'clerk',zh:'奖品柜员',en:'Prize Clerk',coat:'#697487',feature:'glasses',line:['代币分颜色。已经入库的东西，刷新也不会再抽一次。','Tokens have different colors. A stored prize does not reroll when you reload.']},
 {id:'collector',zh:'富有的收藏家',en:'Rich Collector',coat:'#644b70',feature:'monocle',line:['我来了一整周。柜员已经不肯听我说“差一点”了。','I have been here all week. The clerk will no longer listen to me saying “nearly.”']},
 {id:'regular',zh:'可疑的常客',en:'Suspicious Regular',coat:'#3b4748',feature:'hood',line:['我只是看着。你最好也先看清楚，再伸手。','I am only watching. You should look carefully before reaching, too.']}
 ];
 function portrait(n){const extra={cap:'<path d="M29 40 Q32 16 60 18 Q89 18 91 40Z" fill="#63523e"/><path d="M28 39H98V46H27Z" fill="#38372e"/>',whistle:'<path d="M40 91L60 115L80 91" fill="none" stroke="#bdb899" stroke-width="3"/><rect x="55" y="111" width="14" height="9" rx="3" fill="#c3c8b9"/>',glasses:'<g fill="none" stroke="#d0c9ac" stroke-width="3"><rect x="36" y="46" width="20" height="14" rx="3"/><rect x="65" y="46" width="20" height="14" rx="3"/><path d="M56 52H65"/></g>',monocle:'<circle cx="76" cy="53" r="10" fill="none" stroke="#d2b474" stroke-width="3"/><path d="M84 59L91 100" stroke="#d2b474" fill="none"/>',hood:'<path d="M28 82Q18 22 60 14Q105 22 93 82L80 87V39Q60 23 41 40V84Z" fill="#273437"/>'}[n.feature];return '<svg viewBox="0 0 120 140" role="img" aria-label="'+n.en+'"><path d="M13 140V117Q16 83 60 85Q105 83 109 117V140Z" fill="'+n.coat+'"/><path d="M45 76V92L60 106L75 92V76" fill="#ad8f76"/><ellipse cx="60" cy="54" rx="29" ry="34" fill="#bd9f84"/><path d="M32 43Q30 19 62 19Q87 20 89 43L77 30L43 34Z" fill="#3d3530"/><path d="M40 53h9m22 0h9M55 72h14" stroke="#3b3531" stroke-width="3" fill="none"/>'+extra+'</svg>';}
 return {rows,portrait};
})();
