'use strict';
Abyss.HappyClubTargetArt=(()=>{
 const shapes={
 STATIC:'<circle cx="50" cy="50" r="35" fill="none" stroke="currentColor" stroke-width="7"/><circle cx="50" cy="50" r="22" fill="none" stroke="currentColor" stroke-width="5"/><circle cx="50" cy="50" r="8" fill="currentColor"/>',
 SLOW_SLIDE:'<path d="M18 64L31 49L56 46L67 29L74 26L80 30L84 40L76 48L73 63L79 80H70L63 64H39L32 82H24L26 61Z" fill="currentColor"/><path d="M70 30L65 13M74 26L80 13M65 20L56 19M79 19L86 16" fill="none" stroke="currentColor" stroke-width="4"/>',
 FAST_SLIDE:'<path d="M23 67Q18 44 44 45L59 48Q55 20 65 14Q75 16 70 44L75 43Q76 18 84 20Q94 23 82 50Q96 62 82 70L67 72L59 85H44L49 71H28L18 84H9L20 66Z" fill="currentColor"/>',
 VERTICAL_RISE:'<path d="M24 37H75V78H24Z" fill="none" stroke="currentColor" stroke-width="6"/><path d="M35 38V27H65V38M42 75V92M58 75V92" fill="none" stroke="currentColor" stroke-width="5"/><circle cx="38" cy="52" r="5"/><circle cx="62" cy="52" r="5"/><path d="M34 65H65M49 12V26M42 18L49 10L56 18" stroke="currentColor" stroke-width="4" fill="none"/>',
 SIDE_PEEK:'<path d="M16 14H83V86H16Z" fill="none" stroke="currentColor" stroke-width="5"/><path d="M22 73Q30 48 45 52L52 49L61 41L70 40Q70 30 80 34L84 42L73 45L77 60L66 72Z" fill="currentColor"/><path d="M59 69L64 82L75 79M67 58L81 53" stroke="currentColor" stroke-width="4" fill="none"/>',
 SWING:'<path d="M22 14H79M50 14V39" stroke="currentColor" stroke-width="6"/><path d="M27 40H72V82H27Z" fill="none" stroke="currentColor" stroke-width="6"/><circle cx="50" cy="61" r="12" fill="none" stroke="currentColor" stroke-width="5"/>',
 RUN_ACROSS:'<path d="M13 64L29 43L55 41L63 33L77 32L85 46L73 53L67 67L70 83H62L54 66H35L29 85H21L23 65Z" fill="currentColor"/><path d="M65 35L63 21M75 34L80 20M31 42L20 35M7 71H20" fill="none" stroke="currentColor" stroke-width="4"/>',
 CURVE_MOVE:'<path d="M15 64L48 20L82 40L70 83Z" fill="none" stroke="currentColor" stroke-width="5"/><path d="M15 64L82 40M48 20L70 83" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="50" cy="53" r="11" fill="currentColor"/>',
 STOP_AND_GO:'<path d="M15 25H85V80H15Z" fill="none" stroke="currentColor" stroke-width="6"/><path d="M18 27L50 54L82 27M50 54V78" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="27" cy="66" r="6"/><circle cx="72" cy="66" r="6"/>'
 };
 function markup(target){const bomb=target.type==='BOMB',shape=bomb?'<path d="M24 24L76 76M76 24L24 76" stroke="currentColor" stroke-width="13"/>':target.rarity==='ANOMALOUS'?'<path d="M18 18H82V82H18ZM32 32H68V68H32Z" fill="none" stroke="currentColor" stroke-width="5"/><path d="M18 30H8M82 64H93M50 38V58" stroke="currentColor" stroke-width="5"/><circle cx="50" cy="68" r="3"/>':shapes[target.movementType]||shapes.STATIC;return '<svg viewBox="0 0 100 100" aria-hidden="true" focusable="false">'+shape+'</svg>'+(target.hits?'<span class="club-hit-mark" aria-hidden="true">1</span>':'');}
 return {markup};
})();
