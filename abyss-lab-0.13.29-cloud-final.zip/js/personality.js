'use strict';
Abyss.Personality = (() => {
 const shifts={feed:{calm:1},companion:{affectionate:3,calm:1},reward:{affectionate:2,mischievous:1},heal:{affectionate:2,timid:-1},train:{curious:2,independent:1},experiment:{timid:2,curious:1},explore:{curious:2,independent:2},punish:{vengeful:4,aggressive:2,timid:2}};
 function dominant(s){return Object.entries(s.personality).sort((a,b)=>b[1]-a[1])[0][0];}
 function observe(before,s,command){
  if(['train','experiment','explore'].includes(command.type)&&s.history[command.type]===before.history[command.type])return;
  for(const [key,n] of Object.entries(shifts[command.type]||{}))s.personality[key]=Abyss.Util.clamp(s.personality[key]+n);
  if(s.resentment>before.resentment)s.personality.vengeful=Abyss.Util.clamp(s.personality.vengeful+2);
  if(command.type==='feed'&&command.payload===s.favoriteFood)s.personality.calm=Abyss.Util.clamp(s.personality.calm+2);
 }
 function reaction(s,item){
  const c=s.collection;
  if(c.lastReactionDay===s.day||Abyss.Util.random(c)>.34)return '';
  c.lastReactionDay=s.day;
  if(s.resentment>30&&item.type==='restraint')return '它碰到旧式束带时缩了一下。信任恢复了，一些记忆却仍留着。';
  if(s.stats.loyalty<30)return '它一动不动地看着你，没有回应这次换装。';
  if(s.stats.mood<30)return '它没心思欣赏新装饰，只想安静地蜷一会儿。';
  if(s.stats.intelligence>=40&&item.type==='silly')return '它抬起爪子端详这件古怪装饰，随后一本正经地模仿你的表情。';
  if(item.id==='red_ribbon')return '它小心护住旧红丝带，像是认出了某种久远的气味。';
  if(s.stats.loyalty>=80)return `它轻轻碰了碰${item.zh}，然后把头靠近你的手。`;
  const lines={curious:'它翻来覆去地检查这件新东西，连缝线也没有放过。',timid:'它先闻了闻饰品，确认没有危险才松开爪子。',aggressive:'它昂起头，好像这件装饰是一枚胜利勋章。',affectionate:'它凑过来，等着你看一看自己的新模样。',independent:'它自己调整了饰品的角度，满意地退后一步。',mischievous:'它故意把饰品戴歪，又偷偷看你的反应。',calm:'它平静地接纳了新装饰，呼吸仍然舒缓。',vengeful:'它记住了你的动作，眼神里却留着一分戒备。'};
  return lines[dominant(s)];
 }
 function exploration(s){
  const trait=dominant(s);
  // Branch is a narrative route decision; it does not alter the existing success formula.
  const lines={timid:'它选择靠近照明的路线，一步一停地确认你的脚步。',curious:'它执意先看看侧廊，沿途记下那些奇怪的气味。',independent:'它先行探查岔路，再回到路口示意你跟上。',aggressive:'它选择走在前面，替你拨开挡路的废料。',affectionate:'它每走几步就回头，确认你仍和它走在一起。',mischievous:'它绕了个小圈，从另一根管道后面探出头。',calm:'它选择稳妥的路线，慢慢辨认沿途的标记。',vengeful:'它避开熟悉的实验标志，选择另一条安静的路线。'};
  Abyss.State.log(s,lines[trait],'story');
 }
 function eventWeight(s,e){const trait=dominant(s);return e.weight*(({curious:['gene','room'],timid:['blackout','sick'],affectionate:['gift','speech'],calm:['leak','food'],vengeful:['dream','accident'],mischievous:['rare','merchant'],independent:['room','gene'],aggressive:['accident','rare']}[trait]||[]).includes(e.id)?1.15:1);}
 const idle=s=>['timid','vengeful'].includes(dominant(s))?'watchful':dominant(s)==='curious'?'curious':dominant(s)==='mischievous'?'playful':'calm';
 return {dominant,observe,reaction,exploration,eventWeight,idle};
})();
