
'use strict';
// Stable world-distance landmarks: no shared short loop and no gameplay RNG.
Abyss.RoadScenery=(()=>{
 function hash(text){let n=2166136261;for(const c of text)n=Math.imul(n^c.charCodeAt(0),16777619);return n>>>0;}
 function sample(r){const travel=Math.max(0,r.distance)*1000,base=Math.floor(travel/22),key=r.location+':'+(r.target||r.location),out=[];for(let i=base-1;i<=base+12;i++){const seed=hash(key+':'+i);out.push({id:i,seed,z:travel-i*22,x:(seed%2?-1:1)*(8+seed%11),kind:seed%7,height:3+seed%13});}return out;}
 return {sample,hash};
})();
