 'use strict';
// Physical cargo rules are shared by pickup, furnishing and vehicle switching.
Abyss.RoadCargo=(()=>{
 const ranks=['TINY','SMALL','MEDIUM','LARGE','OVERSIZED'];
 function spec(d){if(d.transport)return d.transport;const k=d.kind||d.model||'',n=(d.name||'')+' '+k;
 let x={size:'TINY',volume:.006,weight:1,length:.18};
 if(/computer|电视|电脑|camera|helmet|头盔|radio|收音机/.test(n))x={size:'SMALL',volume:.035,weight:4,length:.4};
 if(/chair|椅|tool|工具箱|步枪/.test(n))x={size:'MEDIUM',volume:.18,weight:14,length:.8};
 if(/desk|table|桌|cabinet|柜|冰箱/.test(n))x={size:'LARGE',volume:.6,weight:35,length:1.25};
 if(/sofa|沙发|bed|床|钢琴|piano|发电机|generator/.test(n))x={size:'OVERSIZED',volume:1.6,weight:95,length:2.1};return x;
 }
 function load(s){return (Abyss.WeaponMetrics?.carried(s).volume||0)+(s.underground?Abyss.UndergroundMarket.cargo(s).volume+(s.underground.mission?.phase==='cargo'?.125:0):0)+s.road.relics.filter(i=>i.status==='keep'&&i.onboard!==false).reduce((n,i)=>n+spec(Abyss.RoadRewards.relics.find(d=>d.id===i.id)).volume,0)+s.road.cabinet.reduce((n,id)=>n+spec(Abyss.Bedroom.get(id)).volume,0);}
 function fits(s,d,v=Abyss.Road.vehicle(s),extra=true){const x=spec(d);return ranks.indexOf(x.size)<=ranks.indexOf(v.maxItemSize)&&(!extra||load(s)+x.volume<=v.cargoVolume+1e-8)&&(v.id!=='mustang'||x.length<=1.2&&x.weight<=35&&x.volume<=.30);}
 function canSwitch(s,v){return (!Abyss.WeaponData.weapons.find(w=>w.id===s.hunt.equippedWeapon)||fits(s,Abyss.WeaponData.weapons.find(w=>w.id===s.hunt.equippedWeapon),v,false))&&load(s)<=v.cargoVolume+1e-8&&s.road.cabinet.every(id=>fits(s,Abyss.Bedroom.get(id),v,false))&&s.road.relics.filter(i=>i.status==='keep'&&i.onboard!==false).every(i=>fits(s,Abyss.RoadRewards.relics.find(d=>d.id===i.id),v,false));}
 return {spec,load,fits,canSwitch,ranks};
})();
