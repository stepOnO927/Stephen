 'use strict';
Abyss.RoadMap=(()=>{
 const D=Abyss.RoadData;
 function create(id){const place=D.locations.find(l=>l.id===id)||D.locations[5],width=Abyss.RoadLayouts[id]?.width||Math.max(64,place.rooms.length*13+12),height=24,tiles=Array.from({length:height},()=>Array(width).fill(0)),objects=[],enemies=[];
 for(let x=0;x<width;x++){tiles[20][x]=1;tiles[21][x]=1;tiles[22][x]=1;tiles[23][x]=1;}for(let y=0;y<20;y++){tiles[y][0]=1;tiles[y][width-1]=1;}
 for(let x=6;x<width-4;x+=5){const y=17-((Math.floor((x-6)/5))%5)*3;for(let j=0;j<4;j++)tiles[y][x+j]=2;}
 const plan=Abyss.RoadLayouts[id];if(plan){for(let y=0;y<20;y++)for(let x=1;x<width-1;x++)tiles[y][x]=0;for(const [x,y,n]of plan.platforms)for(let i=0;i<n;i++)tiles[y][x+i]=2;for(const [x,y,w,h]of plan.blocks)for(let i=0;i<w;i++)for(let j=0;j<h;j++)tiles[y+j][x+i]=1;}
 place.rooms.forEach((name,i)=>{const x=9+i*13;objects.push({id:'chest_'+i,kind:'chest',x,y:19,name,loot:'resources'});objects.push({id:'door_'+i,kind:'door',x:x+3,y:19,locked:i>0});objects.push({id:'lore_'+i,kind:'lore',x:x+7,y:16,name});if(i>0)enemies.push({id:'enemy_'+i,x:x+5,y:19,hp:20+place.tier*18,damage:2+place.tier,kind:['drone','raider','mutant'][i%3]});});
 objects.push({id:'exit',kind:'exit',x:3,y:19},{id:'hidden',kind:'hidden',x:width-7,y:7,loot:'cosmetic'},{id:'cache',kind:'cache',x:width-7,y:19,loot:'relic'},{id:'boss',kind:'boss',x:width-14,y:19,loot:'cosmetic'});if(place.tier>=3)enemies.push({id:'boss_guard',x:width-17,y:19,hp:55+place.tier*25,damage:4+place.tier,kind:'sentinel'});
 for(const o of objects.filter(o=>o.kind==='lore'))for(let x=o.x-2;x<=o.x+2;x++)tiles[17][x]=2;for(let i=0;i<4;i++)for(let j=0;j<4;j++)tiles[17-i*3][width-27+i*5+j]=2;
 if(place.safe){enemies.length=0;for(const o of objects){if(o.kind==='door')o.locked=false;else if(o.kind!=='exit')o.kind='scenery';}}return {width,height,tiles,objects,enemies,place};
 }
 function solid(layout,x,y){return x<0||x>=layout.width||y<0||y>=layout.height||y>=0&&layout.tiles[Math.floor(y)]?.[Math.floor(x)]===1;}
 function support(layout,x,y,oldBottom){const v=layout.tiles[Math.floor(y)]?.[Math.floor(x)];return v===1||v===2&&oldBottom<=Math.floor(y)+.05;}
 function step(m,input,dt=.1){const l=create(m.place),grounded=support(l,m.x-.2,m.y+.76,m.y+.7)||support(l,m.x+.2,m.y+.76,m.y+.7);m.vx=(input.left?-1:0)+(input.right?1:0);m.vx*=4.6;if(m.vx)m.facing=Math.sign(m.vx);if(input.jump&&grounded)m.vy=-11.8;m.vy=Math.min(18,m.vy+22*dt);
 const nextX=m.x+m.vx*dt,blockedDoor=l.objects.some(o=>o.kind==='door'&&!m.opened.includes(o.id)&&Math.min(m.x,nextX)-.25<o.x&&Math.max(m.x,nextX)+.25>o.x);if(!blockedDoor&&!solid(l,nextX+Math.sign(m.vx)*.28,m.y)&&!solid(l,nextX+Math.sign(m.vx)*.28,m.y+.6))m.x=nextX;const nextY=m.y+m.vy*dt;if(m.vy>=0&&(support(l,m.x-.22,nextY+.75,m.y+.75)||support(l,m.x+.22,nextY+.75,m.y+.75))){m.y=Math.floor(nextY+.75)-.75;m.vy=0;}else if(m.vy<0&&(solid(l,m.x,nextY-.7))){m.vy=0;}else m.y=nextY;
 m.x=Abyss.Util.clamp(m.x,1,l.width-2);m.y=Abyss.Util.clamp(m.y,.8,19.25);m.cooldown=Math.max(0,m.cooldown-dt);m.reload=Math.max(0,m.reload-dt);m.lastHit=Math.max(0,m.lastHit-dt);m.elapsed+=dt;m.effects=m.effects.filter(f=>(f.life-=dt)>0);if(m.reload===0&&m.reloading){m.ammo=8;m.reloading=false;}return l;
 }
 function near(m,o,range=1.9){return Math.hypot(m.x-o.x,m.y-o.y)<range;}
 return {create,step,near,solid};
})();
