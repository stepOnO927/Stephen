
'use strict';
// Navigation geometry is independent of rendering and gameplay transactions.
Abyss.RoadNetwork=(()=>{
 const points=Abyss.RoadData.locations, byId=Object.fromEntries(points.map(p=>[p.id,p]));
 const bounds={minX:-6,maxX:8,minY:-7,maxY:7}, edges=[], seen=new Set();
 function add(a,b){const key=[a.id,b.id].sort().join(':');if(a===b||seen.has(key))return;seen.add(key);edges.push({a:a.id,b:b.id,length:Math.hypot(a.x-b.x,a.y-b.y)*1.4});}
 // Each tier connects to an already reachable, equally or less hazardous node.
 const connected=[byId.lab];
 for(const p of points.filter(p=>p.id!=='lab').sort((a,b)=>a.tier-b.tier)){add(p,connected.slice().sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))[0]);connected.push(p);}
 // Regional loops and bypasses create alternatives rather than a single tree.
 for(const p of points)for(const q of points.filter(q=>q!==p&&Math.hypot(p.x-q.x,p.y-q.y)<=2.6).sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y)).slice(0,3))add(p,q);
 function route(from,to,tier=5,state=null,vehicle=null,force=false){if(!byId[from]||!byId[to])return null;const dist={[from]:0},prev={},todo=new Set(points.filter(p=>p.tier<=tier||p.id===from).map(p=>p.id));
 while(todo.size){const id=[...todo].sort((a,b)=>(dist[a]??Infinity)-(dist[b]??Infinity))[0];if(!Number.isFinite(dist[id]))break;todo.delete(id);if(id===to)break;for(const edge of edges){if(state&&vehicle&&!Abyss.Climate.passable(state,edge,vehicle,force))continue;const next=edge.a===id?edge.b:edge.b===id?edge.a:null;if(!todo.has(next))continue;const condition=state?Abyss.Climate.road(state,edge).id:'clear';const value=dist[id]+edge.length*(condition==='clear'?1:1.5)*(state&&[edge.a,edge.b].some(id=>Abyss.Outbreaks?.risk(state,id).some(r=>r.risk==='HIGH'))?1.15:1);if(value<(dist[next]??Infinity)){dist[next]=value;prev[next]=id;}}}
 if(!Number.isFinite(dist[to]))return null;const ids=[to];while(ids[0]!==from)ids.unshift(prev[ids[0]]);return {ids,length:dist[to]};}
 function valid(ids,from,to){return Array.isArray(ids)&&ids.length>1&&ids.length<=points.length&&ids[0]===from&&ids.at(-1)===to&&ids.every((id,i)=>byId[id]&&(!i||seen.has([ids[i-1],id].sort().join(':'))));}
 function pose(r){const ids=r.target&&r.target!==r.location?(valid(r.route,r.location,r.target)?r.route:route(r.location,r.target)?.ids):null;
 if(!ids){const p=byId[r.location]||byId.lab;return {x:p.x,y:p.y,heading:0};}
 const lengths=ids.slice(1).map((id,i)=>Math.hypot(byId[id].x-byId[ids[i]].x,byId[id].y-byId[ids[i]].y));const total=lengths.reduce((a,b)=>a+b,0);let remaining=Math.min(1,Math.max(0,r.distance/Math.max(.001,r.routeLength)))*total;
 for(let i=0;i<lengths.length;i++){if(remaining<=lengths[i]||i===lengths.length-1){const a=byId[ids[i]],b=byId[ids[i+1]],f=Math.min(1,remaining/lengths[i]),heading=Math.atan2(b.y-a.y,b.x-a.x),offset=(r.lane||0)*.055*Math.sin(Math.PI*f);return {x:Math.max(bounds.minX,Math.min(bounds.maxX,a.x+(b.x-a.x)*f-Math.sin(heading)*offset)),y:Math.max(bounds.minY,Math.min(bounds.maxY,a.y+(b.y-a.y)*f+Math.cos(heading)*offset)),heading};}remaining-=lengths[i];}}
 return {edges,bounds,route,valid,pose};
})();
