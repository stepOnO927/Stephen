
'use strict';
// Visual interpolation only. Never advances simulation, RNG or saves.
Abyss.RoadMotion=(()=>{
 function create(){let source=null,target=null,start=0,signature='';
 const lerp=(a,b,t)=>a+(b-a)*t;
 function sample(now){if(!target||!source)return target;const t=Math.min(1,Math.max(0,(now-start)/100)),a=source.road,b=target.road,r={...b};for(const k of ['distance','lane','speed'])r[k]=lerp(a[k],b[k],t);r.interior={...b.interior};for(const k of ['x','z','yaw'])r.interior[k]=lerp(a.interior[k],b.interior[k],t);if(a.mission&&b.mission){r.mission={...b.mission,x:lerp(a.mission.x,b.mission.x,t),y:lerp(a.mission.y,b.mission.y,t)};}return {...target,road:r};}
 function push(s,now){const r=s.road,stamp=[r.mode,r.vehicle,r.location,r.target,r.distance,r.lane,r.speed,r.interior.x,r.interior.z,r.interior.yaw,r.mission?.x,r.mission?.y].join(':');if(stamp===signature){target=s;return;}const current=sample(now);source=current&&current.road.mode===r.mode&&current.road.vehicle===r.vehicle&&current.road.location===r.location?current:s;target=s;start=now;signature=stamp;}
 return {push,sample};}
 return {create};
})();
