
'use strict';
// Replaceable pixel-room art. Room purpose selects fixtures; biome selects materials.
Abyss.RoadSiteArt=(()=>{
 const themes=[[/温室|花园/,'garden'],[/牢房|禁闭|警卫/,'prison'],[/金库|保险/,'vault'],[/病房|手术|门诊|太平/,'medical'],[/服务器|控制|配电|冷却|机组|变电/,'machines'],[/武器|军械|安保/,'armory'],[/档案|资料|观察|权限|记录/,'archive'],[/广播|信号|演播|新闻|化妆|道具/,'broadcast'],[/餐厅|营火|帐篷|小屋|卧室|客厅|居所/,'living'],[/商|市场|集市|便利|柜台/,'market'],[/维修|工场|车间|炉|油泵|车场|停车|货运/,'workshop'],[/塔|屋顶|海岸|围墙|边境|裂隙|雪坡|营/,'exterior']];
 const theme=name=>themes.find(([re])=>re.test(name))?.[1]||'archive';
 const palette={snow:['#647880','#364b56','#c5d8d5'],desert:['#786a53','#423f37','#d2c19a'],forest:['#506a55','#293e38','#b0c3a0'],city:['#58686b','#293a42','#bdc8b8'],industrial:['#746658','#343d3c','#d2b880'],anomaly:['#635972','#292c40','#b1a3cd'],coast:['#526d73','#2e454b','#b8d1c6'],swamp:['#4d6258','#2c3d36','#a7be9a'],central:['#576f67','#2c4140','#b5cabe']};
 function room(c,l,i,tile,x,y,time){const name=l.place.rooms[i],kind=theme(name),P=palette[l.place.biome],X=x(5+i*13),Y=y(3),W=13*tile,H=17*tile,unit=tile/24;
 c.save();c.translate(Math.round(X),Math.round(Y));c.scale(unit,unit);
 const rect=(x,y,w,h,color)=>{c.fillStyle=color;c.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));},line=(x,y,w,color)=>rect(x,y,w,2,color);
 rect(0,0,312,408,P[1]);rect(8,10,296,382,P[0]);for(let n=0;n<8;n++){line(9,35+n*43,294,'#192c293b');rect(25+(i*23+n*37)%240,40+n*43,38,2,'#d7cfaa18');}
 rect(0,0,312,13,'#172c30');rect(0,12,10,396,'#1f3337');rect(302,12,10,396,'#172c30');rect(8,389,296,19,'#1d3030');for(let j=0;j<8;j++){rect(13+j*37,391,35,13,j%2?'#626d5c':'#515f55');line(13+j*37,392,35,'#9da89055');}
 rect(110,15,88,7,'#233b3b');rect(114,17,80,3,P[2]);rect(145,22,22,42,'#cbc7a30b');
 const table=(xx,yy,w=75)=>{rect(xx,yy,w,8,'#a59474');rect(xx,yy+8,w,5,'#605a48');rect(xx+5,yy+13,6,54,'#333f38');rect(xx+w-11,yy+13,6,54,'#333f38');};
 const monitor=(xx,yy)=>{rect(xx,yy,42,31,'#243b41');rect(xx+4,yy+4,34,22,'#77a6a0');line(xx+7,yy+9,22,'#bdd2ba');line(xx+7,yy+15,16,'#a5c0ad');rect(xx+18,yy+31,6,8,'#333e3f');};
 const shelf=(xx,yy,w=67)=>{rect(xx,yy,w,104,'#253b3a');for(let k=0;k<3;k++){rect(xx+4,yy+8+k*30,w-8,22,'#344d44');for(let j=0;j<4;j++)rect(xx+7+j*13,yy+12+k*30,8,17,['#91816a','#b0a68b','#6b8d84','#827991'][(j+k+i)%4]);line(xx,yy+34+k*30,w,'#a69a77');}};
 const window=(xx,yy)=>{rect(xx,yy,78,65,'#233a42');rect(xx+4,yy+4,70,57,l.place.biome==='snow'?'#97b1b5':'#789899');rect(xx+4,yy+38,70,23,l.place.biome==='desert'?'#a49571':'#526c5b');rect(xx+36,yy+4,4,57,'#405654');line(xx+4,yy+30,70,'#405654');};
 if(kind==='garden'){window(20,56);for(let n=0;n<4;n++){table(20+n*65,329,48);rect(25+n*65,301,36,28,'#887255');rect(40+n*65,273-n%2*17,5,33+n%2*17,'#6d9a64');rect(28+n*65,278-n%2*17,17,9,'#95ad73');rect(44+n*65,289,14,10,'#6e955f');}line(15,173,280,'#93947a');}
 else if(kind==='prison'){rect(21,55,168,218,'#293b43');for(let n=0;n<9;n++)rect(27+n*18,56,4,216,'#9ba69d');rect(20,267,170,7,'#bec2a3');rect(218,290,57,70,'#456056');rect(222,298,49,9,'#9ba591');table(26,342,78);}
 else if(kind==='vault'){rect(40,82,158,242,'#334349');rect(47,90,144,225,'#708281');rect(61,105,116,197,'#536565');rect(102,170,39,39,'#a6a994');rect(119,151,5,76,'#d0c7a5');rect(83,186,77,5,'#d0c7a5');rect(211,295,70,71,'#8d8058');rect(217,307,58,6,'#c8b17c');}
 else if(kind==='medical'){if(/门诊/.test(name)){window(20,65);table(22,324,171);monitor(46,286);rect(220,304,53,50,'#617f7c');rect(220,284,53,25,'#91aaa1');rect(233,93,29,24,'#d8d6b9');rect(247,96,3,18,'#856e68');line(237,106,20,'#856e68');}
 else if(/手术/.test(name)){rect(145,53,5,115,'#a9b8ae');rect(115,163,66,18,'#d3d7b7');rect(107,181,82,17,'#aec6bda8');rect(87,299,140,22,'#a1b8ae');rect(147,321,15,61,'#58746c');rect(118,379,74,6,'#a4afa0');monitor(30,245);table(25,276,62);rect(252,196,5,143,'#879f96');rect(241,198,24,28,'#c2cabc');}
 else if(/太平/.test(name)){for(let k=0;k<2;k++)for(let row=0;row<3;row++){rect(25+k*134,118+row*76,122,68,'#728780');rect(31+k*134,124+row*76,110,56,'#465c5b');rect(66+k*134,147+row*76,32,5,'#bbc6b7');rect(35+k*134,131+row*76,20,5,'#d2cdb3');}}
 else{window(20,65);shelf(217,174,64);rect(25,307,145,18,'#bac6bb');rect(25,325,145,33,'#597676');rect(26,296,32,12,'#e2ded0');rect(36,358,6,34,'#324c51');rect(154,358,6,34,'#324c51');rect(181,231,5,125,'#9daaa0');rect(172,233,23,25,'#a3c7bc');}rect(135,77,33,33,'#e0d8c1');rect(149,83,6,22,'#986d67');rect(141,91,22,6,'#986d67');}
 else if(kind==='machines'){if(/控制/.test(name)){for(let k=0;k<3;k++)monitor(35+k*83,155);table(24,305,264);for(let k=0;k<12;k++)rect(35+k*21,293,12,7,k%3?'#a8b496':'#907698');rect(143,328,29,44,'#537172');}
 else if(/冷却|机组/.test(name)){for(let k=0;k<3;k++){rect(29+k*91,104,54,251,'#537a7b');rect(34+k*91,108,44,240,'#79a6a0');rect(52+k*91,84,8,22,'#bcc9b6');rect(27+k*91,355,58,23,'#344b4b');}rect(8,69,293,9,'#99af9e');rect(293,69,9,319,'#99af9e');}
 else{for(let k=0;k<4;k++){rect(20+k*70,108,57,247,'#233740');for(let row=0;row<9;row++){rect(25+k*70,116+row*25,47,18,'#42595e');rect(29+k*70,121+row*25,22,3,'#8da395');rect(60+k*70,121+row*25,4,4,(row+k)%3?'#adbb85':'#9182b2');}rect(30+k*70,355,5,34,'#30353b');}rect(7,40,298,8,'#aa9c73');rect(278,48,8,47,'#aa9c73');}}
 else if(kind==='armory'){rect(25,82,253,159,'#314640');for(let k=0;k<5;k++){rect(40+k*46,99,8,98,'#5b7274');rect(44+k*46,180,14,29,'#ab9274');rect(44+k*46,139,24,8,'#9aaba0');}shelf(30,276,70);table(150,323,120);}
 else if(kind==='broadcast'){rect(25,57,260,84,'#384d54');for(let k=0;k<3;k++)monitor(36+k*80,78);table(30,315,144);monitor(52,277);rect(208,234,5,132,'#222f36');rect(191,222,38,24,'#a0a690');rect(219,225,19,18,'#31464b');rect(193,354,35,5,'#222f36');window(207,79);}
 else if(kind==='living'){window(20,62);rect(27,317,131,37,'#7d7775');rect(23,299,139,27,'#999186');rect(30,354,6,32,'#34403b');rect(146,354,6,32,'#34403b');table(184,329,85);rect(225,216,6,114,'#c5bda0');rect(205,208,45,26,'#b8a979');rect(66,88,40,51,'#c6b593');rect(71,93,30,40,'#677e73');}
 else if(kind==='market'){shelf(23,109,67);shelf(113,109,67);table(21,320,161);rect(123,283,38,36,'#687c76');rect(128,289,28,10,'#adc3a5');rect(206,307,75,73,'#866e4f');line(206,312,75,'#c0a47a');rect(216,295,16,13,'#b8a584');rect(243,291,14,18,'#82a393');window(206,64);}
 else if(kind==='workshop'){table(20,315,178);rect(24,195,174,101,'#344544');for(let k=0;k<7;k++){rect(32+k*22,213,4,53-k%3*8,'#a9ada0');rect(27+k*22,210,14,8,'#778d86');}rect(218,270,61,113,'#87785b');line(222,295,53,'#c0aa76');rect(241,250,9,18,'#9ba79a');window(204,57);}
 else if(kind==='exterior'){rect(8,28,296,293,l.place.biome==='anomaly'?'#696578':'#8ea4a0');for(let n=0;n<5;n++)rect(16+n*60,198-(n*31+i*19)%90,58,123+(n*31+i*19)%90,P[1]);rect(12,319,288,65,'#536b62');rect(32,289,9,92,'#85988b');rect(230,276,9,105,'#85988b');line(32,288,207,'#b7bba0');}
 else {shelf(20,134,67);shelf(213,134,67);table(111,327,81);monitor(128,288);rect(121,89,61,68,'#9b9278');for(let j=0;j<4;j++)line(128,100+j*12,45,'#4c605d');}
 rect(290,365,7,7,'#a7b995');rect(13,16,45,8,'#a6af8c');c.restore();
 }
 return {room,theme};
})();
