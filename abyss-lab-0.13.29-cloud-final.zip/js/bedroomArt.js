'use strict';
// Axonometric primitives. Materials and geometry remain independent replaceable assets.
Abyss.BedroomArt=(()=>{
 const project=(x,y,z=0)=>[425+(x-y)*43,125+(x+y)*23-z*45];
 const path=(d,f,stroke='#263b42')=>`<path d="${d}" fill="${f}" stroke="${stroke}" stroke-width="1.4"/>`,line=d=>path(d,'none','#b7c2b5'),rect=(x,y,w,h,f)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="2" fill="${f}" stroke="#253940"/>`,circle=(x,y,r,f)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${f}" stroke="#455f61"/>`;
 function model(d){const v=d.variant||0,w=22+d.floorFootprint[0]*16,h=20+d.height*26,metal=['#6d8586','#7b8073','#84998b','#8496a3','#a297ac','#b4a588'][v%6],dark='#263b42',cloth=['#798b7b','#967d6c','#7e929b','#72798f','#978798','#b5a07f'][v%6],glass='#7eaaa744';
 const cube=(x,y,a,b,z)=>path(`M${x} ${y}l${a} 0 ${b} -${b*.45} -${a} 0Z`,metal)+path(`M${x+a} ${y}l${b}-${b*.45}v${z}l-${b} ${b*.45}Z`,dark)+rect(x,y,a,z,cloth);
 const legs=(y,span)=>line(`M${-span} ${y}v26M${span} ${y}v26`)+(v===3?line(`M${-span} ${y}l${span*2} 26M${span} ${y}l-${span*2} 26`):v===4?line(`M${-span} ${y+8}h${span*2}M${-span} ${y+17}h${span*2}`):v===2?line(`M${-span} ${y}q-8 11 0 26M${span} ${y}q8 11 0 26`):'');
 const panel=(y)=>v===2?path(`M-${w} ${y}Q0 ${y-28} ${w} ${y}v25H-${w}Z`,cloth):v===1?path(`M-${w} ${y+12}l13-18h${w*2-26}l13 18v13H-${w}Z`,cloth):rect(-w,y,w*2,25,cloth);
 let s='';switch(d.kind){
 case 'bed':s=cube(-w,-3,w*2,24,20)+rect(-w+5,-5,w*2-10,11,'#c4c5b0')+panel(-42-v*2)+rect(-w+10,-21,28,12,'#d2cdb8')+legs(17,w-5);break;
 case 'sofa':s=panel(-51-v*2)+cube(-w,-9,w*2,19,24)+rect(-w-5,-34,11,44,metal)+rect(w-6,-34,11,44,metal)+legs(17,w-10);break;
 case 'chair':s=panel(-h-5)+cube(-w,-10,w*2,14,9)+legs(0,w-3)+line(`M-${w} -${h}V1M${w} -${h}V1`);break;
 case 'table':case 'desk':case 'workbench':s=cube(-w,-20,w*2,21,8)+legs(-12,w-5)+(d.kind==='desk'?rect(-w+3,-12,29,24,dark)+line(`M-${w-2} -2h28`):d.kind==='workbench'?line(`M-${w} -23v-22h${w*2}v22`)+rect(-16,-37,32,8,metal):'');break;
 case 'cabinet':case 'trunk':s=cube(-w,-h,w*2,17,h)+Array.from({length:v===4?5:2+v%3},(_,i)=>line(`M-${w-5} ${-h+13+i*(h-20)/(v===4?5:2+v%3)}h${w*2-10}`)).join('')+rect(-5,-h/2,10,4,'#d8d0ab');break;
 case 'shelf':s=rect(-w,-h,w*2,h,metal)+rect(-w+5,-h+5,w*2-10,h-10,dark)+Array.from({length:2+v},(_,i)=>rect(-w+4,-h+18+i*(h-25)/(2+v),w*2-8,3,metal)).join('')+line(`M0 -${h}V0`);break;
 case 'lamp':case 'floorlamp':s=line(`M0 -${h}V0`)+path(v===2?`M-24 -${h-15}Q0 -${h+33} 24 -${h-15}Z`:`M-15 -${h+16}h30l14 32h-58Z`,cloth)+path('M-20 3Q0-10 20 3Z',metal)+circle(0,-h,5,'#e2d0a066');break;
 case 'rug':s=path(`M-${w} -6l${w*2} 0 22 14-${w*2} 0Z`,cloth)+Array.from({length:v+2},(_,i)=>line(`M${-w+7+i*9}-3l18 11`)).join('');break;
 case 'plant':s=path('M-20-18h40l-7 25h-26Z',cloth)+line(`M0-18V-${h}`)+Array.from({length:3+v},(_,i)=>path(`M0-${24+i*7}q${(i%2?1:-1)*30}-20 ${(i%2?1:-1)*26} 0q-15 8-${(i%2?1:-1)*26} 0`,'#779570')).join('');break;
 case 'clock':s=circle(0,-20,30+v,metal)+circle(0,-20,25+v,'#1d3037')+line('M0-38V-20L14-13')+(v===3?rect(-7,10,14,26,metal):'');break;
 case 'painting':s=rect(-w,-h,w*2,h,metal)+rect(-w+5,-h+5,w*2-10,h-10,'#344d53')+path(`M-${w-5}-8L-${w-12}-${h/2}L0-${h/3}L${w-5}-${h*.7}V-8Z`,cloth)+circle(w/3,-h*.7,6+v,'#b6c3ad');break;
 case 'screen':s=Array.from({length:3+v%3},(_,i)=>rect(-w+i*w*2/(3+v%3),-h,w*2/(3+v%3)-2,h,cloth)).join('')+line(`M-${w} -${h/3}h${w*2}`);break;
 case 'bench':s=cube(-w,-17,w*2,15,6)+legs(-10,w-7);break;
 case 'radio':s=cube(-w,-h,w*2,9,h)+circle(w*.5,-h*.35,8,metal)+Array.from({length:3+v},(_,i)=>line(`M-${w-7} -${h-7+i*5}h${w}`)).join('')+line(`M${w*.5}-${h}V-${h+20}`);break;
 case 'toy':s=circle(-14,-4,11,metal)+circle(14,-4,11,metal)+rect(-23,-29,46,20,cloth)+path('M-11-29v-18h19l13 18Z',cloth);break;
 case 'bowl':case 'vase':s=path(d.kind==='vase'?`M-${9+v}-${h}h${18+v*2}v${14-v}l${13+v*2} ${20+v*2}v${h-28}h-${44+v*6}v-${h-28}l${13+v*2}-${20+v*2}Z`:'M-28-12Q0 0 28-12Q23 22 0 22Q-23 22-28-12Z',d.kind==='vase'?glass:cloth)+line('M-20-8Q0 1 20-8');break;
 case 'basket':s=path(`M-${w}-18Q0-2 ${w}-18L${w-8} 10H-${w-8}Z`,cloth)+Array.from({length:4+v},(_,i)=>line(`M${-w+8+i*9}-12v20`)).join('')+path('M-17-10Q0-22 17-10Z','#c2b69b');break;
 case 'tank':s=cube(-w,-h,w*2,18,h)+rect(-w+4,-h+5,w*2-8,h-10,glass)+path(`M-${w-9}-8l15-17 20 10 15-19 15 26Z`,'#688774')+path('M-10-28q15-18 28 0q-14 18-28 0l-8-8v16Z','#9caea0');break;
 case 'mirror':s=v===2?`<ellipse cy="-${h/2}" rx="${w}" ry="${h/2}" fill="${glass}" stroke="${metal}" stroke-width="5"/>`:rect(-w,-h,w*2,h,metal)+rect(-w+5,-h+5,w*2-10,h-10,glass);s+=line(`M-${w-8}-12L${w-8}-${h-12}`);break;
 case 'mobile':s=line('M0-60V-20M-30-20H30M-23-20V7M23-20V0')+circle(-23,9,8,cloth)+path('M23-11L34 2 23 15 12 2Z',metal)+circle(0,-26,5,'#bbc4b2');break;
 default: {
 const mapping={signal:'radio',book:'book',key:'key',bell:'lamp',camera:'camera',box:'box',coin:'badge',glass:'glass',skull:'sculpture'};
 const art=Abyss.SalvageArt.draw({category:'SALVAGE',visual:{kind:mapping[d.kind]||'mechanism',variant:v%5}},{fill:cloth,metal,light:'#bdc9ba',dark,glass});s=`<g transform="translate(-42 -35) scale(.5)">${art}</g>`;
 if(d.id==='object_silver_skull')s=path('M-25-28Q-32-60 0-60Q32-60 25-28L15-10V4H-15V-10Z',metal)+path('M-20-40L-4-34-9-24-21-25Z','#79b65b')+path('M20-40L4-34 9-24 21-25Z','#79b65b')+line('M-12-6V3M-4-6V3M4-6V3M12-6V3');
 }}
 // Each construction changes geometry: folded gussets, arches, braces, open lattice or carving.
 if(v===1)s+=path(`M-${w} -${h*.3}l9-12v18Z`,metal)+path(`M${w} -${h*.3}l-9-12v18Z`,metal);
 if(v===2)s+=line(`M-${w*.6} -${h*.5}Q0 -${h*.9} ${w*.6} -${h*.5}`);
 if(v===3)s+=line(`M-${w*.55} -${h*.7}L${w*.55} -${h*.25}M${w*.55} -${h*.7}L-${w*.55} -${h*.25}`);
 if(v===4)s+=Array.from({length:5},(_,i)=>line(`M${-w*.6+i*w*.3} -${h*.7}V-${h*.25}`)).join('');
 if(v===5)s+=line(`M-${w*.7}-8Q0-20 ${w*.7}-8M-${w*.6}-12Q0-28 ${w*.6}-12`);return s;
 }
 function item(p,all){const source=Abyss.Bedroom.get(p.id),d={...source,floorFootprint:p.rotation%180?[source.floorFootprint[1],source.floorFootprint[0]]:source.floorFootprint};let z=d.placementType==='wall'?2.3:d.placementType==='ceiling'?3:0;if(p.support)z=Abyss.Bedroom.get(all.find(a=>a.uid===p.support)?.id)?.supportHeight||0;const [x,y]=project(p.x,p.y,z);return `<g class="bedroom-object" data-room-uid="${Abyss.Util.escape(p.uid)}" transform="translate(${x} ${y})"><ellipse cy="6" rx="${20+d.floorFootprint[0]*12}" ry="9" fill="#0006"/><rect x="${-35-d.floorFootprint[0]*16}" y="${-40-d.height*26}" width="${70+d.floorFootprint[0]*32}" height="${60+d.height*26}" fill="transparent" pointer-events="all"/>${model(d)}<title>${Abyss.Util.escape(d.name)}</title></g>`;}
 function render(s,placed=s.bedroom.placed){const active=s.pets.filter(p=>p.active&&p.alive&&!p.escaped&&p.room==='quarters');return `<svg id="bedroom-canvas" viewBox="0 0 850 580" role="img" aria-label="Bedroom layout"><defs><linearGradient id="bedroom-wall" x2="0" y2="1"><stop stop-color="#33464e"/><stop offset="1" stop-color="#1b2c35"/></linearGradient></defs>${path('M81 324V110L425 0 769 110V324L425 508Z','url(#bedroom-wall)')}${path('M81 324L425 140 769 324 425 508Z','#22343b')}${Array.from({length:9},(_,i)=>{const a=project(i,0),b=project(i,8),c=project(0,i),d=project(8,i);return path(`M${a}L${b}M${c}L${d}`,'none','#405158');}).join('')}${path('M296 439L382 485 468 439 382 393Z','#64756633','#97aaa366')}${[...placed].sort((a,b)=>(a.x+a.y)-(b.x+b.y)).map(p=>item(p,placed)).join('')}${active.map((p,i)=>{const [x,y]=project(3+i*.8,5.5);return `<g transform="translate(${x} ${y})">${pet(p)}<title>${Abyss.Util.escape(p.name)}</title></g>`;}).join('')}<text x="425" y="553" text-anchor="middle" fill="#94aaa8" font-family="monospace" font-size="11">JACK / QUARTERS · KEEP THE DOORWAY CLEAR</text></svg>`;}
 function pet(p){const d=Abyss.ContainmentData.species.find(s=>s.id===p.species),color=['#99aaa2','#8090a7','#bda985','#8eaa81','#9b849e'][p.petSeed%5];const shape={mouse:()=>`<ellipse cy="-7" rx="16" ry="10" fill="${color}"/>`+circle(8,-16,7,color)+line('M-14-8q-22-13-19 9'),cat:()=>path('M-16 0Q-23-22-7-29L-8-40 3-32 15-41 17-25Q31-7 17 0Z',color)+line('M-14-4q-26-5-24-25'),moth:()=>path('M0-12Q-42-53-37-6Q-22 16 0-6Q42-53 37-6Q22 16 0-6Z',color)+line('M0-27V4'),frog:()=>path('M-19 1Q-31-25 0-25Q31-25 19 1Z',color)+circle(-13,-23,7,color)+circle(13,-23,7,color),bird:()=>path('M-19-4Q-25-30 3-28Q26-29 18-7L31-12 20 0H-13Z',color)+line('M-8 0v7M8 0v7'),drone:()=>rect(-14,-21,28,17,color)+line('M-31-26h62M-22-26v12M22-26v12'),fungus:()=>path('M-29-17Q0-58 29-17Z',color)+rect(-8,-17,16,20,'#b9c0a8'),fish:()=>path('M-23-8Q0-35 23-8Q0 19-23-8L-37-21V4Z',color),lizard:()=>path('M-25 0Q-31-15 10-17L25-12 14-5-11 0Q-39 16-42-8Z',color)+line('M-11-1l-10 7M8-7l8 10'),hound:()=>path('M-24 0V-16L-16-27 3-28 19-37 30-19 15-7 9 0Z',color)+line('M-23-16l-16-8'),echo:()=>path('M-24 0Q-35-26 0-45Q35-26 24 0Q0-14-24 0Z','#91acbc66'),beetle:()=>path('M0-29Q-21-31-22-7Q0 17 22-7Q21-31 0-29Z',color)+line('M0-28V9M-18-20l-12-7m12 18-15 1M18-20l12-7m-12 18 15 1')};return '<ellipse rx="24" ry="5" fill="#0006"/>'+shape[p.species]()+circle(6,-17,2,'#101e25');}
 return {project,model,render,pet};
})();


