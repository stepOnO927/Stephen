'use strict';
// Independent content preference: changing intensity never touches game state or RNG.
Abyss.StoryPresentation=(()=>{const key='abyss-lab-text-intensity-v1';let value='mild';try{const saved=localStorage.getItem(key);if(['clean','mild','full'].includes(saved))value=saved;}catch{}
 function set(next){if(!['clean','mild','full'].includes(next))return;value=next;try{localStorage.setItem(key,value);}catch{}if(typeof document!=='undefined')document.dispatchEvent(new CustomEvent('abyss:wording'));}
 function wording(text){return Abyss.JackData?.wording?.get(text)?.[value]||text.replace(/\bMia\b/g,'Jasmine').replace(/\bMIA\b/g,'JASMINE');}
 return {wording,intensity:()=>value,set};})();
