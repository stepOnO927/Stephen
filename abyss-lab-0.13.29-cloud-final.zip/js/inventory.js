'use strict';
Abyss.Inventory=(()=>{
 function grantItem(s,id,quantity=1,source='外部奖励'){
  const item=Abyss.ExpeditionData.loot.find(i=>i.id===id)||Abyss.Data.foods.find(i=>i.id===id);if(!item||!Number.isInteger(quantity)||quantity<1||quantity>10000)throw Error('无效物资');
  const x=Abyss.ExpeditionState.ensure(s),old=x.items[id];
  s.inventory[id]=Math.min(10000000,(s.inventory[id]||0)+quantity);
  x.items[id]={source:String(source).slice(0,80),day:s.day,date:new Date().toISOString(),identified:old?.identified??item.category!=='UNKNOWN OBJECT',discovered:true};
  return x.items[id];
 }
 function consumeItem(s,id,quantity=1){Abyss.ExpeditionState.ensure(s);if(!Number.isInteger(quantity)||quantity<1||(s.inventory[id]||0)<quantity)return false;s.inventory[id]-=quantity;return true;}
 function list(s){const x=Abyss.ExpeditionState.ensure(s);return [
  ...Abyss.ExpeditionData.loot.map(item=>({...item,rarity:Abyss.Rarity.id(item.rarity),quantity:s.inventory[item.id]||0,...x.items[item.id]})),
  ...Abyss.Data.foods.map(item=>({id:item.id,name:item.name,description:item.desc,category:'FOOD',rarity:'COMMON',food:item.id,quantity:s.inventory[item.id]||0,day:s.day,date:'',source:'实验室库存',identified:true,discovered:true}))
 ];}
 return {grantItem,consumeItem,list,identifyItem(s,id){const r=Abyss.ExpeditionState.ensure(s).items[id];if(r)r.identified=true;}};
})();
