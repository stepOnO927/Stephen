# 0.13.22 导航固定补漏

修改：navigation.css、index.source.html、package.json、js/data/updateLog.js、CHANGELOG.md、构建后的index.html；新增tests/navigation-rails-browser.cjs。

左侧菜单固定外框、独立列表滚动及固定搜索/折叠入口。补齐9类模块的分类条，衣橱部位栏sticky；远征独立终端设置正文滚动。只固定导航条，新闻事件行动按钮继续跟随所属卡片。

隔离新档真实Chrome测试：1366×900、1024×768、768×1024、390×640、1024×500，45组模块检查通过。桌面/iPad/手机滚动后菜单外框坐标不变，搜索留在视口，分类不滚出正文容器，正文高度>80px，无页面脚本错误。另4宽度中英文HUD回归通过。

公开提交4a3028d875cd960bc9cb725e96ccb6b54ebbceee。后续以Pages部署和公网复测结果为准。未读取玩家存档或密钥。

公开验证完成：Pages #74 Success，39秒，https://github.com/stepOnO927/Stephen/actions/runs/37685579666 。公网重新运行5尺寸×9模块的45组测试全部通过；本地Story烟雾测试通过，普通HUD隐藏。发布截图verification/release-0.13.22-deploy.jpg。公开上传仅index.html与CHANGELOG.md；历史扩展不计入本轮完成。
