# Phase 2 · Accessory collection and creature customization

This feature set is included in the unified schema v3 game. It retains 50 accessories across seven slots, a wardrobe, accessory archive, five outfit presets, hidden outfit sets, personality, structured memories, and occasional creature reactions.

New saves use the unified `abyss-lab-save-v1` key. Legacy version 2 accessory saves migrate while retaining owned items, equipped slots, presets, personality, memories, and favorite food. Accessory ownership and equipment remain in `s.collection`; they share the canonical save with exploration, whose item counts are stored in the common inventory map.

Run `node tests/accessories.test.cjs` to check the accessory and migration behavior. Rebuild the portable page with `node tools/build-local.cjs` after source changes.
