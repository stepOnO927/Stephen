# 独立新闻第一批 — 0.13.3-preview

## 已完成

共15条独立流程，对应原主题1–15。四阶段：初报、回应后等待、复查回应、下一日结案。各自有中英文文本、独立来源与选项；无随机抽取奖励、无打开页面触发、无剧情模式养成操作。

真实影响：实验室→聚落水/药/燃料/食物转移；医疗队请求沿原路运输；电网材料修补；动物隔离和压力；害虫/土壤/污染治理；指定品种种子召回；单个标记污染批次销毁；指定原路况修复。阈值和成本由数据提供。回应不直接清除疫情或病例。

## 修改文件

新增 js/greenhouse/newsChainsData.js（内容）和 newsChains.js（状态机）；扩展 news.js（CHAINS页）、medicine.js（子存档）、state.js（批次标记）、engine.js（事务入口）、index.source.html（加载）、更新日志及测试。

## 存档

infirmary.newsChains.version=1，records记录number/place/source/road/plant/batch/batchDay/started/due/deadline/status/first/final/closedDay/journal；最多15条，按主题去重，未知ID/状态拒绝。缺少子状态的旧档为空，不追溯历史、不补扣旧日资源。库存只给污染目标批次附加newsChainId，其余字段保留。

## 验证

news-chains.test.cjs：15主题的60组合、跨日、存读档、重复回应、过期一次性后果、失败事务、材料不足、原路况已变化、同日另一批次保护、旧档与剧情隔离。
news-chains-browser.cjs：实际按钮，物资扣除，等待/复查/结案，刷新恢复，中英文、三种屏幕宽度和零脚本错误。
相关回归：news-state、medical-relief、clinical-behavior、illness、outbreaks、greenhouse、save-weapons2、story-rework、integration-flow。

## 限制

本批覆盖15/90。未把主题目录计入独立链。没有新增虚构医生、未经证实的死亡或水源污染确诊；饮水事件是储水短缺与当地病例同时出现的复查。原地图缺独立桥梁结构，本轮塌陷链绑定真实塌陷路段；隧道链绑定metro/deep真实封路。新闻不覆盖原天气、病例或道路的继续变化。正式配音未制作。

发布时间和公网验收见报告后续记录。

## 发布验证
GitHub Pages Run 49成功（30秒）：https://github.com/stepOnO927/Stephen/actions/runs/37408054362 。公开网页在隔离浏览器通过实际选择、物资扣除、跨日跟进、结案、刷新、中英文及1366/768/390宽度；无页面错误。截图：verification/news-chains-public-desktop.png。相关11组回归退出0，记录verification/news-chains-regression.txt。

最终显示修正：结案卡片显示真实closedDay，修正后Run50成功（32秒）：https://github.com/stepOnO927/Stephen/actions/runs/37408352419 。公网浏览器包含Closed on: D4断言并通过；截图已更新。
